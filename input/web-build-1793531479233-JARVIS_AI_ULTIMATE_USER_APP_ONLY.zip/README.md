# JARVIS AI - User Android App

This archive contains ONLY the user-facing Android app module (`:app`). The admin module is intentionally excluded.

Build task: `:app:assembleDebug` (or `assembleDebug` in this single-module project).

Android application ID: `com.jarvis.ai`

AndroidForge should build the app module / debug APK.
