# JARVIS 2.3.0 — AndroidForge source ZIP

This archive is an Android source project for AndroidForge. It is **not an APK** and intentionally contains no prebuilt APK. Build it on AndroidForge.

## Current phase
- Chat UI with black / violet palette and a native Android file picker.
- File picker supports multiple files and rejects APK files.
- On-device text extraction: PDF, DOCX, PPTX, XLSX/XLSM, ODT/ODS/ODP, TXT, MD, CSV/TSV, JSON, XML, HTML, JS, CSS, LOG, YAML, INI and basic RTF. Extracted text is capped at 40,000 characters per file; individual input files are capped at 12 MB.
- Images are attached as image data for model vision. Other binary formats may be attached as metadata only; audio/video transcription and legacy binary Office formats (.doc/.xls/.ppt) are not implemented yet.
- Web search and page reading can be chained for multi-step research (up to 10 tool calls per answer). The visible activity timeline reflects actual search/fetch calls, not simulated actions.
- Old video splash is bypassed; app opens directly to chat.

## Build
Open the ZIP in AndroidForge and let it detect the Gradle project. AndroidForge may regenerate the Gradle wrapper if required. Use the existing debug signing key in `app/jarvis-debug.keystore` to preserve the configured Google OAuth SHA-1 for personal test builds.

## Important limitations
- This archive has not been built into an APK or device-tested in this environment. PDFBox and Android dependencies must resolve during AndroidForge's build.
- This is not yet a complete autonomous agent: browser access depends on reachable public pages; authentication, CAPTCHA, robots restrictions, unsupported formats and server/provider limits still apply. No claim is made that it can bypass them.
- The exact previously supplied G logo image was not present in the recovered source or accessible image library, so the current launcher icon has deliberately not been replaced with an invented approximation. Supply that exact image in a later turn when uploads are available.


## WhatsApp (Android notification integration)
This source includes `MessageNotificationService`, a NotificationListenerService that records recent WhatsApp notification previews and uses Android RemoteInput only when WhatsApp exposes a reply action. The app adds a WhatsApp panel for granting notification access, selecting a phone contact, opening a chat with prefilled text, and replying to recent notifications.

Important limits:
- It cannot read WhatsApp's private full chat database, enumerate all WhatsApp chats, or retrieve the entire message history. Android app sandboxing and WhatsApp encryption prevent this.
- Notification previews are only new messages delivered by Android; muted/hidden/disabled notifications are not visible.
- RemoteInput reply works only while the corresponding notification action is still valid and exposes free-form input.
- Opening a chat with a phone contact pre-fills a message; the user taps Send in WhatsApp.
- This phase does not silently auto-reply or send arbitrary messages in the background. That needs explicit user-controlled rules and real-device testing.
