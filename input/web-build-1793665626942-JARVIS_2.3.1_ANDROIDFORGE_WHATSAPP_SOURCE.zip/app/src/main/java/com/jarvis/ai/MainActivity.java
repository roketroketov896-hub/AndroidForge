package com.jarvis.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.provider.ContactsContract;
import android.util.Base64;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.Map;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.view.SurfaceHolder;
import android.view.WindowManager;
import android.view.SurfaceView;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Окно приложения. Порядок запуска:
 * Приложение сразу открывает WebView-чат; сетевые и голосовые компоненты готовятся в фоне.
 * Сервер и ИИ-провайдер на готовность интерфейса не влияют.
 */
public class MainActivity extends Activity implements Emitter {
    static final int REQ_AUDIO = 701;
    static final int REQ_PROJECTION = 702;
    static final int REQ_NOTIF = 703;
    static final int REQ_FILES = 704;
    static final int REQ_CONTACT = 705;

    /** Заставка играет один раз за запуск процесса, а не при каждом пересоздании окна. */
    private static boolean splashDoneThisProcess = false;

    WebView webView;
    JarvisSettings settings;
    SecureStore store;
    AuthManager auth;
    TtsController tts;
    OnlineTts online;
    SpeechInput speech;
    final ChatClient chat = new ChatClient();
    final ExecutorService executor = Executors.newCachedThreadPool();
    final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private FrameLayout root;
    private String pendingLang = "ru";
    private boolean pendingContinuous = false;
    private boolean servicesReady = false;

    // заставка
    private boolean splashActive = false;
    private boolean videoDone = false;
    private boolean uiReady = false;
    private boolean readyTimeout = false;
    private boolean backgroundStarted = false;
    private boolean resumed = false;
    private boolean prepared = false;
    private SurfaceView surface;
    private View cover;
    private ProgressBar spinner;
    private MediaPlayer player;

    // подготовка в фоне
    private volatile String appConfigJson = "";
    private volatile boolean serverChecked = false;
    private volatile boolean serverOk = false;
    private volatile boolean bootstrapRunning = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("jarvis_settings", MODE_PRIVATE);
        settings = new JarvisSettings(prefs);
        store = new SecureStore(prefs);
        auth = new AuthManager(prefs, store);

        getWindow().setStatusBarColor(Color.parseColor("#08070D"));
        getWindow().setNavigationBarColor(Color.parseColor("#08070D"));

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#08070D"));
        setContentView(root);

        ScreenShareService.listener = new ScreenShareService.Listener() {
            @Override
            public void onStarted() {
                emit("screen", json("state", "started"));
            }

            @Override
            public void onFrame(String dataUrl) {
                emit("screen", json("state", "frame", "image", dataUrl));
            }

            @Override
            public void onStopped(String reason) {
                emit("screen", json("state", "stopped", "reason", reason));
            }
        };

        LiveVoiceService.listener = new LiveVoiceService.Listener() {
            @Override
            public void onStopped() {
                emit("live", json("state", "stopped"));
            }
        };

        // Direct entry: the old video opening was intentionally removed.
        splashDoneThisProcess = true;
        startBackground();
    }

    // ---------- заставка ----------

    private void startSplash() {
        splashActive = true;
        surface = new SurfaceView(this);
        surface.setZOrderMediaOverlay(true);
        root.addView(surface, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        cover = new View(this);
        cover.setBackgroundColor(Color.parseColor("#05070F"));
        cover.setAlpha(0f);
        cover.setClickable(true); // не пропускает касания в WebView под заставкой
        root.addView(cover, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        surface.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                if (player == null && !videoDone) prepareVideo(holder);
                else if (player != null) player.setDisplay(holder);
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                if (player != null) {
                    try {
                        player.setDisplay(null);
                    } catch (Exception ignored) {
                    }
                }
            }
        });
    }

    private void prepareVideo(SurfaceHolder holder) {
        try {
            player = new MediaPlayer();
            AssetFileDescriptor afd = getResources().openRawResourceFd(R.raw.jarvis_splash);
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            player.setDisplay(holder);
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build());
            player.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                @Override
                public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
                    fitVideo(width, height);
                }
            });
            player.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                @Override
                public boolean onInfo(MediaPlayer mp, int what, int extra) {
                    if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) startBackground();
                    return false;
                }
            });
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    videoDone = true;
                    maybeFinishSplash();
                }
            });
            player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    // Заставка не должна блокировать приложение: пропускаем её.
                    videoDone = true;
                    startBackground();
                    maybeFinishSplash();
                    return true;
                }
            });
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    prepared = true;
                    if (resumed) mp.start();
                    main.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startBackground(); // если событие первого кадра не пришло
                        }
                    }, 700);
                }
            });
            player.prepareAsync();
        } catch (Exception e) {
            videoDone = true;
            startBackground();
            maybeFinishSplash();
        }
    }

    /** Вписывает видео в экран без растяжения и обрезки. */
    private void fitVideo(final int vw, final int vh) {
        if (vw <= 0 || vh <= 0) return;
        root.post(new Runnable() {
            @Override
            public void run() {
                int pw = root.getWidth(), ph = root.getHeight();
                if (pw <= 0 || ph <= 0 || surface == null) return;
                float scale = Math.min((float) pw / vw, (float) ph / vh);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                        Math.round(vw * scale), Math.round(vh * scale), Gravity.CENTER);
                surface.setLayoutParams(lp);
            }
        });
    }

    private void maybeFinishSplash() {
        if (!splashActive || !videoDone) return;
        if (uiReady || readyTimeout) {
            finishSplash();
            return;
        }
        // Видео закончилось, а интерфейс ещё готовится: показываем аккуратный индикатор и ждём, но не бесконечно.
        if (spinner == null) {
            spinner = new ProgressBar(this);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(96, 96, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            lp.bottomMargin = 120;
            spinner.setVisibility(View.GONE);
            root.addView(spinner, lp);
            main.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (spinner != null && splashActive) spinner.setVisibility(View.VISIBLE);
                }
            }, 400);
            main.postDelayed(new Runnable() {
                @Override
                public void run() {
                    readyTimeout = true;
                    maybeFinishSplash();
                }
            }, 8000);
        }
    }

    private void finishSplash() {
        if (!splashActive) return;
        splashActive = false;
        splashDoneThisProcess = true;
        cover.animate().alpha(1f).setDuration(160).withEndAction(new Runnable() {
            @Override
            public void run() {
                releasePlayer();
                if (surface != null) root.removeView(surface);
                if (spinner != null) root.removeView(spinner);
                surface = null;
                spinner = null;
                cover.animate().alpha(0f).setDuration(240).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        if (cover != null) root.removeView(cover);
                        cover = null;
                    }
                }).start();
            }
        }).start();
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
        }
    }

    /** Вызывается интерфейсом, когда он отрисован и история загружена. */
    void onUiReady() {
        uiReady = true;
        pushBootstrap();
        maybeFinishSplash();
    }

    // ---------- фоновая подготовка ----------

    /** Один раз: создаёт голосовые компоненты и WebView и запускает сетевую подготовку. */
    private void startBackground() {
        if (backgroundStarted) return;
        backgroundStarted = true;
        main.post(new Runnable() {
            @Override
            public void run() {
                initServices();
                createWebView();
                bootstrapAsync();
            }
        });
    }

    private void initServices() {
        if (servicesReady) return;
        servicesReady = true;
        tts = new TtsController(this, settings, this);
        speech = new SpeechInput(this, this);
        online = new OnlineTts(this, this, new OnlineTts.Source() {
            @Override
            public String baseUrl() {
                return normalizeBase(BuildConfig.BACKEND_URL);
            }

            @Override
            public String token() {
                return auth.ensureToken(MainActivity.this, BuildConfig.WEB_CLIENT_ID);
            }
        });
    }

    static String normalizeBase(String url) {
        String u = url == null ? "" : url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u.startsWith("https://") ? u : "";
    }

    boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    /** Сетевая подготовка не блокирует запуск: результат приходит в интерфейс событием. */
    void bootstrapAsync() {
        if (bootstrapRunning) return;
        bootstrapRunning = true;
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String base = normalizeBase(BuildConfig.BACKEND_URL);
                    if (!base.isEmpty()) {
                        try {
                            ChatClient.Result r = ChatClient.request("GET", base + "/v1/app-config", null, null);
                            serverOk = r.status == 200;
                            if (serverOk) appConfigJson = r.body;
                        } catch (Exception e) {
                            serverOk = false;
                        }
                    }
                    serverChecked = true;
                    pushBootstrap();
                    // Предпрогрев токена для уже вошедшего пользователя. Неудача не разлогинивает: токен получится при первом запросе.
                    if (auth.isSignedIn() && !BuildConfig.WEB_CLIENT_ID.isEmpty() && !base.isEmpty()) {
                        auth.ensureToken(MainActivity.this, BuildConfig.WEB_CLIENT_ID);
                    }
                } finally {
                    bootstrapRunning = false;
                }
            }
        });
    }

    void retryBootstrap() {
        serverChecked = false;
        bootstrapAsync();
    }

    void pushBootstrap() {
        if (!uiReady || !serverChecked) return;
        JSONObject d = json("serverChecked", true, "serverOk", serverOk, "online", isOnline(),
                "backendConfigured", !normalizeBase(BuildConfig.BACKEND_URL).isEmpty(), "appConfig", appConfigJson);
        emit("bootstrap", d);
    }

    // ---------- WebView ----------

    private void createWebView() {
        if (webView != null) return;
        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#05070F"));
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setSupportMultipleWindows(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);
        ws.setGeolocationEnabled(false);
        ws.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }

            /** Внешние ресурсы внутри страницы запрещены, кроме аватара Google. */
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    String host = u.getHost();
                    if (host == null || !host.endsWith(".googleusercontent.com")) {
                        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked",
                                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                    }
                }
                return null;
            }
        });
        webView.addJavascriptInterface(new JarvisBridge(this), "JarvisBridge");
        root.addView(webView, 0, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        webView.loadUrl("file:///android_asset/index.html");
    }

    private static JSONObject json(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return o;
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if ("file".equals(scheme)) return false;
        if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
            }
        }
        return true;
    }

    @Override
    public void emit(String event, JSONObject data) {
        final String js = "window.JarvisEvents&&window.JarvisEvents.emit("
                + JSONObject.quote(event) + "," + JSONObject.quote(data.toString()) + ")";
        main.post(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.evaluateJavascript(js, null);
            }
        });
    }

    // ---------- озвучивание: выбор движка и единое управление ----------

    private boolean wantsOnline() {
        return "online".equals(settings.str("ttsEngine"));
    }

    void speakText(String id, String text, String lang) {
        speakText(id, text, lang, false);
    }

    /** keepMic=true: не прерывать распознавание речи (Live с наушниками, чтобы можно было перебить). */
    void speakText(String id, String text, String lang, boolean keepMic) {
        if (!servicesReady) return;
        if (!keepMic) speech.cancel();
        if (wantsOnline()) {
            tts.stop();
            if (normalizeBase(BuildConfig.BACKEND_URL).isEmpty() || !auth.isSignedIn()) {
                emit("ttsError", json("code", "online_unavailable", "message",
                        "Нейро-голос требует входа через Google и подключённого сервера. Выбери системный голос в настройках.", "lang", lang));
                return;
            }
            online.speak(id, text, lang);
        } else {
            online.stop();
            tts.speak(id, text, lang);
        }
    }

    void pauseSpeech() {
        if (!servicesReady) return;
        tts.pause();
        online.pause();
    }

    void resumeSpeech() {
        if (!servicesReady) return;
        tts.resume();
        online.resume();
    }

    void stopSpeech() {
        if (!servicesReady) return;
        tts.stop();
        online.stop();
    }

    // ---------- микрофон ----------

    void beginListening(String lang) {
        beginListening(lang, true, false);
    }

    /** interrupt: остановить речь JARVIS перед записью; continuous: диктовка без остановки на паузах. */
    void beginListening(String lang, boolean interrupt, boolean continuous) {
        if (!servicesReady) return;
        pendingLang = (lang == null || lang.isEmpty()) ? "ru" : lang;
        pendingContinuous = continuous;
        if (interrupt) stopSpeech();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        startRecognition();
    }

    private void startRecognition() {
        if (pendingContinuous) speech.startContinuous(pendingLang);
        else speech.start(pendingLang);
    }

    boolean hasHeadset() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int t = d.getType();
                if (t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                        || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    void keepScreenOn(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // ---------- Live Voice в фоне ----------

    /** Только по нажатию пользователя. Нужны разрешение микрофона и уведомления; служба показывает уведомление с кнопкой «Стоп». */
    void startLiveService() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            emit("live", json("state", "need_mic"));
            return;
        }
        try {
            Intent i = new Intent(this, LiveVoiceService.class).setAction(LiveVoiceService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            emit("live", json("state", "started"));
        } catch (Exception e) {
            emit("live", json("state", "error"));
        }
    }

    void stopLiveService() {
        try {
            stopService(new Intent(this, LiveVoiceService.class));
        } catch (Exception ignored) {
        }
    }

    // ---------- показ экрана ----------

    void requestScreenShare() {
        if (ScreenShareService.running) {
            emit("screen", json("state", "started"));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        launchProjection();
    }

    private void launchProjection() {
        try {
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQ_PROJECTION);
        } catch (Exception e) {
            emit("screen", json("state", "error", "reason", "no_projection"));
        }
    }

    void launchFilePicker() {
        try {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("*/*");
            pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(Intent.createChooser(pick, "Выбрать файлы для JARVIS"), REQ_FILES);
        } catch (Exception e) {
            emit("filePicked", json("ok", false, "error", "Не удалось открыть выбор файлов."));
        }
    }

    private void emitPickedFile(Uri uri) {
        executor.execute(() -> {
            try {
                String name = "Файл";
                long size = -1;
                String mime = getContentResolver().getType(uri);
                try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
                    if (c != null && c.moveToFirst()) {
                        int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        int si = c.getColumnIndex(OpenableColumns.SIZE);
                        if (ni >= 0) name = c.getString(ni);
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                    }
                }
                String lower = name.toLowerCase(java.util.Locale.ROOT);
                if (lower.endsWith(".apk") || "application/vnd.android.package-archive".equalsIgnoreCase(mime)) {
                    emit("filePicked", json("ok", false, "error", "APK-файлы не принимаются.")); return;
                }
                final int maxBytes = 12 * 1024 * 1024;
                if (size > maxBytes) { emit("filePicked", json("ok", false, "error", "Файл больше 12 МБ.")); return; }
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IllegalStateException("empty_stream");
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) > 0) { if (out.size() + n > maxBytes) throw new IllegalStateException("file_too_large"); out.write(buf, 0, n); }
                }
                byte[] bytes = out.toByteArray();
                if (size < 0) size = bytes.length;
                String extracted = extractDocumentText(name, mime, bytes);
                if (extracted != null && extracted.length() > 40000) extracted = extracted.substring(0, 40000) + "\n\n[Текст обрезан: лимит извлечения 40 000 символов]";
                JSONObject result = json("ok", true, "name", name, "mime", mime == null ? "application/octet-stream" : mime,
                        "size", size, "text", extracted == null ? "" : extracted,
                        "data", (mime != null && mime.startsWith("image/")) ? Base64.encodeToString(bytes, Base64.NO_WRAP) : "");
                emit("filePicked", result);
            } catch (Exception e) {
                emit("filePicked", json("ok", false, "error", "Не удалось обработать файл: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage())));
            }
        });
    }

    private String extractDocumentText(String name, String mime, byte[] bytes) throws Exception {
        String ext = name.toLowerCase(java.util.Locale.ROOT);
        if (ext.endsWith(".pdf") || "application/pdf".equalsIgnoreCase(mime)) {
            PDFBoxResourceLoader.init(getApplicationContext());
            try (PDDocument doc = PDDocument.load(bytes)) { return new PDFTextStripper().getText(doc); }
        }
        if (ext.endsWith(".docx")) return extractOfficeXml(bytes, "word/document.xml", null);
        if (ext.endsWith(".pptx")) return extractOfficeXml(bytes, null, "ppt/slides/slide");
        if (ext.endsWith(".xlsx") || ext.endsWith(".xlsm")) return extractXlsx(bytes);
        if (ext.endsWith(".odt") || ext.endsWith(".odp") || ext.endsWith(".ods")) return extractOfficeXml(bytes, "content.xml", null);
        if (ext.endsWith(".txt") || ext.endsWith(".md") || ext.endsWith(".csv") || ext.endsWith(".tsv") || ext.endsWith(".json") || ext.endsWith(".xml") || ext.endsWith(".html") || ext.endsWith(".htm") || ext.endsWith(".js") || ext.endsWith(".css") || ext.endsWith(".log") || ext.endsWith(".yaml") || ext.endsWith(".yml") || ext.endsWith(".ini") || ext.endsWith(".rtf")) {
            String t = new String(bytes, StandardCharsets.UTF_8);
            if (ext.endsWith(".rtf")) t = t.replaceAll("\\\\'[0-9a-fA-F]{2}", " ").replaceAll("\\\\[a-zA-Z]+-?\\d* ?", " ").replaceAll("[{}]", " ");
            if (ext.endsWith(".html") || ext.endsWith(".htm")) t = t.replaceAll("(?is)<script[^>]*>.*?</script>|<style[^>]*>.*?</style>", " ").replaceAll("(?s)<[^>]+>", " ").replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">");
            return t;
        }
        return "";
    }

    private String extractOfficeXml(byte[] bytes, String exact, String prefix) throws Exception {
        StringBuilder result = new StringBuilder();
        try (ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry e; byte[] buf = new byte[8192];
            while ((e = zin.getNextEntry()) != null) {
                String n = e.getName();
                boolean wanted = exact != null ? n.equals(exact) : (prefix != null && n.startsWith(prefix) && n.endsWith(".xml"));
                if (!wanted) continue;
                ByteArrayOutputStream x = new ByteArrayOutputStream(); int k; while ((k = zin.read(buf)) > 0 && x.size() < 4 * 1024 * 1024) x.write(buf,0,k);
                String text = xmlText(x.toByteArray()); if (text.length() > 0) result.append(text).append("\n\n");
            }
        }
        return result.toString();
    }

    private String extractXlsx(byte[] bytes) throws Exception {
        Map<String, byte[]> entries = new HashMap<>();
        try (ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry e; byte[] buf = new byte[8192];
            while ((e = zin.getNextEntry()) != null) {
                String n = e.getName();
                if (n.equals("xl/sharedStrings.xml") || n.matches("xl/worksheets/sheet[0-9]+\\.xml")) {
                    ByteArrayOutputStream x = new ByteArrayOutputStream(); int k;
                    while ((k = zin.read(buf)) > 0 && x.size() < 4 * 1024 * 1024) x.write(buf, 0, k);
                    entries.put(n, x.toByteArray());
                }
            }
        }
        java.util.List<String> shared = new java.util.ArrayList<>();
        byte[] ss = entries.get("xl/sharedStrings.xml");
        if (ss != null) {
            XmlPullParser p = XmlPullParserFactory.newInstance().newPullParser(); p.setInput(new ByteArrayInputStream(ss), "UTF-8");
            StringBuilder item = null; int depth = 0, event;
            while ((event = p.next()) != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && "si".equals(p.getName())) { item = new StringBuilder(); depth = p.getDepth(); }
                else if (item != null && (event == XmlPullParser.TEXT || event == XmlPullParser.CDSECT)) item.append(p.getText());
                else if (event == XmlPullParser.END_TAG && "si".equals(p.getName()) && item != null) { shared.add(item.toString()); item = null; }
            }
        }
        StringBuilder all = new StringBuilder();
        for (Map.Entry<String, byte[]> entry : entries.entrySet()) {
            if (entry.getKey().equals("xl/sharedStrings.xml")) continue;
            XmlPullParser p = XmlPullParserFactory.newInstance().newPullParser(); p.setInput(new ByteArrayInputStream(entry.getValue()), "UTF-8");
            String cellType = "", cellRef = ""; StringBuilder value = new StringBuilder(); boolean inValue = false; int event;
            while ((event = p.next()) != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && "c".equals(p.getName())) { cellType = p.getAttributeValue(null, "t"); cellRef = p.getAttributeValue(null, "r"); value.setLength(0); }
                else if (event == XmlPullParser.START_TAG && "v".equals(p.getName())) inValue = true;
                else if (event == XmlPullParser.TEXT && inValue) value.append(p.getText());
                else if (event == XmlPullParser.END_TAG && "v".equals(p.getName())) inValue = false;
                else if (event == XmlPullParser.END_TAG && "c".equals(p.getName())) {
                    String v = value.toString(); if ("s".equals(cellType)) { try { v = shared.get(Integer.parseInt(v)); } catch (Exception ignored) {} }
                    if (v != null && !v.isEmpty()) all.append(cellRef == null ? "" : cellRef).append(": ").append(v).append("\n");
                }
            }
            all.append("\n");
        }
        return all.toString();
    }

    private String xmlText(byte[] xml) throws Exception {
        XmlPullParser p = XmlPullParserFactory.newInstance().newPullParser();
        p.setInput(new ByteArrayInputStream(xml), "UTF-8"); StringBuilder b=new StringBuilder(); int event;
        while((event=p.next())!=XmlPullParser.END_DOCUMENT) if(event==XmlPullParser.TEXT || event==XmlPullParser.CDSECT) { String t=p.getText(); if(t!=null && !t.trim().isEmpty()) { if(b.length()>0)b.append(' '); b.append(t.trim()); } }
        return b.toString();
    }

    public void launchContactPicker() {
        try {
            Intent pick = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            startActivityForResult(pick, REQ_CONTACT);
        } catch (Exception e) {
            emit("whatsappContact", json("ok", false, "error", "Не удалось открыть контакты."));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CONTACT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (Cursor c = getContentResolver().query(data.getData(),
                        new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                        null, null, null)) {
                    if (c != null && c.moveToFirst()) emit("whatsappContact", json("ok", true,
                            "name", c.getString(0), "phone", c.getString(1)));
                } catch (Exception e) { emit("whatsappContact", json("ok", false, "error", "Не удалось прочитать контакт.")); }
            }
            return;
        }
        if (requestCode == REQ_FILES) {
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    for (int i = 0; i < data.getClipData().getItemCount(); i++) emitPickedFile(data.getClipData().getItemAt(i).getUri());
                } else if (data.getData() != null) emitPickedFile(data.getData());
            }
            return;
        }
        if (requestCode != REQ_PROJECTION) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent i = new Intent(this, ScreenShareService.class)
                    .setAction(ScreenShareService.ACTION_START)
                    .putExtra("code", resultCode)
                    .putExtra("data", data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } else {
            emit("screen", json("state", "denied"));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_AUDIO) {
            if (granted) {
                main.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startRecognition();
                    }
                }, 200);
            } else {
                boolean permanent = !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO);
                emit("speech", json("type", "error", "code", "permission_denied", "permanent", permanent));
            }
        } else if (requestCode == REQ_NOTIF) {
            launchProjection();
        }
    }

    // ---------- жизненный цикл ----------

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (player != null && prepared && splashActive && !videoDone) {
            try {
                player.start();
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onPause() {
        resumed = false;
        if (player != null && prepared && splashActive) {
            try {
                if (player.isPlaying()) player.pause();
            } catch (Exception ignored) {
            }
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (splashActive || webView == null) return; // во время заставки «Назад» ничего не делает
        webView.evaluateJavascript("window.jarvisBack?String(window.jarvisBack()):'false'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value == null || !value.contains("true")) MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onStop() {
        // Когда приложение уходит с экрана, звук и запись прекращаются, КРОМЕ включённого пользователем Live Voice
        // (он виден в уведомлении и останавливается кнопкой).
        if (servicesReady && !LiveVoiceService.running) {
            stopSpeech();
            speech.cancel();
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        ScreenShareService.listener = null;
        LiveVoiceService.listener = null;
        stopLiveService();
        stopService(new Intent(this, ScreenShareService.class));
        releasePlayer();
        if (servicesReady) {
            tts.shutdown();
            online.shutdown();
            speech.cancel();
        }
        executor.shutdownNow();
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
