package com.jarvis.ai;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.app.RemoteInput;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/**
 * WhatsApp integration through Android's supported notification reply surface.
 * It does not access WhatsApp's private database or bypass its sandbox.
 */
public class MessageNotificationService extends NotificationListenerService {
    private static final String PREFS = "jarvis_message_bridge";
    private static final String KEY_ITEMS = "notification_items";
    private static final int MAX_ITEMS = 80;

    public static class Item {
        public String key, packageName, title, text;
        public long when;
        public PendingIntent replyIntent;
        public RemoteInput[] remoteInputs;
        public String resultKey;
    }
    private static final ArrayList<Item> ITEMS = new ArrayList<>();

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        String pkg = sbn.getPackageName();
        if (pkg == null || !(pkg.equals("com.whatsapp") || pkg.equals("com.whatsapp.w4b"))) return;
        Notification n = sbn.getNotification();
        Bundle e = n.extras;
        String title = e == null ? "" : String.valueOf(e.getCharSequence(Notification.EXTRA_TITLE));
        CharSequence cs = e == null ? null : e.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (cs == null && e != null) cs = e.getCharSequence(Notification.EXTRA_TEXT);
        String body = cs == null ? "" : cs.toString();
        if (body.trim().isEmpty()) return;

        Item item = new Item();
        item.key = sbn.getKey();
        item.packageName = pkg;
        item.title = title;
        item.text = body;
        item.when = sbn.getPostTime();

        Notification.Action[] actions = n.actions;
        if (actions != null) {
            for (Notification.Action a : actions) {
                if (a == null || a.actionIntent == null || a.getRemoteInputs() == null) continue;
                for (RemoteInput ri : a.getRemoteInputs()) {
                    if (ri != null && ri.getAllowFreeFormInput()) {
                        item.replyIntent = a.actionIntent;
                        item.remoteInputs = a.getRemoteInputs();
                        item.resultKey = ri.getResultKey();
                        break;
                    }
                }
                if (item.replyIntent != null) break;
            }
        }
        synchronized (ITEMS) {
            for (int i = ITEMS.size() - 1; i >= 0; i--) {
                if (ITEMS.get(i).key.equals(item.key)) ITEMS.remove(i);
            }
            ITEMS.add(0, item);
            while (ITEMS.size() > MAX_ITEMS) ITEMS.remove(ITEMS.size()-1);
            persist();
        }
    }

    @Override public void onNotificationRemoved(StatusBarNotification sbn) {
        // Keep recent notification metadata for the in-app conversation list; only the reply token expires.
        if (sbn == null) return;
        synchronized (ITEMS) {
            for (Item x : ITEMS) if (x.key.equals(sbn.getKey())) {
                x.replyIntent = null; x.remoteInputs = null; x.resultKey = null;
            }
        }
    }

    private void persist() {
        JSONArray a = new JSONArray();
        for (Item x : ITEMS) {
            JSONObject o = new JSONObject();
            try { o.put("key",x.key); o.put("package",x.packageName); o.put("title",x.title); o.put("text",x.text); o.put("when",x.when); o.put("replyAvailable",x.replyIntent != null); } catch(Exception ignored) {}
            a.put(o);
        }
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ITEMS,a.toString()).apply();
    }

    public static JSONArray snapshot(Context c) {
        JSONArray a = new JSONArray();
        synchronized (ITEMS) {
            for (Item x : ITEMS) {
                JSONObject o = new JSONObject();
                try { o.put("key",x.key); o.put("package",x.packageName); o.put("title",x.title); o.put("text",x.text); o.put("when",x.when); o.put("replyAvailable",x.replyIntent != null); } catch(Exception ignored) {}
                a.put(o);
            }
        }
        if (a.length() == 0) {
            try { return new JSONArray(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS,"[]")); } catch(Exception ignored) {}
        }
        return a;
    }

    public static boolean reply(Context c, String key, String message) {
        if (message == null || message.trim().isEmpty()) return false;
        Item found = null;
        synchronized (ITEMS) { for (Item x : ITEMS) if (x.key.equals(key)) { found=x; break; } }
        if (found == null || found.replyIntent == null || found.remoteInputs == null || found.resultKey == null) return false;
        try {
            Intent fillIn = new Intent();
            Bundle results = new Bundle();
            results.putCharSequence(found.resultKey, message);
            RemoteInput.addResultsToIntent(found.remoteInputs, fillIn, results);
            found.replyIntent.send(c, 0, fillIn);
            return true;
        } catch (PendingIntent.CanceledException | RuntimeException e) { return false; }
    }
}
