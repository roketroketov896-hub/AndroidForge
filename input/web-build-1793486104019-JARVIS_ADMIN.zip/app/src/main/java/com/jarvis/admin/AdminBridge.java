package com.jarvis.admin;

import android.webkit.JavascriptInterface;

import org.json.JSONObject;

/**
 * Мост JavaScript → Android для админ-панели.
 * Права доступа к данным определяет сервер (ADMIN_MODE). Здесь нет паролей и ключей:
 * сохраняется только адрес сервера, который вводит сам администратор.
 */
final class AdminBridge {
    private final MainActivity act;

    AdminBridge(MainActivity act) {
        this.act = act;
    }

    private static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return o;
    }

    static String normalizeBase(String url) {
        String u = url == null ? "" : url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u.startsWith("https://") ? u : "";
    }

    private String base() {
        String saved = act.prefs.getString("backendUrl", "");
        String b = normalizeBase(saved);
        return b.isEmpty() ? normalizeBase(BuildConfig.BACKEND_URL) : b;
    }

    @JavascriptInterface
    public String getState() {
        return obj("backendUrl", base(), "googleConfigured", !BuildConfig.WEB_CLIENT_ID.trim().isEmpty(), "profile", act.auth.profile()).toString();
    }

    /** Возвращает true, если адрес принят (должен начинаться с https://). */
    @JavascriptInterface
    public boolean saveServer(String url) {
        String b = normalizeBase(url);
        if (b.isEmpty()) return false;
        act.prefs.edit().putString("backendUrl", b).apply();
        return true;
    }

    @JavascriptInterface
    public void clearServer() {
        act.prefs.edit().remove("backendUrl").apply();
    }

    /** Вход через официальное окно выбора аккаунта Google. Результат приходит событием "auth". */
    @JavascriptInterface
    public void signIn() {
        act.main.post(new Runnable() {
            @Override
            public void run() {
                if (BuildConfig.WEB_CLIENT_ID.trim().isEmpty()) {
                    JSONObject p0 = act.auth.profile();
                    try {
                        p0.put("error", "no_client_id");
                    } catch (Exception ignored) {
                    }
                    act.emit("auth", p0);
                    return;
                }
                act.auth.signIn(act, BuildConfig.WEB_CLIENT_ID, new AuthManager.Done() {
                    @Override
                    public void done(boolean ok, String error) {
                        JSONObject p = act.auth.profile();
                        try {
                            p.put("error", ok ? "" : error);
                        } catch (Exception ignored) {
                        }
                        act.emit("auth", p);
                    }
                });
            }
        });
    }

    @JavascriptInterface
    public void signOut() {
        act.auth.signOut();
        act.emit("auth", act.auth.profile());
    }

    /** Запрос к серверу JARVIS. Ответ приходит событием "api". */
    @JavascriptInterface
    public void api(final String reqId, final String method, final String path, final String body) {
        act.executor.execute(new Runnable() {
            @Override
            public void run() {
                JSONObject out;
                try {
                    String base = base();
                    if (base.isEmpty()) {
                        out = obj("reqId", reqId, "ok", false, "status", 0, "code", "not_configured", "body", "");
                    } else if (!path.equals("/health") && !act.auth.isSignedIn()) {
                        out = obj("reqId", reqId, "ok", false, "status", 0, "code", "auth_required", "body", "");
                    } else {
                        // /health публичный; остальное только с действующим Google ID-токеном (обновляется тихо).
                        String token = path.equals("/health") ? "" : act.auth.ensureToken(act, BuildConfig.WEB_CLIENT_ID);
                        if (!path.equals("/health") && token.isEmpty()) {
                            out = obj("reqId", reqId, "ok", false, "status", 0, "code", "auth_required", "body", "");
                        } else {
                            Http.Result r = Http.request(method, base + path, token, body);
                            out = obj("reqId", reqId, "ok", r.status >= 200 && r.status < 300, "status", r.status, "code", "", "body", r.body);
                        }
                    }
                } catch (Exception e) {
                    out = obj("reqId", reqId, "ok", false, "status", 0, "code", "network", "body", "");
                }
                act.emit("api", out);
            }
        });
    }
}
