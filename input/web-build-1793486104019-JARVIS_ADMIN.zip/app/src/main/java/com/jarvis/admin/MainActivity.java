package com.jarvis.admin;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Админ-панель JARVIS. Открывается сразу, без входа: на этом этапе доступ к данным определяет сервер (режим ADMIN_MODE). */
public class MainActivity extends Activity implements Emitter {
    WebView webView;
    SharedPreferences prefs;
    AuthManager auth;
    final ExecutorService executor = Executors.newCachedThreadPool();
    final Handler main = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("jarvis_admin", MODE_PRIVATE);
        auth = new AuthManager(prefs);

        getWindow().setStatusBarColor(Color.parseColor("#05070F"));
        getWindow().setNavigationBarColor(Color.parseColor("#05070F"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#05070F"));
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }
        });
        webView.addJavascriptInterface(new AdminBridge(this), "AdminBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if ("file".equals(scheme)) return false;
        if ("http".equals(scheme) || "https".equals(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
            }
        }
        return true;
    }

    @Override
    public void emit(String event, JSONObject data) {
        final String js = "window.AdminEvents&&window.AdminEvents.emit("
                + JSONObject.quote(event) + "," + JSONObject.quote(data.toString()) + ")";
        main.post(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.evaluateJavascript(js, null);
            }
        });
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript("window.adminBack?String(window.adminBack()):'false'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value == null || !value.contains("true")) MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
