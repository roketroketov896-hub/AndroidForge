// Сервер-посредник JARVIS для бесплатного режима. Node.js 18+, без зависимостей.
// Хранит общий ключ OpenRouter, проверяет вход через Google, считает лимиты по серверному времени.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { evaluate, reserve, refund, activePlan, DAY_MS, dayKey } from './quota.mjs';
import { verifyGoogleIdToken, fetchGoogleJwks } from './auth.mjs';

const MAX_CHAT_BYTES = 6 * 1024 * 1024;   // с запасом на снимок экрана
const MAX_HISTORY_BYTES = 5 * 1024 * 1024;

// Шифрование ключа провайдера «на диске» (если задан CONFIG_SECRET). Без него ключ хранится открытым текстом.
export function sealSecret(plain, secret) {
  if (!secret) return 'plain:' + plain;
  const key = crypto.scryptSync(secret, 'jarvis-config-v1', 32);
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([c.update(plain, 'utf8'), c.final()]);
  return 'enc:' + Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64');
}
export function openSecret(stored, secret) {
  if (!stored) return '';
  if (stored.startsWith('plain:')) return stored.slice(6);
  if (!stored.startsWith('enc:') || !secret) return '';
  try {
    const raw = Buffer.from(stored.slice(4), 'base64');
    const key = crypto.scryptSync(secret, 'jarvis-config-v1', 32);
    const d = crypto.createDecipheriv('aes-256-gcm', key, raw.subarray(0, 12));
    d.setAuthTag(raw.subarray(12, 28));
    return Buffer.concat([d.update(raw.subarray(28)), d.final()]).toString('utf8');
  } catch { return ''; }
}
const hint = (k) => (k ? '…' + k.slice(-4) : '');

export function createApp(opts) {
  const adminEmails = (opts.adminEmails || []).map((e) => e.trim().toLowerCase()).filter(Boolean);
  const keyCheckUrl = opts.keyCheckUrl || 'https://openrouter.ai/api/v1/auth/key';
  const dataFile = opts.dataFile;
  const verify = opts.verify || ((token) => verifyGoogleIdToken(token, { clientId: opts.googleClientId, getJwks: fetchGoogleJwks }));
  const upstreamUrl = opts.upstreamUrl || 'https://openrouter.ai/api/v1/chat/completions';
  const now = opts.now || (() => Date.now());

  let db = { users: {}, history: {}, config: {} };
  try { db = JSON.parse(fs.readFileSync(dataFile, 'utf8')); } catch { /* новый файл */ }
  db.config = db.config || {}; db.users = db.users || {}; db.history = db.history || {};

  // Рабочие настройки: значения из админки перекрывают значения из переменных окружения.
  const num = (v, d) => (Number.isFinite(Number(v)) && v !== null && v !== '' && v !== undefined ? Number(v) : d);
  const cfg = () => ({
    unlimitedDays: num(db.config.unlimitedDays, opts.unlimitedDays ?? 15),
    dailyLimit: num(db.config.dailyLimit, opts.dailyLimit ?? 5),
    proDailyLimit: num(db.config.proDailyLimit, opts.proDailyLimit ?? 200),
  });
  const freeModel = () => db.config.freeModel || opts.freeModel || 'openrouter/auto';
  const proModel = () => db.config.proModel || opts.proModel || freeModel();
  const providerKey = () => openSecret(db.config.keyStored, opts.configSecret) || opts.openrouterKey || '';
  let writing = Promise.resolve();
  function persist() {
    writing = writing.then(() => {
      const tmp = dataFile + '.tmp';
      fs.mkdirSync(path.dirname(dataFile), { recursive: true });
      fs.writeFileSync(tmp, JSON.stringify(db));
      fs.renameSync(tmp, dataFile);
    }).catch((e) => console.error('persist failed', e.message));
    return writing;
  }

  const send = (res, code, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(body);
  };
  const err = (res, code, errCode, message) => send(res, code, { error: { code: errCode, message } });

  function readBody(req, limit) {
    return new Promise((resolve, reject) => {
      let size = 0; const chunks = [];
      req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('too_large')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', reject);
    });
  }

  async function authenticate(req) {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : '';
    if (!token) return null;
    try {
      const u = await verify(token);
      return u && u.sub ? u : null;
    } catch { return null; }
  }

  function getUser(sub, email) {
    let u = db.users[sub];
    if (!u) { u = db.users[sub] = { startedAt: now(), dayKey: '', count: 0, email, plan: 'free', blocked: false, total: 0, lastSeen: now() }; }
    if (email) u.email = email;
    return u;
  }

  function sanitizeMessages(raw) {
    if (!Array.isArray(raw)) return null;
    const out = [];
    for (const m of raw.slice(-40)) {
      if (!m || !['system', 'user', 'assistant'].includes(m.role)) continue;
      if (typeof m.content === 'string') out.push({ role: m.role, content: m.content.slice(0, 40000) });
      else if (Array.isArray(m.content) && m.role === 'user') {
        const parts = [];
        for (const p of m.content) {
          if (p && p.type === 'text' && typeof p.text === 'string') parts.push({ type: 'text', text: p.text.slice(0, 40000) });
          else if (p && p.type === 'image_url' && p.image_url && typeof p.image_url.url === 'string' && p.image_url.url.startsWith('data:image/')) parts.push({ type: 'image_url', image_url: { url: p.image_url.url } });
        }
        if (parts.length) out.push({ role: 'user', content: parts });
      }
    }
    return out.length ? out : null;
  }

  async function handleChat(req, res, user) {
    let body;
    try { body = JSON.parse(await readBody(req, MAX_CHAT_BYTES)); } catch (e) { return err(res, e.message === 'too_large' ? 413 : 400, 'bad_request', 'Некорректный запрос.'); }
    const messages = sanitizeMessages(body.messages);
    if (!messages) return err(res, 400, 'bad_request', 'Нет сообщений.');

    const u = getUser(user.sub, user.email);
    if (u.blocked) return err(res, 403, 'blocked', 'Доступ к JARVIS для этого аккаунта заблокирован администратором.');
    if (!providerKey()) return err(res, 503, 'not_configured', 'На сервере не задан ключ ИИ-провайдера.');
    const r = reserve(u, now(), cfg());
    if (!r.ok) {
      return send(res, 429, { error: { code: 'daily_limit', message: 'Дневной лимит бесплатного режима исчерпан.' }, status: r.status });
    }
    await persist();

    const refundIt = async () => { refund(u, now()); await persist(); };
    let up;
    try {
      up = await fetch(upstreamUrl, {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + providerKey(), 'Content-Type': 'application/json', 'HTTP-Referer': 'https://jarvis.local', 'X-Title': 'JARVIS AI' },
        body: JSON.stringify({ model: activePlan(u, now()) === 'pro' ? proModel() : freeModel(), messages, stream: true, max_tokens: opts.maxTokens ?? 1500 }),
      });
    } catch {
      await refundIt();
      return err(res, 502, 'upstream', 'Провайдер ИИ недоступен.');
    }
    if (!up.ok) {
      await refundIt();
      return err(res, up.status === 429 ? 503 : 502, 'upstream', 'Провайдер ИИ вернул ошибку ' + up.status + '.');
    }
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
    let sent = false;
    try {
      for await (const chunk of up.body) { sent = true; if (!res.write(chunk)) await new Promise((ok) => res.once('drain', ok)); }
    } catch { /* клиент отключился или поток прерван */ }
    if (!sent) await refundIt();
    res.end();
  }


  // ---------- администрирование ----------
  const isAdmin = (user) => !!user.email && user.emailVerified !== false && adminEmails.includes(user.email.toLowerCase());
  const publicUser = (sub, u) => ({ sub, email: u.email || '', plan: activePlan(u, now()), planUntil: u.planUntil || null, blocked: !!u.blocked,
    dailyLimitOverride: Number.isFinite(u.dailyLimit) ? u.dailyLimit : null, startedAt: u.startedAt, lastSeen: u.lastSeen || null,
    total: u.total || 0, status: evaluate(u, now(), cfg()) });
  const publicConfig = () => ({ hasKey: !!providerKey(), keyHint: hint(providerKey()), keySource: db.config.keyStored ? 'admin' : (opts.openrouterKey ? 'env' : 'none'),
    encryptedAtRest: !!db.config.keyStored && db.config.keyStored.startsWith('enc:'),
    freeModel: freeModel(), proModel: proModel(), ...cfg() });

  async function handleAdmin(req, res, url, user) {
    if (!isAdmin(user)) return err(res, 403, 'forbidden', 'Нет прав администратора.');
    const m = req.method, p = url.pathname;
    const readJson = async () => { try { return JSON.parse(await readBody(req, 64 * 1024)); } catch { return null; } };
    if (m === 'GET' && p === '/admin/me') return send(res, 200, { admin: true, email: user.email });
    if (m === 'GET' && p === '/admin/config') return send(res, 200, publicConfig());
    if (m === 'PUT' && p === '/admin/config') {
      const b = await readJson();
      if (!b || typeof b !== 'object') return err(res, 400, 'bad_request', 'Некорректный запрос.');
      if (typeof b.openrouterKey === 'string' && b.openrouterKey.trim()) {
        const k = b.openrouterKey.trim();
        if (k.length < 12 || k.length > 400 || /\s/.test(k)) return err(res, 400, 'bad_key', 'Ключ выглядит некорректно.');
        db.config.keyStored = sealSecret(k, opts.configSecret);
      }
      if (b.clearKey === true) delete db.config.keyStored;
      for (const k of ['freeModel', 'proModel']) if (typeof b[k] === 'string' && b[k].trim()) db.config[k] = b[k].trim().slice(0, 120);
      for (const k of ['unlimitedDays', 'dailyLimit', 'proDailyLimit']) {
        if (b[k] === undefined) continue;
        const v = Number(b[k]);
        if (!Number.isFinite(v) || v < 0 || v > 100000) return err(res, 400, 'bad_request', 'Некорректное значение: ' + k);
        db.config[k] = Math.floor(v);
      }
      await persist();
      return send(res, 200, publicConfig());
    }
    if (m === 'POST' && p === '/admin/test-key') {
      const b = (await readJson()) || {};
      const k = (typeof b.openrouterKey === 'string' && b.openrouterKey.trim()) || providerKey();
      if (!k) return send(res, 200, { ok: false, message: 'Ключ не задан.' });
      try {
        const r = await fetch(keyCheckUrl, { headers: { Authorization: 'Bearer ' + k } });
        return send(res, 200, { ok: r.ok, status: r.status, message: r.ok ? 'Ключ принят провайдером.' : 'Провайдер отклонил ключ (код ' + r.status + ').' });
      } catch { return send(res, 200, { ok: false, message: 'Не удалось связаться с провайдером.' }); }
    }
    if (m === 'GET' && p === '/admin/stats') {
      const list = Object.values(db.users);
      const today = dayKey(now());
      return send(res, 200, { users: list.length, blocked: list.filter((u) => u.blocked).length, pro: list.filter((u) => activePlan(u, now()) === 'pro').length,
        requestsToday: list.reduce((a, u) => a + (u.dayKey === today ? u.count : 0), 0), totalRequests: list.reduce((a, u) => a + (u.total || 0), 0) });
    }
    if (m === 'GET' && p === '/admin/users') {
      const q = (url.searchParams.get('q') || '').toLowerCase();
      const rows = Object.entries(db.users).filter(([, u]) => !q || (u.email || '').toLowerCase().includes(q))
        .sort((a, b) => (b[1].lastSeen || 0) - (a[1].lastSeen || 0)).slice(0, 200).map(([sub, u]) => publicUser(sub, u));
      return send(res, 200, { users: rows });
    }
    const mm = p.match(/^\/admin\/users\/([^/]+)$/);
    if (mm && m === 'PATCH') {
      const sub = decodeURIComponent(mm[1]);
      const u = db.users[sub];
      if (!u) return err(res, 404, 'not_found', 'Пользователь не найден.');
      const b = await readJson();
      if (!b || typeof b !== 'object') return err(res, 400, 'bad_request', 'Некорректный запрос.');
      if (typeof b.blocked === 'boolean') u.blocked = b.blocked;
      if (b.plan === 'pro') { u.plan = 'pro'; const d = Number(b.days); u.planUntil = Number.isFinite(d) && d > 0 ? now() + Math.min(d, 3650) * DAY_MS : null; }
      else if (b.plan === 'free') { u.plan = 'free'; u.planUntil = null; }
      if (b.dailyLimit === null) delete u.dailyLimit;
      else if (b.dailyLimit !== undefined) {
        const v = Number(b.dailyLimit);
        if (!Number.isFinite(v) || v < 0 || v > 100000) return err(res, 400, 'bad_request', 'Некорректный лимит.');
        u.dailyLimit = Math.floor(v);
      }
      await persist();
      return send(res, 200, publicUser(sub, u));
    }
    return err(res, 404, 'not_found', 'Не найдено.');
  }

  const handler = async (req, res) => {
    const url = new URL(req.url, 'http://x');
    // Android HttpURLConnection не умеет PATCH: админ-приложение шлёт POST с X-HTTP-Method-Override (только для /admin/).
    if (req.method === 'POST' && url.pathname.startsWith('/admin/') && req.headers['x-http-method-override'] === 'PATCH') req.method = 'PATCH';
    try {
      if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true });
      const user = await authenticate(req);
      if (!user) return err(res, 401, 'auth_required', 'Нужен вход через Google.');

      if (url.pathname.startsWith('/admin/')) return await handleAdmin(req, res, url, user);
      if (req.method === 'GET' && url.pathname === '/v1/status') {
        const u = getUser(user.sub, user.email);
        await persist();
        return send(res, 200, { ok: true, email: u.email, startedAt: u.startedAt, serverTime: now(), ...evaluate(u, now(), cfg()) });
      }
      if (req.method === 'POST' && url.pathname === '/v1/chat') return await handleChat(req, res, user);

      if (url.pathname === '/v1/history') {
        if (req.method === 'GET') return send(res, 200, db.history[user.sub] || { chats: [] });
        if (req.method === 'PUT') {
          let parsed;
          try { parsed = JSON.parse(await readBody(req, MAX_HISTORY_BYTES)); } catch (e) { return err(res, e.message === 'too_large' ? 413 : 400, 'bad_request', 'Некорректная история.'); }
          if (!parsed || !Array.isArray(parsed.chats)) return err(res, 400, 'bad_request', 'Некорректная история.');
          db.history[user.sub] = { version: 2, at: now(), chats: parsed.chats };
          await persist();
          return send(res, 200, { ok: true });
        }
        if (req.method === 'DELETE') { delete db.history[user.sub]; await persist(); return send(res, 200, { ok: true }); }
      }
      return err(res, 404, 'not_found', 'Не найдено.');
    } catch (e) {
      console.error('handler error', e.message);
      if (!res.headersSent) err(res, 500, 'server_error', 'Ошибка сервера.');
      else res.end();
    }
  };
  return { server: http.createServer(handler), db: () => db, flush: () => writing };
}

// Запуск как программы
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const need = (k) => { if (!process.env[k]) { console.error('Не задана переменная окружения ' + k); process.exit(1); } return process.env[k]; };
  const app = createApp({
    googleClientId: need('GOOGLE_WEB_CLIENT_ID'),
    openrouterKey: process.env.OPENROUTER_API_KEY || '',
    adminEmails: (process.env.ADMIN_EMAILS || '').split(','),
    configSecret: process.env.CONFIG_SECRET || '',
    proModel: process.env.PRO_MODEL || '',
    proDailyLimit: Number(process.env.PRO_DAILY_LIMIT || 200),
    freeModel: process.env.FREE_MODEL || 'openrouter/auto',
    dataFile: process.env.DATA_FILE || './data/jarvis-data.json',
    unlimitedDays: Number(process.env.UNLIMITED_DAYS || 15),
    dailyLimit: Number(process.env.DAILY_LIMIT || 5),
    maxTokens: Number(process.env.MAX_TOKENS || 1500),
  });
  const port = Number(process.env.PORT || 8080);
  app.server.listen(port, () => console.log('JARVIS server listening on :' + port));
}
