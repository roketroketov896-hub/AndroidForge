// Проверка Google ID-токена (RS256) по открытым ключам Google, без сторонних библиотек.
import crypto from 'node:crypto';

const b64 = (s) => Buffer.from(s, 'base64url');

export async function verifyGoogleIdToken(token, { clientId, getJwks, now = Date.now() }) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) throw new Error('malformed');
  const header = JSON.parse(b64(parts[0]).toString('utf8'));
  const payload = JSON.parse(b64(parts[1]).toString('utf8'));
  if (header.alg !== 'RS256') throw new Error('alg');
  const jwks = await getJwks(header.kid);
  const jwk = (jwks.keys || []).find((k) => k.kid === header.kid);
  if (!jwk) throw new Error('kid');
  const key = crypto.createPublicKey({ key: jwk, format: 'jwk' });
  const ok = crypto.verify('RSA-SHA256', Buffer.from(parts[0] + '.' + parts[1]), key, b64(parts[2]));
  if (!ok) throw new Error('signature');
  if (!['accounts.google.com', 'https://accounts.google.com'].includes(payload.iss)) throw new Error('iss');
  if (payload.aud !== clientId) throw new Error('aud');
  if (!payload.exp || payload.exp * 1000 < now) throw new Error('expired');
  if (!payload.sub) throw new Error('sub');
  return { sub: payload.sub, email: payload.email || '', emailVerified: payload.email_verified === true || payload.email_verified === 'true' };
}

let cache = { at: 0, jwks: null };
export async function fetchGoogleJwks(kid) {
  const fresh = cache.jwks && Date.now() - cache.at < 3600000 && (!kid || cache.jwks.keys.some((k) => k.kid === kid));
  if (fresh) return cache.jwks;
  const r = await fetch('https://www.googleapis.com/oauth2/v3/certs');
  if (!r.ok) throw new Error('jwks');
  cache = { at: Date.now(), jwks: await r.json() };
  return cache.jwks;
}
