import assert from 'node:assert/strict';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { createApp, sealSecret, openSecret } from './server.mjs';

// поддельный провайдер ИИ: запоминает, с каким ключом и моделью к нему обратились
let upstreamFail = false; const seen = [];
const upstream = http.createServer((req, res) => {
  let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => {
    if (req.url.startsWith('/auth/key')) { res.writeHead(req.headers.authorization === 'Bearer GOODKEY123456' ? 200 : 401); return res.end('{}'); }
    seen.push({ auth: req.headers.authorization, model: JSON.parse(b).model });
    if (upstreamFail) { res.writeHead(500); return res.end('x'); }
    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
    res.write('data: {"choices":[{"delta":{"content":"Прив"}}]}\n\n');
    res.end('data: [DONE]\n\n');
  });
});
await new Promise((r) => upstream.listen(0, r));
const upBase = 'http://127.0.0.1:' + upstream.address().port;

let clock = Date.UTC(2026, 0, 1, 12);
const file = path.join(os.tmpdir(), 'jarvis-test-' + Date.now() + '.json');
const users = { tokA: { sub: 'A', email: 'a@x' }, tokB: { sub: 'B', email: 'b@x' }, tokAdmin: { sub: 'ADM', email: 'Boss@x', emailVerified: true }, tokFake: { sub: 'F', email: 'boss@x', emailVerified: false } };
const mk = () => createApp({ dataFile: file, upstreamUrl: upBase + '/v1/chat/completions', keyCheckUrl: upBase + '/auth/key', openrouterKey: 'ENVKEY-0000000000', freeModel: 'free-m', proModel: 'pro-m',
  adminEmails: ['boss@x'], configSecret: 'secret', now: () => clock, verify: async (t) => { if (users[t]) return users[t]; throw new Error('bad'); } });
const app = mk();
await new Promise((r) => app.server.listen(0, r));
const base = 'http://127.0.0.1:' + app.server.address().port;
const call = (p, tok, method = 'GET', body) => fetch(base + p, { method, headers: { ...(tok ? { Authorization: 'Bearer ' + tok } : {}), 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
const chat = (tok) => call('/v1/chat', tok, 'POST', { messages: [{ role: 'user', content: 'hi' }] });

assert.equal((await call('/health')).status, 200);
assert.equal((await call('/v1/status')).status, 401);

// обычный пользователь: безлимит 15 дней, потом 5 в день
for (let i = 0; i < 8; i++) assert.equal((await chat('tokA')).status, 200);
assert.equal(seen.at(-1).auth, 'Bearer ENVKEY-0000000000');
assert.equal(seen.at(-1).model, 'free-m');
clock += 15 * 86400000;
for (let i = 0; i < 5; i++) assert.equal((await chat('tokA')).status, 200);
const blocked = await chat('tokA');
assert.equal(blocked.status, 429);
assert.equal((await blocked.json()).error.code, 'daily_limit');

// админ-функции недоступны обычным и «непроверенным» почтам
assert.equal((await call('/admin/config', 'tokA')).status, 403);
assert.equal((await call('/admin/users', 'tokFake')).status, 403);
assert.equal((await call('/admin/config')).status, 401);
assert.equal((await call('/admin/me', 'tokAdmin')).status, 200);

// смена общего ключа и модели через админку, пользователи сразу используют новый ключ
let cfg = await (await call('/admin/config', 'tokAdmin')).json();
assert.equal(cfg.keySource, 'env');
assert.equal((await (await call('/admin/test-key', 'tokAdmin', 'POST', { openrouterKey: 'BAD-KEY-1234567890' })).json()).ok, false);
assert.equal((await (await call('/admin/test-key', 'tokAdmin', 'POST', { openrouterKey: 'GOODKEY123456' })).json()).ok, true);
cfg = await (await call('/admin/config', 'tokAdmin', 'PUT', { openrouterKey: 'GOODKEY123456', freeModel: 'free-m2', dailyLimit: 7 })).json();
assert.equal(cfg.keySource, 'admin'); assert.equal(cfg.keyHint, '…3456'); assert.equal(cfg.encryptedAtRest, true); assert.equal(cfg.dailyLimit, 7);
assert.ok(!JSON.stringify(cfg).includes('GOODKEY'), 'ключ не должен возвращаться');
await app.flush();
assert.ok(!fs.readFileSync(file, 'utf8').includes('GOODKEY'), 'ключ не должен лежать на диске открытым текстом');
clock += 86400000;
assert.equal((await chat('tokA')).status, 200);
assert.equal(seen.at(-1).auth, 'Bearer GOODKEY123456');
assert.equal(seen.at(-1).model, 'free-m2');

// управление пользователями: список, Pro, блокировка
let list = (await (await call('/admin/users?q=a@', 'tokAdmin')).json()).users;
assert.equal(list.length, 1); assert.equal(list[0].email, 'a@x');
const subA = list[0].sub;
let r = await call('/admin/users/' + subA, 'tokAdmin', 'PATCH', { plan: 'pro', days: 30 });
let pu = await r.json();
assert.equal(pu.plan, 'pro'); assert.equal(pu.status.dailyLimit, 200);
assert.equal((await chat('tokA')).status, 200);
assert.equal(seen.at(-1).model, 'pro-m');
pu = await (await call('/admin/users/' + subA, 'tokAdmin', 'PATCH', { blocked: true })).json();
assert.equal(pu.blocked, true);
const bl = await chat('tokA');
assert.equal(bl.status, 403); assert.equal((await bl.json()).error.code, 'blocked');
assert.equal((await (await call('/v1/status', 'tokA')).json()).phase, 'blocked');
await call('/admin/users/' + subA, 'tokAdmin', 'PATCH', { blocked: false, plan: 'free' });
assert.equal((await chat('tokA')).status, 200);
const ov = await fetch(base + '/admin/users/' + subA, { method: 'POST', headers: { Authorization: 'Bearer tokAdmin', 'X-HTTP-Method-Override': 'PATCH', 'Content-Type': 'application/json' }, body: JSON.stringify({ dailyLimit: 9 }) });
assert.equal((await ov.json()).dailyLimitOverride, 9);
await call('/admin/users/' + subA, 'tokAdmin', 'PATCH', { dailyLimit: null });
assert.equal((await call('/admin/users/nobody', 'tokAdmin', 'PATCH', { blocked: true })).status, 404);
assert.equal((await call('/admin/users/' + subA, 'tokA', 'PATCH', { plan: 'pro' })).status, 403);
const stats = await (await call('/admin/stats', 'tokAdmin')).json();
assert.ok(stats.users >= 1 && stats.totalRequests > 10);

// ошибка провайдера не списывает запрос; ключ без CONFIG_SECRET отсутствует => 503
upstreamFail = true;
const before = (await (await call('/v1/status', 'tokB')).json()).usedToday;
assert.equal((await chat('tokB')).status, 502);
upstreamFail = false;
assert.equal((await (await call('/v1/status', 'tokB')).json()).usedToday, before);

// история и изоляция
assert.equal((await call('/v1/history', 'tokA', 'PUT', { chats: [{ id: '1', messages: [] }] })).status, 200);
assert.equal((await (await call('/v1/history', 'tokA')).json()).chats.length, 1);
assert.deepEqual((await (await call('/v1/history', 'tokB')).json()).chats, []);

// перезапуск: ключ и настройки сохраняются
await app.flush();
app.server.close();
const app2 = mk();
assert.equal(app2.db().config.freeModel, 'free-m2');
assert.equal(openSecret(app2.db().config.keyStored, 'secret'), 'GOODKEY123456');
assert.equal(openSecret(app2.db().config.keyStored, 'wrong'), '');
assert.equal(sealSecret('x', ''), 'plain:x');

upstream.close();
console.log('server tests passed');
process.exit(0);
