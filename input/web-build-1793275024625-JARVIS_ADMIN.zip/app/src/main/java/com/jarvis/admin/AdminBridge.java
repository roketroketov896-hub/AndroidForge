package com.jarvis.admin;

import android.webkit.JavascriptInterface;

import org.json.JSONObject;

/** Мост JavaScript → Android для админ-панели. */
final class AdminBridge {
    private final MainActivity act;

    AdminBridge(MainActivity act) {
        this.act = act;
    }

    private static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return o;
    }

    private static String normalizeBase(String url) {
        String u = url == null ? "" : url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u.startsWith("https://") ? u : "";
    }

    @JavascriptInterface
    public String getState() {
        boolean configured = !normalizeBase(BuildConfig.BACKEND_URL).isEmpty() && !BuildConfig.WEB_CLIENT_ID.trim().isEmpty();
        return obj(
                "configured", configured,
                "backendHost", normalizeBase(BuildConfig.BACKEND_URL),
                "profile", act.auth.profile()
        ).toString();
    }

    @JavascriptInterface
    public void signIn() {
        act.main.post(new Runnable() {
            @Override
            public void run() {
                act.auth.signIn(act, BuildConfig.WEB_CLIENT_ID, new AuthManager.Done() {
                    @Override
                    public void done(boolean ok, String error) {
                        JSONObject p = act.auth.profile();
                        try {
                            p.put("error", ok ? "" : error);
                        } catch (Exception ignored) {
                        }
                        act.emit("auth", p);
                    }
                });
            }
        });
    }

    @JavascriptInterface
    public void signOut() {
        act.auth.signOut();
        act.emit("auth", act.auth.profile());
    }

    /** Запрос к серверу JARVIS от имени вошедшего администратора. Ответ приходит событием "api". */
    @JavascriptInterface
    public void api(final String reqId, final String method, final String path, final String body) {
        act.executor.execute(new Runnable() {
            @Override
            public void run() {
                JSONObject out;
                try {
                    String base = normalizeBase(BuildConfig.BACKEND_URL);
                    if (base.isEmpty()) {
                        out = obj("reqId", reqId, "ok", false, "status", 0, "code", "not_configured", "body", "");
                    } else if (!act.auth.isSignedIn()) {
                        out = obj("reqId", reqId, "ok", false, "status", 0, "code", "auth_required", "body", "");
                    } else {
                        String token = act.auth.ensureToken(act, BuildConfig.WEB_CLIENT_ID);
                        if (token.isEmpty()) {
                            out = obj("reqId", reqId, "ok", false, "status", 0, "code", "auth_required", "body", "");
                        } else {
                            Http.Result r = Http.request(method, base + path, token, body);
                            out = obj("reqId", reqId, "ok", r.status >= 200 && r.status < 300, "status", r.status, "code", "", "body", r.body);
                        }
                    }
                } catch (Exception e) {
                    out = obj("reqId", reqId, "ok", false, "status", 0, "code", "network", "body", "");
                }
                act.emit("api", out);
            }
        });
    }
}
