package com.jarvis.admin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Простой блокирующий HTTP-клиент для запросов к серверу JARVIS. */
final class Http {
    private Http() {
    }

    static final class Result {
        int status;
        String body = "";
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[4096];
            int n;
            while ((n = br.read(buf)) > 0) sb.append(buf, 0, n);
        }
        return sb.toString();
    }

    /** PATCH не поддерживается HttpURLConnection напрямую, поэтому отправляем POST с переопределением метода. */
    static Result request(String method, String url, String bearer, String body) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        try {
            boolean patch = "PATCH".equals(method);
            conn.setRequestMethod(patch ? "POST" : method);
            if (patch) conn.setRequestProperty("X-HTTP-Method-Override", "PATCH");
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(60000);
            if (bearer != null && !bearer.isEmpty()) conn.setRequestProperty("Authorization", "Bearer " + bearer);
            conn.setRequestProperty("Accept", "application/json");
            if (body != null && !body.isEmpty()) {
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.getBytes(StandardCharsets.UTF_8));
                }
            }
            Result r = new Result();
            r.status = conn.getResponseCode();
            InputStream in = (r.status >= 200 && r.status < 300) ? conn.getInputStream() : conn.getErrorStream();
            r.body = readAll(in);
            return r;
        } finally {
            conn.disconnect();
        }
    }
}
