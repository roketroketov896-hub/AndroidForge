'use strict';
(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const B = window.AdminBridge || null;
  function native(name) {
    const a = Array.prototype.slice.call(arguments, 1);
    try { if (B && typeof B[name] === 'function') return B[name].apply(B, a); } catch (e) { console.error(name, e); }
    return null;
  }
  const safeJson = (s, fb) => { try { const v = JSON.parse(s); return v == null ? fb : v; } catch (e) { return fb; } };
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  const I = {
    home: '<path d="M4 11l8-7 8 7v9H4z"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6.5 6.5 0 0 1 3.5 6"/>',
    gauge: '<path d="M4 18a8 8 0 1 1 16 0M12 18l4-6"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4-4"/>',
    out: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>'
  };
  const ic = (n, s) => '<svg class="ic" width="' + (s || 22) + '" height="' + (s || 22) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + I[n] + '</svg>';

  /* ---------- состояние ---------- */
  const S = { configured: false, host: '', profile: {}, isAdmin: false, tab: 'overview', config: null, loaded: {} };

  /* ---------- уведомления и подтверждение ---------- */
  let toastTimer = 0;
  function toast(t) {
    const el = $('#toast'); el.textContent = t; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3000);
  }
  function confirmDialog(text, yes) {
    return new Promise(res => {
      $('#dialogText').textContent = text; $('#dialogYes').textContent = yes || 'Подтвердить'; $('#dialog').hidden = false;
      const done = v => { $('#dialog').hidden = true; $('#dialogYes').onclick = null; $('#dialogNo').onclick = null; res(v); };
      $('#dialogYes').onclick = () => done(true); $('#dialogNo').onclick = () => done(false);
    });
  }

  /* ---------- запросы к серверу ---------- */
  const pending = {};
  function api(method, path, body) {
    return new Promise(resolve => {
      const id = uid();
      const timer = setTimeout(() => { delete pending[id]; resolve({ ok: false, status: 0, code: 'timeout', data: null }); }, 70000);
      pending[id] = r => { clearTimeout(timer); resolve(r); };
      if (!B) { delete pending[id]; clearTimeout(timer); resolve({ ok: false, status: 0, code: 'no_bridge', data: null }); return; }
      native('api', id, method, path, body === undefined ? '' : JSON.stringify(body));
    });
  }
  function errText(r) {
    if (r.code === 'not_configured') return 'Приложение не настроено при сборке (адрес сервера или Client ID).';
    if (r.code === 'auth_required' || r.status === 401) return 'Нужно войти заново.';
    if (r.code === 'network') return 'Нет связи с сервером.';
    if (r.code === 'timeout') return 'Сервер не ответил вовремя.';
    if (r.status === 403) return 'У этого аккаунта нет прав администратора.';
    const m = r.data && r.data.error && r.data.error.message;
    return m || ('Ошибка сервера' + (r.status ? ' (' + r.status + ')' : ''));
  }
  const busyBtn = async (btn, fn) => {
    if (btn.disabled) return;
    btn.disabled = true;
    try { return await fn(); } finally { btn.disabled = false; }
  };

  /* ---------- экраны ---------- */
  function showPage(id) { $$('.page').forEach(p => { p.hidden = p.id !== id; }); $('#view').scrollTop = 0; }
  function setGate(title, text, btnLabel, btnAction, note) {
    showPage('p-gate');
    $('#tabs').hidden = true; $('#logout').hidden = !S.profile.signedIn; 
    $('#gateTitle').textContent = title; $('#gateText').textContent = text;
    const b = $('#gateBtn'); b.hidden = !btnLabel; b.textContent = btnLabel || ''; b.onclick = btnAction || null;
    $('#gateNote').textContent = note || '';
  }
  function who() {
    const w = $('#who'); w.hidden = !S.profile.signedIn; w.textContent = S.profile.email || '';
  }
  function authHint(err) {
    if (!err) return '';
    if (/Cancel/i.test(err)) return 'Вход отменён.';
    if (/28444|Developer console|NoCredential|ProviderConfiguration|Unsupported/i.test(err)) return 'Google не принял конфигурацию. Проверь Client ID, Android-клиент (пакет com.jarvis.admin и SHA-1) и тестовых пользователей. См. SETUP_ADMIN_RU.txt. (' + err + ')';
    return 'Ошибка входа: ' + err;
  }

  function gateNotConfigured() {
    setGate('Нужна настройка сборки', 'В этой сборке не задан адрес сервера или Web Client ID. Впиши их в файл jarvis-config.properties и пересобери проект (подробно в SETUP_ADMIN_RU.txt).', null, null, '');
  }
  function gateSignIn(note) {
    setGate('JARVIS Admin', 'Панель управления общим ключом, тарифами и пользователями. Доступ только для администраторов сервера.', 'Войти через Google', () => { $('#gateNote').textContent = 'Открываю вход Google…'; native('signIn'); }, note || '');
  }
  async function checkAdmin() {
    setGate('Проверяю доступ…', 'Связываюсь с сервером.', null, null, '');
    const r = await api('GET', '/admin/me');
    if (r.ok) { S.isAdmin = true; enterApp(); return; }
    S.isAdmin = false;
    if (r.code === 'auth_required' || r.status === 401) { gateSignIn('Сессия истекла, войди снова.'); return; }
    if (r.status === 403) {
      setGate('Нет доступа', 'Аккаунт ' + (S.profile.email || '') + ' не входит в список администраторов сервера.', 'Войти другим аккаунтом', () => { native('signOut'); }, 'Список задаётся переменной ADMIN_EMAILS на сервере.');
      return;
    }
    setGate('Сервер недоступен', errText(r), 'Повторить', checkAdmin, S.host);
  }
  function enterApp() {
    who(); $('#logout').hidden = false; $('#tabs').hidden = false;
    S.loaded = {};
    openTab(S.tab || 'overview', true);
  }

  /* ---------- вкладки ---------- */
  const TAB_TITLES = { overview: ['home', 'Обзор'], key: ['key', 'Ключ'], users: ['users', 'Люди'], limits: ['gauge', 'Лимиты'] };
  function openTab(t, force) {
    S.tab = t;
    $$('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === t));
    showPage('p-' + t);
    if (force || !S.loaded[t]) loadTab(t);
  }
  function loadTab(t) {
    if (t === 'overview') loadOverview();
    else if (t === 'key' || t === 'limits') loadConfig();
    else if (t === 'users') loadUsers();
  }
  async function loadConfig() {
    const r = await api('GET', '/admin/config');
    if (!r.ok) { toast(errText(r)); handleAuthFail(r); return null; }
    S.config = r.data; S.loaded.key = true; S.loaded.limits = true;
    renderConfig();
    return r.data;
  }
  function handleAuthFail(r) { if (r.code === 'auth_required' || r.status === 401) gateSignIn('Сессия истекла, войди снова.'); }

  /* ---------- обзор ---------- */
  async function loadOverview() {
    const [st, cf] = await Promise.all([api('GET', '/admin/stats'), api('GET', '/admin/config')]);
    if (!st.ok) { toast(errText(st)); handleAuthFail(st); return; }
    S.loaded.overview = true;
    const d = st.data || {};
    const cells = [['Пользователей', d.users], ['JARVIS Pro', d.pro], ['Заблокировано', d.blocked], ['Запросов сегодня', d.requestsToday], ['Запросов всего', d.totalRequests]];
    $('#statGrid').innerHTML = cells.map(c => '<div class="stat glass"><b>' + esc(c[1] == null ? '–' : c[1]) + '</b><span>' + esc(c[0]) + '</span></div>').join('');
    if (cf.ok) { S.config = cf.data; renderBrief(); }
  }
  function renderBrief() {
    const c = S.config; if (!c) return;
    $('#keyBrief').innerHTML = '<h3>Состояние ключа</h3><div class="note ' + (c.hasKey ? 'ok' : 'bad') + '">' +
      (c.hasKey ? 'Ключ задан (' + esc(c.keyHint) + '), источник: ' + (c.keySource === 'admin' ? 'админ-панель' : 'переменная окружения сервера') + '.' : 'Ключ НЕ задан: бесплатный режим не работает.') + '</div>' +
      '<div class="note">Модель Free: ' + esc(c.freeModel) + '<br>Модель Pro: ' + esc(c.proModel) + '</div>';
  }

  /* ---------- ключ и модели ---------- */
  function renderConfig() {
    const c = S.config; if (!c) return;
    const st = $('#keyStatus');
    st.className = 'note ' + (c.hasKey ? 'ok' : 'bad');
    st.textContent = c.hasKey
      ? 'Ключ задан: ' + c.keyHint + ' · источник: ' + (c.keySource === 'admin' ? 'админ-панель' : 'сервер (переменная окружения)') + (c.keySource === 'admin' ? (c.encryptedAtRest ? ' · зашифрован на диске' : ' · НЕ зашифрован на диске (задай CONFIG_SECRET на сервере)') : '')
      : 'Ключ не задан. Бесплатный режим не работает.';
    $('#freeModel').value = c.freeModel || ''; $('#proModel').value = c.proModel || '';
    $('#unlimitedDays').value = c.unlimitedDays; $('#dailyLimit').value = c.dailyLimit; $('#proDailyLimit').value = c.proDailyLimit;
    renderBrief();
  }
  function bindKey() {
    $('#testKey').onclick = function () {
      busyBtn(this, async () => {
        const k = $('#newKey').value.trim();
        $('#keyOut').className = 'note'; $('#keyOut').textContent = 'Проверяю…';
        const r = await api('POST', '/admin/test-key', k ? { openrouterKey: k } : {});
        if (!r.ok) { $('#keyOut').className = 'note bad'; $('#keyOut').textContent = errText(r); return; }
        $('#keyOut').className = 'note ' + (r.data.ok ? 'ok' : 'bad'); $('#keyOut').textContent = r.data.message || '';
      });
    };
    $('#saveKey').onclick = function () {
      busyBtn(this, async () => {
        const k = $('#newKey').value.trim();
        if (!k) { $('#keyOut').className = 'note bad'; $('#keyOut').textContent = 'Вставь новый ключ в поле.'; return; }
        if (!(await confirmDialog('Заменить общий ключ ИИ? Он сразу начнёт использоваться во всех пользовательских приложениях.', 'Заменить'))) return;
        const r = await api('PUT', '/admin/config', { openrouterKey: k });
        if (!r.ok) { $('#keyOut').className = 'note bad'; $('#keyOut').textContent = errText(r); return; }
        $('#newKey').value = ''; S.config = r.data; renderConfig();
        $('#keyOut').className = 'note ok'; $('#keyOut').textContent = 'Ключ применён для всех пользователей.';
      });
    };
    $('#clearKey').onclick = function () {
      busyBtn(this, async () => {
        if (!(await confirmDialog('Удалить ключ, заданный через админку? Если на сервере нет резервного ключа, бесплатный режим перестанет работать.', 'Удалить'))) return;
        const r = await api('PUT', '/admin/config', { clearKey: true });
        if (!r.ok) { toast(errText(r)); return; }
        S.config = r.data; renderConfig(); toast('Ключ удалён');
      });
    };
    $('#saveModels').onclick = function () {
      busyBtn(this, async () => {
        const r = await api('PUT', '/admin/config', { freeModel: $('#freeModel').value.trim(), proModel: $('#proModel').value.trim() });
        const o = $('#modelOut');
        if (!r.ok) { o.className = 'note bad'; o.textContent = errText(r); return; }
        S.config = r.data; renderConfig(); o.className = 'note ok'; o.textContent = 'Модели сохранены и действуют для всех.';
      });
    };
    $('#saveLimits').onclick = function () {
      busyBtn(this, async () => {
        const body = { unlimitedDays: $('#unlimitedDays').value, dailyLimit: $('#dailyLimit').value, proDailyLimit: $('#proDailyLimit').value };
        for (const k in body) if (body[k] === '' || Number(body[k]) < 0) { $('#limitsOut').className = 'note bad'; $('#limitsOut').textContent = 'Укажи неотрицательные числа во всех полях.'; return; }
        const r = await api('PUT', '/admin/config', body);
        const o = $('#limitsOut');
        if (!r.ok) { o.className = 'note bad'; o.textContent = errText(r); return; }
        S.config = r.data; renderConfig(); o.className = 'note ok'; o.textContent = 'Лимиты сохранены.';
      });
    };
  }

  /* ---------- пользователи ---------- */
  let searchTimer = 0, userReq = 0;
  async function loadUsers() {
    const my = ++userReq;
    const q = $('#userSearch').value.trim();
    $('#usersMeta').textContent = 'Загрузка…';
    const r = await api('GET', '/admin/users' + (q ? '?q=' + encodeURIComponent(q) : ''));
    if (my !== userReq) return;                       // устаревший ответ игнорируется
    if (!r.ok) { $('#usersMeta').textContent = errText(r); handleAuthFail(r); return; }
    S.loaded.users = true;
    const list = (r.data && r.data.users) || [];
    $('#usersMeta').textContent = list.length ? 'Найдено: ' + list.length + (list.length >= 200 ? ' (показаны первые 200)' : '') : '';
    const box = $('#ulist'); box.innerHTML = '';
    if (!list.length) { box.innerHTML = '<div class="empty-note">Пользователей пока нет</div>'; return; }
    list.forEach(u => box.appendChild(userCard(u)));
  }
  function badges(u) {
    let h = '';
    if (u.blocked) h += '<span class="badge bad">заблокирован</span>';
    h += u.plan === 'pro' ? '<span class="badge pro">Pro' + (u.planUntil ? ' до ' + esc(new Date(u.planUntil).toLocaleDateString()) : '') + '</span>' : '<span class="badge">Free</span>';
    return h;
  }
  function usageLine(u) {
    const st = u.status || {};
    const lim = u.dailyLimitOverride != null ? ' (свой лимит ' + u.dailyLimitOverride + ')' : '';
    const today = st.phase === 'unlimited' ? 'сегодня ' + st.usedToday + ' (безлимитный период)' : 'сегодня ' + (st.usedToday || 0) + ' из ' + (st.dailyLimit == null ? '–' : st.dailyLimit);
    const last = u.lastSeen ? new Date(u.lastSeen).toLocaleString() : 'нет данных';
    return today + lim + ' · всего ' + (u.total || 0) + ' · был: ' + last;
  }
  function userCard(u) {
    const card = document.createElement('div');
    card.className = 'ucard glass'; card.dataset.sub = u.sub;
    card.innerHTML = '<button class="uhead"><b></b><div class="bd"></div><small></small></button>' +
      '<div class="uact">' +
      '<div class="note">Тариф</div><div class="row"><button class="btn primary" data-a="pro30">Pro 30 дн.</button><button class="btn primary" data-a="pro365">Pro 365 дн.</button><button class="btn ghost" data-a="proinf">Pro без срока</button><button class="btn ghost" data-a="free">Снять Pro</button></div>' +
      '<div class="note">Доступ</div><div class="row"><button class="btn danger" data-a="block"></button></div>' +
      '<div class="note">Свой лимит запросов в день</div><div class="row"><input class="field num" type="number" min="0" inputmode="numeric" placeholder="число"><button class="btn ghost" data-a="limit">Применить</button><button class="btn ghost" data-a="limitreset">Сбросить</button></div>' +
      '<div class="note dim sub"></div></div>';
    fillCard(card, u);
    $('.uhead', card).onclick = () => card.classList.toggle('open');
    card.addEventListener('click', e => {
      const b = e.target.closest('[data-a]'); if (!b) return;
      busyBtn(b, () => userAction(card, b.dataset.a));
    });
    return card;
  }
  function fillCard(card, u) {
    card.dataset.json = JSON.stringify(u);
    $('.uhead b', card).textContent = u.email || u.sub;
    $('.bd', card).innerHTML = badges(u);
    $('.uhead small', card).textContent = usageLine(u);
    $('[data-a="block"]', card).textContent = u.blocked ? 'Разблокировать' : 'Заблокировать';
    $('.sub', card).textContent = 'ID: ' + u.sub;
  }
  async function userAction(card, action) {
    const u = safeJson(card.dataset.json, null); if (!u) return;
    const who = u.email || u.sub;
    let body = null;
    if (action === 'pro30') body = { plan: 'pro', days: 30 };
    else if (action === 'pro365') body = { plan: 'pro', days: 365 };
    else if (action === 'proinf') body = { plan: 'pro' };
    else if (action === 'free') { if (!(await confirmDialog('Снять JARVIS Pro у ' + who + '?', 'Снять'))) return; body = { plan: 'free' }; }
    else if (action === 'block') {
      const next = !u.blocked;
      if (!(await confirmDialog((next ? 'Заблокировать ' : 'Разблокировать ') + who + '?', next ? 'Заблокировать' : 'Разблокировать'))) return;
      body = { blocked: next };
    } else if (action === 'limit') {
      const v = $('.num', card).value;
      if (v === '' || Number(v) < 0 || !Number.isFinite(Number(v))) { toast('Введи число от 0'); return; }
      body = { dailyLimit: Number(v) };
    } else if (action === 'limitreset') body = { dailyLimit: null };
    if (!body) return;
    const r = await api('PATCH', '/admin/users/' + encodeURIComponent(u.sub), body);
    if (!r.ok) { toast(errText(r)); handleAuthFail(r); return; }
    fillCard(card, r.data);                           // обновляем только эту карточку
    toast('Готово: ' + who);
  }

  /* ---------- события Android ---------- */
  const H = {
    api: d => { const f = pending[d.reqId]; if (!f) return; delete pending[d.reqId]; f({ ok: !!d.ok, status: d.status, code: d.code, data: safeJson(d.body, null) }); },
    auth: d => {
      const err = d.error; delete d.error; S.profile = d; who();
      if (d.signedIn) checkAdmin();
      else { S.isAdmin = false; $('#logout').hidden = true; $('#tabs').hidden = true; gateSignIn(authHint(err)); }
    }
  };
  window.AdminEvents = { emit: function (name, json) { if (H[name]) { try { H[name](safeJson(json, {})); } catch (e) { console.error(name, e); } } } };

  /* ---------- запуск ---------- */
  function init() {
    $('#searchIc').innerHTML = ic('search', 18); $('#logout').innerHTML = ic('out', 20);
    $$('#tabs button').forEach(b => { const t = TAB_TITLES[b.dataset.tab]; b.innerHTML = ic(t[0], 22) + '<span>' + t[1] + '</span>'; b.onclick = () => openTab(b.dataset.tab, false); });
    $('#logout').onclick = async () => { if (await confirmDialog('Выйти из админ-панели?', 'Выйти')) native('signOut'); };
    $('#refreshStats').onclick = () => loadOverview();
    $('#userSearch').oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadUsers, 350); };
    bindKey();
    window.adminBack = () => { if (!$('#dialog').hidden) { $('#dialogNo').click(); return true; } if (S.isAdmin && S.tab !== 'overview') { openTab('overview', false); return true; } return false; };
    const st = safeJson(native('getState'), null);
    if (!st || !st.configured) { S.configured = false; gateNotConfigured(); return; }
    S.configured = true; S.host = st.backendHost || ''; S.profile = st.profile || {}; who();
    if (S.profile.signedIn) checkAdmin(); else gateSignIn('');
  }
  init();
})();
