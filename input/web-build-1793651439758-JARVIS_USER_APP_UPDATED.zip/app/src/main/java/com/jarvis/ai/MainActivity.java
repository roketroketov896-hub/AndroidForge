package com.jarvis.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.view.SurfaceHolder;
import android.view.WindowManager;
import android.view.SurfaceView;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Окно приложения. Порядок запуска:
 * 1) сразу играет нативная видеозаставка (res/raw/jarvis_splash.mp4, оригинальный звук);
 * 2) как только пошёл первый кадр, параллельно создаются WebView с интерфейсом и голосовые компоненты,
 *    а в фоне идёт сетевая подготовка (настройки сервера, предпрогрев токена);
 * 3) когда видео закончилось и интерфейс готов, заставка плавно исчезает.
 * Сервер и ИИ-провайдер на готовность интерфейса не влияют.
 */
public class MainActivity extends Activity implements Emitter {
    static final int REQ_AUDIO = 701;
    static final int REQ_PROJECTION = 702;
    static final int REQ_NOTIF = 703;

    /** Заставка играет один раз за запуск процесса, а не при каждом пересоздании окна. */
    private static boolean splashDoneThisProcess = false;

    WebView webView;
    JarvisSettings settings;
    SecureStore store;
    AuthManager auth;
    TtsController tts;
    OnlineTts online;
    SpeechInput speech;
    final ChatClient chat = new ChatClient();
    final ExecutorService executor = Executors.newCachedThreadPool();
    final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private FrameLayout root;
    private String pendingLang = "ru";
    private boolean pendingContinuous = false;
    private boolean servicesReady = false;

    // заставка
    private boolean splashActive = false;
    private boolean videoDone = false;
    private boolean uiReady = false;
    private boolean readyTimeout = false;
    private boolean backgroundStarted = false;
    private boolean resumed = false;
    private boolean prepared = false;
    private SurfaceView surface;
    private View cover;
    private ProgressBar spinner;
    private MediaPlayer player;

    // подготовка в фоне
    private volatile String appConfigJson = "";
    private volatile boolean serverChecked = false;
    private volatile boolean serverOk = false;
    private volatile boolean bootstrapRunning = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("jarvis_settings", MODE_PRIVATE);
        settings = new JarvisSettings(prefs);
        store = new SecureStore(prefs);
        auth = new AuthManager(prefs, store);

        getWindow().setStatusBarColor(Color.parseColor("#05070F"));
        getWindow().setNavigationBarColor(Color.parseColor("#05070F"));

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#05070F"));
        setContentView(root);

        ScreenShareService.listener = new ScreenShareService.Listener() {
            @Override
            public void onStarted() {
                emit("screen", json("state", "started"));
            }

            @Override
            public void onFrame(String dataUrl) {
                emit("screen", json("state", "frame", "image", dataUrl));
            }

            @Override
            public void onStopped(String reason) {
                emit("screen", json("state", "stopped", "reason", reason));
            }
        };

        LiveVoiceService.listener = new LiveVoiceService.Listener() {
            @Override
            public void onStopped() {
                emit("live", json("state", "stopped"));
            }
        };

        if (splashDoneThisProcess) {
            startBackground();
        } else {
            startSplash();
        }
    }

    // ---------- заставка ----------

    private void startSplash() {
        splashActive = true;
        surface = new SurfaceView(this);
        surface.setZOrderMediaOverlay(true);
        root.addView(surface, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        cover = new View(this);
        cover.setBackgroundColor(Color.parseColor("#05070F"));
        cover.setAlpha(0f);
        cover.setClickable(true); // не пропускает касания в WebView под заставкой
        root.addView(cover, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        surface.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                if (player == null && !videoDone) prepareVideo(holder);
                else if (player != null) player.setDisplay(holder);
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                if (player != null) {
                    try {
                        player.setDisplay(null);
                    } catch (Exception ignored) {
                    }
                }
            }
        });
    }

    private void prepareVideo(SurfaceHolder holder) {
        try {
            player = new MediaPlayer();
            AssetFileDescriptor afd = getResources().openRawResourceFd(R.raw.jarvis_splash);
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            player.setDisplay(holder);
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build());
            player.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                @Override
                public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
                    fitVideo(width, height);
                }
            });
            player.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                @Override
                public boolean onInfo(MediaPlayer mp, int what, int extra) {
                    if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) startBackground();
                    return false;
                }
            });
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    videoDone = true;
                    maybeFinishSplash();
                }
            });
            player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    // Заставка не должна блокировать приложение: пропускаем её.
                    videoDone = true;
                    startBackground();
                    maybeFinishSplash();
                    return true;
                }
            });
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    prepared = true;
                    if (resumed) mp.start();
                    main.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startBackground(); // если событие первого кадра не пришло
                        }
                    }, 700);
                }
            });
            player.prepareAsync();
        } catch (Exception e) {
            videoDone = true;
            startBackground();
            maybeFinishSplash();
        }
    }

    /** Вписывает видео в экран без растяжения и обрезки. */
    private void fitVideo(final int vw, final int vh) {
        if (vw <= 0 || vh <= 0) return;
        root.post(new Runnable() {
            @Override
            public void run() {
                int pw = root.getWidth(), ph = root.getHeight();
                if (pw <= 0 || ph <= 0 || surface == null) return;
                float scale = Math.min((float) pw / vw, (float) ph / vh);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                        Math.round(vw * scale), Math.round(vh * scale), Gravity.CENTER);
                surface.setLayoutParams(lp);
            }
        });
    }

    private void maybeFinishSplash() {
        if (!splashActive || !videoDone) return;
        if (uiReady || readyTimeout) {
            finishSplash();
            return;
        }
        // Видео закончилось, а интерфейс ещё готовится: показываем аккуратный индикатор и ждём, но не бесконечно.
        if (spinner == null) {
            spinner = new ProgressBar(this);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(96, 96, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            lp.bottomMargin = 120;
            spinner.setVisibility(View.GONE);
            root.addView(spinner, lp);
            main.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (spinner != null && splashActive) spinner.setVisibility(View.VISIBLE);
                }
            }, 400);
            main.postDelayed(new Runnable() {
                @Override
                public void run() {
                    readyTimeout = true;
                    maybeFinishSplash();
                }
            }, 8000);
        }
    }

    private void finishSplash() {
        if (!splashActive) return;
        splashActive = false;
        splashDoneThisProcess = true;
        cover.animate().alpha(1f).setDuration(160).withEndAction(new Runnable() {
            @Override
            public void run() {
                releasePlayer();
                if (surface != null) root.removeView(surface);
                if (spinner != null) root.removeView(spinner);
                surface = null;
                spinner = null;
                cover.animate().alpha(0f).setDuration(240).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        if (cover != null) root.removeView(cover);
                        cover = null;
                    }
                }).start();
            }
        }).start();
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
        }
    }

    /** Вызывается интерфейсом, когда он отрисован и история загружена. */
    void onUiReady() {
        uiReady = true;
        pushBootstrap();
        maybeFinishSplash();
    }

    // ---------- фоновая подготовка ----------

    /** Один раз: создаёт голосовые компоненты и WebView и запускает сетевую подготовку. */
    private void startBackground() {
        if (backgroundStarted) return;
        backgroundStarted = true;
        main.post(new Runnable() {
            @Override
            public void run() {
                initServices();
                createWebView();
                bootstrapAsync();
            }
        });
    }

    private void initServices() {
        if (servicesReady) return;
        servicesReady = true;
        tts = new TtsController(this, settings, this);
        speech = new SpeechInput(this, this);
        online = new OnlineTts(this, this, new OnlineTts.Source() {
            @Override
            public String baseUrl() {
                return normalizeBase(BuildConfig.BACKEND_URL);
            }

            @Override
            public String token() {
                return auth.ensureToken(MainActivity.this, BuildConfig.WEB_CLIENT_ID);
            }
        });
    }

    static String normalizeBase(String url) {
        String u = url == null ? "" : url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u.startsWith("https://") ? u : "";
    }

    boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    /** Сетевая подготовка не блокирует запуск: результат приходит в интерфейс событием. */
    void bootstrapAsync() {
        if (bootstrapRunning) return;
        bootstrapRunning = true;
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String base = normalizeBase(BuildConfig.BACKEND_URL);
                    if (!base.isEmpty()) {
                        try {
                            ChatClient.Result r = ChatClient.request("GET", base + "/v1/app-config", null, null);
                            serverOk = r.status == 200;
                            if (serverOk) appConfigJson = r.body;
                        } catch (Exception e) {
                            serverOk = false;
                        }
                    }
                    serverChecked = true;
                    pushBootstrap();
                    // Предпрогрев токена для уже вошедшего пользователя. Неудача не разлогинивает: токен получится при первом запросе.
                    if (auth.isSignedIn() && !BuildConfig.WEB_CLIENT_ID.isEmpty() && !base.isEmpty()) {
                        auth.ensureToken(MainActivity.this, BuildConfig.WEB_CLIENT_ID);
                    }
                } finally {
                    bootstrapRunning = false;
                }
            }
        });
    }

    void retryBootstrap() {
        serverChecked = false;
        bootstrapAsync();
    }

    void pushBootstrap() {
        if (!uiReady || !serverChecked) return;
        JSONObject d = json("serverChecked", true, "serverOk", serverOk, "online", isOnline(),
                "backendConfigured", !normalizeBase(BuildConfig.BACKEND_URL).isEmpty(), "appConfig", appConfigJson);
        emit("bootstrap", d);
    }

    // ---------- WebView ----------

    private void createWebView() {
        if (webView != null) return;
        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#05070F"));
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setSupportMultipleWindows(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);
        ws.setGeolocationEnabled(false);
        ws.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }

            /** Внешние ресурсы внутри страницы запрещены, кроме аватара Google. */
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    String host = u.getHost();
                    if (host == null || !host.endsWith(".googleusercontent.com")) {
                        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked",
                                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                    }
                }
                return null;
            }
        });
        webView.addJavascriptInterface(new JarvisBridge(this), "JarvisBridge");
        root.addView(webView, 0, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        webView.loadUrl("file:///android_asset/index.html");
    }

    private static JSONObject json(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return o;
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if ("file".equals(scheme)) return false;
        if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
            }
        }
        return true;
    }

    @Override
    public void emit(String event, JSONObject data) {
        final String js = "window.JarvisEvents&&window.JarvisEvents.emit("
                + JSONObject.quote(event) + "," + JSONObject.quote(data.toString()) + ")";
        main.post(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.evaluateJavascript(js, null);
            }
        });
    }

    // ---------- озвучивание: выбор движка и единое управление ----------

    private boolean wantsOnline() {
        return "online".equals(settings.str("ttsEngine"));
    }

    void speakText(String id, String text, String lang) {
        speakText(id, text, lang, false);
    }

    /** keepMic=true: не прерывать распознавание речи (Live с наушниками, чтобы можно было перебить). */
    void speakText(String id, String text, String lang, boolean keepMic) {
        if (!servicesReady) return;
        if (!keepMic) speech.cancel();
        if (wantsOnline()) {
            tts.stop();
            if (normalizeBase(BuildConfig.BACKEND_URL).isEmpty() || !auth.isSignedIn()) {
                emit("ttsError", json("code", "online_unavailable", "message",
                        "Нейро-голос требует входа через Google и подключённого сервера. Выбери системный голос в настройках.", "lang", lang));
                return;
            }
            online.speak(id, text, lang);
        } else {
            online.stop();
            tts.speak(id, text, lang);
        }
    }

    void pauseSpeech() {
        if (!servicesReady) return;
        tts.pause();
        online.pause();
    }

    void resumeSpeech() {
        if (!servicesReady) return;
        tts.resume();
        online.resume();
    }

    void stopSpeech() {
        if (!servicesReady) return;
        tts.stop();
        online.stop();
    }

    // ---------- микрофон ----------

    void beginListening(String lang) {
        beginListening(lang, true, false);
    }

    /** interrupt: остановить речь JARVIS перед записью; continuous: диктовка без остановки на паузах. */
    void beginListening(String lang, boolean interrupt, boolean continuous) {
        if (!servicesReady) return;
        pendingLang = (lang == null || lang.isEmpty()) ? "ru" : lang;
        pendingContinuous = continuous;
        if (interrupt) stopSpeech();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        startRecognition();
    }

    private void startRecognition() {
        if (pendingContinuous) speech.startContinuous(pendingLang);
        else speech.start(pendingLang);
    }

    boolean hasHeadset() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int t = d.getType();
                if (t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                        || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    void keepScreenOn(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // ---------- Live Voice в фоне ----------

    /** Только по нажатию пользователя. Нужны разрешение микрофона и уведомления; служба показывает уведомление с кнопкой «Стоп». */
    void startLiveService() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            emit("live", json("state", "need_mic"));
            return;
        }
        try {
            Intent i = new Intent(this, LiveVoiceService.class).setAction(LiveVoiceService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            emit("live", json("state", "started"));
        } catch (Exception e) {
            emit("live", json("state", "error"));
        }
    }

    void stopLiveService() {
        try {
            stopService(new Intent(this, LiveVoiceService.class));
        } catch (Exception ignored) {
        }
    }

    // ---------- показ экрана ----------

    void requestScreenShare() {
        if (ScreenShareService.running) {
            emit("screen", json("state", "started"));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        launchProjection();
    }

    private void launchProjection() {
        try {
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQ_PROJECTION);
        } catch (Exception e) {
            emit("screen", json("state", "error", "reason", "no_projection"));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PROJECTION) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent i = new Intent(this, ScreenShareService.class)
                    .setAction(ScreenShareService.ACTION_START)
                    .putExtra("code", resultCode)
                    .putExtra("data", data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } else {
            emit("screen", json("state", "denied"));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_AUDIO) {
            if (granted) {
                main.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startRecognition();
                    }
                }, 200);
            } else {
                boolean permanent = !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO);
                emit("speech", json("type", "error", "code", "permission_denied", "permanent", permanent));
            }
        } else if (requestCode == REQ_NOTIF) {
            launchProjection();
        }
    }

    // ---------- жизненный цикл ----------

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (player != null && prepared && splashActive && !videoDone) {
            try {
                player.start();
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onPause() {
        resumed = false;
        if (player != null && prepared && splashActive) {
            try {
                if (player.isPlaying()) player.pause();
            } catch (Exception ignored) {
            }
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (splashActive || webView == null) return; // во время заставки «Назад» ничего не делает
        webView.evaluateJavascript("window.jarvisBack?String(window.jarvisBack()):'false'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value == null || !value.contains("true")) MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onStop() {
        // Когда приложение уходит с экрана, звук и запись прекращаются, КРОМЕ включённого пользователем Live Voice
        // (он виден в уведомлении и останавливается кнопкой).
        if (servicesReady && !LiveVoiceService.running) {
            stopSpeech();
            speech.cancel();
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        ScreenShareService.listener = null;
        LiveVoiceService.listener = null;
        stopLiveService();
        stopService(new Intent(this, ScreenShareService.class));
        releasePlayer();
        if (servicesReady) {
            tts.shutdown();
            online.shutdown();
            speech.cancel();
        }
        executor.shutdownNow();
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
