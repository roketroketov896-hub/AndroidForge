package com.jarvis.ai;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Открытие приложений по явной команде пользователя через обычные Android Intents (без касаний и ввода).
 * Установлено: запускается. Не установлено: открывается Google Play (страница приложения, если пакет известен,
 * иначе поиск по названию).
 */
final class AppLauncher {
    private static final Map<String, String> KNOWN = new HashMap<String, String>();

    private static void alias(String pkg, String... names) {
        for (String n : names) KNOWN.put(n, pkg);
    }

    static {
        alias("com.google.android.youtube", "youtube", "ютуб", "ютьюб", "you tube", "yutub");
        alias("com.whatsapp", "whatsapp", "ватсап", "вотсап", "вацап", "уотсап");
        alias("org.telegram.messenger", "telegram", "телеграм", "телеграмм", "телега");
        alias("com.instagram.android", "instagram", "инстаграм", "инста");
        alias("com.zhiliaoapp.musically", "tiktok", "тикток", "tik tok");
        alias("com.facebook.katana", "facebook", "фейсбук");
        alias("com.spotify.music", "spotify", "спотифай");
        alias("com.android.chrome", "chrome", "хром", "google chrome");
        alias("com.google.android.gm", "gmail", "гмейл", "джимейл", "почта gmail");
        alias("com.google.android.apps.maps", "maps", "google maps", "карты", "гугл карты", "xəritə", "harita");
        alias("com.netflix.mediaclient", "netflix", "нетфликс");
        alias("com.viber.voip", "viber", "вайбер");
        alias("com.discord", "discord", "дискорд");
        alias("com.snapchat.android", "snapchat", "снапчат");
        alias("com.twitter.android", "twitter", "твиттер", "x");
        alias("com.ubercab", "uber", "убер");
        alias("us.zoom.videomeetings", "zoom", "зум");
        alias("com.skype.raider", "skype", "скайп");
        alias("com.vkontakte.android", "vk", "вк", "вконтакте");
        alias("com.google.android.apps.photos", "google photos", "гугл фото", "фото");
        alias("com.google.android.apps.translate", "translate", "переводчик", "google translate");
        alias("com.android.vending", "google play", "play market", "плей маркет", "гугл плей", "play store");
        alias("ru.yandex.searchplugin", "yandex", "яндекс");
        alias("com.google.android.calendar", "calendar", "календарь");
        alias("com.google.android.apps.docs", "google drive", "драйв", "гугл диск");
    }

    private AppLauncher() {
    }

    private static boolean any(String q, String... names) {
        for (String n : names) if (q.equals(n)) return true;
        return false;
    }

    private static JSONObject result(boolean ok, String message, boolean store) {
        JSONObject r = new JSONObject();
        try {
            r.put("ok", ok);
            r.put("message", message);
            r.put("store", store);
        } catch (Exception ignored) {
        }
        return r;
    }

    /** Открывает Google Play: сначала приложение Play, при его отсутствии браузер. Выполняется на UI-потоке. */
    private static void openStore(final Activity act, final String pkg, final String query) {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String marketUri = pkg != null ? "market://details?id=" + pkg : "market://search?q=" + Uri.encode(query) + "&c=apps";
                String webUri = pkg != null ? "https://play.google.com/store/apps/details?id=" + pkg
                        : "https://play.google.com/store/search?q=" + Uri.encode(query) + "&c=apps";
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(marketUri));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(i);
                } catch (Exception e) {
                    try {
                        Intent w = new Intent(Intent.ACTION_VIEW, Uri.parse(webUri));
                        w.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        act.startActivity(w);
                    } catch (Exception ignored) {
                    }
                }
            }
        });
    }

    static JSONObject open(final Activity act, String rawName) {
        try {
            String q = rawName == null ? "" : rawName.toLowerCase(Locale.ROOT).trim();
            q = q.replaceAll("[\\p{Punct}]", " ").replaceAll("\\s+", " ").trim();
            q = q.replaceAll("^(приложение|app|uygulama|tətbiq)\\s+", "")
                 .replaceAll("\\s+(приложение|app|uygulaması|tətbiqi)$", "").trim();
            if (q.isEmpty()) return result(false, "Не понял, какое приложение открыть.", false);

            Intent intent = null;
            String label = rawName;
            if (any(q, "настройки", "настройка", "settings", "ayarlar", "parametrlər", "tənzimləmələr")) {
                intent = new Intent(Settings.ACTION_SETTINGS);
                label = "Настройки";
            } else if (any(q, "браузер", "browser", "tarayıcı", "brauzer", "интернет", "internet")) {
                intent = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
                label = "Браузер";
            } else if (any(q, "камера", "camera", "kamera")) {
                intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                label = "Камера";
            }

            PackageManager pm = act.getPackageManager();
            String knownPkg = KNOWN.get(q);

            if (intent == null) {
                // 1) известный пакет, установленный на телефоне
                if (knownPkg != null) {
                    Intent li = pm.getLaunchIntentForPackage(knownPkg);
                    if (li != null) {
                        intent = li;
                        label = rawName;
                    }
                }
            }
            if (intent == null) {
                // 2) поиск среди установленных приложений по названию
                Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
                ResolveInfo best = null;
                int bestScore = -1;
                for (ResolveInfo ri : apps) {
                    String l = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT).trim();
                    int score = -1;
                    if (l.equals(q)) score = 1000;
                    else if (l.contains(q) || q.contains(l)) score = 500 - Math.abs(l.length() - q.length());
                    if (score > bestScore) {
                        bestScore = score;
                        best = ri;
                    }
                }
                if (best != null && bestScore >= 0) {
                    intent = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
                    label = best.loadLabel(pm).toString();
                }
            }
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                final Intent launch = intent;
                act.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            act.startActivity(launch);
                        } catch (Exception ignored) {
                        }
                    }
                });
                return result(true, "Открываю: " + label, false);
            }
            // 3) приложения нет на телефоне: Google Play
            if (knownPkg != null) {
                openStore(act, knownPkg, q);
                return result(true, "Приложение «" + rawName + "» не установлено. Открываю его в Google Play.", true);
            }
            if (q.split(" ").length <= 2) {
                openStore(act, null, q);
                return result(true, "Не нашёл «" + rawName + "» на телефоне. Ищу в Google Play.", true);
            }
            return result(false, "Приложение «" + rawName + "» не найдено на этом телефоне.", false);
        } catch (Exception e) {
            return result(false, "Не удалось открыть приложение.", false);
        }
    }
}
