from pathlib import Path
p=Path('/mnt/data/jarvis_work/app/src/main/java/com/jarvis/ai/MainActivity.java')
s=p.read_text()
for old,new in [
('import android.content.Intent;','import android.content.Intent;\nimport android.database.Cursor;\nimport android.provider.OpenableColumns;\nimport android.util.Base64;\nimport java.io.InputStream;\nimport java.io.ByteArrayOutputStream;'),
('    static final int REQ_NOTIF = 703;','    static final int REQ_NOTIF = 703;\n    static final int REQ_FILES = 704;'),
('''        if (splashDoneThisProcess) {
            startBackground();
        } else {
            startSplash();
        }''','''        // Direct entry: the old video opening was intentionally removed.
        splashDoneThisProcess = true;
        startBackground();'''),
('getWindow().setStatusBarColor(Color.parseColor("#05070F"));','getWindow().setStatusBarColor(Color.parseColor("#08070D"));'),
('getWindow().setNavigationBarColor(Color.parseColor("#05070F"));','getWindow().setNavigationBarColor(Color.parseColor("#08070D"));'),
('root.setBackgroundColor(Color.parseColor("#05070F"));','root.setBackgroundColor(Color.parseColor("#08070D"));')]:
    s=s.replace(old,new)
needle='''    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {'''
insert=r'''    void launchFilePicker() {
        try {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("*/*");
            pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(Intent.createChooser(pick, "Выбрать файлы для JARVIS"), REQ_FILES);
        } catch (Exception e) {
            emit("filePicked", json("ok", false, "error", "Не удалось открыть выбор файлов."));
        }
    }

    private void emitPickedFile(Uri uri) {
        executor.execute(() -> {
            try {
                String name = "Файл";
                long size = -1;
                String mime = getContentResolver().getType(uri);
                try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
                    if (c != null && c.moveToFirst()) {
                        int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        int si = c.getColumnIndex(OpenableColumns.SIZE);
                        if (ni >= 0) name = c.getString(ni);
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                    }
                }
                if (name.toLowerCase(java.util.Locale.ROOT).endsWith(".apk")) {
                    emit("filePicked", json("ok", false, "error", "APK-файлы пока не поддерживаются."));
                    return;
                }
                if (size > 12L * 1024 * 1024) {
                    emit("filePicked", json("ok", false, "error", "Файл больше 12 МБ. Пока выбери файл меньшего размера."));
                    return;
                }
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IllegalStateException("empty_stream");
                    byte[] buf = new byte[8192]; int n; int total = 0;
                    while ((n = in.read(buf)) > 0) { total += n; if (total > 12 * 1024 * 1024) throw new IllegalStateException("file_too_large"); out.write(buf, 0, n); }
                    if (size < 0) size = total;
                }
                String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                emit("filePicked", json("ok", true, "name", name, "mime", mime == null ? "application/octet-stream" : mime, "size", size, "data", b64));
            } catch (Exception e) {
                emit("filePicked", json("ok", false, "error", "Не удалось прочитать файл: " + e.getClass().getSimpleName()));
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {'''
s=s.replace(needle,insert)
s=s.replace('''        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PROJECTION) return;''','''        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILES) {
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    for (int i = 0; i < data.getClipData().getItemCount(); i++) emitPickedFile(data.getClipData().getItemAt(i).getUri());
                } else if (data.getData() != null) emitPickedFile(data.getData());
            }
            return;
        }
        if (requestCode != REQ_PROJECTION) return;''')
p.write_text(s)

p=Path('/mnt/data/jarvis_work/app/src/main/java/com/jarvis/ai/JarvisBridge.java')
s=p.read_text()
s=s.replace('''    // ---------- чат ----------
''','''    @JavascriptInterface
    public void openFilePicker() {
        ui(new Runnable() { @Override public void run() { act.launchFilePicker(); } });
    }

    // ---------- чат ----------
''')
p.write_text(s)
