from pathlib import Path
import re
root=Path('/mnt/data/jarvis_work')
css=root/'app/src/main/assets/style.css'
s=css.read_text()
# Theme: black + violet + lilac + white, restrained glassmorphism
s=s.replace('--bg:#05070f; --text:#eaf0ff; --muted:#8f9bb8; --dim:#66718f;', '--bg:#08070d; --text:#f3efff; --muted:#aaa1bd; --dim:#746b86;')
s=s.replace('--glass:rgba(255,255,255,.055); --glass2:rgba(255,255,255,.09); --line:rgba(255,255,255,.12);', '--glass:rgba(255,255,255,.045); --glass2:rgba(255,255,255,.075); --line:rgba(210,190,255,.14);')
s=s.replace('--cyan:#5be3ff; --blue:#5b8cff; --violet:#a46bff; --danger:#ff6b8a; --ok:#5dffb0;', '--cyan:#b58aff; --blue:#7840e8; --violet:#c9aaff; --danger:#ff7898; --ok:#a7e6c1;')
s=s.replace('--grad:linear-gradient(135deg,#5be3ff 0%,#5b8cff 52%,#a46bff 100%);', '--grad:linear-gradient(135deg,#f7f1ff 0%,#c8aaff 42%,#7b35ed 100%);')
s=s.replace('background:radial-gradient(circle,#2a5cff,transparent 65%)','background:radial-gradient(circle,#5420a5,transparent 65%)')
s=s.replace('background:radial-gradient(circle,#7a3bff,transparent 65%)','background:radial-gradient(circle,#7d35e8,transparent 65%)')
s=s.replace('background:radial-gradient(circle,#00c8ff,transparent 65%);opacity:.35','background:radial-gradient(circle,#b58aff,transparent 65%);opacity:.22')
s=s.replace('background:rgba(18,22,40,.92)','background:rgba(17,13,25,.94)')
s=s.replace('rgba(91,227,255,.35)','rgba(151,83,255,.28)').replace('rgba(91,140,255,.35)','rgba(123,53,237,.28)').replace('rgba(91,227,255,.16)','rgba(151,83,255,.13)').replace('rgba(91,227,255,.18)','rgba(151,83,255,.15)').replace('rgba(91,140,255,.45)','rgba(123,53,237,.38)').replace('rgba(91,227,255,.12)','rgba(151,83,255,.12)').replace('rgba(91,227,255,.5)','rgba(151,83,255,.45)')
s=s.replace('rgba(91,227,255,.42),rgba(91,140,255,.26) 38%,rgba(164,107,255,.12) 55%', 'rgba(190,151,255,.34),rgba(123,53,237,.25) 38%,rgba(75,31,145,.16) 55%')
s=s.replace('radial-gradient(circle at 34% 28%,#cdf8ff 0%,#63d0ff 20%,#3f74ff 52%,#2a1f8f 82%,#0b0a35 100%)', 'radial-gradient(circle at 34% 24%,#fffaff 0%,#d9c5ff 18%,#9b65f2 43%,#4b1ca5 72%,#10091d 100%)')
s=s.replace('rgba(8,6,60,.6)', 'rgba(12,5,28,.72)').replace('rgba(80,160,255,.55)', 'rgba(113,54,219,.48)')
s=s.replace('radial-gradient(circle,#8ff4ff,transparent 66%)','radial-gradient(circle,#f2eaff,transparent 66%)').replace('radial-gradient(circle,#b985ff,transparent 66%)','radial-gradient(circle,#b98aff,transparent 66%)').replace('radial-gradient(circle,#4f86ff,transparent 66%)','radial-gradient(circle,#7130dc,transparent 66%)')
s=s.replace('rgba(140,210,255,.28)', 'rgba(199,166,255,.24)')
s=s.replace('color:#04101f', 'color:#170d26').replace('color:#06101f', 'color:#170d26')
s=s.replace('rgba(30,50,140,.55)', 'rgba(63,25,112,.48)').replace('rgba(5,7,15,.98)', 'rgba(8,7,13,.98)').replace('rgba(34,58,160,.6)', 'rgba(73,30,135,.55)').replace('rgba(5,7,15,1)', 'rgba(8,7,13,1)')
# Tool activity cards
s += '''\n/* JARVIS agent activity / tool-use timeline */
.agent-card{margin:10px 0 12px;border:1px solid rgba(190,151,255,.18);border-radius:16px;background:rgba(28,19,42,.62);overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.18)}
.agent-summary{width:100%;display:flex;align-items:center;gap:10px;padding:12px 14px;text-align:left;color:var(--text);font-size:13px}
.agent-summary .agent-count{color:#d6baff;font-weight:650;flex:1}
.agent-summary .agent-state{color:var(--muted);font-size:12px}
.agent-list{padding:0 14px 12px 18px;display:grid;gap:10px}
.agent-step{display:grid;grid-template-columns:18px 1fr auto;gap:9px;align-items:start;font-size:13px;color:#e7def5}
.agent-step .step-icon{color:#bd98ff}.agent-step .step-status{font-size:11px;color:var(--muted)}
.agent-step.done .step-icon,.agent-step.done .step-status{color:#a7e6c1}
.agent-step.active .step-icon{color:#c8aaff;animation:agentPulse 1.3s ease-in-out infinite}
@keyframes agentPulse{50%{opacity:.45;transform:scale(.9)}}
.composer .plus-btn{width:40px;height:40px;border-radius:50%;flex:none;display:grid;place-items:center;background:rgba(255,255,255,.075);color:#e9ddff;border:1px solid rgba(190,151,255,.12)}
.composer .plus-btn:active{background:rgba(151,83,255,.2)}
.file-chip{display:flex;align-items:center;gap:8px;padding:8px 10px;margin:0 0 7px;border-radius:13px;background:rgba(38,25,56,.75);border:1px solid var(--line);font-size:12px;color:var(--muted)}
.file-chip span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.file-chip button{color:#d7c4f6;font-size:18px;padding:0 5px}
'''
css.write_text(s)

# Update HTML: plus control and file attachment strip
html=root/'app/src/main/assets/index.html'
h=html.read_text()
h=h.replace('<div class="attach glass" id="attach" hidden><img id="attachImg" alt=""><span>Снимок экрана приложен</span><button class="icon-btn small" id="attachRemove" aria-label="Убрать"></button></div>\n      <form class="composer glass" id="form">\n        <textarea', '<div class="attach glass" id="attach" hidden><img id="attachImg" alt=""><span>Снимок экрана приложен</span><button class="icon-btn small" id="attachRemove" aria-label="Убрать"></button></div>\n      <div id="fileAttachments" aria-live="polite"></div>\n      <form class="composer glass" id="form">\n        <button type="button" class="plus-btn" id="addFile" aria-label="Добавить файл"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></button>\n        <textarea')
html.write_text(h)

# Disable intro video: initialize app directly. Splash code remains unused for compatibility.
main=root/'app/src/main/java/com/jarvis/ai/MainActivity.java'
m=main.read_text()
m=m.replace('''        if (splashDoneThisProcess) {
            startBackground();
        } else {
            startSplash();
        }''','''        // Direct entry: the old video opening was intentionally removed.
        splashDoneThisProcess = true;
        startBackground();''')
m=m.replace('getWindow().setStatusBarColor(Color.parseColor("#05070F"));','getWindow().setStatusBarColor(Color.parseColor("#08070D"));')
m=m.replace('getWindow().setNavigationBarColor(Color.parseColor("#05070F"));','getWindow().setNavigationBarColor(Color.parseColor("#08070D"));')
m=m.replace('root.setBackgroundColor(Color.parseColor("#05070F"));','root.setBackgroundColor(Color.parseColor("#08070D"));')
main.write_text(m)
# Set app theme color
man=root/'app/src/main/AndroidManifest.xml'
a=man.read_text().replace('android:label="JARVIS AI"','android:label="JARVIS"')
man.write_text(a)
# Remove obsolete video asset to avoid carrying it in APK.
video=root/'app/src/main/res/raw/jarvis_splash.mp4'
if video.exists(): video.unlink()
