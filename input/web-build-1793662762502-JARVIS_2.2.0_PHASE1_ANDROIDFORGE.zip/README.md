# JARVIS AI — Android application

Single-module Android Gradle project.

- Application ID: `com.jarvis.ai`
- Version: `2.2.0` (versionCode 5)
- Backend: Cloudflare Worker configured in `jarvis-config.properties`
- Build task: `:app:assembleDebug`
- Minimum SDK: 23; compile/target SDK: 34

## AndroidForge

Upload this ZIP as the Android source project. AndroidForge detects Gradle projects and can regenerate a missing/corrupt Gradle wrapper. Select Android / Debug (or Auto). The project ZIP is the source project, not an APK.

## Current implementation notes

This delivery is an initial modernization pass, not a claim that every planned JARVIS feature is complete. It includes the dark violet theme, direct app entry without the old video opening, a native multi-file picker (APK excluded), plain-text and image attachment handling, and a collapsible activity card for real web-tool calls. PDF/Office/archive/audio/video content extraction and the full WhatsApp automation system are still pending implementation.

No private API keys are included. Keep provider credentials in Android Keystore or Cloudflare Secrets.
