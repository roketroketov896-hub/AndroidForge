from pathlib import Path
p=Path('/mnt/data/jarvis_work/app/src/main/assets/app.js')
s=p.read_text()
s=s.replace("let chats = [], activeId = null, req = null, pendingImage = '', lastLang = 'ru';", "let chats = [], activeId = null, req = null, pendingImage = '', pendingFiles = [], lastLang = 'ru';")
s=s.replace("req = { id: am.id, chatId: chat.id, voice: voiceMode, hadImage: !!image, gotToken: false };", "req = { id: am.id, chatId: chat.id, voice: voiceMode, hadImage: !!image, gotToken: false, steps: 0 };\n    am.toolSteps = [{ label: 'Анализирую запрос', status: 'active', kind: 'plan' }];")
s=s.replace("req.steps = (req.steps || 0) + 1; req.extra = req.extra || [];", "req.steps = (req.steps || 0) + 1; req.extra = req.extra || [];\n    if (!m.toolSteps) m.toolSteps = [{ label: 'Анализирую запрос', status: 'done', kind: 'plan' }];\n    m.toolSteps.forEach(x => { if (x.status === 'active') x.status = 'done'; });\n    m.toolSteps.push({ label: toolLabel(call).replace(/^[^ ]+ /, ''), status: 'active', kind: call.name });")
s=s.replace("const image = pendingImage;\n    const mem", "const image = pendingImage;\n    const filesForSend = pendingFiles.slice();\n    if (filesForSend.length) { text += filesForSend.filter(f => f.text).map(f => '\\n\\n[Содержимое файла ' + f.name + ']\\n' + f.text).join(''); }\n    const mem")
s=s.replace("const chat = ensureChat(text || 'Снимок экрана');\n    chat.messages.push({ id: uid(), role: 'user', content: text, hadImage: !!image });", "const chat = ensureChat(text || (filesForSend.length ? 'Проанализируй прикреплённые файлы' : 'Снимок экрана'));\n    chat.messages.push({ id: uid(), role: 'user', content: text + (filesForSend.length ? '\\n\\n📎 ' + filesForSend.map(f => f.name).join(', ') : ''), hadImage: !!image });")
s=s.replace("pendingImage = '';\n    resetInput();", "pendingImage = '';\n    pendingFiles = []; renderFileAttachments();\n    resetInput();")
marker="  function fillBubble(el, m, isLast) {\n"
helper=r'''  function escapeHtml(v) {
    return String(v || '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
  }
  function renderAgentCard(m) {
    const el = msgElById(m.id);
    if (!el || !m.toolSteps || !m.toolSteps.length) return;
    let card = $('.agent-card', el);
    const wasOpen = card && card.dataset.open === '1';
    if (!card) { card = document.createElement('section'); card.className = 'agent-card'; el.insertBefore(card, $('.bubble', el)); }
    if (wasOpen) card.dataset.open = '1';
    const active = m.toolSteps.some(x => x.status === 'active');
    card.innerHTML = '<button class="agent-summary" type="button"><span>✦</span><span class="agent-count">Use tools · ' + m.toolSteps.length + '</span><span class="agent-state">' + (active ? 'Выполняется' : 'Завершено') + '</span><span>' + (card.dataset.open === '1' ? '⌃' : '⌄') + '</span></button>' +
      '<div class="agent-list" ' + (card.dataset.open === '1' ? '' : 'hidden') + '>' + m.toolSteps.map(x => '<div class="agent-step ' + x.status + '"><span class="step-icon">' + (x.status === 'done' ? '✓' : x.status === 'active' ? '◌' : '·') + '</span><span>' + escapeHtml(x.label) + '</span><span class="step-status">' + (x.status === 'done' ? 'Готово' : x.status === 'active' ? 'Сейчас' : 'Ожидает') + '</span></div>').join('') + '</div>';
    card.querySelector('.agent-summary').onclick = () => { card.dataset.open = card.dataset.open === '1' ? '0' : '1'; renderAgentCard(m); };
  }

'''
s=s.replace(marker,helper+marker)
s=s.replace("const b = $('.bubble', el);\n    if (m.role === 'user')", "if (m.toolSteps && m.toolSteps.length) renderAgentCard(m);\n    const b = $('.bubble', el);\n    if (m.role === 'user')")
s=s.replace("if (m && !d.ok) { m.pre", "if (m && m.toolSteps) { const step = m.toolSteps.find(x => x.status === 'active'); if (step) step.status = 'done'; if (!d.ok) m.toolSteps.push({ label: 'Инструмент сообщил об ошибке', status: 'error', kind: 'error' }); renderAgentCard(m); }\n      if (m && !d.ok) { m.pre")
s=s.replace("if (m) {\n      m.streaming = false;", "if (m) {\n      m.streaming = false;\n      if (m.toolSteps) { m.toolSteps.forEach(x => { if (x.status === 'active') x.status = err ? 'error' : 'done'; }); renderAgentCard(m); }")
old=r'''  function renderAttach() {
    $('#attach').hidden = !pendingImage;
    if (pendingImage) $('#attachImg').src = pendingImage;
  }'''
new=r'''  function renderAttach() {
    $('#attach').hidden = !pendingImage;
    if (pendingImage) $('#attachImg').src = pendingImage;
    renderFileAttachments();
  }
  function renderFileAttachments() {
    const box = $('#fileAttachments'); if (!box) return; box.innerHTML = '';
    pendingFiles.forEach((f, i) => {
      const row = document.createElement('div'); row.className = 'file-chip';
      row.innerHTML = '<span>📎 ' + escapeHtml(f.name) + '</span><small>' + (f.size ? (f.size / 1024).toFixed(0) + ' КБ' : '') + '</small><button type="button" aria-label="Удалить">×</button>';
      row.querySelector('button').onclick = () => { pendingFiles.splice(i, 1); renderFileAttachments(); };
      box.appendChild(row);
    });
  }
  function handlePickedFile(f) {
    if (!f || !f.ok) { toast(f && f.error || 'Не удалось добавить файл'); return; }
    const name = String(f.name || 'Файл'), mime = String(f.mime || 'application/octet-stream'), raw = f.data || '';
    let text = '';
    if (/^(text\/|application\/(json|xml|javascript))/.test(mime) || /\.(txt|md|csv|json|xml|html|js|css|log)$/i.test(name)) {
      try { text = decodeURIComponent(escape(atob(raw))); } catch (e) { try { text = atob(raw); } catch (_) {} }
    }
    if (mime.startsWith('image/')) pendingImage = 'data:' + mime + ';base64,' + raw;
    pendingFiles.push({ name, mime, size: +f.size || 0, text });
    renderAttach();
    if (text) toast('Текст файла добавлен в контекст');
    else if (mime.startsWith('image/')) toast('Изображение добавлено');
    else toast('Файл прикреплён. Извлечение содержимого этого формата ещё не подключено.');
  }'''
if old not in s: print('renderAttach block not found')
s=s.replace(old,new)
s=s.replace("$('#snapBtn').onclick = () => native('captureScreen');\n    $('#attachRemove').onclick = () => { pendingImage = ''; renderAttach(); };", "$('#snapBtn').onclick = () => native('captureScreen');\n    $('#addFile').onclick = () => native('openFilePicker');\n    $('#attachRemove').onclick = () => { pendingImage = ''; renderAttach(); };")
s=s.replace("  const H = {", "  const H = {\n    filePicked: d => handlePickedFile(d),")
p.write_text(s)
