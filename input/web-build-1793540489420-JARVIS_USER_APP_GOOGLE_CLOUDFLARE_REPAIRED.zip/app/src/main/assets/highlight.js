/* Лёгкая подсветка синтаксиса без зависимостей: Python, JS/TS, Java, Kotlin, C/C++, C#, Go, Rust, SQL, Bash, HTML, CSS, JSON. */
(function (root) {
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const W = (s) => new Set(s.split(' '));
  const KW = {
    js: W('break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new return super switch this throw try typeof var void while with yield async await of static get set null true false undefined interface type enum implements readonly'),
    java: W('abstract boolean byte char class double else enum extends final float for if implements import instanceof int interface long new package private protected public return short static super switch this throw throws try void while true false null var record case break continue default catch finally string'),
    kotlin: W('fun val var class object interface when is in as null true false return if else for while package import override open data sealed companion private public protected throw try catch finally by init constructor suspend'),
    cpp: W('auto bool char class const double else enum float for if include int long namespace new nullptr private public protected return short signed sizeof static struct switch case break continue template this typename union unsigned using virtual void while true false try catch throw default delete'),
    go: W('func var const type struct interface package import return if else for range switch case default go defer chan map nil true false break continue select'),
    rust: W('fn let mut struct enum impl trait pub use mod return if else match loop while for in self Self true false const static ref move as where async await break continue'),
    python: W('and as assert async await break class continue def del elif else except False finally for from global if import in is lambda None nonlocal not or pass raise return True try while with yield print self'),
    bash: W('if then else elif fi for while do done case esac function echo cd ls export in return local exit sudo'),
    sql: W('select from where insert into values update set delete create table alter drop join left right inner outer on group by order limit and or not null as distinct having union index primary key foreign references like in is between exists case when then else end'),
  };
  const ALIAS = { js: 'js', javascript: 'js', jsx: 'js', ts: 'js', typescript: 'js', tsx: 'js', node: 'js', java: 'java', cs: 'java', csharp: 'java', 'c#': 'java', kt: 'kotlin', kotlin: 'kotlin',
    c: 'cpp', 'c++': 'cpp', cc: 'cpp', cpp: 'cpp', h: 'cpp', hpp: 'cpp', go: 'go', golang: 'go', rust: 'rust', rs: 'rust', py: 'python', python: 'python', python3: 'python',
    sh: 'bash', bash: 'bash', shell: 'bash', zsh: 'bash', sql: 'sql', html: 'html', xml: 'html', svg: 'html', css: 'css', json: 'json', math: 'js' };
  const COMMENT = { js: '\\/\\*[\\s\\S]*?\\*\\/|\\/\\/[^\\n]*', java: '\\/\\*[\\s\\S]*?\\*\\/|\\/\\/[^\\n]*', kotlin: '\\/\\*[\\s\\S]*?\\*\\/|\\/\\/[^\\n]*', cpp: '\\/\\*[\\s\\S]*?\\*\\/|\\/\\/[^\\n]*', go: '\\/\\*[\\s\\S]*?\\*\\/|\\/\\/[^\\n]*', rust: '\\/\\*[\\s\\S]*?\\*\\/|\\/\\/[^\\n]*', python: '#[^\\n]*', bash: '#[^\\n]*', sql: '--[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/' };
  const STR = '"""[\\s\\S]*?"""|\'\'\'[\\s\\S]*?\'\'\'|"(?:\\\\.|[^"\\\\\\n])*"|\'(?:\\\\.|[^\'\\\\\\n])*\'|`(?:\\\\.|[^`\\\\])*`';
  const NUM = '\\b0x[\\da-fA-F]+\\b|\\b\\d[\\d_]*(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b';
  const span = (c, t) => '<span class="t-' + c + '">' + esc(t) + '</span>';

  function generic(code, lang) {
    const re = new RegExp('(' + COMMENT[lang] + ')|(' + STR + ')|(' + NUM + ')|([A-Za-z_$][\\w$]*)', 'g');
    const kw = KW[lang]; const ci = lang === 'sql';
    let out = '', last = 0, m;
    while ((m = re.exec(code))) {
      out += esc(code.slice(last, m.index)); last = re.lastIndex;
      if (m[1]) out += span('c', m[1]);
      else if (m[2]) out += span('s', m[2]);
      else if (m[3]) out += span('n', m[3]);
      else if (kw.has(ci ? m[4].toLowerCase() : m[4])) out += span('k', m[4]);
      else if (code[last] === '(') out += span('f', m[4]);
      else out += esc(m[4]);
    }
    return out + esc(code.slice(last));
  }
  function html(code) {
    const re = /(<!--[\s\S]*?-->)|(<\/?[a-zA-Z][^>]*>)/g;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) { out += esc(code.slice(last, m.index)); last = re.lastIndex; out += m[1] ? span('c', m[1]) : span('k', m[2]); }
    return out + esc(code.slice(last));
  }
  function css(code) {
    const re = /(\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|(#[\da-fA-F]{3,8}\b|\b\d[\d.]*(?:px|em|rem|%|vh|vw|s|ms|deg)?\b)|([a-zA-Z-]+)(?=\s*:)/g;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) { out += esc(code.slice(last, m.index)); last = re.lastIndex; out += m[1] ? span('c', m[1]) : m[2] ? span('s', m[2]) : m[3] ? span('n', m[3]) : span('f', m[4]); }
    return out + esc(code.slice(last));
  }
  function json(code) {
    const re = /("(?:\\.|[^"\\\n])*")(\s*:)?|(\b-?\d[\d.eE+-]*\b)|\b(true|false|null)\b/g;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) { out += esc(code.slice(last, m.index)); last = re.lastIndex; out += m[1] ? (m[2] ? span('f', m[1]) + esc(m[2]) : span('s', m[1])) : m[3] ? span('n', m[3]) : span('k', m[4]); }
    return out + esc(code.slice(last));
  }
  function highlightCode(code, lang) {
    const l = ALIAS[String(lang || '').toLowerCase()];
    if (!l || code.length > 60000) return esc(code);
    try { return l === 'html' ? html(code) : l === 'css' ? css(code) : l === 'json' ? json(code) : generic(code, l); } catch (e) { return esc(code); }
  }
  root.highlightCode = highlightCode;
  if (typeof module !== 'undefined') module.exports = { highlightCode };
})(typeof window !== 'undefined' ? window : globalThis);
