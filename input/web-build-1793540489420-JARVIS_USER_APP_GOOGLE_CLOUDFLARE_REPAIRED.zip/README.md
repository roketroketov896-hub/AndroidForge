# JARVIS AI — User Android App

This archive contains ONLY the user-facing Android app module (`:app`). It does not contain the admin app.

Google sign-in is implemented natively with Android Credential Manager. No separate login website is required.
See `SETUP_GOOGLE_CLOUDFLARE_RU.txt` for the exact Google Cloud OAuth setup.

Configured backend:
`https://jarvis-backend.roketroketov896.workers.dev`

Build task: `:app:assembleDebug` (or `assembleDebug` in this single-module project).

Android application ID: `com.jarvis.ai`
