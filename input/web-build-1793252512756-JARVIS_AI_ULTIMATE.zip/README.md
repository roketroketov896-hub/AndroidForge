# JARVIS AI (Android)

Нативный Android-проект (Java, WebView-интерфейс). Сборка: `assembleDebug`, AGP 8.6.1, Gradle 8.7, JDK 17, compileSdk/targetSdk 34, minSdk 23.

- `app/src/main/java/com/jarvis/ai` — Android-код: `MainActivity`, `JarvisBridge` (JS↔Android), `ChatClient` (OpenRouter/OpenAI-совместимый API, SSE), `TtsController` (озвучка с паузой по сегментам), `SpeechInput`, `AuthManager` (Google, Credential Manager), `SecureStore` (Keystore), `ScreenShareService` (MediaProjection), `AppLauncher`.
- `app/src/main/assets` — интерфейс (HTML/CSS/JS).
- `backend` — сервер бесплатного режима (отдельно развёртывается).
- `SETUP_RU.md` — внешние настройки.

Не реализовано намеренно: Telegram, WhatsApp, подписка и оплата, управление касаниями.
