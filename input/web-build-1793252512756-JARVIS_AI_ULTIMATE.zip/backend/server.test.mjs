import assert from 'node:assert/strict';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { createApp } from './server.mjs';

// поддельный провайдер ИИ
let upstreamCalls = 0, upstreamFail = false;
const upstream = http.createServer((req, res) => {
  upstreamCalls++;
  if (upstreamFail) { res.writeHead(500); return res.end('x'); }
  res.writeHead(200, { 'Content-Type': 'text/event-stream' });
  res.write('data: {"choices":[{"delta":{"content":"Прив"}}]}\n\n');
  res.write('data: {"choices":[{"delta":{"content":"ет"}}]}\n\n');
  res.end('data: [DONE]\n\n');
});
await new Promise((r) => upstream.listen(0, r));
const upUrl = 'http://127.0.0.1:' + upstream.address().port + '/v1/chat/completions';

let clock = Date.UTC(2026, 0, 1, 12);
const file = path.join(os.tmpdir(), 'jarvis-test-' + Date.now() + '.json');
const app = createApp({ dataFile: file, upstreamUrl: upUrl, openrouterKey: 'k', freeModel: 'm', now: () => clock,
  verify: async (t) => { if (t === 'tokA') return { sub: 'A', email: 'a@x' }; if (t === 'tokB') return { sub: 'B', email: 'b@x' }; throw new Error('bad'); } });
await new Promise((r) => app.server.listen(0, r));
const base = 'http://127.0.0.1:' + app.server.address().port;
const call = (p, tok, init = {}) => fetch(base + p, { ...init, headers: { ...(tok ? { Authorization: 'Bearer ' + tok } : {}), 'Content-Type': 'application/json' } });
const chat = (tok) => call('/v1/chat', tok, { method: 'POST', body: JSON.stringify({ messages: [{ role: 'user', content: 'hi' }] }) });

assert.equal((await call('/health')).status, 200);
assert.equal((await call('/v1/status')).status, 401);
assert.equal((await call('/v1/status', 'nope')).status, 401);

// первые 15 дней — много запросов без дневного лимита
for (let i = 0; i < 8; i++) { const r = await chat('tokA'); assert.equal(r.status, 200); assert.match(await r.text(), /Прив/); }
let st = await (await call('/v1/status', 'tokA')).json();
assert.equal(st.phase, 'unlimited');

// сервер сам определяет время: через 15 дней действует лимит 5
clock += 15 * 86400000;
for (let i = 0; i < 5; i++) assert.equal((await chat('tokA')).status, 200);
const blocked = await chat('tokA');
assert.equal(blocked.status, 429);
assert.equal((await blocked.json()).error.code, 'daily_limit');
st = await (await call('/v1/status', 'tokA')).json();
assert.equal(st.remainingToday, 0);

// другой аккаунт учитывается отдельно (новый 15-дневный период)
assert.equal((await chat('tokB')).status, 200);

// ошибка провайдера не списывает запрос
clock += 86400000;
upstreamFail = true;
assert.equal((await chat('tokA')).status, 502);
upstreamFail = false;
st = await (await call('/v1/status', 'tokA')).json();
assert.equal(st.usedToday, 0);

// синхронизация истории, изоляция между аккаунтами
const put = await call('/v1/history', 'tokA', { method: 'PUT', body: JSON.stringify({ chats: [{ id: '1', messages: [] }] }) });
assert.equal(put.status, 200);
assert.equal((await (await call('/v1/history', 'tokA')).json()).chats.length, 1);
assert.deepEqual((await (await call('/v1/history', 'tokB')).json()).chats, []);
assert.equal((await call('/v1/history', 'tokA', { method: 'DELETE' })).status, 200);
assert.deepEqual((await (await call('/v1/history', 'tokA')).json()).chats, []);

// счётчики переживают перезапуск (файл)
await app.flush();
const app2 = createApp({ dataFile: file, upstreamUrl: upUrl, openrouterKey: 'k', freeModel: 'm', now: () => clock, verify: async () => ({ sub: 'A', email: 'a@x' }) });
assert.ok(app2.db().users.A.startedAt);

app.server.close(); upstream.close();
console.log('server tests passed');
process.exit(0);
