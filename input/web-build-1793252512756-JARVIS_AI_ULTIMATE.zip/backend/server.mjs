// Сервер-посредник JARVIS для бесплатного режима. Node.js 18+, без зависимостей.
// Хранит общий ключ OpenRouter, проверяет вход через Google, считает лимиты по серверному времени.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { evaluate, reserve, refund } from './quota.mjs';
import { verifyGoogleIdToken, fetchGoogleJwks } from './auth.mjs';

const MAX_CHAT_BYTES = 6 * 1024 * 1024;   // с запасом на снимок экрана
const MAX_HISTORY_BYTES = 5 * 1024 * 1024;

export function createApp(opts) {
  const cfg = {
    unlimitedDays: opts.unlimitedDays ?? 15,
    dailyLimit: opts.dailyLimit ?? 5,
  };
  const dataFile = opts.dataFile;
  const verify = opts.verify || ((token) => verifyGoogleIdToken(token, { clientId: opts.googleClientId, getJwks: fetchGoogleJwks }));
  const upstreamUrl = opts.upstreamUrl || 'https://openrouter.ai/api/v1/chat/completions';
  const now = opts.now || (() => Date.now());

  let db = { users: {}, history: {} };
  try { db = JSON.parse(fs.readFileSync(dataFile, 'utf8')); } catch { /* новый файл */ }
  let writing = Promise.resolve();
  function persist() {
    writing = writing.then(() => {
      const tmp = dataFile + '.tmp';
      fs.mkdirSync(path.dirname(dataFile), { recursive: true });
      fs.writeFileSync(tmp, JSON.stringify(db));
      fs.renameSync(tmp, dataFile);
    }).catch((e) => console.error('persist failed', e.message));
    return writing;
  }

  const send = (res, code, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(body);
  };
  const err = (res, code, errCode, message) => send(res, code, { error: { code: errCode, message } });

  function readBody(req, limit) {
    return new Promise((resolve, reject) => {
      let size = 0; const chunks = [];
      req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('too_large')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', reject);
    });
  }

  async function authenticate(req) {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : '';
    if (!token) return null;
    try {
      const u = await verify(token);
      return u && u.sub ? u : null;
    } catch { return null; }
  }

  function getUser(sub, email) {
    let u = db.users[sub];
    if (!u) { u = db.users[sub] = { startedAt: now(), dayKey: '', count: 0, email }; }
    if (email) u.email = email;
    return u;
  }

  function sanitizeMessages(raw) {
    if (!Array.isArray(raw)) return null;
    const out = [];
    for (const m of raw.slice(-40)) {
      if (!m || !['system', 'user', 'assistant'].includes(m.role)) continue;
      if (typeof m.content === 'string') out.push({ role: m.role, content: m.content.slice(0, 40000) });
      else if (Array.isArray(m.content) && m.role === 'user') {
        const parts = [];
        for (const p of m.content) {
          if (p && p.type === 'text' && typeof p.text === 'string') parts.push({ type: 'text', text: p.text.slice(0, 40000) });
          else if (p && p.type === 'image_url' && p.image_url && typeof p.image_url.url === 'string' && p.image_url.url.startsWith('data:image/')) parts.push({ type: 'image_url', image_url: { url: p.image_url.url } });
        }
        if (parts.length) out.push({ role: 'user', content: parts });
      }
    }
    return out.length ? out : null;
  }

  async function handleChat(req, res, user) {
    let body;
    try { body = JSON.parse(await readBody(req, MAX_CHAT_BYTES)); } catch (e) { return err(res, e.message === 'too_large' ? 413 : 400, 'bad_request', 'Некорректный запрос.'); }
    const messages = sanitizeMessages(body.messages);
    if (!messages) return err(res, 400, 'bad_request', 'Нет сообщений.');

    const u = getUser(user.sub, user.email);
    const r = reserve(u, now(), cfg);
    if (!r.ok) {
      return send(res, 429, { error: { code: 'daily_limit', message: 'Дневной лимит бесплатного режима исчерпан.' }, status: r.status });
    }
    await persist();

    const refundIt = async () => { refund(u, now()); await persist(); };
    let up;
    try {
      up = await fetch(upstreamUrl, {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + opts.openrouterKey, 'Content-Type': 'application/json', 'HTTP-Referer': 'https://jarvis.local', 'X-Title': 'JARVIS AI' },
        body: JSON.stringify({ model: opts.freeModel, messages, stream: true, max_tokens: opts.maxTokens ?? 1500 }),
      });
    } catch {
      await refundIt();
      return err(res, 502, 'upstream', 'Провайдер ИИ недоступен.');
    }
    if (!up.ok) {
      await refundIt();
      return err(res, up.status === 429 ? 503 : 502, 'upstream', 'Провайдер ИИ вернул ошибку ' + up.status + '.');
    }
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
    let sent = false;
    try {
      for await (const chunk of up.body) { sent = true; if (!res.write(chunk)) await new Promise((ok) => res.once('drain', ok)); }
    } catch { /* клиент отключился или поток прерван */ }
    if (!sent) await refundIt();
    res.end();
  }

  const handler = async (req, res) => {
    const url = new URL(req.url, 'http://x');
    try {
      if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true });
      const user = await authenticate(req);
      if (!user) return err(res, 401, 'auth_required', 'Нужен вход через Google.');

      if (req.method === 'GET' && url.pathname === '/v1/status') {
        const u = getUser(user.sub, user.email);
        await persist();
        return send(res, 200, { ok: true, email: u.email, startedAt: u.startedAt, serverTime: now(), ...evaluate(u, now(), cfg) });
      }
      if (req.method === 'POST' && url.pathname === '/v1/chat') return await handleChat(req, res, user);

      if (url.pathname === '/v1/history') {
        if (req.method === 'GET') return send(res, 200, db.history[user.sub] || { chats: [] });
        if (req.method === 'PUT') {
          let parsed;
          try { parsed = JSON.parse(await readBody(req, MAX_HISTORY_BYTES)); } catch (e) { return err(res, e.message === 'too_large' ? 413 : 400, 'bad_request', 'Некорректная история.'); }
          if (!parsed || !Array.isArray(parsed.chats)) return err(res, 400, 'bad_request', 'Некорректная история.');
          db.history[user.sub] = { version: 2, at: now(), chats: parsed.chats };
          await persist();
          return send(res, 200, { ok: true });
        }
        if (req.method === 'DELETE') { delete db.history[user.sub]; await persist(); return send(res, 200, { ok: true }); }
      }
      return err(res, 404, 'not_found', 'Не найдено.');
    } catch (e) {
      console.error('handler error', e.message);
      if (!res.headersSent) err(res, 500, 'server_error', 'Ошибка сервера.');
      else res.end();
    }
  };
  return { server: http.createServer(handler), db: () => db, flush: () => writing };
}

// Запуск как программы
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const need = (k) => { if (!process.env[k]) { console.error('Не задана переменная окружения ' + k); process.exit(1); } return process.env[k]; };
  const app = createApp({
    googleClientId: need('GOOGLE_WEB_CLIENT_ID'),
    openrouterKey: need('OPENROUTER_API_KEY'),
    freeModel: process.env.FREE_MODEL || 'openrouter/auto',
    dataFile: process.env.DATA_FILE || './data/jarvis-data.json',
    unlimitedDays: Number(process.env.UNLIMITED_DAYS || 15),
    dailyLimit: Number(process.env.DAILY_LIMIT || 5),
    maxTokens: Number(process.env.MAX_TOKENS || 1500),
  });
  const port = Number(process.env.PORT || 8080);
  app.server.listen(port, () => console.log('JARVIS server listening on :' + port));
}
