import assert from 'node:assert/strict';
import { evaluate, reserve, refund, DAY_MS, dayKey } from './quota.mjs';

const cfg = { unlimitedDays: 15, dailyLimit: 5 };
const t0 = Date.UTC(2026, 0, 1, 10, 0, 0);
const user = { startedAt: t0, dayKey: '', count: 0 };

// первые 15 дней: нет дневного лимита JARVIS
for (let i = 0; i < 50; i++) assert.equal(reserve(user, t0 + 3 * DAY_MS, cfg).ok, true);
assert.equal(evaluate(user, t0 + 3 * DAY_MS, cfg).phase, 'unlimited');
assert.equal(evaluate(user, t0 + 3 * DAY_MS, cfg).daysLeft, 12);

// граница: ровно через 15 дней начинается лимит
const after = t0 + 15 * DAY_MS;
assert.equal(evaluate(user, after - 1, cfg).phase, 'unlimited');
assert.equal(evaluate(user, after, cfg).phase, 'limited');

// после 15 дней: 5 в день, шестой отклоняется
const u2 = { startedAt: t0, dayKey: '', count: 0 };
for (let i = 0; i < 5; i++) assert.equal(reserve(u2, after + i, cfg).ok, true);
const sixth = reserve(u2, after + 10, cfg);
assert.equal(sixth.ok, false);
assert.equal(sixth.status.remainingToday, 0);

// возврат резерва при ошибке провайдера
refund(u2, after + 20);
assert.equal(reserve(u2, after + 30, cfg).ok, true);
assert.equal(reserve(u2, after + 40, cfg).ok, false);

// новые сутки по UTC сбрасывают счётчик
const nextDay = Date.UTC(2026, 0, 17, 0, 0, 1);
assert.notEqual(dayKey(after), dayKey(nextDay));
assert.equal(reserve(u2, nextDay, cfg).ok, true);
assert.equal(evaluate(u2, nextDay, cfg).usedToday, 1);

console.log('quota tests passed');
