// Чистая логика лимитов бесплатного режима (без сети и диска), чтобы её можно было тестировать.
export const DAY_MS = 86400000;

export function dayKey(ms) {
  return new Date(ms).toISOString().slice(0, 10); // сутки по UTC
}

export function nextResetMs(now) {
  const d = new Date(now);
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1);
}

/** user: { startedAt:ms, dayKey:string, count:number }. Ничего не изменяет. */
export function evaluate(user, now, cfg) {
  const unlimitedUntil = user.startedAt + cfg.unlimitedDays * DAY_MS;
  if (now < unlimitedUntil) {
    return { allowed: true, phase: 'unlimited', unlimitedUntil, daysLeft: Math.ceil((unlimitedUntil - now) / DAY_MS),
      dailyLimit: cfg.dailyLimit, usedToday: user.dayKey === dayKey(now) ? user.count : 0 };
  }
  const used = user.dayKey === dayKey(now) ? user.count : 0;
  return { allowed: used < cfg.dailyLimit, phase: 'limited', unlimitedUntil, daysLeft: 0, dailyLimit: cfg.dailyLimit,
    usedToday: used, remainingToday: Math.max(0, cfg.dailyLimit - used), resetAt: nextResetMs(now) };
}

/** Резервирует один запрос. Возвращает { ok, status }. Изменяет user. */
export function reserve(user, now, cfg) {
  const st = evaluate(user, now, cfg);
  if (!st.allowed) return { ok: false, status: st };
  if (user.dayKey !== dayKey(now)) { user.dayKey = dayKey(now); user.count = 0; }
  user.count += 1;
  return { ok: true, status: evaluate(user, now, cfg) };
}

/** Возвращает резерв, если запрос к провайдеру не удался. */
export function refund(user, now) {
  if (user.dayKey === dayKey(now) && user.count > 0) user.count -= 1;
}
