package com.jarvis.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Окно приложения: WebView с интерфейсом + контроллеры голоса, входа, чата и показа экрана. */
public class MainActivity extends Activity implements Emitter {
    static final int REQ_AUDIO = 701;
    static final int REQ_PROJECTION = 702;
    static final int REQ_NOTIF = 703;

    WebView webView;
    JarvisSettings settings;
    SecureStore store;
    AuthManager auth;
    TtsController tts;
    SpeechInput speech;
    final ChatClient chat = new ChatClient();
    final ExecutorService executor = Executors.newCachedThreadPool();
    final Handler main = new Handler(Looper.getMainLooper());
    private String pendingLang = "ru";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = getSharedPreferences("jarvis_settings", MODE_PRIVATE);
        settings = new JarvisSettings(prefs);
        store = new SecureStore(prefs);
        // Ключ, переданный при сборке, один раз переносится в зашифрованное хранилище.
        if (!BuildConfig.DEFAULT_OPENROUTER_KEY.isEmpty() && !prefs.getBoolean("build_key_seeded", false)) {
            if (!store.has("openrouter")) store.put("openrouter", BuildConfig.DEFAULT_OPENROUTER_KEY);
            prefs.edit().putBoolean("build_key_seeded", true).apply();
        }
        if (!prefs.getBoolean("build_defaults_seeded", false)) {
            try {
                JSONObject patch = new JSONObject();
                if (!BuildConfig.DEFAULT_BACKEND_URL.isEmpty()) {
                    patch.put("backendUrl", BuildConfig.DEFAULT_BACKEND_URL);
                    patch.put("mode", "free");
                }
                if (!BuildConfig.DEFAULT_WEB_CLIENT_ID.isEmpty()) patch.put("webClientId", BuildConfig.DEFAULT_WEB_CLIENT_ID);
                if (patch.length() > 0) settings.merge(patch);
            } catch (Exception ignored) {
            }
            prefs.edit().putBoolean("build_defaults_seeded", true).apply();
        }
        auth = new AuthManager(prefs);
        tts = new TtsController(this, settings, this);
        speech = new SpeechInput(this, this);

        getWindow().setStatusBarColor(Color.parseColor("#05070F"));
        getWindow().setNavigationBarColor(Color.parseColor("#05070F"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#05070F"));
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }
        });
        webView.addJavascriptInterface(new JarvisBridge(this), "JarvisBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        ScreenShareService.listener = new ScreenShareService.Listener() {
            @Override
            public void onStarted() {
                emit("screen", json("state", "started"));
            }

            @Override
            public void onFrame(String dataUrl) {
                emit("screen", json("state", "frame", "image", dataUrl));
            }

            @Override
            public void onStopped(String reason) {
                emit("screen", json("state", "stopped", "reason", reason));
            }
        };
    }

    private static JSONObject json(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return o;
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if ("file".equals(scheme)) return false;
        if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
            }
        }
        return true;
    }

    @Override
    public void emit(String event, JSONObject data) {
        final String js = "window.JarvisEvents&&window.JarvisEvents.emit("
                + JSONObject.quote(event) + "," + JSONObject.quote(data.toString()) + ")";
        main.post(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.evaluateJavascript(js, null);
            }
        });
    }

    // ---------- микрофон ----------

    void beginListening(String lang) {
        pendingLang = (lang == null || lang.isEmpty()) ? "ru" : lang;
        tts.stop();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        speech.start(pendingLang);
    }

    // ---------- показ экрана ----------

    void requestScreenShare() {
        if (ScreenShareService.running) {
            emit("screen", json("state", "started"));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        launchProjection();
    }

    private void launchProjection() {
        try {
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQ_PROJECTION);
        } catch (Exception e) {
            emit("screen", json("state", "error", "reason", "no_projection"));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PROJECTION) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent i = new Intent(this, ScreenShareService.class)
                    .setAction(ScreenShareService.ACTION_START)
                    .putExtra("code", resultCode)
                    .putExtra("data", data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } else {
            emit("screen", json("state", "denied"));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_AUDIO) {
            if (granted) {
                main.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        speech.start(pendingLang);
                    }
                }, 200);
            } else {
                boolean permanent = !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO);
                emit("speech", json("type", "error", "code", "permission_denied", "permanent", permanent));
            }
        } else if (requestCode == REQ_NOTIF) {
            // Уведомление желательно, но не обязательно: показ экрана можно запустить и без него.
            launchProjection();
        }
    }

    // ---------- жизненный цикл ----------

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript("window.jarvisBack?String(window.jarvisBack()):'false'", new android.webkit.ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value == null || !value.contains("true")) MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onStop() {
        // Не оставляем неконтролируемого звука или записи, когда приложение уходит с экрана.
        tts.stop();
        speech.cancel();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        ScreenShareService.listener = null;
        stopService(new Intent(this, ScreenShareService.class));
        tts.shutdown();
        speech.cancel();
        executor.shutdownNow();
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
