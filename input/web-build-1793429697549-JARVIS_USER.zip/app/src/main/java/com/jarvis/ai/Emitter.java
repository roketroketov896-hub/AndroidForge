package com.jarvis.ai;

import org.json.JSONObject;

/** Канал событий из Java в JavaScript (WebView). Можно вызывать из любого потока. */
interface Emitter {
    void emit(String event, JSONObject data);
}
