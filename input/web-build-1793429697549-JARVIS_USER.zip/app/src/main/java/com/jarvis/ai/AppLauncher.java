package com.jarvis.ai;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;

import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

/** Открытие приложений по явной команде пользователя через обычные Android Intents. Без касаний и ввода. */
final class AppLauncher {
    private AppLauncher() {
    }

    private static boolean any(String q, String... names) {
        for (String n : names) if (q.equals(n)) return true;
        return false;
    }

    static JSONObject open(Activity act, String rawName) {
        JSONObject res = new JSONObject();
        try {
            String q = rawName == null ? "" : rawName.toLowerCase(Locale.ROOT).trim();
            q = q.replaceAll("[\\p{Punct}]", " ").replaceAll("\\s+", " ").trim();
            q = q.replaceAll("^(приложение|app|uygulama|tətbiq)\\s+", "")
                 .replaceAll("\\s+(приложение|app|uygulaması|tətbiqi)$", "").trim();
            if (q.isEmpty()) {
                res.put("ok", false);
                res.put("message", "Не понял, какое приложение открыть.");
                return res;
            }
            Intent intent = null;
            String label = rawName;
            if (any(q, "настройки", "настройка", "settings", "ayarlar", "parametrlər", "tənzimləmələr")) {
                intent = new Intent(Settings.ACTION_SETTINGS);
                label = "Настройки";
            } else if (any(q, "браузер", "browser", "tarayıcı", "brauzer", "интернет", "internet")) {
                intent = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
                label = "Браузер";
            } else if (any(q, "камера", "camera", "kamera")) {
                intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                label = "Камера";
            }
            if (intent == null) {
                PackageManager pm = act.getPackageManager();
                Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
                ResolveInfo best = null;
                int bestScore = -1;
                for (ResolveInfo ri : apps) {
                    String l = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT).trim();
                    int score = -1;
                    if (l.equals(q)) score = 1000;
                    else if (l.contains(q) || q.contains(l)) score = 500 - Math.abs(l.length() - q.length());
                    if (score > bestScore) {
                        bestScore = score;
                        best = ri;
                    }
                }
                if (best != null && bestScore >= 0) {
                    intent = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
                    label = best.loadLabel(pm).toString();
                }
            }
            if (intent == null) {
                res.put("ok", false);
                res.put("message", "Приложение «" + rawName + "» не найдено на этом телефоне.");
                return res;
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            final Intent launch = intent;
            act.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        act.startActivity(launch);
                    } catch (Exception ignored) {
                    }
                }
            });
            res.put("ok", true);
            res.put("label", label);
            res.put("message", "Открываю: " + label);
        } catch (Exception e) {
            try {
                res.put("ok", false);
                res.put("message", "Не удалось открыть приложение.");
            } catch (Exception ignored) {
            }
        }
        return res;
    }
}
