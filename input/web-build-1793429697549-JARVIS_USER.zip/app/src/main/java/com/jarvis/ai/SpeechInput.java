package com.jarvis.ai;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import org.json.JSONObject;

import java.util.ArrayList;

/** Голосовой ввод через Android SpeechRecognizer. Запускается только по явному действию пользователя. */
final class SpeechInput {
    private final Context ctx;
    private final Emitter emitter;
    private SpeechRecognizer recognizer;
    private boolean cancelledByUs = false;
    private long lastLevel = 0L;

    SpeechInput(Context ctx, Emitter emitter) {
        this.ctx = ctx;
        this.emitter = emitter;
    }

    private void send(String type, String text, String code, float level) {
        JSONObject d = new JSONObject();
        try {
            d.put("type", type);
            d.put("text", text);
            d.put("code", code);
            d.put("level", level);
        } catch (Exception ignored) {
        }
        emitter.emit("speech", d);
    }

    private static String tagFor(String lang) {
        if ("az".equals(lang)) return "az-AZ";
        if ("tr".equals(lang)) return "tr-TR";
        if ("en".equals(lang)) return "en-US";
        return "ru-RU";
    }

    private static String codeFor(int error) {
        switch (error) {
            case 7: return "no_match";
            case 6: return "timeout";
            case 1:
            case 2: return "network";
            case 3: return "audio";
            case 4: return "server";
            case 5: return "client";
            case 8: return "busy";
            case 9: return "permission";
            case 12:
            case 13: return "lang";
            default: return "unknown";
        }
    }

    /** Главный поток; разрешение RECORD_AUDIO должно быть уже выдано. */
    void start(String lang) {
        cancel();
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            send("error", "", "unavailable", 0f);
            return;
        }
        try {
            cancelledByUs = false;
            recognizer = SpeechRecognizer.createSpeechRecognizer(ctx);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                    send("listening", "", "", 0f);
                }

                @Override
                public void onBeginningOfSpeech() {
                }

                @Override
                public void onRmsChanged(float rmsdB) {
                    long now = System.currentTimeMillis();
                    if (now - lastLevel < 70L) return;
                    lastLevel = now;
                    float v = Math.max(0f, Math.min(1f, (rmsdB + 2f) / 12f));
                    send("level", "", "", v);
                }

                @Override
                public void onBufferReceived(byte[] buffer) {
                }

                @Override
                public void onEndOfSpeech() {
                    send("processing", "", "", 0f);
                }

                @Override
                public void onError(int error) {
                    if (cancelledByUs) return;
                    send("error", "", codeFor(error), 0f);
                }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> m = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String text = (m == null || m.isEmpty()) ? "" : m.get(0);
                    if (text.isEmpty()) send("error", "", "no_match", 0f);
                    else send("result", text, "", 0f);
                }

                @Override
                public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> m = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (m != null && !m.isEmpty()) send("partial", m.get(0), "", 0f);
                }

                @Override
                public void onEvent(int eventType, Bundle params) {
                }
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, tagFor(lang));
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tagFor(lang));
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            recognizer.startListening(i);
        } catch (Exception e) {
            send("error", "", "client", 0f);
        }
    }

    /** Завершить запись и получить результат распознавания. */
    void finish() {
        if (recognizer != null) {
            try {
                recognizer.stopListening();
            } catch (Exception ignored) {
            }
        }
    }

    void cancel() {
        cancelledByUs = true;
        if (recognizer != null) {
            try {
                recognizer.cancel();
            } catch (Exception ignored) {
            }
            try {
                recognizer.destroy();
            } catch (Exception ignored) {
            }
            recognizer = null;
        }
    }
}
