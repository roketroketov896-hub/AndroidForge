package com.jarvis.ai;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.MessageDigest;

/** Единственная точка входа JavaScript → Android. Все методы вызываются из потока WebView-моста. */
final class JarvisBridge {
    private final MainActivity act;

    JarvisBridge(MainActivity act) {
        this.act = act;
    }

    // ---------- вспомогательное ----------

    private static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return o;
    }

    private static String normalizeBase(String url) {
        String u = url == null ? "" : url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u.startsWith("https://") ? u : "";
    }

    /** Имя ячейки хранилища для провайдера (только безопасные символы). */
    private static String keyName(String provider) {
        String p = provider == null ? "" : provider.toLowerCase();
        return p.matches("[a-z0-9_-]{1,24}") ? p : "custom";
    }

    private void ui(Runnable r) {
        act.main.post(r);
    }

    // ---------- состояние и настройки ----------

    @JavascriptInterface
    public String getState() {
        return obj(
                "settings", act.settings.all(),
                "profile", act.auth.profile(),
                "configured", obj("backend", !normalizeBase(BuildConfig.BACKEND_URL).isEmpty(), "google", !BuildConfig.WEB_CLIENT_ID.trim().isEmpty()),
                "online", act.isOnline(),
                "ttsReady", act.tts != null && act.tts.isReady(),
                "screenActive", ScreenShareService.running,
                "sdk", Build.VERSION.SDK_INT
        ).toString();
    }

    @JavascriptInterface
    public void saveSettings(String json) {
        try {
            act.settings.merge(new JSONObject(json));
        } catch (Exception ignored) {
        }
    }

    @JavascriptInterface
    public boolean saveApiKey(String provider, String key) {
        String name = keyName(provider);
        if (key == null || key.trim().isEmpty()) return false;
        act.store.put(name, key.trim());
        return act.store.has(name);
    }

    @JavascriptInterface
    public void clearApiKey(String provider) {
        act.store.clear(keyName(provider));
    }

    @JavascriptInterface
    public boolean hasKey(String provider) {
        return act.store.has(keyName(provider));
    }

    // ---------- чат ----------

    @JavascriptInterface
    public void sendChat(final String id, final String messagesJson) {
        act.executor.execute(new Runnable() {
            @Override
            public void run() {
                doChat(id, messagesJson);
            }
        });
    }

    @JavascriptInterface
    public void cancelChat(String id) {
        act.chat.cancel(id);
    }

    private void doChat(final String id, String messagesJson) {
        ChatClient.Callback cb = new ChatClient.Callback() {
            @Override
            public void onDelta(String text) {
                act.emit("chatDelta", obj("id", id, "text", text));
            }

            @Override
            public void onDone() {
                act.emit("chatDone", obj("id", id));
            }

            @Override
            public void onError(String code, String detail) {
                act.emit("chatError", obj("id", id, "code", code, "detail", detail == null ? "" : detail));
            }
        };
        try {
            JSONArray msgs = new JSONArray(messagesJson);
            JSONObject s = act.settings.all();
            if ("free".equals(s.optString("mode", "own"))) {
                String base = normalizeBase(BuildConfig.BACKEND_URL);
                if (base.isEmpty()) {
                    cb.onError("free_not_configured", "");
                    return;
                }
                if (!act.auth.isSignedIn()) {
                    cb.onError("auth_required", "");
                    return;
                }
                String token = act.auth.ensureToken(act, BuildConfig.WEB_CLIENT_ID);
                if (token.isEmpty()) {
                    cb.onError("auth_required", "");
                    return;
                }
                act.chat.stream(id, base + "/v1/chat", token, false, ChatClient.buildBody(null, msgs, true), cb);
                return;
            }
            String provider = s.optString("provider", "openrouter");
            boolean custom = !"openrouter".equals(provider);
            String url;
            if (custom) {
                String base = normalizeBase(s.optString("customBaseUrl", ""));
                if (base.isEmpty()) {
                    cb.onError("custom_not_configured", "");
                    return;
                }
                url = base + "/chat/completions";
            } else {
                url = "https://openrouter.ai/api/v1/chat/completions";
            }
            String key = act.store.get(keyName(provider));
            if (key.isEmpty()) {
                cb.onError("no_key", "");
                return;
            }
            String model = s.optString("model", "openrouter/auto").trim();
            if (model.isEmpty()) model = "openrouter/auto";
            act.chat.stream(id, url, key, !custom, ChatClient.buildBody(model, msgs, true), cb);
        } catch (Exception e) {
            cb.onError("bad_request", e.getClass().getSimpleName());
        }
    }

    @JavascriptInterface
    public void testConnection() {
        act.executor.execute(new Runnable() {
            @Override
            public void run() {
                JSONObject r;
                try {
                    r = runTest();
                } catch (Exception e) {
                    r = obj("ok", false, "message", "Нет соединения: " + e.getClass().getSimpleName());
                }
                act.emit("testResult", r);
            }
        });
    }

    private JSONObject runTest() throws Exception {
        JSONObject s = act.settings.all();
        if ("free".equals(s.optString("mode", "own"))) {
            String base = normalizeBase(BuildConfig.BACKEND_URL);
            if (base.isEmpty()) return obj("ok", false, "message", "Сервер JARVIS не подключён в этой сборке приложения.");
            ChatClient.Result r = ChatClient.request("GET", base + "/health", null, null);
            if (r.status == 200) return obj("ok", true, "message", "Сервер JARVIS отвечает.");
            return obj("ok", false, "message", "Сервер ответил кодом " + r.status + ".");
        }
        String provider = s.optString("provider", "openrouter");
        boolean custom = !"openrouter".equals(provider);
        String key = act.store.get(keyName(provider));
        if (key.isEmpty()) return obj("ok", false, "message", "Сначала сохрани API-ключ.");
        ChatClient.Result r;
        if (custom) {
            String base = normalizeBase(s.optString("customBaseUrl", ""));
            if (base.isEmpty()) return obj("ok", false, "message", "Укажи базовый адрес API (https://…).");
            r = ChatClient.request("GET", base + "/models", key, null);
        } else {
            r = ChatClient.request("GET", "https://openrouter.ai/api/v1/auth/key", key, null);
        }
        if (r.status == 401 || r.status == 403) return obj("ok", false, "message", "Провайдер отклонил ключ.");
        if (r.status < 200 || r.status >= 300) return obj("ok", false, "message", "Провайдер ответил кодом " + r.status + ".");
        String image = "unknown";
        if (!custom) image = ChatClient.openRouterImageSupport(s.optString("model", "openrouter/auto"));
        return obj("ok", true, "message", "Ключ принят. Это проверка доступа, запрос к модели не выполнялся.", "imageSupport", image);
    }

    // ---------- сервер JARVIS: статус, синхронизация ----------

    private JSONObject backend(String method, String path, String body) {
        try {
            String base = normalizeBase(BuildConfig.BACKEND_URL);
            if (base.isEmpty()) return obj("ok", false, "code", "free_not_configured");
            if (!act.auth.isSignedIn()) return obj("ok", false, "code", "auth_required");
            String token = act.auth.ensureToken(act, BuildConfig.WEB_CLIENT_ID);
            if (token.isEmpty()) return obj("ok", false, "code", "auth_required");
            ChatClient.Result r = ChatClient.request(method, base + path, token, body);
            if (r.status >= 200 && r.status < 300) return obj("ok", true, "body", r.body);
            return obj("ok", false, "code", "http_" + r.status, "body", r.body);
        } catch (Exception e) {
            return obj("ok", false, "code", "network", "detail", e.getClass().getSimpleName());
        }
    }

    @JavascriptInterface
    public void backendStatus() {
        act.executor.execute(new Runnable() {
            @Override
            public void run() {
                act.emit("freeStatus", backend("GET", "/v1/status", null));
            }
        });
    }

    @JavascriptInterface
    public void syncUp(final String json) {
        act.executor.execute(new Runnable() {
            @Override
            public void run() {
                JSONObject r = backend("PUT", "/v1/history", json);
                try {
                    r.put("action", "up");
                } catch (Exception ignored) {
                }
                act.emit("syncResult", r);
            }
        });
    }

    @JavascriptInterface
    public void syncDown() {
        act.executor.execute(new Runnable() {
            @Override
            public void run() {
                JSONObject r = backend("GET", "/v1/history", null);
                try {
                    r.put("action", "down");
                } catch (Exception ignored) {
                }
                act.emit("syncResult", r);
            }
        });
    }

    @JavascriptInterface
    public void deleteServerHistory() {
        act.executor.execute(new Runnable() {
            @Override
            public void run() {
                JSONObject r = backend("DELETE", "/v1/history", null);
                try {
                    r.put("action", "delete");
                } catch (Exception ignored) {
                }
                act.emit("syncResult", r);
            }
        });
    }

    // ---------- вход Google ----------

    @JavascriptInterface
    public void signIn() {
        ui(new Runnable() {
            @Override
            public void run() {
                if (BuildConfig.WEB_CLIENT_ID.trim().isEmpty()) {
                    JSONObject p0 = act.auth.profile();
                    try {
                        p0.put("error", "no_client_id");
                    } catch (Exception ignored) {
                    }
                    act.emit("auth", p0);
                    return;
                }
                act.auth.signIn(act, BuildConfig.WEB_CLIENT_ID, new AuthManager.Done() {
                    @Override
                    public void done(boolean ok, String error) {
                        JSONObject p = act.auth.profile();
                        try {
                            p.put("error", ok ? "" : error);
                        } catch (Exception ignored) {
                        }
                        act.emit("auth", p);
                    }
                });
            }
        });
    }

    @JavascriptInterface
    public void signOut() {
        act.auth.signOut();
        act.emit("auth", act.auth.profile());
    }

    @JavascriptInterface
    public String getSigning() {
        try {
            PackageManager pm = act.getPackageManager();
            Signature[] sigs;
            if (Build.VERSION.SDK_INT >= 28) {
                PackageInfo pi = pm.getPackageInfo(act.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                sigs = pi.signingInfo.hasMultipleSigners()
                        ? pi.signingInfo.getApkContentsSigners()
                        : pi.signingInfo.getSigningCertificateHistory();
            } else {
                PackageInfo pi = pm.getPackageInfo(act.getPackageName(), PackageManager.GET_SIGNATURES);
                sigs = pi.signatures;
            }
            byte[] cert = sigs[0].toByteArray();
            return obj("package", act.getPackageName(),
                    "sha1", hex(MessageDigest.getInstance("SHA-1").digest(cert)),
                    "sha256", hex(MessageDigest.getInstance("SHA-256").digest(cert))).toString();
        } catch (Exception e) {
            return obj("package", act.getPackageName(), "sha1", "", "sha256", "").toString();
        }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < b.length; i++) {
            if (i > 0) sb.append(':');
            sb.append(String.format("%02X", b[i]));
        }
        return sb.toString();
    }

    // ---------- озвучивание ----------

    @JavascriptInterface
    public void speak(final String msgId, final String text, final String lang) {
        ui(new Runnable() {
            @Override
            public void run() {
                act.speakText(msgId, text, lang);
            }
        });
    }

    @JavascriptInterface
    public void pauseSpeech() {
        ui(new Runnable() {
            @Override
            public void run() {
                act.pauseSpeech();
            }
        });
    }

    @JavascriptInterface
    public void resumeSpeech() {
        ui(new Runnable() {
            @Override
            public void run() {
                act.resumeSpeech();
            }
        });
    }

    @JavascriptInterface
    public void stopSpeech() {
        ui(new Runnable() {
            @Override
            public void run() {
                act.stopSpeech();
            }
        });
    }

    @JavascriptInterface
    public String getVoices(String lang) {
        return act.tts == null ? "[]" : act.tts.voices(lang).toString();
    }

    /** Интерфейс отрисован и история загружена: заставку можно завершать. */
    @JavascriptInterface
    public void appReady() {
        act.main.post(new Runnable() {
            @Override
            public void run() {
                act.onUiReady();
            }
        });
    }

    @JavascriptInterface
    public void retryBootstrap() {
        act.retryBootstrap();
    }

    @JavascriptInterface
    public void setVoice(String lang, String name) {
        act.settings.setVoice(lang, name == null ? "" : name);
    }

    @JavascriptInterface
    public void previewVoice(final String lang) {
        final String text;
        if ("az".equals(lang)) text = "Salam. Mən JARVİS, sizin səsli köməkçinizəm.";
        else if ("tr".equals(lang)) text = "Merhaba. Ben JARVIS, sesli asistanınız.";
        else if ("en".equals(lang)) text = "Hello. I am JARVIS, your voice assistant.";
        else text = "Здравствуйте. Я JARVIS, ваш голосовой помощник.";
        speak("preview", text, lang);
    }

    @JavascriptInterface
    public void openTtsSettings() {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    act.startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
                } catch (Exception e) {
                    try {
                        act.startActivity(new Intent(Settings.ACTION_SETTINGS));
                    } catch (Exception ignored) {
                    }
                }
            }
        });
    }

    @JavascriptInterface
    public void installTtsData() {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    act.startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA));
                } catch (Exception e) {
                    act.emit("ttsError", obj("code", "no_installer", "message", "На телефоне нет установщика голосовых данных. Открой настройки синтеза речи.", "lang", ""));
                }
            }
        });
    }

    // ---------- голосовой ввод ----------

    @JavascriptInterface
    public void startListening(final String lang) {
        ui(new Runnable() {
            @Override
            public void run() {
                act.beginListening(lang);
            }
        });
    }

    @JavascriptInterface
    public void finishListening() {
        ui(new Runnable() {
            @Override
            public void run() {
                act.speech.finish();
            }
        });
    }

    @JavascriptInterface
    public void cancelListening() {
        ui(new Runnable() {
            @Override
            public void run() {
                act.speech.cancel();
            }
        });
    }

    @JavascriptInterface
    public void openAppSettings() {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", act.getPackageName(), null));
                    act.startActivity(i);
                } catch (Exception ignored) {
                }
            }
        });
    }

    // ---------- экран ----------

    @JavascriptInterface
    public void startScreenShare() {
        ui(new Runnable() {
            @Override
            public void run() {
                act.requestScreenShare();
            }
        });
    }

    @JavascriptInterface
    public void stopScreenShare() {
        ui(new Runnable() {
            @Override
            public void run() {
                act.stopService(new Intent(act, ScreenShareService.class));
            }
        });
    }

    @JavascriptInterface
    public void captureScreen() {
        act.executor.execute(new Runnable() {
            @Override
            public void run() {
                String frame = ScreenShareService.captureDataUrl();
                act.emit("screen", obj("state", "frame", "image", frame == null ? "" : frame));
            }
        });
    }

    // ---------- прочее ----------

    @JavascriptInterface
    public String openApp(String name) {
        return AppLauncher.open(act, name).toString();
    }

    @JavascriptInterface
    public void copyText(final String text) {
        ui(new Runnable() {
            @Override
            public void run() {
                ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("JARVIS", text));
            }
        });
    }
}
