'use strict';
(function () {
  /* ===================== утилиты и мост ===================== */
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const N = window.JarvisBridge || null;
  function native(name) {
    const args = Array.prototype.slice.call(arguments, 1);
    try { if (N && typeof N[name] === 'function') return N[name].apply(N, args); } catch (e) { console.error(name, e); }
    return null;
  }
  function safeJson(s, fb) { try { const v = JSON.parse(s); return v == null ? fb : v; } catch (e) { return fb; } }
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  const I = {
    menu: '<path d="M4 7h16M4 12h16M4 17h10"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4-4"/>',
    send: '<path d="M12 19V5M5 12l7-7 7 7"/>',
    stop: '<rect x="6.5" y="6.5" width="11" height="11" rx="2.5" fill="currentColor" stroke="none"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    micoff: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M3 3l18 18"/>',
    speaker: '<path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>',
    pause: '<path d="M8 5v14M16 5v14" stroke-width="2.6"/>',
    play: '<path d="M7 5l12 7-12 7z" fill="currentColor"/>',
    copy: '<rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>',
    wave: '<path d="M3 12h2M7 8v8M11 4v16M15 8v8M19 10v4"/>',
    gauge: '<path d="M4 18a8 8 0 1 1 16 0M12 18l4-6"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    back: '<path d="M15 6l-6 6 6 6"/>',
    camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>'
  };
  const ic = (n, s) => '<svg class="ic" width="' + (s || 22) + '" height="' + (s || 22) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + I[n] + '</svg>';

  function toast(t) {
    const el = $('#toast');
    el.textContent = t;
    el.classList.add('show');
    clearTimeout(toast.t);
    toast.t = setTimeout(() => el.classList.remove('show'), 3200);
  }

  function askConfirm(text, yes) {
    return new Promise(res => {
      $('#dialogText').textContent = text;
      $('#dialogYes').textContent = yes || 'Удалить';
      $('#dialog').hidden = false;
      const done = v => { $('#dialog').hidden = true; $('#dialogYes').onclick = null; $('#dialogNo').onclick = null; res(v); };
      $('#dialogYes').onclick = () => done(true);
      $('#dialogNo').onclick = () => done(false);
    });
  }

  /* ===================== состояние ===================== */
  const S = {
    settings: { mode: 'own', provider: 'openrouter', customBaseUrl: '', model: 'openrouter/auto', systemPrompt: '', lang: 'auto',
      ttsEngine: 'system', perf: 'auto', ttsRate: 0.95, ttsPitch: 0.85, voices: {}, autoSpeak: false },
    keys: {}, profile: {}, ttsReady: false, screenActive: false,
    configured: { backend: false, google: false }, online: true, server: { checked: false, ok: true }, appConfig: null, remotePrompt: ''
  };
  let chats = [], activeId = null, req = null, pendingImage = '', lastLang = 'ru';
  let ttsState = { state: 'idle', msgId: '' };
  const voice = { open: false, listening: false, muted: false, lang: 'ru' };
  // Провайдеры с OpenAI-совместимым API (POST {base}/chat/completions). Названия моделей могут устареть, их можно изменить вручную.
  const PROVIDERS = [
    { id: 'openrouter', name: 'OpenRouter (много моделей)', base: '', model: 'openrouter/auto' },
    { id: 'openai', name: 'OpenAI (ChatGPT)', base: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
    { id: 'deepseek', name: 'DeepSeek', base: 'https://api.deepseek.com', model: 'deepseek-chat' },
    { id: 'gemini', name: 'Google Gemini', base: 'https://generativelanguage.googleapis.com/v1beta/openai', model: 'gemini-2.0-flash' },
    { id: 'groq', name: 'Groq', base: 'https://api.groq.com/openai/v1', model: 'llama-3.3-70b-versatile' },
    { id: 'mistral', name: 'Mistral', base: 'https://api.mistral.ai/v1', model: 'mistral-small-latest' },
    { id: 'xai', name: 'xAI (Grok)', base: 'https://api.x.ai/v1', model: 'grok-2-latest' },
    { id: 'together', name: 'Together AI', base: 'https://api.together.xyz/v1', model: 'meta-llama/Llama-3.3-70B-Instruct-Turbo' },
    { id: 'custom', name: 'Другой (свой адрес API)', base: '', model: '' }
  ];
  const providerById = id => PROVIDERS.find(x => x.id === id) || PROVIDERS[0];
  const hasKeyFor = id => !!S.keys[id];
  const DEFAULT_SYSTEM = 'Ты JARVIS — спокойный, точный и дружелюбный персональный ИИ-помощник. Отвечай по существу, ясно и кратко, если не просят подробно. Если не уверен — честно скажи об этом.';

  function saveSettings(patch) {
    Object.assign(S.settings, patch);
    native('saveSettings', JSON.stringify(patch));
  }

  /* ===================== хранение чатов ===================== */
  const KEY = 'jarvis_chats_v2';
  function loadChats() {
    let raw = null;
    try { raw = localStorage.getItem(KEY) || localStorage.getItem('jarvis_chats_v1'); } catch (e) { /* ignore */ }
    const arr = safeJson(raw, []);
    chats = (Array.isArray(arr) ? arr : []).filter(c => c && c.id && Array.isArray(c.messages)).map(c => {
      c.updated = c.updated || c.created || Date.now();
      c.messages.forEach(m => { delete m.streaming; });
      return c;
    });
  }
  let saveTimer = 0;
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      try {
        const out = chats.slice(0, 100).map(c => ({ id: c.id, title: c.title, created: c.created, updated: c.updated,
          messages: c.messages.filter(m => !m.streaming).map(m => ({ id: m.id, role: m.role, content: m.content, error: m.error || undefined, stopped: m.stopped || undefined, hadImage: m.hadImage || undefined, local: m.local || undefined })) }));
        localStorage.setItem(KEY, JSON.stringify(out));
      } catch (e) { toast('Не удалось сохранить историю на устройстве'); }
    }, 250);
  }
  const cur = () => chats.find(c => c.id === activeId) || null;
  function findMsg(chatId, id) { const c = chats.find(x => x.id === chatId); return c ? c.messages.find(m => m.id === id) : null; }
  function titleFrom(t) { t = (t || '').replace(/\s+/g, ' ').trim(); if (!t) return 'Новый чат'; return t.length > 38 ? t.slice(0, 38) + '…' : t; }
  function speechLang() { return S.settings.lang !== 'auto' ? S.settings.lang : lastLang; }

  /* ===================== шар ===================== */
  let errorUntil = 0, lvl = 0, lvlTarget = 0, raf = 0;
  function recomputeOrb() {
    let st = 'idle';
    if (voice.listening) st = 'listening';
    else if (req) st = req.gotToken ? 'generating' : 'thinking';
    else if (ttsState.state === 'speaking') st = 'speaking';
    else if (ttsState.state === 'paused') st = 'paused';
    else if (voice.open) st = 'ready';
    if (!S.online && (st === 'idle' || st === 'ready')) st = 'offline';
    if (errorUntil > Date.now()) st = 'error';
    if (document.body.dataset.orb !== st) document.body.dataset.orb = st;
  }
  function flashError() { errorUntil = Date.now() + 2600; recomputeOrb(); setTimeout(recomputeOrb, 2700); }
  // Реальные данные: уровень микрофона (SpeechRecognizer) и слова озвучки. Обновляется только голосовой шар, одним rAF-циклом.
  let orbEl = null;
  function setLevel(v) {
    if (!voice.open) return;
    lvlTarget = Math.max(lvlTarget, v);
    if (!raf) raf = requestAnimationFrame(tick);
  }
  function tick() {
    lvl += (lvlTarget - lvl) * 0.4;
    lvlTarget *= 0.86;
    if (!orbEl) orbEl = $('#voiceOrb');
    orbEl.style.setProperty('--lvl', lvl.toFixed(3));
    if (lvl > 0.01 || lvlTarget > 0.01) raf = requestAnimationFrame(tick);
    else { raf = 0; lvl = 0; orbEl.style.setProperty('--lvl', '0'); }
  }

  /* ===================== список чатов ===================== */
  function fmtDate(ts) {
    const d = new Date(ts), n = new Date();
    return d.toDateString() === n.toDateString()
      ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : d.toLocaleDateString([], { day: '2-digit', month: '2-digit' });
  }
  function renderChatList() {
    const q = $('#search').value.trim().toLowerCase();
    const list = $('#chatList');
    list.innerHTML = '';
    const items = chats.slice().sort((a, b) => b.updated - a.updated).filter(c =>
      !q || (c.title || '').toLowerCase().includes(q) || c.messages.some(m => (m.content || '').toLowerCase().includes(q)));
    if (!items.length) {
      const e = document.createElement('div');
      e.className = 'empty';
      e.textContent = q ? 'Ничего не найдено' : 'Здесь появятся прошлые чаты';
      list.appendChild(e);
      return;
    }
    items.forEach(c => {
      const row = document.createElement('div');
      row.className = 'chat-item' + (c.id === activeId ? ' active' : '');
      const open = document.createElement('button');
      open.className = 'chat-open';
      const b = document.createElement('b'); b.textContent = c.title || 'Новый чат';
      const sm = document.createElement('small'); sm.textContent = fmtDate(c.updated) + ' · ' + c.messages.length + ' сообщ.';
      open.append(b, sm);
      open.onclick = () => { activeId = c.id; closeDrawer(); renderAll(); };
      const del = document.createElement('button');
      del.className = 'chat-del'; del.setAttribute('aria-label', 'Удалить чат'); del.innerHTML = ic('trash', 18);
      del.onclick = async e => {
        e.stopPropagation();
        if (!(await askConfirm('Удалить чат «' + (c.title || 'Новый чат') + '»?'))) return;
        if (req && req.chatId === c.id) stopGeneration();
        chats = chats.filter(x => x.id !== c.id);
        if (activeId === c.id) activeId = null;
        save(); renderAll();
      };
      row.append(open, del);
      list.appendChild(row);
    });
  }

  /* ===================== сообщения ===================== */
  function actionsEl(m) {
    const a = document.createElement('div');
    a.className = 'actions';
    const btn = (cls, act, inner, title) => '<button class="act ' + cls + '" data-a="' + act + '" title="' + title + '" aria-label="' + title + '">' + inner + '</button>';
    let h = '';
    if (!m.error && !m.local) {
      h += btn('spk', 'speak', ic('speaker', 18) + '<span class="eq"><i></i><i></i><i></i></span>', 'Озвучить');
      h += btn('pz', 'pause', ic('pause', 18), 'Пауза');
      h += btn('pl', 'resume', ic('play', 18), 'Продолжить');
      h += btn('st', 'stopspeech', ic('stop', 18), 'Остановить');
      h += btn('', 'copy', ic('copy', 18), 'Копировать');
    }
    if (!m.local) h += btn('rg', 'regen', ic('refresh', 18), m.error ? 'Повторить' : 'Сгенерировать заново');
    a.innerHTML = h;
    return a;
  }
  function fillBubble(el, m, isLast) {
    const b = $('.bubble', el);
    if (m.role === 'user') { b.textContent = m.content + (m.hadImage ? '\n📷 снимок экрана' : ''); return; }
    if (m.streaming && !m.content) b.innerHTML = '<span class="dots"><i></i><i></i><i></i></span>';
    else b.innerHTML = '<div class="md">' + (m.streaming ? streamHtml(m) : renderMarkdown(m.content || '')) + '</div>' + (m.stopped ? '<div class="note-stopped">Генерация остановлена</div>' : '');
    const old = $('.actions', el);
    if (old) old.remove();
    if (!m.streaming && m.content) {
      const a = actionsEl(m);
      if (!isLast) { const rg = $('.rg', a); if (rg && !m.error) rg.remove(); }
      el.appendChild(a);
    }
  }
  function streamHtml(m) {
    const t = m.content;
    let cut = t.lastIndexOf('\n\n');
    while (cut > 0 && ((t.slice(0, cut).match(/```/g) || []).length % 2) !== 0) cut = t.lastIndexOf('\n\n', cut - 1);
    if (cut < 0) cut = 0;
    if (cut > (m._cut || 0)) { m._head = (m._head || '') + renderMarkdown(t.slice(m._cut || 0, cut)); m._cut = cut; }
    return (m._head || '') + renderMarkdown(t.slice(m._cut || 0));
  }
  function msgEl(m, isLast) {
    const el = document.createElement('article');
    el.className = 'msg ' + m.role + (m.error ? ' error' : '');
    el.dataset.id = m.id;
    const b = document.createElement('div'); b.className = 'bubble';
    el.appendChild(b);
    fillBubble(el, m, isLast);
    if (ttsState.state !== 'idle' && ttsState.msgId === m.id) el.dataset.tts = ttsState.state;
    return el;
  }
  let chatListTimer = 0;
  function renderChatListSoon() { clearTimeout(chatListTimer); chatListTimer = setTimeout(renderChatList, 120); }
  const msgElById = id => $('#messages').querySelector('[data-id="' + id + '"]');
  /** Добавляет недостающие сообщения и убирает удалённые, не пересоздавая остальные. */
  function syncMessages() {
    const c = cur(), box = $('#messages');
    $('#welcome').hidden = !!(c && c.messages.length);
    if (!c) { box.innerHTML = ''; return; }
    const ids = new Set(c.messages.map(m => m.id));
    Array.from(box.children).forEach(el => { if (!ids.has(el.dataset.id)) el.remove(); });
    c.messages.forEach((m, i) => {
      const last = i === c.messages.length - 1;
      let el = msgElById(m.id);
      if (!el) { box.appendChild(msgEl(m, last)); el = msgElById(m.id); el.dataset.last = String(last); return; }
      if (el.dataset.last !== String(last)) { el.dataset.last = String(last); if (!m.streaming) fillBubble(el, m, last); }
    });
    scrollBottom(true);
  }
  function renderMessages() {
    const box = $('#messages');
    box.innerHTML = '';
    const c = cur();
    $('#welcome').hidden = !!(c && c.messages.length);
    if (!c) return;
    c.messages.forEach((m, i) => { const el = msgEl(m, i === c.messages.length - 1); el.dataset.last = String(i === c.messages.length - 1); box.appendChild(el); });
    scrollBottom(true);
  }
  function nearBottom() { const s = $('#scroller'); return s.scrollHeight - s.scrollTop - s.clientHeight < 140; }
  function scrollBottom(force) {
    const s = $('#scroller');
    if (force || nearBottom()) requestAnimationFrame(() => { s.scrollTop = s.scrollHeight; });
  }
  let renderQueued = null, lastStreamPaint = 0;
  function scheduleRender(m) {
    renderQueued = m;
    if (scheduleRender.p) return;
    scheduleRender.p = requestAnimationFrame(function paint() {
      const wait = 60 - (performance.now() - lastStreamPaint);
      if (wait > 0) { scheduleRender.p = setTimeout(() => { scheduleRender.p = requestAnimationFrame(paint); }, wait); return; }
      scheduleRender.p = 0; lastStreamPaint = performance.now();
      const mm = renderQueued; if (!mm) return;
      const el = msgElById(mm.id);
      if (el) { const stick = nearBottom(); fillBubble(el, mm, true); if (stick) scrollBottom(true); }
    });
  }

  function renderHeader() {
    const c = cur();
    $('#topTitle').textContent = c ? (c.title || 'JARVIS') : 'JARVIS';
    const s = S.settings;
    const hasKey = hasKeyFor(s.provider);
    const configured = s.mode === 'free' ? S.configured.backend : hasKey;
    $('#welcomeSub').textContent = s.mode === 'free'
      ? 'Бесплатный режим JARVIS'
      : (hasKey ? providerById(s.provider).name.split(' (')[0] + ' · ' + s.model : 'Подключи ИИ, чтобы начать общение');
    $('#setupBtn').hidden = configured;
    $('#screenPill').hidden = !S.screenActive;
    $('#snapBtn').hidden = !S.screenActive;
    renderProfileChip();
  }
  function renderAll() { renderChatList(); renderMessages(); renderHeader(); renderComposer(); }

  /* ===================== чат с ИИ ===================== */
  function systemText(hasImage, voiceMode) {
    const names = { ru: 'русском', az: 'азербайджанском', tr: 'турецком', en: 'английском' };
    const custom = S.settings.systemPrompt && S.settings.systemPrompt !== DEFAULT_SYSTEM;
    let p = custom ? S.settings.systemPrompt : (S.remotePrompt || S.settings.systemPrompt || DEFAULT_SYSTEM);
    if (S.settings.lang !== 'auto') p += '\nВсегда отвечай на ' + names[S.settings.lang] + ' языке, если пользователь явно не попросил другой.';
    else p += '\nОтвечай на том же языке, на котором написано последнее сообщение пользователя (русский, азербайджанский, турецкий или английский).';
    p += '\nФорматируй ответы в Markdown.';
    if (voiceMode) p += '\nПользователь общается голосом: отвечай естественно и коротко (1–4 предложения), без таблиц, списков и кода, если не просят иначе.';
    if (hasImage) p += '\nК последнему сообщению приложен снимок экрана телефона пользователя. Анализируй только то, что на нём видно. Ты не управляешь телефоном и не можешь нажимать кнопки.';
    return p;
  }
  function buildMessages(chat, amId, image, voiceMode) {
    const hist = chat.messages.filter(m => m.id !== amId && !m.error && !m.local && m.content).slice(-24);
    const arr = hist.map(m => ({ role: m.role, content: m.content }));
    if (image) for (let i = arr.length - 1; i >= 0; i--) if (arr[i].role === 'user') { arr[i].image = image; break; }
    return [{ role: 'system', content: systemText(!!image, voiceMode) }].concat(arr);
  }
  function ensureChat(text) {
    let c = cur();
    if (c) return c;
    c = { id: uid(), title: titleFrom(text), created: Date.now(), updated: Date.now(), messages: [] };
    chats.unshift(c);
    activeId = c.id;
    return c;
  }
  function parseOpenCommand(t) {
    t = t.trim().replace(/[.!?]+$/, '');
    let m = t.match(/^(?:пожалуйста,?\s+)?(?:открой|открыть|запусти|запустить|open|launch|please open|aç|başlat)\s+(.+)$/i);
    if (m) return m[1].trim();
    m = t.match(/^(.+?)\s+(?:aç|açın|başlat)$/i);
    return m ? m[1].trim() : null;
  }
  function send(text, opts) {
    opts = opts || {};
    text = (text || '').trim();
    if ((!text && !pendingImage) || req) return;
    lastLang = detectLang(text, lastLang);
    const image = pendingImage;
    const cmd = !image && text ? parseOpenCommand(text) : null;
    if (cmd) {
      const r = safeJson(native('openApp', cmd), null);
      const words = cmd.split(/\s+/).length;
      if (r && (r.ok || words <= 2)) {
        const chat = ensureChat(text);
        chat.messages.push({ id: uid(), role: 'user', content: text, local: true });
        const am = { id: uid(), role: 'assistant', content: r.message || (r.ok ? 'Открываю.' : 'Не удалось открыть.'), local: true, error: !r.ok };
        chat.messages.push(am);
        chat.updated = Date.now();
        save(); resetInput(); renderAll();
        if (voice.open) { setVoiceReply(am.content); native('speak', am.id, am.content, 'ru'); }
        return;
      }
    }
    const chat = ensureChat(text || 'Снимок экрана');
    chat.messages.push({ id: uid(), role: 'user', content: text, hadImage: !!image });
    const am = { id: uid(), role: 'assistant', content: '', streaming: true };
    chat.messages.push(am);
    chat.updated = Date.now();
    pendingImage = '';
    resetInput();
    startRequest(chat, am, image, !!opts.voice || voice.open);
  }
  function startRequest(chat, am, image, voiceMode) {
    req = { id: am.id, chatId: chat.id, voice: voiceMode, hadImage: !!image, gotToken: false };
    save(); syncMessages(); renderChatListSoon(); renderHeader(); renderComposer(); recomputeOrb();
    if (!N) { finishRequest(true, 'no_bridge', ''); return; }
    native('sendChat', am.id, JSON.stringify(buildMessages(chat, am.id, image, voiceMode)));
  }
  function resetInput() {
    $('#input').value = ''; autoGrow(); renderAttach();
  }
  function stopGeneration() {
    if (!req) return;
    const r = req;
    native('cancelChat', r.id);
    const m = findMsg(r.chatId, r.id);
    req = null;
    if (m) {
      m.streaming = false; m.stopped = true;
      if (!m.content) { const c = chats.find(x => x.id === r.chatId); if (c) c.messages = c.messages.filter(x => x.id !== m.id); }
    }
    save(); syncMessages();
    if (m && m.content) { const el = msgElById(m.id); const c2 = chats.find(x => x.id === r.chatId); if (el && c2) fillBubble(el, m, c2.messages[c2.messages.length - 1] === m); }
    renderChatListSoon(); renderComposer(); recomputeOrb();
  }
  function regenerate() {
    if (req) return;
    const c = cur();
    if (!c) return;
    while (c.messages.length && c.messages[c.messages.length - 1].role === 'assistant') c.messages.pop();
    if (!c.messages.length || c.messages[c.messages.length - 1].role !== 'user') { renderAll(); return; }
    const am = { id: uid(), role: 'assistant', content: '', streaming: true };
    c.messages.push(am);
    startRequest(c, am, '', false);
  }
  function friendly(code, detail, hadImage) {
    const d = detail ? ' (' + detail + ')' : '';
    if (code === 'no_key') return 'Не указан API-ключ. Открой «ИИ-подключение» и сохрани ключ.';
    if (code === 'no_bridge') return 'Мост приложения недоступен. Перезапусти JARVIS.';
    if (code === 'free_not_configured') return 'Адрес сервера JARVIS не указан. Бесплатный режим не работает, пока сервер не развёрнут и не подключён в «ИИ-подключении».';
    if (code === 'custom_not_configured') return 'Укажи базовый адрес API (https://…) в «ИИ-подключении».';
    if (code === 'auth_required') return 'Для бесплатного режима нужен вход через Google (раздел «Профиль»).';
    if (code === 'blocked') return 'Доступ к JARVIS для этого аккаунта заблокирован администратором.';
    if (code === 'not_configured') return 'На сервере JARVIS пока не задан ключ ИИ. Обратись к администратору или используй свой ключ.';
    if (code === 'daily_limit') return 'Дневной лимит бесплатного режима исчерпан. Он обновится завтра, а пока можно подключить свой ключ.' + d;
    if (code === 'network') return 'Нет соединения с интернетом или сервером.' + d;
    if (code === 'timeout') return 'Время ожидания ответа истекло. Попробуй ещё раз.';
    if (code === 'empty') return 'Модель не вернула текст. Попробуй другую модель.';
    if (code === 'bad_response' || code === 'bad_request') return 'Не удалось разобрать ответ сервера.' + d;
    if (code === 'http_401' || code === 'http_403') return 'Провайдер отклонил ключ или доступ. Проверь ключ и вход.' + d;
    if (code === 'http_402') return 'У провайдера недостаточно средств или лимита для этого запроса.';
    if (code === 'http_429') return 'Слишком много запросов. Подожди немного и повтори.';
    if (code === 'http_404') return 'Модель или адрес не найдены. Проверь ID модели.' + d;
    if (/^http_5/.test(code)) return 'Сервер провайдера временно недоступен.' + d;
    if (code === 'http_400' && hadImage) return 'Провайдер отклонил запрос. Возможно, модель не поддерживает изображения.' + d;
    return 'Ошибка: ' + code + (detail ? ' — ' + detail : '');
  }
  function finishRequest(err, code, detail) {
    const r = req;
    if (!r) return;
    req = null;
    const c = chats.find(x => x.id === r.chatId);
    const m = findMsg(r.chatId, r.id);
    if (m) {
      m.streaming = false;
      if (err) {
        if (!m.content) { m.error = true; m.content = friendly(code, detail, r.hadImage); }
        else toast(friendly(code, detail, r.hadImage));
        flashError();
      }
    }
    if (c) c.updated = Date.now();
    if (m) { delete m._cut; delete m._head; }
    save();
    if (m && activeId === r.chatId) { const el = msgElById(m.id); const lastM = c && c.messages[c.messages.length - 1] === m; if (el) fillBubble(el, m, lastM); else syncMessages(); if (el && m.error) el.classList.add('error'); }
    renderChatListSoon(); renderComposer(); recomputeOrb();
    if (voice.open) {
      if (err && m) { setVState('Ошибка'); setVoiceReply(m.content); }
    }
    if (!err && m && m.content && (voice.open || S.settings.autoSpeak)) speakMessage(m);
  }
  function speakMessage(m) {
    native('speak', m.id, m.content, detectLang(m.content, voice.open ? voice.lang : speechLang()));
  }

  /* ===================== ввод ===================== */
  function autoGrow() { const t = $('#input'); t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 140) + 'px'; }
  function renderComposer() {
    const b = $('#sendBtn');
    b.innerHTML = ic(req ? 'stop' : 'send', 22);
    b.classList.toggle('stop', !!req);
    b.setAttribute('aria-label', req ? 'Остановить генерацию' : 'Отправить');
    renderAttach();
  }
  function renderAttach() {
    $('#attach').hidden = !pendingImage;
    if (pendingImage) $('#attachImg').src = pendingImage;
  }

  /* ===================== панели ===================== */
  function openDrawer() { $('#drawer').classList.add('open'); $('#scrim').classList.add('show'); }
  function closeDrawer() { $('#drawer').classList.remove('open'); $('#scrim').classList.remove('show'); }
  function closePanels() { $$('.panel.open').forEach(p => p.classList.remove('open')); }
  const FILL = { panelAi: fillAi, panelVoice: fillVoice, panelLimit: refreshLimit, panelScreen: fillScreen, panelAccount: fillAccount };
  function openPanel(id) {
    closeDrawer();
    if (FILL[id]) FILL[id]();
    $('#' + id).classList.add('open');
  }

  /* --- ИИ-подключение --- */
  function setMode(mode, persist) {
    $('#modeOwn').classList.toggle('on', mode === 'own');
    $('#modeFree').classList.toggle('on', mode === 'free');
    $('#ownBox').hidden = mode !== 'own';
    $('#freeBox').hidden = mode !== 'free';
    if (persist) { saveSettings({ mode: mode }); renderHeader(); }
  }
  function keyState() {
    const has = hasKeyFor(S.settings.provider);
    const el = $('#keyState');
    el.textContent = has ? 'Ключ сохранён и зашифрован. Оставь поле пустым, чтобы не менять.' : 'Ключ не задан.';
    el.className = 'note ' + (has ? 'ok' : '');
  }
  function fillAi() {
    const s = S.settings;
    const sel = $('#provider');
    if (!sel.options.length) PROVIDERS.forEach(pr => { const o = document.createElement('option'); o.value = pr.id; o.textContent = pr.name; sel.appendChild(o); });
    setMode(s.mode, false);
    $('#provider').value = s.provider;
    $('#customUrl').value = s.customBaseUrl || '';
    $('#customUrlBox').hidden = s.provider !== 'custom';
    $('#providerNote').textContent = s.provider === 'custom' ? '' : (s.provider === 'openrouter' ? 'Ключ: openrouter.ai → Keys.' : 'Адрес API уже подставлен. Если провайдер сменил названия моделей, поправь поле «Модель».');
    $('#model').value = s.model;
    $('#langSel').value = s.lang;
    $('#sysPrompt').value = s.systemPrompt || DEFAULT_SYSTEM;
    $('#freeStatusLine').textContent = S.configured.backend ? 'Сервер JARVIS подключён в этой сборке.' : 'Сервер JARVIS не подключён в этой сборке приложения: бесплатный режим недоступен.';
    $('#freeStatusLine').className = 'note ' + (S.configured.backend ? 'ok' : 'bad');
    $('#apiKey').value = '';
    $('#testOut').textContent = ''; $('#testOutFree').textContent = ''; $('#saveOut').textContent = '';
    keyState();
  }
  function saveAi() {
    saveSettings({
      provider: $('#provider').value,
      customBaseUrl: $('#provider').value === 'custom' ? $('#customUrl').value.trim() : providerById($('#provider').value).base,
      model: $('#model').value.trim() || 'openrouter/auto',
      lang: $('#langSel').value,
      systemPrompt: $('#sysPrompt').value.trim() || DEFAULT_SYSTEM
    });
    renderHeader();
    $('#saveOut').textContent = 'Настройки сохранены на этом телефоне.';
    $('#saveOut').className = 'note ok';
  }

  /* --- Голос --- */
  let vpLang = 'ru';
  const LANGS = [['ru', 'Русский'], ['az', 'Azərbaycanca'], ['tr', 'Türkçe'], ['en', 'English']];
  function chipsInto(el, current, onPick, short) {
    el.innerHTML = '';
    LANGS.forEach(l => {
      const b = document.createElement('button');
      b.type = 'button'; b.dataset.lang = l[0]; b.className = 'chip' + (l[0] === current ? ' on' : ''); b.textContent = short ? l[0].toUpperCase() : l[1];
      b.onclick = () => onPick(l[0]);
      el.appendChild(b);
    });
  }
  function fillVoice() {
    vpLang = speechLang();
    renderVpChips();
    fillVoiceList();
    $('#rate').value = S.settings.ttsRate; $('#rateVal').textContent = (+S.settings.ttsRate).toFixed(2) + '×';
    $('#pitch').value = S.settings.ttsPitch; $('#pitchVal').textContent = (+S.settings.ttsPitch).toFixed(2);
    $('#autoSpeak').checked = !!S.settings.autoSpeak;
    $('#ttsEngine').value = S.settings.ttsEngine || 'system';
    engineNote();
  }
  function engineNote() {
    const on = $('#ttsEngine').value === 'online';
    $('#engineNote').textContent = on
      ? 'Мужской нейро-голос синтезирует сервер JARVIS: текст ответа отправляется на ваш сервер и в сервис речи. Нужны вход через Google и подключённый сервер, действует дневной лимит символов. Пауза и продолжение работают, голос не переключается незаметно.'
      : 'Голос задаёт движок Android на телефоне. Работает без интернета; пол и тембр приложение определить не может, поэтому выбери голос из списка вручную.';
  }
  function renderVpChips() {
    chipsInto($('#vLangChips'), vpLang, l => { vpLang = l; renderVpChips(); fillVoiceList(); });
  }
  function fillVoiceList() {
    const sel = $('#voiceSel');
    const list = safeJson(native('getVoices', vpLang), []);
    const q = { 100: 'очень низкое', 200: 'низкое', 300: 'обычное', 400: 'высокое', 500: 'очень высокое' };
    sel.innerHTML = '<option value="">Голос по умолчанию</option>';
    list.forEach(v => {
      const o = document.createElement('option');
      o.value = v.name;
      o.textContent = v.name + ' · ' + (q[v.quality] || 'качество ?') + (v.network ? ' · онлайн' : '');
      if (v.selected) o.selected = true;
      sel.appendChild(o);
    });
    const note = $('#voiceNote');
    if (!S.ttsReady) note.textContent = 'Синтез речи ещё не готов или не установлен на этом телефоне.';
    else if (!list.length) note.textContent = 'Для этого языка нет установленных голосов. Нажми «Установить голосовые данные» или выбери язык, который поддерживает твой движок.';
    else note.textContent = 'Доступно голосов: ' + list.length + '. Название показывает движок телефона; пол и тембр приложение определить не может.';
  }

  /* --- Лимит --- */
  function refreshLimit() {
    $('#limitCard').innerHTML = '<div class="note">Запрашиваю состояние у сервера…</div>';
    native('backendStatus');
  }
  function renderLimit(d) {
    const el = $('#limitCard');
    if (!d.ok) {
      const m = {
        free_not_configured: 'Сервер JARVIS не настроен: адрес не указан. Бесплатный режим недоступен, пока сервер не развёрнут (см. SETUP_RU.md).',
        auth_required: 'Войди через Google в разделе «Профиль», чтобы сервер мог вести учёт.',
        network: 'Сервер недоступен. Лимит нельзя проверить без связи с сервером, локальный счётчик не используется.'
      };
      el.innerHTML = '<div class="note bad">' + escapeHtml(m[d.code] || ('Сервер ответил ошибкой: ' + (d.code || 'неизвестно'))) + '</div>';
      return;
    }
    const st = safeJson(d.body, {});
    let h = '';
    if (st.phase === 'blocked') {
      h += '<div class="note bad"><b>Аккаунт заблокирован администратором.</b> Бесплатный режим недоступен. Можно использовать свой ключ.</div>';
    } else if (st.phase === 'pro') {
      const pct = Math.min(100, Math.round(100 * st.usedToday / st.dailyLimit));
      h += '<div class="big-num">JARVIS Pro</div><div class="note">' + (st.planUntil ? 'Действует до ' + new Date(st.planUntil).toLocaleDateString() : 'Без срока') + '. Сегодня осталось ' + st.remainingToday + ' из ' + st.dailyLimit + '.</div><div class="bar"><i style="width:' + pct + '%"></i></div>';
    } else if (st.phase === 'unlimited') {
      h += '<div class="big-num">' + st.daysLeft + ' дн.</div><div class="note">Безлимитный период JARVIS. Дневного лимита нет до ' + new Date(st.unlimitedUntil).toLocaleDateString() + '. Ограничения провайдера ИИ всё равно возможны.</div>';
    } else {
      const pct = Math.min(100, Math.round(100 * st.usedToday / st.dailyLimit));
      h += '<div class="big-num">' + st.remainingToday + ' из ' + st.dailyLimit + '</div><div class="note">осталось запросов сегодня</div><div class="bar"><i style="width:' + pct + '%"></i></div>';
      if (st.resetAt) h += '<div class="note">Сброс счётчика: ' + new Date(st.resetAt).toLocaleString() + '</div>';
    }
    h += '<div class="note dim">Аккаунт: ' + escapeHtml(st.email || '') + '</div>';
    el.innerHTML = h;
  }

  /* --- Экран --- */
  function fillScreen() {
    $('#screenState').textContent = S.screenActive ? '● Показ экрана включён. Снимок можно сделать из уведомления или кнопкой ниже.' : 'Показ экрана выключен.';
    $('#screenStart').disabled = S.screenActive;
    $('#screenStop').disabled = !S.screenActive;
    $('#screenSnap').disabled = !S.screenActive;
  }

  /* --- Профиль --- */
  function renderProfileChip() {
    const p = S.profile || {};
    const chip = $('#profileChip');
    const letter = (p.name || p.email || 'J').charAt(0).toUpperCase();
    const av = p.photo ? '<span class="avatar"><img src="' + escapeHtml(p.photo) + '" alt=""></span>' : '<span class="avatar">' + escapeHtml(letter) + '</span>';
    chip.innerHTML = av + '<span><b>' + escapeHtml(p.signedIn ? (p.name || 'Аккаунт Google') : 'Войти через Google') + '</b><small>' + escapeHtml(p.signedIn ? p.email : 'для бесплатного режима и синхронизации') + '</small></span>';
  }
  function fillAccount() {
    const p = S.profile || {};
    const letter = (p.name || p.email || 'J').charAt(0).toUpperCase();
    $('#profileCard').innerHTML = (p.photo ? '<span class="avatar"><img src="' + escapeHtml(p.photo) + '" alt=""></span>' : '<span class="avatar">' + escapeHtml(letter) + '</span>') +
      '<div><b>' + escapeHtml(p.signedIn ? (p.name || 'Аккаунт Google') : 'Вы не вошли') + '</b><small>' + escapeHtml(p.signedIn ? p.email : 'Вход нужен для бесплатного режима и синхронизации') + '</small></div>';
    $('#signInBtn').hidden = !!p.signedIn;
    $('#signOutBtn').hidden = !p.signedIn;
    $('#perfSel').value = S.settings.perf || 'auto';
  }
  function authHint(err) {
    if (!err) return '';
    if (err === 'no_client_id') return 'Вход через Google не настроен при сборке приложения (нет Web Client ID). См. SETUP_RU.txt.';
    if (/Cancel/i.test(err)) return 'Вход отменён.';
    if (/28444|Developer console|NoCredential|ProviderConfiguration|Unsupported/i.test(err)) return 'Google не принял конфигурацию: проверь Web Client ID, Android Client ID (пакет и SHA-1 из блока ниже), экран согласия OAuth и наличие Google Play Services. Подробности: SETUP_RU.md. (' + err + ')';
    return 'Ошибка входа: ' + err;
  }

  /* --- синхронизация --- */
  function mergeRemote(remote) {
    let added = 0, updated = 0;
    (remote || []).forEach(rc => {
      if (!rc || !rc.id || !Array.isArray(rc.messages)) return;
      const lc = chats.find(c => c.id === rc.id);
      if (!lc) { chats.push(rc); added++; }
      else if ((rc.updated || 0) > (lc.updated || 0)) { Object.assign(lc, rc); updated++; }
    });
    save(); renderAll();
    return added + ' новых, ' + updated + ' обновлено';
  }

  /* ===================== озвучивание (UI) ===================== */
  function markTts() {
    $$('.msg').forEach(el => {
      if (ttsState.state !== 'idle' && el.dataset.id === ttsState.msgId) el.dataset.tts = ttsState.state;
      else delete el.dataset.tts;
    });
  }
  $('#messages').addEventListener('click', e => {
    const cc = e.target.closest('.code-copy');
    if (cc) { native('copyText', cc.closest('.code').querySelector('code').textContent); toast('Код скопирован'); return; }
    const b = e.target.closest('[data-a]');
    if (!b) return;
    const el = b.closest('.msg');
    const c = cur();
    const m = c && c.messages.find(x => x.id === el.dataset.id);
    if (!m) return;
    switch (b.dataset.a) {
      case 'speak': speakMessage(m); break;
      case 'pause': native('pauseSpeech'); break;
      case 'resume': native('resumeSpeech'); break;
      case 'stopspeech': native('stopSpeech'); break;
      case 'copy': native('copyText', m.content); toast('Ответ скопирован'); break;
      case 'regen': regenerate(); break;
    }
  });

  /* ===================== голосовой режим ===================== */
  function plain(s) { return String(s || '').replace(/```[\s\S]*?```/g, ' [код] ').replace(/[*_`#>|]/g, ''); }
  function setVState(t) { $('#vState').textContent = t; }
  function setVoiceReply(t) { $('#vReply').textContent = plain(t); const r = $('#vReply'); r.scrollTop = r.scrollHeight; }
  function renderVoiceUi() {
    $('#vMic').innerHTML = ic(voice.listening ? 'stop' : 'mic', 32);
    $('#vMic').classList.toggle('live', voice.listening);
    $('#vMic').disabled = voice.muted;
    $('#vMic').style.opacity = voice.muted ? .4 : 1;
    $('#vMute').innerHTML = ic(voice.muted ? 'micoff' : 'mic', 24);
    $('#vMute').classList.toggle('on', voice.muted);
    const speaking = ttsState.state !== 'idle';
    $('#vSpeech').hidden = !speaking;
    $('#vSpeechStop').hidden = !speaking;
    $('#vSpeech').innerHTML = ic(ttsState.state === 'paused' ? 'play' : 'pause', 24);
    $('#vSpeech').setAttribute('aria-label', ttsState.state === 'paused' ? 'Продолжить' : 'Пауза');
    $$('#voiceLangs .chip').forEach(b => b.classList.toggle('on', b.dataset.lang === voice.lang));
  }
  function openVoice() {
    closeDrawer();
    voice.open = true; voice.listening = false; voice.lang = speechLang();
    $('#voice').classList.add('open');
    $('#voice').setAttribute('aria-hidden', 'false');
    document.body.classList.add('voice-open');
    $('#vUser').textContent = ''; $('#vReply').textContent = ''; $('#vPerm').hidden = true;
    setVState('Нажми на микрофон');
    native('stopSpeech');
    renderVoiceUi(); recomputeOrb();
  }
  function closeVoice() {
    voice.open = false; voice.listening = false;
    $('#voice').classList.remove('open');
    $('#voice').setAttribute('aria-hidden', 'true');
    document.body.classList.remove('voice-open');
    native('cancelListening');
    native('stopSpeech');
    if (req && req.voice) stopGeneration();
    recomputeOrb();
  }
  function micPress() {
    if (voice.muted) { toast('Микрофон выключен'); return; }
    if (voice.listening) { native('finishListening'); return; }
    if (req) { toast('Подожди, JARVIS ещё отвечает'); return; }
    $('#vPerm').hidden = true; $('#vUser').textContent = ''; $('#vReply').textContent = '';
    setVState('Подключаю микрофон…');
    native('startListening', voice.lang);
  }
  const SPEECH_ERR = {
    no_match: 'Не расслышал. Нажми на микрофон и повтори.',
    timeout: 'Тишина — запись остановлена.',
    network: 'Службе распознавания речи нужен интернет.',
    audio: 'Ошибка записи звука. Проверь, не занят ли микрофон.',
    server: 'Служба распознавания речи вернула ошибку.',
    busy: 'Служба распознавания занята. Повтори через секунду.',
    client: 'Распознавание остановлено.',
    lang: 'Служба распознавания не поддерживает выбранный язык.',
    unavailable: 'На телефоне нет службы распознавания речи. Включи или установи «Google» / «Службы Google».',
    permission: 'Нет разрешения на микрофон.',
    permission_denied: 'Доступ к микрофону не выдан. Разреши его в настройках приложения.'
  };
  function onSpeech(d) {
    if (d.type === 'listening') { voice.listening = true; setVState('Слушаю…'); renderVoiceUi(); recomputeOrb(); }
    else if (d.type === 'level') { setLevel(d.level || 0); }
    else if (d.type === 'partial') { $('#vUser').textContent = d.text; }
    else if (d.type === 'processing') { voice.listening = false; setVState('Обрабатываю…'); renderVoiceUi(); recomputeOrb(); }
    else if (d.type === 'result') {
      voice.listening = false; renderVoiceUi();
      $('#vUser').textContent = d.text;
      setVState('Думаю…');
      send(d.text, { voice: true });
    } else if (d.type === 'error') {
      voice.listening = false; renderVoiceUi(); recomputeOrb(); flashError();
      setVState(SPEECH_ERR[d.code] || 'Ошибка распознавания речи.');
      if (d.code === 'permission_denied' || d.code === 'permission') $('#vPerm').hidden = false;
    }
  }

  /* ===================== события из Android ===================== */
  const H = {
    chatDelta: d => {
      if (!req || req.id !== d.id) return;
      const m = findMsg(req.chatId, d.id);
      if (!m) return;
      m.content += d.text;
      if (activeId === req.chatId) scheduleRender(m);
      if (!req.gotToken) { req.gotToken = true; recomputeOrb(); }
      if (voice.open) { setVState('JARVIS отвечает…'); setVoiceReply(m.content); }
    },
    chatDone: d => { if (req && req.id === d.id) finishRequest(false); },
    chatError: d => { if (req && req.id === d.id) finishRequest(true, d.code, d.detail); },
    tts: d => {
      ttsState = { state: d.state, msgId: d.msgId };
      markTts();
      if (voice.open) {
        if (d.state === 'speaking') setVState('JARVIS говорит…');
        else if (d.state === 'paused') setVState('Пауза');
        else if (!voice.listening && !req) setVState('Готов. Нажми на микрофон');
        renderVoiceUi();
      }
      recomputeOrb();
    },
    ttsWord: () => { setLevel(0.75); },
    ttsReady: d => { S.ttsReady = !!d.ready; },
    bootstrap: d => {
      S.server = { checked: !!d.serverChecked, ok: !!d.serverOk }; S.online = d.online !== false;
      const ac = safeJson(d.appConfig, null);
      if (ac) { S.appConfig = ac; applyAppConfig(); }
      renderNet(); recomputeOrb();
    },
    ttsError: d => {
      toast(d.message || 'Ошибка озвучивания');
      if (voice.open) setVState(d.message || 'Ошибка озвучивания');
      flashError();
    },
    speech: onSpeech,
    auth: d => {
      const err = d.error; delete d.error;
      S.profile = d;
      renderProfileChip(); renderLogin(err ? authHint(err) : '');
      if ($('#panelAccount').classList.contains('open')) {
        fillAccount();
        const o = $('#authOut');
        o.textContent = err ? authHint(err) : (d.signedIn ? 'Вход выполнен: ' + d.email : 'Вы вышли из аккаунта.');
        o.className = 'note ' + (err ? 'bad' : 'ok');
      }
    },
    screen: d => {
      if (d.state === 'started') { S.screenActive = true; toast('Показ экрана включён'); }
      else if (d.state === 'stopped') { S.screenActive = false; pendingImage = ''; toast(d.reason === 'revoked' ? 'Доступ к экрану отозван' : 'Показ экрана остановлен'); }
      else if (d.state === 'denied') toast('Доступ к записи экрана не выдан');
      else if (d.state === 'error') toast('Не удалось включить показ экрана');
      else if (d.state === 'frame') {
        if (d.image) { pendingImage = d.image; toast('Снимок приложен к следующему сообщению'); }
        else toast('Кадра пока нет: открой нужный экран и повтори');
      }
      renderHeader(); renderComposer(); fillScreen();
    },
    testResult: d => {
      const el = S.settings.mode === 'free' ? $('#testOutFree') : $('#testOut');
      let t = d.message || '';
      if (d.ok && d.imageSupport === 'yes') t += ' Модель поддерживает изображения.';
      else if (d.ok && d.imageSupport === 'no') t += ' Эта модель, судя по каталогу, не принимает изображения.';
      el.textContent = t;
      el.className = 'note ' + (d.ok ? 'ok' : 'bad');
    },
    freeStatus: d => { renderLimit(d); },
    syncResult: d => {
      const o = $('#syncOut');
      let t;
      if (!d.ok) {
        t = d.code === 'auth_required' ? 'Нужен вход через Google.' : d.code === 'free_not_configured' ? 'Адрес сервера не указан.' : 'Сервер недоступен или отклонил запрос (' + d.code + ').';
      } else if (d.action === 'up') t = 'История отправлена на сервер.';
      else if (d.action === 'delete') t = 'История на сервере удалена.';
      else { const body = safeJson(d.body, {}); t = 'Загружено с сервера: ' + mergeRemote(body.chats); }
      o.textContent = t; o.className = 'note ' + (d.ok ? 'ok' : 'bad');
    }
  };
  window.JarvisEvents = { emit: function (name, json) { const d = safeJson(json, {}); if (H[name]) { try { H[name](d); } catch (e) { console.error(name, e); } } } };

  /* ===================== привязка элементов ===================== */
  function mountIcons() {
    $('#closeDrawer').innerHTML = ic('close');
    $('#newChat').innerHTML = ic('plus', 20) + ' Новый чат';
    $('#searchIcon').innerHTML = ic('search', 18);
    const nav = { panelAi: ['key', 'ИИ-подключение'], panelVoice: ['wave', 'Голос JARVIS'], panelLimit: ['gauge', 'Бесплатный лимит'], panelScreen: ['eye', 'Показать экран'], panelAccount: ['user', 'Профиль и данные'] };
    $$('.nav button').forEach(b => { const n = nav[b.dataset.open]; b.innerHTML = ic(n[0], 20) + '<span>' + n[1] + '</span>'; });
    $('#openDrawer').innerHTML = ic('menu'); $('#topNew').innerHTML = ic('plus'); $('#openVoice').innerHTML = ic('wave');
    $('#snapBtn').innerHTML = ic('camera'); $('#attachRemove').innerHTML = ic('close', 16);
    $$('.back').forEach(b => { b.innerHTML = ic('back'); });
    $('#voiceClose').innerHTML = ic('close');
    $('#vSpeechStop').innerHTML = ic('stop', 22); $('#vEnd').innerHTML = ic('close', 24);
    chipsInto($('#voiceLangs'), 'ru', l => { voice.lang = l; renderVoiceUi(); }, true);
    $('#foot').textContent = 'JARVIS может ошибаться. Проверяй важное.';
    $('#suggestions').innerHTML = '';
    ['Объясни простыми словами, как работает ИИ', 'Составь план на сегодня', 'Помоги написать вежливое письмо', 'Придумай идею для проекта'].forEach(t => {
      const b = document.createElement('button'); b.className = 'chip'; b.textContent = t; b.onclick = () => send(t); $('#suggestions').appendChild(b);
    });
  }
  function newChat() { if (req && !req.voice) { /* генерация продолжается в своём чате */ } activeId = null; renderAll(); closeDrawer(); $('#input').focus(); }

  function bind() {
    $('#openDrawer').onclick = openDrawer; $('#closeDrawer').onclick = closeDrawer; $('#scrim').onclick = closeDrawer;
    $('#newChat').onclick = newChat; $('#topNew').onclick = newChat;
    $('#search').oninput = renderChatList;
    $$('.nav button').forEach(b => { b.onclick = () => openPanel(b.dataset.open); });
    $('#profileChip').onclick = () => openPanel('panelAccount');
    $('#setupBtn').onclick = () => openPanel('panelAi');
    $$('[data-close]').forEach(b => { b.onclick = closePanels; });
    $('#openVoice').onclick = openVoice; $('#voiceClose').onclick = closeVoice; $('#vEnd').onclick = closeVoice;
    $('#input').addEventListener('input', autoGrow);
    $('#form').addEventListener('submit', e => { e.preventDefault(); if (req) stopGeneration(); else send($('#input').value); });
    $('#snapBtn').onclick = () => native('captureScreen');
    $('#attachRemove').onclick = () => { pendingImage = ''; renderAttach(); };

    // ИИ
    $('#modeOwn').onclick = () => setMode('own', true);
    $('#modeFree').onclick = () => setMode('free', true);
    $('#provider').onchange = () => {
      const pr = providerById($('#provider').value);
      const prevPr = providerById(S.settings.provider);
      const modelNow = $('#model').value.trim();
      const patch = { provider: pr.id };
      if (pr.id !== 'custom' && pr.id !== 'openrouter') patch.customBaseUrl = pr.base;
      if (pr.id === 'custom') patch.customBaseUrl = '';
      if (!modelNow || modelNow === prevPr.model) { patch.model = pr.model || modelNow; $('#model').value = patch.model; }
      $('#customUrl').value = patch.customBaseUrl !== undefined ? patch.customBaseUrl : $('#customUrl').value;
      $('#customUrlBox').hidden = pr.id !== 'custom';
      $('#providerNote').textContent = pr.id === 'custom' ? '' : (pr.id === 'openrouter' ? 'Ключ: openrouter.ai → Keys.' : 'Адрес API уже подставлен. Если провайдер сменил названия моделей, поправь поле «Модель».');
      saveSettings(patch); keyState(); renderHeader();
    };
    $('#saveKey').onclick = () => {
      const k = $('#apiKey').value.trim();
      if (!k) { toast('Вставь ключ в поле'); return; }
      const prov = $('#provider').value;
      if (native('saveApiKey', prov, k)) {
        S.keys[prov] = true;
        $('#apiKey').value = ''; keyState(); renderHeader(); toast('Ключ сохранён');
      } else toast('Не удалось сохранить ключ');
    };
    $('#clearKey').onclick = async () => {
      if (!(await askConfirm('Удалить сохранённый API-ключ с этого телефона?'))) return;
      const prov = $('#provider').value;
      native('clearApiKey', prov);
      S.keys[prov] = false;
      keyState(); renderHeader(); toast('Ключ удалён');
    };
    $('#testBtn').onclick = () => { saveAi(); $('#testOut').textContent = 'Проверяю…'; $('#testOut').className = 'note'; native('testConnection'); };
    $('#testFree').onclick = () => { saveAi(); $('#testOutFree').textContent = 'Проверяю…'; $('#testOutFree').className = 'note'; native('testConnection'); };
    $('#saveAi').onclick = saveAi;
    $('#resetPrompt').onclick = () => { $('#sysPrompt').value = DEFAULT_SYSTEM; };

    // Голос
    $('#voiceSel').onchange = () => { native('setVoice', vpLang, $('#voiceSel').value); setTimeout(() => native('previewVoice', vpLang), 150); };
    $('#ttsEngine').onchange = () => {
      const v = $('#ttsEngine').value; saveSettings({ ttsEngine: v }); engineNote();
      if (v === 'online' && (!S.configured.backend || !(S.profile && S.profile.signedIn))) toast('Нейро-голос заработает после входа через Google и при подключённом сервере');
    };
    $('#rate').oninput = () => { $('#rateVal').textContent = (+$('#rate').value).toFixed(2) + '×'; };
    $('#rate').onchange = () => saveSettings({ ttsRate: +$('#rate').value });
    $('#pitch').oninput = () => { $('#pitchVal').textContent = (+$('#pitch').value).toFixed(2); };
    $('#pitch').onchange = () => saveSettings({ ttsPitch: +$('#pitch').value });
    $('#preview').onclick = () => native('previewVoice', vpLang);
    $('#stopPreview').onclick = () => native('stopSpeech');
    $('#autoSpeak').onchange = () => saveSettings({ autoSpeak: $('#autoSpeak').checked });
    $('#ttsSettings').onclick = () => native('openTtsSettings');
    $('#ttsInstall').onclick = () => native('installTtsData');

    // Лимит и экран
    $('#refreshLimit').onclick = refreshLimit;
    $('#screenStart').onclick = () => native('startScreenShare');
    $('#screenStop').onclick = () => native('stopScreenShare');
    $('#screenSnap').onclick = () => native('captureScreen');

    // Аккаунт
    $('#signInBtn').onclick = () => { $('#authOut').textContent = 'Открываю вход Google…'; $('#authOut').className = 'note'; native('signIn'); };
    $('#signOutBtn').onclick = () => native('signOut');
    $('#perfSel').onchange = () => { saveSettings({ perf: $('#perfSel').value }); applyPerf(); };
    $('#syncUp').onclick = () => {
      const payload = JSON.stringify({ version: 2, at: Date.now(), chats: chats.map(c => ({ id: c.id, title: c.title, created: c.created, updated: c.updated, messages: c.messages.map(m => ({ id: m.id, role: m.role, content: m.content, error: m.error, stopped: m.stopped, local: m.local })) })) });
      if (payload.length > 4500000) { toast('История слишком большая для отправки'); return; }
      $('#syncOut').textContent = 'Отправляю…'; $('#syncOut').className = 'note';
      native('syncUp', payload);
    };
    $('#syncDown').onclick = () => { $('#syncOut').textContent = 'Загружаю…'; $('#syncOut').className = 'note'; native('syncDown'); };
    $('#delServer').onclick = async () => { if (await askConfirm('Удалить историю этого аккаунта на сервере?')) native('deleteServerHistory'); };
    $('#delLocal').onclick = async () => {
      if (!(await askConfirm('Удалить всю историю чатов на этом телефоне?'))) return;
      if (req) stopGeneration();
      chats = []; activeId = null;
      try { localStorage.removeItem(KEY); localStorage.removeItem('jarvis_chats_v1'); } catch (e) { /* ignore */ }
      renderAll(); toast('Локальная история удалена');
    };

    // Вход и состояние сети
    $('#loginBtn').onclick = () => { $('#loginErr').textContent = ''; native('signIn'); };
    $('#loginGuest').onclick = () => { try { sessionStorage.setItem('jarvis_dev_guest', '1'); } catch (e) { /* ignore */ } renderLogin(''); maybeOnboard(); };
    $('#netPill').onclick = () => { if ($('#netPill').dataset.act === 'retry') { S.server.checked = false; native('retryBootstrap'); toast('Проверяю сервер…'); } };

    // Голосовой экран
    $('#vMic').onclick = micPress;
    $('#vMute').onclick = () => { voice.muted = !voice.muted; if (voice.muted && voice.listening) { native('cancelListening'); voice.listening = false; setVState('Микрофон выключен'); recomputeOrb(); } renderVoiceUi(); };
    $('#vSpeech').onclick = () => native(ttsState.state === 'paused' ? 'resumeSpeech' : 'pauseSpeech');
    $('#vSpeechStop').onclick = () => native('stopSpeech');
    $('#vPerm').onclick = () => native('openAppSettings');

    // кнопка «Назад»
    window.jarvisBack = function () {
      if (!$('#keyDialog').hidden) { $('#keyDialogLater').click(); return true; }
      if (!$('#dialog').hidden) { $('#dialogNo').click(); return true; }
      if (voice.open) { closeVoice(); return true; }
      if ($$('.panel.open').length) { closePanels(); return true; }
      if ($('#drawer').classList.contains('open')) { closeDrawer(); return true; }
      return false;
    };
  }

  /* ===================== конфигурация сервера, сеть, вход, эффекты ===================== */
  function applyAppConfig() {
    const ac = S.appConfig || {};
    S.remotePrompt = ac.systemPrompt || '';
    const notice = $('#notice');
    const text = ac.maintenance ? (ac.announcement || 'Идут технические работы: бесплатный режим временно недоступен.') : (ac.announcement || '');
    notice.hidden = !text; notice.textContent = text;
    const f = ac.features || {};
    const nav = document.querySelector('.nav [data-open="panelScreen"]'); if (nav) nav.hidden = f.screenShare === false;
    const opt = $('#ttsEngine option[value="online"]'); if (opt) opt.disabled = f.onlineTts === false || ac.ttsAvailable === false;
  }
  function renderNet() {
    const p = $('#netPill');
    if (!S.online) { p.hidden = false; p.textContent = 'нет сети'; p.dataset.act = ''; }
    else if (S.configured.backend && S.server.checked && !S.server.ok) { p.hidden = false; p.textContent = 'сервер недоступен · повторить'; p.dataset.act = 'retry'; }
    else p.hidden = true;
  }
  function needLogin() { return !(S.profile && S.profile.signedIn) && !sessionStorage.getItem('jarvis_dev_guest'); }
  function renderLogin(err) {
    const el = $('#login'), show = needLogin();
    el.classList.toggle('open', show); el.setAttribute('aria-hidden', show ? 'false' : 'true');
    if (!show) return;
    $('#loginText').textContent = S.configured.google
      ? 'Войди через Google, чтобы пользоваться JARVIS. Аккаунт нужен для истории, лимитов и бесплатного режима.'
      : 'Вход через Google не настроен при сборке приложения: не задан Web Client ID. Это делает владелец проекта (инструкция в SETUP_RU.txt).';
    $('#loginBtn').hidden = !S.configured.google; $('#loginGuest').hidden = S.configured.google;
    $('#loginErr').textContent = err || '';
  }
  function applyPerf() {
    let mode = S.settings.perf || 'auto', lite = mode === 'lite';
    if (mode === 'auto') { try { lite = localStorage.getItem('jarvis_perf_auto') === 'lite'; } catch (e) { lite = false; } }
    document.body.classList.toggle('lite', lite);
  }
  /** Замер реальной частоты кадров один раз: если телефон медленный, включается лёгкий режим. */
  function perfProbe() {
    let stored = null; try { stored = localStorage.getItem('jarvis_perf_auto'); } catch (e) { /* ignore */ }
    if (stored || (S.settings.perf || 'auto') !== 'auto') return;
    let n = 0, t0 = 0;
    (function frame(t) {
      if (!t0) t0 = t;
      if (++n < 45) { requestAnimationFrame(frame); return; }
      const avg = (t - t0) / (n - 1);
      try { localStorage.setItem('jarvis_perf_auto', avg > 28 ? 'lite' : 'full'); } catch (e) { /* ignore */ }
      applyPerf();
    })(performance.now());
  }

  /* ===================== запуск ===================== */
  function init() {
    mountIcons();
    const st = safeJson(native('getState'), null);
    if (st) {
      S.settings = Object.assign(S.settings, st.settings || {});
      PROVIDERS.forEach(pr => { S.keys[pr.id] = !!native('hasKey', pr.id); });
      S.profile = st.profile || {}; S.ttsReady = !!st.ttsReady; S.screenActive = !!st.screenActive;
      S.configured = st.configured || S.configured; S.online = st.online !== false;
    }
    if (!S.settings.systemPrompt) S.settings.systemPrompt = DEFAULT_SYSTEM;
    loadChats();
    bind();
    applyPerf();
    renderAll();
    recomputeOrb();
    renderLogin('');
    if (!needLogin()) maybeOnboard();
    window.addEventListener('online', () => { S.online = true; renderNet(); recomputeOrb(); native('retryBootstrap'); });
    window.addEventListener('offline', () => { S.online = false; renderNet(); recomputeOrb(); });
    document.addEventListener('visibilitychange', () => document.body.classList.toggle('paused', document.hidden));
    renderNet();
    // Интерфейс готов: история загружена и отрисована. Нативная заставка может завершаться.
    requestAnimationFrame(() => { native('appReady'); setTimeout(perfProbe, 600); });
  }
  function isConfigured() {
    const s = S.settings;
    return s.mode === 'free' ? S.configured.backend : hasKeyFor(s.provider);
  }
  function maybeOnboard() {
    let skipped = false;
    try { skipped = localStorage.getItem('jarvis_key_prompt_skipped') === '1'; } catch (e) { /* ignore */ }
    if (isConfigured() || skipped) return;
    $('#keyDialog').hidden = false;
    if (!S.configured.backend) $('#ourKeyNote').textContent = 'Сервер JARVIS пока не подключён (его адрес задаёт владелец приложения). Пока используй свой ключ.';
    $('#useOurKey').onclick = () => {
      if (!S.configured.backend) { $('#keyDialogOut').textContent = 'Адрес сервера JARVIS не задан, ключ JARVIS недоступен.'; $('#keyDialogOut').className = 'note bad'; return; }
      saveSettings({ mode: 'free' });
      $('#keyDialog').hidden = true;
      renderHeader();
      if (!(S.profile && S.profile.signedIn)) { toast('Войди через Google, чтобы пользоваться ключом JARVIS'); openPanel('panelAccount'); }
      else toast('Готово: используется ключ JARVIS');
    };
    $('#keyDialogSave').onclick = () => {
      const k = $('#keyDialogInput').value.trim();
      const out = $('#keyDialogOut');
      if (!k) { out.textContent = 'Вставь ключ в поле.'; out.className = 'note bad'; return; }
      saveSettings({ mode: 'own', provider: 'openrouter' });
      if (native('saveApiKey', 'openrouter', k)) {
        S.keys.openrouter = true;
        $('#keyDialogInput').value = '';
        $('#keyDialog').hidden = true;
        renderHeader();
        toast('Ключ сохранён. JARVIS готов.');
      } else { out.textContent = 'Не удалось сохранить ключ.'; out.className = 'note bad'; }
    };
    $('#keyDialogLater').onclick = () => {
      try { localStorage.setItem('jarvis_key_prompt_skipped', '1'); } catch (e) { /* ignore */ }
      $('#keyDialog').hidden = true;
    };
  }
  init();
})();
