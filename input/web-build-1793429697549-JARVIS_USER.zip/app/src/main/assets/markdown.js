/* Небольшой безопасный Markdown-рендерер: заголовки, списки, цитаты, таблицы, код, ссылки. */
(function (root) {
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function fmt(s) {
    s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2">$1</a>');
    s = s.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>').replace(/__([^_\n]+)__/g, '<strong>$1</strong>');
    s = s.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<em>$2</em>');
    s = s.replace(/~~([^~\n]+)~~/g, '<del>$1</del>');
    return s;
  }

  function inline(t) {
    return t.split(/(`[^`\n]+`)/).map(function (p, i) {
      return i % 2 ? '<code>' + esc(p.slice(1, -1)) + '</code>' : fmt(esc(p));
    }).join('');
  }

  function codeBlock(lang, code) {
    return '<div class="code"><div class="code-head"><span>' + esc(lang || 'code') +
      '</span><button type="button" class="code-copy">Копировать</button></div><pre><code>' + esc(code) + '</code></pre></div>';
  }

  function cells(line) {
    line = line.trim().replace(/^\|/, '').replace(/\|$/, '');
    return line.split('|').map(function (c) { return c.trim(); });
  }

  function render(src) {
    src = String(src == null ? '' : src).replace(/\r\n?/g, '\n');
    const lines = src.split('\n');
    const out = [];
    let para = [];
    let i = 0;
    const flush = function () {
      if (para.length) { out.push('<p>' + inline(para.join('\n')).replace(/\n/g, '<br>') + '</p>'); para = []; }
    };
    while (i < lines.length) {
      const line = lines[i];
      let m = line.match(/^\s*```\s*([\w+#.-]*)\s*$/);
      if (m) {
        flush();
        const code = [];
        i++;
        while (i < lines.length && !/^\s*```\s*$/.test(lines[i])) { code.push(lines[i]); i++; }
        i++;
        out.push(codeBlock(m[1], code.join('\n')));
        continue;
      }
      if (/^\s*$/.test(line)) { flush(); i++; continue; }
      m = line.match(/^(#{1,4})\s+(.+?)\s*#*$/);
      if (m) { flush(); const n = m[1].length + 1; out.push('<h' + n + '>' + inline(m[2]) + '</h' + n + '>'); i++; continue; }
      if (/^\s*([-*_])\s*\1\s*\1[\s\-*_]*$/.test(line)) { flush(); out.push('<hr>'); i++; continue; }
      if (/^\s*>/.test(line)) {
        flush();
        const q = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) { q.push(lines[i].replace(/^\s*>\s?/, '')); i++; }
        out.push('<blockquote>' + inline(q.join('\n')).replace(/\n/g, '<br>') + '</blockquote>');
        continue;
      }
      if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(lines[i + 1])) {
        flush();
        const head = cells(line);
        i += 2;
        let html = '<div class="table-wrap"><table><thead><tr>' + head.map(function (c) { return '<th>' + inline(c) + '</th>'; }).join('') + '</tr></thead><tbody>';
        while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) {
          html += '<tr>' + cells(lines[i]).map(function (c) { return '<td>' + inline(c) + '</td>'; }).join('') + '</tr>';
          i++;
        }
        out.push(html + '</tbody></table></div>');
        continue;
      }
      m = line.match(/^\s*([-*+]|\d+[.)])\s+(.*)$/);
      if (m) {
        flush();
        const ordered = /\d/.test(m[1]);
        const items = [];
        while (i < lines.length) {
          const mm = lines[i].match(/^\s*([-*+]|\d+[.)])\s+(.*)$/);
          if (!mm || /\d/.test(mm[1]) !== ordered) break;
          items.push(inline(mm[2]));
          i++;
        }
        const tag = ordered ? 'ol' : 'ul';
        out.push('<' + tag + '>' + items.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</' + tag + '>');
        continue;
      }
      para.push(line);
      i++;
    }
    flush();
    return out.join('');
  }

  root.renderMarkdown = render;
  root.escapeHtml = esc;
  if (typeof module !== 'undefined') module.exports = { renderMarkdown: render, escapeHtml: esc };
})(typeof window !== 'undefined' ? window : globalThis);
