/* Определение языка сообщения: русский, азербайджанский, турецкий, английский. */
(function (root) {
  const AZ = new Set(['və', 'necə', 'nə', 'mən', 'sən', 'üçün', 'deyil', 'salam', 'yox', 'bəli', 'nədir', 'zəhmət',
    'olar', 'çox', 'mənə', 'sizə', 'lazımdır', 'kömək', 'haqqında', 'azərbaycan', 'bilirsən', 'danış', 'göstər', 'yaz']);
  const TR = new Set(['ve', 'nasıl', 'ne', 'ben', 'sen', 'için', 'değil', 'merhaba', 'evet', 'hayır', 'lütfen', 'çok',
    'bugün', 'nedir', 'mı', 'mi', 'bana', 'yardım', 'istiyorum', 'bunu', 'şunu', 'olarak', 'türkiye', 'söyle', 'anlat']);
  const EN = new Set(['the', 'is', 'are', 'what', 'how', 'you', 'i', 'to', 'of', 'and', 'in', 'for', 'can', 'please',
    'hello', 'why', 'with', 'this', 'that', 'my', 'me', 'do', 'does', 'it', 'write', 'show', 'help', 'open', 'tell', 'explain']);

  function detectLang(text, fallback) {
    fallback = fallback || 'ru';
    const t = String(text || '').toLowerCase();
    const cyr = (t.match(/[\u0400-\u04ff]/g) || []).length;
    const lat = (t.match(/[a-zçğıöşüə]/g) || []).length;
    if (cyr >= 2 && cyr >= lat) return 'ru';
    const words = t.match(/[a-zçğıöşüə]+/g) || [];
    const s = { az: 0, tr: 0, en: 0 };
    for (const w of words) {
      if (AZ.has(w)) s.az += 2;
      if (TR.has(w)) s.tr += 2;
      if (EN.has(w)) s.en += 1;
    }
    if (t.indexOf('ə') >= 0) s.az += 4;
    let best = fallback, max = 0;
    for (const k of ['az', 'tr', 'en']) if (s[k] > max) { max = s[k]; best = k; }
    if (max === 0) {
      if (lat >= 3 && !/[çğıöşüə]/.test(t)) return fallback === 'ru' ? 'en' : fallback;
      return fallback;
    }
    return best;
  }

  root.detectLang = detectLang;
  if (typeof module !== 'undefined') module.exports = { detectLang };
})(typeof window !== 'undefined' ? window : globalThis);
