// Сервер-посредник JARVIS для бесплатного режима. Node.js 18+, без зависимостей.
// Хранит общий ключ OpenRouter, проверяет вход через Google, считает лимиты по серверному времени.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { evaluate, reserve, refund, activePlan, DAY_MS, dayKey } from './quota.mjs';
import { verifyGoogleIdToken, fetchGoogleJwks } from './auth.mjs';

const MAX_CHAT_BYTES = 6 * 1024 * 1024;   // с запасом на снимок экрана
const MAX_HISTORY_BYTES = 5 * 1024 * 1024;

// Шифрование ключа провайдера «на диске» (если задан CONFIG_SECRET). Без него ключ хранится открытым текстом.
export function sealSecret(plain, secret) {
  if (!secret) return 'plain:' + plain;
  const key = crypto.scryptSync(secret, 'jarvis-config-v1', 32);
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([c.update(plain, 'utf8'), c.final()]);
  return 'enc:' + Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64');
}
export function openSecret(stored, secret) {
  if (!stored) return '';
  if (stored.startsWith('plain:')) return stored.slice(6);
  if (!stored.startsWith('enc:') || !secret) return '';
  try {
    const raw = Buffer.from(stored.slice(4), 'base64');
    const key = crypto.scryptSync(secret, 'jarvis-config-v1', 32);
    const d = crypto.createDecipheriv('aes-256-gcm', key, raw.subarray(0, 12));
    d.setAuthTag(raw.subarray(12, 28));
    return Buffer.concat([d.update(raw.subarray(28)), d.final()]).toString('utf8');
  } catch { return ''; }
}
const hint = (k) => (k ? '…' + k.slice(-4) : '');

export function createApp(opts) {
  const adminEmails = (opts.adminEmails || []).map((e) => e.trim().toLowerCase()).filter(Boolean);
  const keyCheckUrl = opts.keyCheckUrl || 'https://openrouter.ai/api/v1/auth/key';
  const dataFile = opts.dataFile;
  const verify = opts.verify || ((token) => verifyGoogleIdToken(token, { clientId: opts.googleClientId, getJwks: fetchGoogleJwks }));
  const upstreamUrl = opts.upstreamUrl || 'https://openrouter.ai/api/v1/chat/completions';
  const now = opts.now || (() => Date.now());

  let db = { users: {}, history: {}, config: {} };
  try { db = JSON.parse(fs.readFileSync(dataFile, 'utf8')); } catch { /* новый файл */ }
  db.config = db.config || {}; db.users = db.users || {}; db.history = db.history || {};

  // Рабочие настройки: значения из админки перекрывают значения из переменных окружения.
  const num = (v, d) => (Number.isFinite(Number(v)) && v !== null && v !== '' && v !== undefined ? Number(v) : d);
  const cfg = () => ({
    unlimitedDays: num(db.config.unlimitedDays, opts.unlimitedDays ?? 15),
    dailyLimit: num(db.config.dailyLimit, opts.dailyLimit ?? 5),
    proDailyLimit: num(db.config.proDailyLimit, opts.proDailyLimit ?? 200),
  });
  const azureKey = () => openSecret(db.config.azureKeyStored, opts.configSecret) || opts.azureKey || '';
  const azureRegion = () => db.config.azureRegion || opts.azureRegion || '';
  const cget = (k, d) => (db.config[k] !== undefined && db.config[k] !== null ? db.config[k] : d);
  const adminMode = opts.adminMode === 'open' ? 'open' : 'google';
  const startedAtMs = Date.now();
  // Журнал событий (кольцевой буфер, без секретов и без текста сообщений).
  const logs = [];
  const logEvent = (level, type, message, extra) => {
    logs.push({ t: now(), level, type, message: String(message).slice(0, 300), ...(extra || {}) });
    if (logs.length > 500) logs.splice(0, logs.length - 500);
    if (level === 'error') console.error('[' + type + ']', String(message).slice(0, 200));
  };
  const freeModel = () => db.config.freeModel || opts.freeModel || 'openrouter/auto';
  const proModel = () => db.config.proModel || opts.proModel || freeModel();
  const providerKey = () => openSecret(db.config.keyStored, opts.configSecret) || opts.openrouterKey || '';
  const activeChats = new Map();           // sub -> число одновременных запросов
  const ipHits = new Map();                // ip -> { n, reset }
  const rateLimited = (req) => {
    const ip = (opts.trustProxy && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '?';
    const t = now();
    let h = ipHits.get(ip);
    if (!h || h.reset < t) { h = { n: 0, reset: t + 60000 }; ipHits.set(ip, h); if (ipHits.size > 5000) for (const [k, v] of ipHits) if (v.reset < t) ipHits.delete(k); }
    h.n += 1;
    return h.n > (opts.ipLimitPerMin ?? 240);
  };
  let writing = Promise.resolve();
  function persist() {
    writing = writing.then(() => {
      const tmp = dataFile + '.tmp';
      fs.mkdirSync(path.dirname(dataFile), { recursive: true });
      fs.writeFileSync(tmp, JSON.stringify(db));
      fs.renameSync(tmp, dataFile);
    }).catch((e) => console.error('persist failed', e.message));
    return writing;
  }

  const send = (res, code, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(body);
  };
  const err = (res, code, errCode, message) => send(res, code, { error: { code: errCode, message } });

  function readBody(req, limit) {
    return new Promise((resolve, reject) => {
      let size = 0; const chunks = [];
      req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('too_large')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', reject);
    });
  }

  async function authenticate(req) {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : '';
    if (!token) return null;
    try {
      const u = await verify(token);
      return u && u.sub ? u : null;
    } catch { return null; }
  }

  function getUser(sub, email) {
    let u = db.users[sub];
    if (!u) { u = db.users[sub] = { startedAt: now(), dayKey: '', count: 0, email, plan: 'free', blocked: false, total: 0, lastSeen: now() }; }
    if (email) u.email = email;
    return u;
  }

  function sanitizeMessages(raw) {
    if (!Array.isArray(raw)) return null;
    const out = [];
    for (const m of raw.slice(-40)) {
      if (!m || !['system', 'user', 'assistant'].includes(m.role)) continue;
      if (typeof m.content === 'string') out.push({ role: m.role, content: m.content.slice(0, 40000) });
      else if (Array.isArray(m.content) && m.role === 'user') {
        const parts = [];
        for (const p of m.content) {
          if (p && p.type === 'text' && typeof p.text === 'string') parts.push({ type: 'text', text: p.text.slice(0, 40000) });
          else if (p && p.type === 'image_url' && p.image_url && typeof p.image_url.url === 'string' && p.image_url.url.startsWith('data:image/')) parts.push({ type: 'image_url', image_url: { url: p.image_url.url } });
        }
        if (parts.length) out.push({ role: 'user', content: parts });
      }
    }
    return out.length ? out : null;
  }

  async function handleChat(req, res, user) {
    const n = activeChats.get(user.sub) || 0;
    if (n >= (opts.maxParallelChats ?? 2)) return err(res, 429, 'busy', 'Слишком много одновременных запросов.');
    activeChats.set(user.sub, n + 1);
    try { await handleChatInner(req, res, user); }
    finally { const c = (activeChats.get(user.sub) || 1) - 1; if (c <= 0) activeChats.delete(user.sub); else activeChats.set(user.sub, c); }
  }

  async function handleChatInner(req, res, user) {
    let body;
    try { body = JSON.parse(await readBody(req, MAX_CHAT_BYTES)); } catch (e) { return err(res, e.message === 'too_large' ? 413 : 400, 'bad_request', 'Некорректный запрос.'); }
    const messages = sanitizeMessages(body.messages);
    if (!messages) return err(res, 400, 'bad_request', 'Нет сообщений.');
    if (cget('maintenance', false)) return err(res, 503, 'maintenance', cget('announcement', '') || 'Идут технические работы.');
    // Системный промпт администратора главный; системные сообщения клиента добавляются после него.
    const adminPrompt = String(cget('systemPrompt', '') || '').trim();
    if (adminPrompt) {
      const clientSys = messages.filter((m) => m.role === 'system' && typeof m.content === 'string').map((m) => m.content).join('\n');
      const rest = messages.filter((m) => m.role !== 'system');
      messages.length = 0;
      messages.push({ role: 'system', content: adminPrompt + (clientSys ? '\n\n' + clientSys : '') }, ...rest);
    }

    const u = getUser(user.sub, user.email);
    if (u.blocked) { logEvent('warn', 'blocked', 'Запрос заблокированного пользователя', { user: u.email }); return err(res, 403, 'blocked', 'Доступ к JARVIS для этого аккаунта заблокирован администратором.'); }
    if (!providerKey()) return err(res, 503, 'not_configured', 'На сервере не задан ключ ИИ-провайдера.');
    const r = reserve(u, now(), cfg());
    if (!r.ok) {
      return send(res, 429, { error: { code: 'daily_limit', message: 'Дневной лимит бесплатного режима исчерпан.' }, status: r.status });
    }
    await persist();

    const refundIt = async () => { refund(u, now()); await persist(); };
    // Клиент отключился (отмена генерации): прерываем запрос к провайдеру.
    const ac = new AbortController();
    res.on('close', () => { if (!res.writableEnded) ac.abort(); });
    let up;
    try {
      up = await fetch(upstreamUrl, {
        signal: ac.signal,
        method: 'POST',
        headers: { Authorization: 'Bearer ' + providerKey(), 'Content-Type': 'application/json', 'HTTP-Referer': 'https://jarvis.local', 'X-Title': 'JARVIS AI' },
        body: JSON.stringify({ model: activePlan(u, now()) === 'pro' ? proModel() : freeModel(), messages, stream: true, max_tokens: cget('maxTokens', opts.maxTokens ?? 1500),
          ...(cget('temperature', null) !== null ? { temperature: cget('temperature', null) } : {}), ...(cget('topP', null) !== null ? { top_p: cget('topP', null) } : {}) }),
      });
    } catch {
      await refundIt();
      if (ac.signal.aborted) return res.end();
      logEvent('error', 'upstream', 'Провайдер ИИ недоступен', { user: u.email });
      return err(res, 502, 'upstream', 'Провайдер ИИ недоступен.');
    }
    if (!up.ok) {
      await refundIt();
      logEvent('error', 'upstream', 'Провайдер ИИ вернул ' + up.status, { user: u.email });
      return err(res, up.status === 429 ? 503 : 502, 'upstream', 'Провайдер ИИ вернул ошибку ' + up.status + '.');
    }
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
    let sent = false;
    try {
      for await (const chunk of up.body) { sent = true; if (!res.write(chunk)) await new Promise((ok) => res.once('drain', ok)); }
    } catch { /* клиент отключился или поток прерван */ }
    if (!sent) await refundIt();
    res.end();
  }



  // ---------- нейро-голос (Azure Speech), ключ хранится только на сервере ----------
  const VOICES = { ru: ['ru-RU', opts.voiceRu || 'ru-RU-DmitryNeural'], az: ['az-AZ', opts.voiceAz || 'az-AZ-BabekNeural'],
    tr: ['tr-TR', opts.voiceTr || 'tr-TR-AhmetNeural'], en: ['en-US', opts.voiceEn || 'en-US-GuyNeural'] };
  const xmlEsc = (t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
  const voiceFor = (l) => { const o = (db.config.voices || {})[l]; const d = VOICES[l]; return d ? [d[0], o || d[1]] : null; };
  const ttsAvailable = () => cget('ttsEnabled', true) && !!(azureKey() && (azureRegion() || opts.ttsUrl));
  async function handleTts(req, res, user) {
    if (!ttsAvailable()) return err(res, 503, 'not_configured', 'Нейро-голос не настроен на сервере.');
    let body;
    try { body = JSON.parse(await readBody(req, 16 * 1024)); } catch { return err(res, 400, 'bad_request', 'Некорректный запрос.'); }
    const text = typeof body.text === 'string' ? body.text.trim().slice(0, 700) : '';
    const v = voiceFor(body.lang);
    if (!text || !v) return err(res, 400, 'bad_request', 'Нужны text и lang (ru, az, tr, en).');
    const u = getUser(user.sub, user.email);
    if (u.blocked) return err(res, 403, 'blocked', 'Доступ заблокирован администратором.');
    const day = dayKey(now());
    if (u.ttsDay !== day) { u.ttsDay = day; u.ttsChars = 0; }
    const budget = activePlan(u, now()) === 'pro' ? cget('ttsProChars', opts.ttsProChars ?? 60000) : cget('ttsFreeChars', opts.ttsFreeChars ?? 6000);
    if (u.ttsChars + text.length > budget) return err(res, 429, 'tts_limit', 'Дневной лимит нейро-голоса исчерпан.');
    u.ttsChars += text.length;
    const refundChars = async () => { u.ttsChars = Math.max(0, u.ttsChars - text.length); await persist(); };
    await persist();
    const ssml = `<speak version='1.0' xml:lang='${v[0]}'><voice name='${v[1]}'><prosody rate='${cget('voiceRate', -4)}%'>${xmlEsc(text)}</prosody></voice></speak>`;
    const url = opts.ttsUrl || `https://${azureRegion()}.tts.speech.microsoft.com/cognitiveservices/v1`;
    let up;
    try {
      up = await fetch(url, { method: 'POST', headers: { 'Ocp-Apim-Subscription-Key': azureKey(), 'Content-Type': 'application/ssml+xml',
        'X-Microsoft-OutputFormat': 'audio-24khz-48kbitrate-mono-mp3', 'User-Agent': 'jarvis-server' }, body: ssml });
    } catch { await refundChars(); logEvent('error', 'tts', 'Сервис речи недоступен', { user: u.email }); return err(res, 502, 'upstream', 'Сервис синтеза речи недоступен.'); }
    if (!up.ok) { await refundChars(); logEvent('error', 'tts', 'Сервис речи вернул ' + up.status, { user: u.email }); return err(res, 502, 'upstream', 'Сервис синтеза речи вернул ошибку ' + up.status + '.'); }
    const audio = Buffer.from(await up.arrayBuffer());
    res.writeHead(200, { 'Content-Type': 'audio/mpeg', 'Content-Length': audio.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(audio);
  }

  // ---------- администрирование ----------
  // Защита вынесена в одно место: adminMode 'open' (без входа, только на текущем этапе, включается ADMIN_MODE=open)
  // или 'google' (ID-токен Google + список ADMIN_EMAILS). Позже можно добавить другие правила, не меняя маршруты.
  const isAdmin = (user) => adminMode === 'open' || (!!user.email && user.emailVerified !== false && adminEmails.includes(user.email.toLowerCase()));
  const publicUser = (sub, u) => ({ sub, email: u.email || '', plan: activePlan(u, now()), planUntil: u.planUntil || null, blocked: !!u.blocked,
    dailyLimitOverride: Number.isFinite(u.dailyLimit) ? u.dailyLimit : null, startedAt: u.startedAt, lastSeen: u.lastSeen || null,
    total: u.total || 0, ttsCharsToday: u.ttsDay === dayKey(now()) ? (u.ttsChars || 0) : 0, hasHistory: !!db.history[sub], status: evaluate(u, now(), cfg()) });
  const publicConfig = () => ({ hasKey: !!providerKey(), keyHint: hint(providerKey()), keySource: db.config.keyStored ? 'admin' : (opts.openrouterKey ? 'env' : 'none'),
    encryptedAtRest: !!db.config.keyStored && db.config.keyStored.startsWith('enc:'),
    freeModel: freeModel(), proModel: proModel(), ...cfg(),
    systemPrompt: cget('systemPrompt', ''), temperature: cget('temperature', null), topP: cget('topP', null), maxTokens: cget('maxTokens', opts.maxTokens ?? 1500),
    announcement: cget('announcement', ''), maintenance: !!cget('maintenance', false),
    features: { gmail: true, screenShare: true, onlineTts: true, ...(db.config.features || {}) },
    ttsEnabled: !!cget('ttsEnabled', true), voiceRate: cget('voiceRate', -4), voices: { ru: VOICES.ru[1], az: VOICES.az[1], tr: VOICES.tr[1], en: VOICES.en[1], ...(db.config.voices || {}) },
    ttsFreeChars: cget('ttsFreeChars', opts.ttsFreeChars ?? 6000), ttsProChars: cget('ttsProChars', opts.ttsProChars ?? 60000),
    azureRegion: azureRegion(), hasAzureKey: !!azureKey(), azureKeyHint: hint(azureKey()), azureSource: db.config.azureKeyStored ? 'admin' : (opts.azureKey ? 'env' : 'none') });
  const CFG_FIELDS = {
    freeModel: { t: 'str', max: 120 }, proModel: { t: 'str', max: 120 }, systemPrompt: { t: 'text', max: 8000 }, announcement: { t: 'text', max: 500 },
    temperature: { t: 'num', min: 0, max: 2 }, topP: { t: 'num', min: 0, max: 1 }, maxTokens: { t: 'int', min: 16, max: 32000 },
    unlimitedDays: { t: 'int', min: 0, max: 3650 }, dailyLimit: { t: 'int', min: 0, max: 100000 }, proDailyLimit: { t: 'int', min: 0, max: 100000 },
    ttsFreeChars: { t: 'int', min: 0, max: 10000000 }, ttsProChars: { t: 'int', min: 0, max: 10000000 }, voiceRate: { t: 'num', min: -30, max: 30 },
    maintenance: { t: 'bool' }, ttsEnabled: { t: 'bool' }, azureRegion: { t: 'str', max: 40 },
  };
  function applyConfig(b) {
    const changed = [];
    for (const [k, f] of Object.entries(CFG_FIELDS)) {
      if (!(k in b)) continue;
      const v = b[k];
      if (v === null) { delete db.config[k]; changed.push(k); continue; }
      if (f.t === 'bool') { if (typeof v !== 'boolean') return 'Некорректное значение: ' + k; db.config[k] = v; }
      else if (f.t === 'str' || f.t === 'text') { if (typeof v !== 'string' || v.length > f.max) return 'Некорректное значение: ' + k; db.config[k] = v.trim(); }
      else { const n = Number(v); if (v === '' || !Number.isFinite(n) || n < f.min || n > f.max) return 'Некорректное значение: ' + k; db.config[k] = f.t === 'int' ? Math.floor(n) : n; }
      changed.push(k);
    }
    if (b.features && typeof b.features === 'object') {
      db.config.features = { ...(db.config.features || {}) };
      for (const k of ['gmail', 'screenShare', 'onlineTts']) if (typeof b.features[k] === 'boolean') { db.config.features[k] = b.features[k]; changed.push('features.' + k); }
    }
    if (b.voices && typeof b.voices === 'object') {
      db.config.voices = { ...(db.config.voices || {}) };
      for (const l of ['ru', 'az', 'tr', 'en']) if (typeof b.voices[l] === 'string') {
        if (b.voices[l] && !/^[A-Za-z0-9-]{3,60}$/.test(b.voices[l])) return 'Некорректное имя голоса: ' + l;
        if (b.voices[l]) db.config.voices[l] = b.voices[l]; else delete db.config.voices[l];
        changed.push('voices.' + l);
      }
    }
    for (const [field, store, clear] of [['openrouterKey', 'keyStored', 'clearKey'], ['azureKey', 'azureKeyStored', 'clearAzureKey']]) {
      if (typeof b[field] === 'string' && b[field].trim()) {
        const k = b[field].trim();
        if (k.length < 12 || k.length > 400 || /\s/.test(k)) return 'Ключ выглядит некорректно: ' + field;
        db.config[store] = sealSecret(k, opts.configSecret); changed.push(field);
      }
      if (b[clear] === true) { delete db.config[store]; changed.push(clear); }
    }
    return changed;
  }

  async function handleAdmin(req, res, url, user) {
    if (!isAdmin(user)) return err(res, 403, 'forbidden', 'Нет прав администратора.');
    const m = req.method, p = url.pathname;
    const who = user.email || 'admin';
    const readJson = async () => { try { return JSON.parse(await readBody(req, 128 * 1024)); } catch { return null; } };
    if (m === 'GET' && p === '/admin/me') return send(res, 200, { admin: true, mode: adminMode, email: user.email || '' });
    if (m === 'GET' && p === '/admin/config') return send(res, 200, publicConfig());
    if (m === 'PUT' && p === '/admin/config') {
      const b = await readJson();
      if (!b || typeof b !== 'object') return err(res, 400, 'bad_request', 'Некорректный запрос.');
      const changed = applyConfig(b);
      if (typeof changed === 'string') return err(res, 400, 'bad_request', changed);
      await persist();
      logEvent('info', 'admin', 'Изменены настройки: ' + changed.join(', '), { by: who });
      return send(res, 200, publicConfig());
    }
    if (m === 'POST' && p === '/admin/test-key') {
      const b = (await readJson()) || {};
      const k = (typeof b.openrouterKey === 'string' && b.openrouterKey.trim()) || providerKey();
      if (!k) return send(res, 200, { ok: false, message: 'Ключ не задан.' });
      try {
        const r = await fetch(keyCheckUrl, { headers: { Authorization: 'Bearer ' + k } });
        return send(res, 200, { ok: r.ok, status: r.status, message: r.ok ? 'Ключ принят провайдером.' : 'Провайдер отклонил ключ (код ' + r.status + ').' });
      } catch { return send(res, 200, { ok: false, message: 'Не удалось связаться с провайдером.' }); }
    }
    if (m === 'POST' && p === '/admin/test-tts') {
      if (!ttsAvailable()) return send(res, 200, { ok: false, message: 'Нейро-голос не настроен или выключен.' });
      const b = (await readJson()) || {};
      const v = voiceFor(b.lang || 'ru');
      if (!v) return send(res, 200, { ok: false, message: 'Неизвестный язык.' });
      try {
        const url2 = opts.ttsUrl || `https://${azureRegion()}.tts.speech.microsoft.com/cognitiveservices/v1`;
        const r = await fetch(url2, { method: 'POST', headers: { 'Ocp-Apim-Subscription-Key': azureKey(), 'Content-Type': 'application/ssml+xml', 'X-Microsoft-OutputFormat': 'audio-24khz-48kbitrate-mono-mp3', 'User-Agent': 'jarvis-server' },
          body: `<speak version='1.0' xml:lang='${v[0]}'><voice name='${v[1]}'>Test</voice></speak>` });
        const len = r.ok ? (await r.arrayBuffer()).byteLength : 0;
        return send(res, 200, { ok: r.ok, status: r.status, voice: v[1], message: r.ok ? 'Синтез работает (' + len + ' байт аудио).' : 'Сервис речи отклонил запрос (код ' + r.status + ').' });
      } catch { return send(res, 200, { ok: false, message: 'Не удалось связаться с сервисом речи.' }); }
    }
    if (m === 'GET' && p === '/admin/integrations') {
      return send(res, 200, { integrations: [
        { id: 'ai', name: 'ИИ-провайдер (OpenRouter)', configured: !!providerKey(), source: db.config.keyStored ? 'admin' : (opts.openrouterKey ? 'env' : 'none'), hint: hint(providerKey()), note: 'Ключ общего бесплатного режима' },
        { id: 'tts', name: 'Нейро-голос (Azure Speech)', configured: ttsAvailable(), source: db.config.azureKeyStored ? 'admin' : (opts.azureKey ? 'env' : 'none'), hint: hint(azureKey()), note: 'Регион: ' + (azureRegion() || 'не задан') },
        { id: 'google', name: 'Вход через Google (проверка токенов)', configured: !!opts.googleClientId, source: 'env', hint: '', note: 'Web Client ID задаётся переменной GOOGLE_WEB_CLIENT_ID на сервере' },
        { id: 'gmail', name: 'Gmail', configured: null, source: 'device', hint: '', note: 'Подключается на устройстве пользователя; сервер почту не хранит' },
      ] });
    }
    if (m === 'GET' && p === '/admin/stats') {
      const list = Object.values(db.users);
      const today = dayKey(now());
      return send(res, 200, { users: list.length, blocked: list.filter((u) => u.blocked).length, pro: list.filter((u) => activePlan(u, now()) === 'pro').length,
        requestsToday: list.reduce((a, u) => a + (u.dayKey === today ? u.count : 0), 0), totalRequests: list.reduce((a, u) => a + (u.total || 0), 0) });
    }
    if (m === 'GET' && p === '/admin/logs') {
      const lvl = url.searchParams.get('level');
      const lim = Math.min(Number(url.searchParams.get('limit')) || 100, 500);
      const rows = logs.filter((l) => !lvl || l.level === lvl).slice(-lim).reverse();
      return send(res, 200, { logs: rows });
    }
    if (m === 'DELETE' && p === '/admin/logs') { logs.length = 0; logEvent('info', 'admin', 'Журнал очищен', { by: who }); return send(res, 200, { ok: true }); }
    if (m === 'GET' && p === '/admin/diagnostics') {
      let fileBytes = 0; try { fileBytes = fs.statSync(dataFile).size; } catch { /* файла ещё нет */ }
      return send(res, 200, { version: '2.1.0', node: process.version, uptimeSec: Math.round((Date.now() - startedAtMs) / 1000), memoryMB: Math.round(process.memoryUsage().rss / 1048576),
        serverTime: now(), adminMode, users: Object.keys(db.users).length, dataFileBytes: fileBytes, activeChats: Array.from(activeChats.values()).reduce((a, b2) => a + b2, 0),
        keyConfigured: !!providerKey(), ttsAvailable: ttsAvailable(), googleConfigured: !!opts.googleClientId, errorsLastHour: logs.filter((l) => l.level === 'error' && l.t > now() - 3600000).length });
    }
    if (m === 'GET' && p === '/admin/users') {
      const q = (url.searchParams.get('q') || '').toLowerCase();
      const rows = Object.entries(db.users).filter(([, u]) => !q || (u.email || '').toLowerCase().includes(q))
        .sort((a, b2) => (b2[1].lastSeen || 0) - (a[1].lastSeen || 0)).slice(0, 200).map(([sub, u]) => publicUser(sub, u));
      return send(res, 200, { users: rows });
    }
    const mm = p.match(/^\/admin\/users\/([^/]+)$/);
    if (mm && m === 'PATCH') {
      const sub = decodeURIComponent(mm[1]);
      const u = db.users[sub];
      if (!u) return err(res, 404, 'not_found', 'Пользователь не найден.');
      const b = await readJson();
      if (!b || typeof b !== 'object') return err(res, 400, 'bad_request', 'Некорректный запрос.');
      if (typeof b.blocked === 'boolean') u.blocked = b.blocked;
      if (b.plan === 'pro') { u.plan = 'pro'; const d = Number(b.days); u.planUntil = Number.isFinite(d) && d > 0 ? now() + Math.min(d, 3650) * DAY_MS : null; }
      else if (b.plan === 'free') { u.plan = 'free'; u.planUntil = null; }
      if (b.dailyLimit === null) delete u.dailyLimit;
      else if (b.dailyLimit !== undefined) {
        const v = Number(b.dailyLimit);
        if (!Number.isFinite(v) || v < 0 || v > 100000) return err(res, 400, 'bad_request', 'Некорректный лимит.');
        u.dailyLimit = Math.floor(v);
      }
      if (b.resetToday === true) { u.count = 0; u.ttsChars = 0; }
      if (b.deleteHistory === true) delete db.history[sub];
      await persist();
      logEvent('info', 'admin', 'Изменён пользователь ' + (u.email || sub) + ': ' + Object.keys(b).join(', '), { by: who });
      return send(res, 200, publicUser(sub, u));
    }
    return err(res, 404, 'not_found', 'Не найдено.');
  }

  const handler = async (req, res) => {
    const url = new URL(req.url, 'http://x');
    // Android HttpURLConnection не умеет PATCH: админ-приложение шлёт POST с X-HTTP-Method-Override (только для /admin/).
    if (req.method === 'POST' && url.pathname.startsWith('/admin/') && req.headers['x-http-method-override'] === 'PATCH') req.method = 'PATCH';
    try {
      if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true, adminMode });
      if (rateLimited(req)) return err(res, 429, 'rate_limited', 'Слишком много запросов. Подожди минуту.');
      if (req.method === 'GET' && url.pathname === '/v1/app-config') {
        return send(res, 200, { systemPrompt: cget('systemPrompt', ''), announcement: cget('announcement', ''), maintenance: !!cget('maintenance', false),
          features: { gmail: true, screenShare: true, onlineTts: true, ...(db.config.features || {}) }, ttsAvailable: ttsAvailable(), freeModel: freeModel() });
      }
      if (url.pathname.startsWith('/admin/')) {
        const adm = adminMode === 'open' ? { sub: 'open', email: '' } : await authenticate(req);
        if (!adm) return err(res, 401, 'auth_required', 'Нужен вход администратора.');
        return await handleAdmin(req, res, url, adm);
      }
      const user = await authenticate(req);
      if (!user) { logEvent('warn', 'auth', 'Запрос без действительного токена: ' + url.pathname); return err(res, 401, 'auth_required', 'Нужен вход через Google.'); }

      if (req.method === 'GET' && url.pathname === '/v1/status') {
        const u = getUser(user.sub, user.email);
        await persist();
        return send(res, 200, { ok: true, email: u.email, startedAt: u.startedAt, serverTime: now(), ttsAvailable: ttsAvailable(), ...evaluate(u, now(), cfg()) });
      }
      if (req.method === 'POST' && url.pathname === '/v1/chat') return await handleChat(req, res, user);
      if (req.method === 'POST' && url.pathname === '/v1/tts') return await handleTts(req, res, user);

      if (url.pathname === '/v1/history') {
        if (req.method === 'GET') return send(res, 200, db.history[user.sub] || { chats: [] });
        if (req.method === 'PUT') {
          let parsed;
          try { parsed = JSON.parse(await readBody(req, MAX_HISTORY_BYTES)); } catch (e) { return err(res, e.message === 'too_large' ? 413 : 400, 'bad_request', 'Некорректная история.'); }
          if (!parsed || !Array.isArray(parsed.chats)) return err(res, 400, 'bad_request', 'Некорректная история.');
          db.history[user.sub] = { version: 2, at: now(), chats: parsed.chats };
          await persist();
          return send(res, 200, { ok: true });
        }
        if (req.method === 'DELETE') { delete db.history[user.sub]; await persist(); return send(res, 200, { ok: true }); }
      }
      return err(res, 404, 'not_found', 'Не найдено.');
    } catch (e) {
      console.error('handler error', e.message);
      if (!res.headersSent) err(res, 500, 'server_error', 'Ошибка сервера.');
      else res.end();
    }
  };
  return { server: http.createServer(handler), db: () => db, flush: () => writing };
}

// Запуск как программы
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const need = (k) => { if (!process.env[k]) { console.error('Не задана переменная окружения ' + k); process.exit(1); } return process.env[k]; };
  const app = createApp({
    googleClientId: process.env.GOOGLE_WEB_CLIENT_ID || '',
    openrouterKey: process.env.OPENROUTER_API_KEY || '',
    adminEmails: (process.env.ADMIN_EMAILS || '').split(','),
    adminMode: process.env.ADMIN_MODE === 'open' ? 'open' : 'google',
    configSecret: process.env.CONFIG_SECRET || '',
    proModel: process.env.PRO_MODEL || '',
    azureKey: process.env.AZURE_SPEECH_KEY || '',
    azureRegion: process.env.AZURE_SPEECH_REGION || '',
    voiceRu: process.env.VOICE_RU, voiceAz: process.env.VOICE_AZ, voiceTr: process.env.VOICE_TR, voiceEn: process.env.VOICE_EN,
    ttsFreeChars: Number(process.env.TTS_FREE_CHARS || 6000),
    ttsProChars: Number(process.env.TTS_PRO_CHARS || 60000),
    trustProxy: process.env.TRUST_PROXY === '1',
    proDailyLimit: Number(process.env.PRO_DAILY_LIMIT || 200),
    freeModel: process.env.FREE_MODEL || 'openrouter/auto',
    dataFile: process.env.DATA_FILE || './data/jarvis-data.json',
    unlimitedDays: Number(process.env.UNLIMITED_DAYS || 15),
    dailyLimit: Number(process.env.DAILY_LIMIT || 5),
    maxTokens: Number(process.env.MAX_TOKENS || 1500),
  });
  if (!process.env.GOOGLE_WEB_CLIENT_ID) console.warn('ВНИМАНИЕ: GOOGLE_WEB_CLIENT_ID не задан. Вход пользователей через Google работать не будет.');
  const port = Number(process.env.PORT || 8080);
  app.server.listen(port, () => {
    console.log('JARVIS server listening on :' + port);
    if (process.env.ADMIN_MODE === 'open') console.warn('ВНИМАНИЕ: ADMIN_MODE=open. Админ-API доступен БЕЗ входа любому, кто знает адрес сервера. Используй только на этапе настройки.');
  });
}
