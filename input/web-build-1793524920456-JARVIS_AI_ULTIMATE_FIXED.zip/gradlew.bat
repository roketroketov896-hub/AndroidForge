@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo ERROR: Gradle wrapper JAR is not bundled and system gradle was not found on PATH.
  echo Install Gradle 8.7 or let AndroidForge configure its Gradle fallback.
  exit /b 127
)
gradle %*
