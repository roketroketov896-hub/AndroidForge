package com.jarvis.ai;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.util.Base64;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Чтение выбранных пользователем файлов (Storage Access Framework) и извлечение текста.
 * Результат честно описывает, что реально прочитано: поле "note" содержит ограничения.
 * Без внешних библиотек: TXT/MD/CSV/JSON/XML/HTML/LOG, DOCX, XLSX, PPTX (ZIP+XML), изображения (JPEG для vision),
 * PDF (PDFBox-Android через рефлексию, если подключён; иначе рендер страниц в изображения),
 * DOC/XLS (старый бинарный формат): только грубое извлечение строк, с пометкой.
 */
final class FileExtractor {
    static final int MAX_FILE_BYTES = 25 * 1024 * 1024;
    static final int MAX_TEXT = 40000;

    private FileExtractor() {
    }

    private static String ext(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    private static byte[] readAll(InputStream in, int max) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n, total = 0;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > max) throw new IllegalStateException("too_big");
            bo.write(buf, 0, n);
        }
        return bo.toByteArray();
    }

    static JSONObject extract(Context c, Uri uri) {
        JSONObject r = new JSONObject();
        String name = "file";
        long size = -1;
        try {
            try (Cursor cur = c.getContentResolver().query(uri, null, null, null, null)) {
                if (cur != null && cur.moveToFirst()) {
                    int ni = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    int si = cur.getColumnIndex(OpenableColumns.SIZE);
                    if (ni >= 0) name = cur.getString(ni);
                    if (si >= 0 && !cur.isNull(si)) size = cur.getLong(si);
                }
            } catch (Exception ignored) {
            }
            r.put("name", name);
            r.put("size", size);
            String e = ext(name);
            r.put("ext", e);
            if (size > MAX_FILE_BYTES) {
                r.put("ok", false);
                r.put("error", "Файл больше 25 МБ: не читаю.");
                return r;
            }
            switch (e) {
                case "png": case "jpg": case "jpeg": case "webp":
                    readImage(c, uri, r);
                    break;
                case "pdf":
                    readPdf(c, uri, r);
                    break;
                case "docx":
                    finishText(r, docx(read(c, uri)), "");
                    break;
                case "xlsx":
                    finishText(r, xlsx(read(c, uri)), "");
                    break;
                case "pptx":
                    finishText(r, pptx(read(c, uri)), "");
                    break;
                case "doc": case "xls":
                    finishText(r, legacyStrings(read(c, uri)), "Старый бинарный формат ." + e + ": извлечены только фрагменты текста, форматирование и таблицы могут быть потеряны. Лучше сохранить файл как ." + e + "x.");
                    break;
                case "txt": case "md": case "csv": case "json": case "xml": case "html": case "htm": case "log": {
                    String t = new String(read(c, uri), StandardCharsets.UTF_8);
                    if (e.equals("html") || e.equals("htm")) t = htmlToText(t);
                    finishText(r, t, "");
                    break;
                }
                default:
                    r.put("ok", false);
                    r.put("error", "Формат ." + e + " не поддерживается.");
            }
        } catch (IllegalStateException ex) {
            put(r, "ok", false);
            put(r, "error", "Файл слишком большой.");
        } catch (Exception ex) {
            put(r, "ok", false);
            put(r, "error", "Не удалось прочитать файл (" + ex.getClass().getSimpleName() + ").");
        }
        return r;
    }

    private static void put(JSONObject o, String k, Object v) {
        try {
            o.put(k, v);
        } catch (Exception ignored) {
        }
    }

    private static byte[] read(Context c, Uri uri) throws Exception {
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("no_stream");
            return readAll(in, MAX_FILE_BYTES);
        }
    }

    private static void finishText(JSONObject r, String text, String note) throws Exception {
        text = text == null ? "" : text.replace("\r", "").trim();
        if (text.isEmpty()) {
            r.put("ok", false);
            r.put("error", "В файле не найден текст.");
            return;
        }
        boolean cut = text.length() > MAX_TEXT;
        if (cut) text = text.substring(0, MAX_TEXT);
        r.put("ok", true);
        r.put("kind", "text");
        r.put("text", text);
        r.put("chars", text.length());
        r.put("truncated", cut);
        r.put("note", (cut ? "Файл длиннее лимита: прочитаны первые " + MAX_TEXT + " символов. " : "") + note);
    }

    // ---------- изображения ----------

    private static void readImage(Context c, Uri uri, JSONObject r) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, o);
        }
        int s = 1;
        while (o.outWidth / s > 2000 || o.outHeight / s > 2000) s *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = s;
        Bitmap b;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            b = BitmapFactory.decodeStream(in, null, o);
        }
        if (b == null) {
            r.put("ok", false);
            r.put("error", "Не удалось декодировать изображение.");
            return;
        }
        r.put("ok", true);
        r.put("kind", "image");
        r.put("image", toDataUrl(b));
        r.put("note", "Изображение будет передано модели; описать его сможет только модель с поддержкой изображений.");
        b.recycle();
    }

    private static String toDataUrl(Bitmap b) {
        Bitmap flat = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(flat);
        cv.drawColor(Color.WHITE);
        cv.drawBitmap(b, 0, 0, null);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        flat.compress(Bitmap.CompressFormat.JPEG, 82, bo);
        flat.recycle();
        return "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    // ---------- PDF ----------

    private static void readPdf(Context c, Uri uri, JSONObject r) throws Exception {
        String text = pdfBoxText(c, uri);
        if (text != null && text.trim().length() > 20) {
            finishText(r, text, "");
            return;
        }
        // Текста нет (скан) или PDFBox не подключён: отрисовываем первую страницу для модели с поддержкой изображений.
        ParcelFileDescriptor pfd = c.getContentResolver().openFileDescriptor(uri, "r");
        if (pfd == null) throw new IllegalStateException("no_fd");
        try (PdfRenderer pr = new PdfRenderer(pfd)) {
            if (pr.getPageCount() == 0) {
                r.put("ok", false);
                r.put("error", "PDF пустой.");
                return;
            }
            PdfRenderer.Page p = pr.openPage(0);
            int w = 1200, h = Math.max(1, (int) (1200f * p.getHeight() / p.getWidth()));
            Bitmap bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            bm.eraseColor(Color.WHITE);
            p.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            p.close();
            r.put("ok", true);
            r.put("kind", "image");
            r.put("image", toDataUrl(bm));
            r.put("note", "Текст в PDF не извлёкся (скан или нет PDFBox). Передана только 1-я страница из " + pr.getPageCount() + " как изображение; остальные страницы НЕ прочитаны.");
            bm.recycle();
        }
    }

    /** PDFBox-Android подключается через рефлексию: если библиотеки нет, возвращается null. */
    private static String pdfBoxText(Context c, Uri uri) {
        try {
            Class<?> loader = Class.forName("com.tom_roush.pdfbox.android.PDFBoxResourceLoader");
            loader.getMethod("init", Context.class).invoke(null, c.getApplicationContext());
            Class<?> docC = Class.forName("com.tom_roush.pdfbox.pdmodel.PDDocument");
            Class<?> stripC = Class.forName("com.tom_roush.pdfbox.text.PDFTextStripper");
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                Object doc = docC.getMethod("load", InputStream.class).invoke(null, in);
                try {
                    Object stripper = stripC.getConstructor().newInstance();
                    Object t = stripC.getMethod("getText", docC).invoke(stripper, doc);
                    return t == null ? null : t.toString();
                } finally {
                    docC.getMethod("close").invoke(doc);
                }
            }
        } catch (Throwable t) {
            return null;
        }
    }

    // ---------- Office (ZIP + XML) ----------

    private static String unxml(String s) {
        return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&");
    }

    private static Map<String, byte[]> unzip(byte[] data, String prefixOrName) throws Exception {
        Map<String, byte[]> m = new HashMap<>();
        try (ZipInputStream z = new ZipInputStream(new java.io.ByteArrayInputStream(data))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String n = e.getName();
                if (!n.startsWith(prefixOrName)) continue;
                m.put(n, readAll(z, 20 * 1024 * 1024));
            }
        }
        return m;
    }

    private static String docx(byte[] data) throws Exception {
        Map<String, byte[]> m = unzip(data, "word/");
        byte[] d = m.get("word/document.xml");
        if (d == null) return "";
        String x = new String(d, StandardCharsets.UTF_8);
        x = x.replaceAll("</w:p>", "\n").replaceAll("<w:tab/>", "\t").replaceAll("<w:br/>", "\n").replaceAll("</w:tc>", " | ");
        return unxml(x.replaceAll("<[^>]+>", ""));
    }

    private static String pptx(byte[] data) throws Exception {
        Map<String, byte[]> m = unzip(data, "ppt/slides/slide");
        List<String> names = new ArrayList<>(m.keySet());
        Collections.sort(names, new Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                return num(a) - num(b);
            }

            private int num(String s) {
                try {
                    return Integer.parseInt(s.replaceAll("[^0-9]", ""));
                } catch (Exception e) {
                    return 0;
                }
            }
        });
        StringBuilder sb = new StringBuilder();
        int i = 0;
        Pattern t = Pattern.compile("<a:t>([^<]*)</a:t>");
        for (String n : names) {
            if (!n.endsWith(".xml")) continue;
            sb.append("--- Слайд ").append(++i).append(" ---\n");
            String x = new String(m.get(n), StandardCharsets.UTF_8).replace("</a:p>", "</a:p>\u0001");
            Matcher mm = t.matcher(x);
            while (mm.find()) sb.append(unxml(mm.group(1))).append('\n');
        }
        return sb.toString();
    }

    private static String xlsx(byte[] data) throws Exception {
        Map<String, byte[]> m = unzip(data, "xl/");
        List<String> shared = new ArrayList<>();
        byte[] ss = m.get("xl/sharedStrings.xml");
        if (ss != null) {
            Matcher si = Pattern.compile("<si>(.*?)</si>", Pattern.DOTALL).matcher(new String(ss, StandardCharsets.UTF_8));
            while (si.find()) {
                StringBuilder one = new StringBuilder();
                Matcher tt = Pattern.compile("<t[^>]*>([^<]*)</t>").matcher(si.group(1));
                while (tt.find()) one.append(unxml(tt.group(1)));
                shared.add(one.toString());
            }
        }
        List<String> sheets = new ArrayList<>();
        for (String k : m.keySet()) if (k.startsWith("xl/worksheets/sheet") && k.endsWith(".xml")) sheets.add(k);
        Collections.sort(sheets);
        StringBuilder sb = new StringBuilder();
        int n = 0;
        Pattern row = Pattern.compile("<row[^>]*>(.*?)</row>", Pattern.DOTALL);
        Pattern cell = Pattern.compile("<c ([^>]*?)(?:/>|>(.*?)</c>)", Pattern.DOTALL);
        for (String sh : sheets) {
            sb.append("--- Лист ").append(++n).append(" ---\n");
            Matcher rm = row.matcher(new String(m.get(sh), StandardCharsets.UTF_8));
            while (rm.find()) {
                Matcher cm = cell.matcher(rm.group(1));
                StringBuilder line = new StringBuilder();
                while (cm.find()) {
                    String attrs = cm.group(1), body = cm.group(2) == null ? "" : cm.group(2);
                    Matcher v = Pattern.compile("<v>([^<]*)</v>").matcher(body);
                    String val = "";
                    if (v.find()) val = unxml(v.group(1));
                    if (attrs.contains("t=\"s\"")) {
                        try {
                            val = shared.get(Integer.parseInt(val.trim()));
                        } catch (Exception ignored) {
                        }
                    } else if (attrs.contains("t=\"inlineStr\"")) {
                        Matcher is = Pattern.compile("<t[^>]*>([^<]*)</t>").matcher(body);
                        if (is.find()) val = unxml(is.group(1));
                    }
                    if (line.length() > 0) line.append('\t');
                    line.append(val);
                }
                if (line.toString().trim().length() > 0) sb.append(line).append('\n');
                if (sb.length() > MAX_TEXT * 2) return sb.toString();
            }
        }
        return sb.toString();
    }

    private static String legacyStrings(byte[] d) {
        StringBuilder out = new StringBuilder(), cur = new StringBuilder();
        for (int i = 0; i < d.length && out.length() < MAX_TEXT * 2; i++) {
            int b = d[i] & 0xff;
            if ((b >= 32 && b < 127) || b == '\n' || b == '\t') {
                cur.append((char) b);
            } else {
                if (cur.length() >= 6) out.append(cur).append('\n');
                cur.setLength(0);
            }
        }
        return out.toString();
    }

    private static String htmlToText(String h) {
        String t = h.replaceAll("(?is)<(script|style)[^>]*>.*?</\\1>", " ").replaceAll("(?i)<br\\s*/?>|</p>|</div>|</li>|</tr>|</h[1-6]>", "\n");
        return unxml(t.replaceAll("<[^>]+>", " ")).replaceAll("[ \\t]+", " ").replaceAll("\\n\\s*\\n+", "\n\n");
    }
}
