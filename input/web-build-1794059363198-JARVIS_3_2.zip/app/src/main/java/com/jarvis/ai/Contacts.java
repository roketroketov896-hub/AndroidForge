package com.jarvis.ai;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/** Поиск контактов по имени. Требует разрешение READ_CONTACTS, которое запрашивается только при использовании. */
final class Contacts {
    private Contacts() {
    }

    static boolean hasPermission(Context c) {
        return c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
    }

    static String digits(String phone) {
        if (phone == null) return "";
        String d = phone.replaceAll("[^0-9]", "");
        if (d.startsWith("00")) d = d.substring(2);
        return d;
    }

    static boolean looksLikePhone(String s) {
        if (s == null) return false;
        String t = s.trim();
        return t.matches("\\+?[0-9][0-9 ()\\-]{5,}") && digits(t).length() >= 7;
    }

    /** Возвращает до 5 контактов с номерами: [{name, phone}]. Бросает SecurityException без разрешения. */
    static JSONArray find(Context c, String name) throws Exception {
        JSONArray out = new JSONArray();
        if (!hasPermission(c)) throw new SecurityException("READ_CONTACTS");
        String q = name == null ? "" : name.trim();
        if (q.isEmpty()) return out;
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] proj = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
        Set<String> seen = new HashSet<>();
        try (Cursor cur = c.getContentResolver().query(uri, proj,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", new String[]{"%" + q + "%"},
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
            if (cur == null) return out;
            while (cur.moveToNext() && out.length() < 5) {
                String n = cur.getString(0);
                String p = cur.getString(1);
                String key = n + "|" + digits(p);
                if (!seen.add(key)) continue;
                JSONObject o = new JSONObject();
                o.put("name", n);
                o.put("phone", p);
                out.put(o);
            }
        }
        return out;
    }
}
