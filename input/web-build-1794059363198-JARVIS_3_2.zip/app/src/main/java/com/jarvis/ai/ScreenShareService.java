package com.jarvis.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.Base64;
import android.util.DisplayMetrics;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

/**
 * Показ экрана для JARVIS. Работает только после явного согласия пользователя в системном окне
 * MediaProjection и всегда показывает постоянное уведомление. Передаются не видеопоток, а отдельные
 * кадры: последний кадр сохраняется в памяти и уходит в модель только когда пользователь сам
 * прикрепляет его к сообщению. Касаниями ИИ не управляет.
 */
public class ScreenShareService extends Service {
    static final String ACTION_START = "com.jarvis.ai.SCREEN_START";
    static final String ACTION_STOP = "com.jarvis.ai.SCREEN_STOP";
    static final String ACTION_SNAP = "com.jarvis.ai.SCREEN_SNAP";
    private static final String CHANNEL = "jarvis_screen";
    private static final int NOTIF_ID = 4711;

    interface Listener {
        void onStarted();

        void onFrame(String dataUrl);

        void onStopped(String reason);
    }

    static volatile Listener listener;
    static volatile boolean running = false;
    private static volatile ScreenShareService instance;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private int width;
    private int height;
    private volatile Bitmap latest;
    private long lastConvert = 0L;
    private boolean stopping = false;

    /** Кадр в виде data URL (JPEG) или null, если показ не активен или кадра ещё нет. */
    static String captureDataUrl() {
        ScreenShareService s = instance;
        return s == null ? null : s.encodeLatest();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            shutdown("user");
            return START_NOT_STICKY;
        }
        if (ACTION_SNAP.equals(action)) {
            String frame = encodeLatest();
            Listener l = listener;
            if (l != null && frame != null) l.onFrame(frame);
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action) || running) {
            if (!running) stopSelf();
            return START_NOT_STICKY;
        }

        startInForeground();
        try {
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager mgr = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mgr.getMediaProjection(code, data);
            if (projection == null) {
                shutdown("error");
                return START_NOT_STICKY;
            }
            thread = new HandlerThread("jarvis-screen");
            thread.start();
            handler = new Handler(thread.getLooper());
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    shutdown("revoked");
                }
            }, new Handler(Looper.getMainLooper()));

            DisplayMetrics m = getResources().getDisplayMetrics();
            float scale = Math.min(1f, 1920f / Math.max(m.widthPixels, m.heightPixels));
            width = Math.max(2, Math.round(m.widthPixels * scale));
            height = Math.max(2, Math.round(m.heightPixels * scale));
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader r) {
                    convert(r);
                }
            }, handler);
            display = projection.createVirtualDisplay("jarvis-screen", width, height, m.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
            instance = this;
            running = true;
            Listener l = listener;
            if (l != null) l.onStarted();
        } catch (Exception e) {
            shutdown("error");
        }
        return START_NOT_STICKY;
    }

    private void startInForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Показ экрана JARVIS", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent openPi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | imm);
        PendingIntent snapPi = PendingIntent.getService(this, 2,
                new Intent(this, ScreenShareService.class).setAction(ACTION_SNAP), PendingIntent.FLAG_UPDATE_CURRENT | imm);
        PendingIntent stopPi = PendingIntent.getService(this, 3,
                new Intent(this, ScreenShareService.class).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT | imm);
        b.setContentTitle("JARVIS видит экран")
                .setContentText("Показ экрана включён. Нажми «Снимок», чтобы отправить кадр в JARVIS.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_menu_camera, "Снимок", snapPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Остановить", stopPi);
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void convert(ImageReader r) {
        Image image = null;
        try {
            image = r.acquireLatestImage();
            if (image == null) return;
            long now = System.currentTimeMillis();
            if (now - lastConvert < 800L) return;
            lastConvert = now;
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buf = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int rowPadding = rowStride - pixelStride * width;
            Bitmap full = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);
            Bitmap cropped = Bitmap.createBitmap(full, 0, 0, width, height);
            if (cropped != full) full.recycle();
            Bitmap old = latest;
            latest = cropped;
            if (old != null && !old.isRecycled()) old.recycle();
        } catch (Exception ignored) {
        } finally {
            if (image != null) image.close();
        }
    }

    private String encodeLatest() {
        Bitmap b = latest;
        if (b == null || b.isRecycled()) return null;
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 80, out);
            return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }

    private synchronized void shutdown(String reason) {
        if (stopping) return;
        stopping = true;
        running = false;
        instance = null;
        try {
            if (display != null) display.release();
        } catch (Exception ignored) {
        }
        try {
            if (reader != null) reader.close();
        } catch (Exception ignored) {
        }
        try {
            if (projection != null) projection.stop();
        } catch (Exception ignored) {
        }
        if (thread != null) thread.quitSafely();
        Bitmap b = latest;
        latest = null;
        if (b != null && !b.isRecycled()) b.recycle();
        stopForeground(true);
        Listener l = listener;
        if (l != null) l.onStopped(reason);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (!stopping) shutdown("destroyed");
        super.onDestroy();
    }
}
