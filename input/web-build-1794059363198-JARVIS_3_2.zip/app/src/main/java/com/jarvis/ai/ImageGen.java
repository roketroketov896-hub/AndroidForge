package com.jarvis.ai;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Создание изображений по описанию. Два честных пути:
 * 1) OpenRouter с твоим ключом (модель из настройки imageModel, по умолчанию google/gemini-2.5-flash-image);
 * 2) без ключа (или если путь 1 не сработал) публичный бесплатный сервис pollinations.ai: описание картинки
 *    уходит на этот внешний сервис, об этом сказано в ответе инструмента.
 * Результат сохраняется настоящим файлом (PNG/JPG) в хранилище JARVIS.
 */
final class ImageGen {
    private ImageGen() {
    }

    private static JSONObject o(Object... kv) {
        JSONObject r = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) r.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return r;
    }

    static JSONObject generate(MainActivity act, String prompt, String name) {
        String p = prompt == null ? "" : prompt.trim();
        if (p.length() < 3) return o("ok", false, "message", "Нужно описание изображения.");
        if (p.length() > 1500) p = p.substring(0, 1500);
        String base = FileStore.safeName(name == null || name.isEmpty() ? "image" : name, "image");
        if (FileStore.ext(base).isEmpty()) base = base + ".png";
        String why = "";
        try {
            JSONObject s = act.settings.all();
            boolean own = !"free".equals(s.optString("mode", "own")) && "openrouter".equals(s.optString("provider", "openrouter"));
            String key = own ? act.store.get("openrouter") : "";
            if (!key.isEmpty()) {
                String model = s.optString("imageModel", "google/gemini-2.5-flash-image").trim();
                if (model.isEmpty()) model = "google/gemini-2.5-flash-image";
                byte[] img = viaOpenRouter(key, model, p);
                if (img != null) {
                    String n = base;
                    if (looksJpeg(img) && n.toLowerCase().endsWith(".png")) n = n.substring(0, n.length() - 4) + ".jpg";
                    JSONObject r = FileStore.createBytes(act, n, img);
                    if (r.optBoolean("ok")) r.put("message", "Изображение создано через OpenRouter (" + model + ") и сохранено файлом.");
                    return r;
                }
                why = "Модель " + model + " не вернула изображение (нужна модель с генерацией картинок). ";
            }
            byte[] img = viaPollinations(p);
            if (img != null) {
                String n = base.toLowerCase().endsWith(".png") ? base.substring(0, base.length() - 4) + ".jpg" : base;
                JSONObject r = FileStore.createBytes(act, n, img);
                if (r.optBoolean("ok")) r.put("message", why + "Изображение создано бесплатным внешним сервисом pollinations.ai (описание было отправлено туда) и сохранено файлом.");
                return r;
            }
            return o("ok", false, "message", why + "Не удалось создать изображение: нет сети или сервис не ответил. Попробуй позже или укажи в настройках модель с генерацией картинок (imageModel) и ключ OpenRouter.");
        } catch (Exception e) {
            return o("ok", false, "message", "Ошибка создания изображения: " + e.getClass().getSimpleName());
        }
    }

    private static boolean looksJpeg(byte[] b) {
        return b.length > 3 && (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xD8;
    }

    private static byte[] viaOpenRouter(String key, String model, String prompt) {
        HttpURLConnection c = null;
        try {
            JSONObject body = new JSONObject();
            body.put("model", model);
            body.put("modalities", new JSONArray().put("image").put("text"));
            body.put("messages", new JSONArray().put(o("role", "user", "content", prompt)));
            c = (HttpURLConnection) new URL("https://openrouter.ai/api/v1/chat/completions").openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(20000);
            c.setReadTimeout(120000);
            c.setDoOutput(true);
            c.setRequestProperty("Authorization", "Bearer " + key);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            if (c.getResponseCode() != 200) return null;
            String resp = new String(readAll(c.getInputStream(), 40 * 1024 * 1024), StandardCharsets.UTF_8);
            JSONArray ch = new JSONObject(resp).optJSONArray("choices");
            if (ch == null || ch.length() == 0) return null;
            JSONObject msg = ch.getJSONObject(0).optJSONObject("message");
            JSONArray imgs = msg == null ? null : msg.optJSONArray("images");
            if (imgs == null || imgs.length() == 0) return null;
            JSONObject iu = imgs.getJSONObject(0).optJSONObject("image_url");
            String url = iu == null ? "" : iu.optString("url", "");
            int comma = url.indexOf("base64,");
            if (!url.startsWith("data:") || comma < 0) return null;
            byte[] data = Base64.decode(url.substring(comma + 7), Base64.DEFAULT);
            return data.length > 1000 ? data : null;
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static byte[] viaPollinations(String prompt) {
        HttpURLConnection c = null;
        try {
            String u = "https://image.pollinations.ai/prompt/" + URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
                    + "?width=1024&height=1024&nologo=true";
            c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(20000);
            c.setReadTimeout(120000);
            if (c.getResponseCode() != 200) return null;
            String ct = c.getContentType();
            if (ct == null || !ct.startsWith("image/")) return null;
            byte[] data = readAll(c.getInputStream(), 12 * 1024 * 1024);
            return data.length > 1000 ? data : null;
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static byte[] readAll(InputStream in, int max) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int r;
        while ((r = in.read(buf)) > 0) {
            bo.write(buf, 0, r);
            if (bo.size() > max) throw new IllegalStateException("too big");
        }
        return bo.toByteArray();
    }
}
