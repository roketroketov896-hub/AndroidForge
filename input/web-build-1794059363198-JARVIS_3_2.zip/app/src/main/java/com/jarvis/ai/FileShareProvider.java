package com.jarvis.ai;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Отдаёт другим приложениям (просмотр, «Отправить») только файлы из папки JARVIS и только на чтение.
 * Без androidx: провайдер не экспортируется, доступ выдаётся временным разрешением на конкретный URI.
 */
public class FileShareProvider extends ContentProvider {
    static Uri uriFor(Context c, String id) {
        return new Uri.Builder().scheme("content").authority(c.getPackageName() + ".files").appendPath(id).build();
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    private File file(Uri uri) {
        Context c = getContext();
        String id = uri.getLastPathSegment();
        return c == null ? null : FileStore.resolve(c, id);
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("read only");
        File f = file(uri);
        if (f == null) throw new FileNotFoundException("not found");
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        File f = file(uri);
        if (f == null) return null;
        String[] cols = projection != null ? projection : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor mc = new MatrixCursor(cols);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = f.getName();
            else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = f.length();
        }
        mc.addRow(row);
        return mc;
    }

    @Override
    public String getType(Uri uri) {
        File f = file(uri);
        return f == null ? null : FileStore.mime(f.getName());
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
