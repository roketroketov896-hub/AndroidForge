package com.jarvis.ai;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.Locale;

/**
 * Служба доступности. Ничего не делает сама: выполняет только те действия, которые JARVIS вызвал
 * по команде пользователя (назад, домой, прокрутка, нажатие на видимый элемент по тексту).
 * Включается пользователем вручную в системных настройках.
 */
public class JarvisAccessibilityService extends AccessibilityService {
    static volatile JarvisAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // события не обрабатываются: служба работает только по явным вызовам
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    static boolean isEnabled(Context ctx) {
        try {
            String enabled = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (TextUtils.isEmpty(enabled)) return false;
            String me = new ComponentName(ctx, JarvisAccessibilityService.class).flattenToString();
            for (String s : enabled.split(":")) if (s.equalsIgnoreCase(me)) return true;
        } catch (Exception ignored) {
        }
        return false;
    }

    static boolean isConnected() {
        return instance != null;
    }

    boolean global(String action) {
        switch (action) {
            case "back": return performGlobalAction(GLOBAL_ACTION_BACK);
            case "home": return performGlobalAction(GLOBAL_ACTION_HOME);
            case "recents": return performGlobalAction(GLOBAL_ACTION_RECENTS);
            case "notifications": return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
            default: return false;
        }
    }

    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 12) return null;
        if (n.isScrollable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            AccessibilityNodeInfo r = findScrollable(c, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    boolean scroll(boolean forward) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo s = findScrollable(root, 0);
        if (s == null) return false;
        return s.performAction(forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
    }

    private static boolean clickUp(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 6 && cur != null; i++) {
            if (cur.isClickable() && cur.isEnabled()) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            cur = cur.getParent();
        }
        return false;
    }

    /** Нажимает видимый элемент с указанным текстом или описанием. Возвращает false, если элемент не найден. */
    boolean clickByText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || text == null || text.trim().isEmpty()) return false;
        List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByText(text.trim());
        if (found != null) for (AccessibilityNodeInfo n : found) if (clickUp(n)) return true;
        return false;
    }

    /** Кнопка отправки в открытом чате WhatsApp. true только если нажатие выполнено. */
    boolean clickWhatsAppSend() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        String pkg = root.getPackageName() == null ? "" : root.getPackageName().toString();
        if (!pkg.startsWith("com.whatsapp")) return false;
        List<AccessibilityNodeInfo> byId = root.findAccessibilityNodeInfosByViewId(pkg + ":id/send");
        if (byId != null) for (AccessibilityNodeInfo n : byId) if (clickUp(n)) return true;
        String[] labels = {"Send", "Отправить", "Göndər", "Gönder"};
        for (String l : labels) {
            List<AccessibilityNodeInfo> f = root.findAccessibilityNodeInfosByText(l);
            if (f == null) continue;
            for (AccessibilityNodeInfo n : f) {
                CharSequence d = n.getContentDescription();
                if (d != null && d.toString().toLowerCase(Locale.ROOT).contains(l.toLowerCase(Locale.ROOT)) && clickUp(n)) return true;
            }
        }
        return false;
    }
}
