package com.jarvis.ai;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Вход через Google (Credential Manager). ID-токен хранится только в памяти;
 * в SharedPreferences сохраняются имя, e-mail и ссылка на аватар для показа профиля.
 * Токен нужен серверу JARVIS для бесплатного режима и синхронизации.
 */
final class AuthManager {
    private final SharedPreferences prefs;
    private final SecureStore store;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Executor mainExecutor = new Executor() {
        @Override
        public void execute(Runnable command) {
            main.post(command);
        }
    };
    private volatile String idToken = "";

    AuthManager(SharedPreferences prefs, SecureStore store) {
        this.prefs = prefs;
        this.store = store;
    }

    JSONObject profile() {
        JSONObject o = new JSONObject();
        try {
            o.put("signedIn", prefs.getBoolean("auth_signed_in", false));
            o.put("name", prefs.getString("auth_name", ""));
            o.put("email", prefs.getString("auth_email", ""));
            o.put("photo", prefs.getString("auth_photo", ""));
        } catch (Exception ignored) {
        }
        return o;
    }

    boolean isSignedIn() {
        return prefs.getBoolean("auth_signed_in", false);
    }

    interface Done {
        void done(boolean ok, String error);
    }

    /** Явный вход: показывает системный выбор аккаунта Google. Вызывать из главного потока. */
    void signIn(Activity act, String webClientId, final Done done) {
        if (webClientId == null || webClientId.trim().isEmpty()) {
            done.done(false, "no_client_id");
            return;
        }
        try {
            GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(webClientId.trim()).build();
            GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
            CredentialManager manager = CredentialManager.create(act);
            manager.getCredentialAsync(act, request, new CancellationSignal(), mainExecutor,
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override
                        public void onResult(GetCredentialResponse result) {
                            handle(result.getCredential(), done);
                        }

                        @Override
                        public void onError(GetCredentialException e) {
                            done.done(false, e.getClass().getSimpleName() + ": " + e.getMessage());
                        }
                    });
        } catch (Exception e) {
            done.done(false, e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    /** Тихое обновление токена для уже вошедшего пользователя. Главный поток. */
    private void silentRefresh(Activity act, String webClientId, boolean strict, final Done done) {
        try {
            GetGoogleIdOption option = new GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(strict)
                    .setAutoSelectEnabled(true)
                    .setServerClientId(webClientId.trim())
                    .build();
            GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
            CredentialManager manager = CredentialManager.create(act);
            manager.getCredentialAsync(act, request, new CancellationSignal(), mainExecutor,
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override
                        public void onResult(GetCredentialResponse result) {
                            handle(result.getCredential(), done);
                        }

                        @Override
                        public void onError(GetCredentialException e) {
                            done.done(false, e.getClass().getSimpleName());
                        }
                    });
        } catch (Exception e) {
            done.done(false, e.getClass().getSimpleName());
        }
    }

    private void handle(Credential credential, Done done) {
        try {
            if (credential instanceof CustomCredential
                    && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(credential.getData());
                idToken = g.getIdToken();
                store.put("idtoken", idToken);
                String name = g.getDisplayName() == null ? "" : g.getDisplayName();
                String photo = g.getProfilePictureUri() == null ? "" : g.getProfilePictureUri().toString();
                // commit(): запись сразу на диск, чтобы сессия не потерялась, если процесс завершат сразу после входа
                prefs.edit()
                        .putBoolean("auth_signed_in", true)
                        .putString("auth_name", name)
                        .putString("auth_email", g.getId())
                        .putString("auth_photo", photo)
                        .commit();
                done.done(true, "");
            } else {
                done.done(false, "unexpected_credential");
            }
        } catch (Exception e) {
            done.done(false, e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    private static long expiry(String jwt) {
        try {
            String payload = jwt.split("\\.")[1];
            byte[] b = Base64.decode(payload, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            return new JSONObject(new String(b, StandardCharsets.UTF_8)).optLong("exp", 0L);
        } catch (Exception e) {
            return 0L;
        }
    }

    /**
     * Возвращает действующий ID-токен или пустую строку. БЛОКИРУЮЩИЙ метод: вызывать только из фонового потока.
     */
    private static boolean valid(String t) {
        return t != null && !t.isEmpty() && expiry(t) > System.currentTimeMillis() / 1000L + 120L;
    }

    /** Действующий токен без сети и без окон (для фоновых автоответов). Пусто, если токена нет или он истёк. */
    String cachedToken() {
        if (valid(idToken)) return idToken;
        String saved = store.get("idtoken");
        if (valid(saved)) {
            idToken = saved;
            return saved;
        }
        return "";
    }

    String ensureToken(final Activity act, final String webClientId) {
        if (valid(idToken)) return idToken;
        // Токен, сохранённый в зашифрованном виде, переживает перезапуск приложения.
        String saved = store.get("idtoken");
        if (valid(saved)) {
            idToken = saved;
            return saved;
        }
        if (!isSignedIn() || webClientId == null || webClientId.trim().isEmpty()) return "";
        // Сначала строгое тихое обновление (только уже авторизованные аккаунты), затем мягкое.
        for (int attempt = 0; attempt < 2; attempt++) {
            final boolean strict = attempt == 0;
            final CountDownLatch latch = new CountDownLatch(1);
            final AtomicReference<Boolean> ok = new AtomicReference<>(Boolean.FALSE);
            main.post(new Runnable() {
                @Override
                public void run() {
                    silentRefresh(act, webClientId, strict, new Done() {
                        @Override
                        public void done(boolean success, String error) {
                            ok.set(success);
                            latch.countDown();
                        }
                    });
                }
            });
            try {
                latch.await(30, TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {
            }
            if (ok.get() && valid(idToken)) return idToken;
        }
        return "";
    }

    void signOut() {
        idToken = "";
        store.clear("idtoken");
        prefs.edit()
                .putBoolean("auth_signed_in", false)
                .remove("auth_name")
                .remove("auth_email")
                .remove("auth_photo")
                .apply();
    }
}
