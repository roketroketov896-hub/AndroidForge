package com.jarvis.ai;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Озвучивание ответов. Текст режется на сегменты (предложения); пауза запоминает номер
 * сегмента и продолжает с него, а не с начала ответа. Одновременно звучит только один ответ.
 * Все публичные методы вызывать из главного потока.
 */
final class TtsController {
    private final JarvisSettings settings;
    private final Emitter emitter;
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private volatile boolean ready = false;

    private volatile int gen = 0;
    private volatile List<String> segments = new ArrayList<String>();
    private volatile int index = 0;
    private String msgId = "";
    private String state = "idle";
    private String lang = "ru";
    private long lastWord = 0L;
    private boolean streamOpen = false;   // ответ ещё приходит: после последней фразы не уходим в idle
    private int doneIndex = -1;
    private final AudioFocusHelper focus;

    TtsController(Context ctx, JarvisSettings settings, Emitter emitter) {
        this.settings = settings;
        this.emitter = emitter;
        this.focus = new AudioFocusHelper(ctx);
        tts = new TextToSpeech(ctx.getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                ready = (status == TextToSpeech.SUCCESS);
                if (ready) {
                    tts.setOnUtteranceProgressListener(new Progress());
                    tts.setAudioAttributes(new android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build());
                }
                JSONObject d = new JSONObject();
                try {
                    d.put("ready", ready);
                } catch (Exception ignored) {
                }
                TtsController.this.emitter.emit("ttsReady", d);
            }
        });
    }

    boolean isReady() {
        return ready;
    }

    private final class Progress extends UtteranceProgressListener {
        private int[] parse(String id) {
            try {
                int c = id.indexOf(':');
                return new int[]{Integer.parseInt(id.substring(0, c)), Integer.parseInt(id.substring(c + 1))};
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        public void onStart(String utteranceId) {
            int[] p = parse(utteranceId);
            if (p == null || p[0] != gen) return;
            index = p[1];
            emitState();
        }

        @Override
        public void onDone(String utteranceId) {
            final int[] p = parse(utteranceId);
            if (p == null || p[0] != gen) return;
            main.post(new Runnable() {
                @Override
                public void run() {
                    if (p[0] != gen) return;
                    if (p[1] > doneIndex) doneIndex = p[1];
                    if (!streamOpen && p[1] >= segments.size() - 1) {
                        state = "idle";
                        focus.release();
                        emitState();
                    }
                }
            });
        }

        @Override
        @SuppressWarnings("deprecation")
        public void onError(String utteranceId) {
            reportError(utteranceId);
        }

        @Override
        public void onError(String utteranceId, int errorCode) {
            reportError(utteranceId);
        }

        private void reportError(String utteranceId) {
            final int[] p = parse(utteranceId);
            if (p == null || p[0] != gen) return;
            main.post(new Runnable() {
                @Override
                public void run() {
                    if (p[0] == gen) {
                        state = "idle";
                        focus.release();
                        emitState();
                        error("synth_error", "Не удалось озвучить текст. Проверь голосовой движок Android.");
                    }
                }
            });
        }

        @Override
        public void onRangeStart(String utteranceId, int start, int end, int frame) {
            int[] p = parse(utteranceId);
            if (p == null || p[0] != gen) return;
            long now = System.currentTimeMillis();
            if (now - lastWord < 90L) return;
            lastWord = now;
            JSONObject d = new JSONObject();
            try {
                d.put("msgId", msgId);
            } catch (Exception ignored) {
            }
            emitter.emit("ttsWord", d);
        }
    }

    private void emitState() {
        JSONObject d = new JSONObject();
        try {
            d.put("state", state);
            d.put("msgId", msgId);
            d.put("index", index);
            d.put("total", segments.size());
        } catch (Exception ignored) {
        }
        emitter.emit("tts", d);
    }

    private void error(String code, String message) {
        JSONObject d = new JSONObject();
        try {
            d.put("code", code);
            d.put("message", message);
            d.put("lang", lang);
        } catch (Exception ignored) {
        }
        emitter.emit("ttsError", d);
    }

    private static Locale localeFor(String l) {
        if ("az".equals(l)) return new Locale("az", "AZ");
        if ("tr".equals(l)) return new Locale("tr", "TR");
        if ("en".equals(l)) return Locale.US;
        return new Locale("ru", "RU");
    }

    void speak(String id, String text, String language) {
        if (!ready) {
            error("not_ready", "Синтез речи ещё не готов или не установлен на этом телефоне.");
            return;
        }
        stopInternal();
        lang = (language == null || language.isEmpty()) ? "ru" : language;
        int r = tts.setLanguage(localeFor(lang));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            state = "idle";
            msgId = id;
            emitState();
            error("lang_unsupported", "Выбранный голосовой движок не поддерживает этот язык или у него нет данных голоса.");
            return;
        }
        applyVoice(lang);
        tts.setSpeechRate((float) settings.all().optDouble("ttsRate", 0.95));
        tts.setPitch((float) settings.all().optDouble("ttsPitch", 0.85));
        List<String> segs = split(text);
        if (segs.isEmpty()) {
            state = "idle";
            msgId = id;
            emitState();
            return;
        }
        segments = segs;
        msgId = id;
        index = 0;
        doneIndex = -1;
        streamOpen = false;
        gen++;
        state = "speaking";
        focus.acquire(new Runnable() {
            @Override
            public void run() {
                pause();
            }
        });
        emitState();
        enqueueFrom(0);
    }

    private void enqueueFrom(int from) {
        List<String> segs = segments;
        int g = gen;
        for (int k = from; k < segs.size(); k++) {
            tts.speak(segs.get(k), TextToSpeech.QUEUE_ADD, null, g + ":" + k);
        }
    }

    /** Потоковая речь для Live: фразы добавляются по мере прихода ответа модели. */
    void streamStart(String id, String language) {
        if (!ready) {
            error("not_ready", "Синтез речи ещё не готов или не установлен на этом телефоне.");
            return;
        }
        stopInternal();
        lang = (language == null || language.isEmpty()) ? "ru" : language;
        int r = tts.setLanguage(localeFor(lang));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            state = "idle";
            msgId = id;
            emitState();
            error("lang_unsupported", "Выбранный голосовой движок не поддерживает этот язык или у него нет данных голоса.");
            return;
        }
        applyVoice(lang);
        tts.setSpeechRate((float) settings.all().optDouble("ttsRate", 0.95));
        tts.setPitch((float) settings.all().optDouble("ttsPitch", 0.85));
        segments = new ArrayList<String>();
        msgId = id;
        index = 0;
        doneIndex = -1;
        gen++;
        streamOpen = true;
        state = "speaking";
        focus.acquire(new Runnable() {
            @Override
            public void run() {
                pause();
            }
        });
        emitState();
    }

    void streamAdd(String text) {
        if (!streamOpen || !ready) return;
        List<String> add = split(text);
        if (add.isEmpty()) return;
        List<String> all = new ArrayList<String>(segments);
        int base = all.size();
        all.addAll(add);
        segments = all;
        if ("paused".equals(state)) return;   // при паузе только копим: resume() озвучит с текущего места
        int g = gen;
        for (int k = 0; k < add.size(); k++) {
            tts.speak(add.get(k), TextToSpeech.QUEUE_ADD, null, g + ":" + (base + k));
        }
    }

    /** Ответ закончился: когда доиграют все накопленные фразы, состояние станет idle. */
    void streamEnd() {
        if (!streamOpen) return;
        streamOpen = false;
        if (!"speaking".equals(state)) return;
        if (segments.isEmpty() || doneIndex >= segments.size() - 1) {
            state = "idle";
            focus.release();
            emitState();
        }
    }

    void pause() {
        if (!"speaking".equals(state)) return;
        state = "paused";
        gen++;
        tts.stop();
        focus.release();
        emitState();
    }

    void resume() {
        if (!"paused".equals(state)) return;
        state = "speaking";
        gen++;
        focus.acquire(new Runnable() {
            @Override
            public void run() {
                pause();
            }
        });
        applyVoice(lang);
        tts.setLanguage(localeFor(lang));
        applyVoice(lang);
        enqueueFrom(index);
        emitState();
    }

    void stop() {
        boolean was = !"idle".equals(state);
        stopInternal();
        if (was) emitState();
    }

    private void stopInternal() {
        gen++;
        streamOpen = false;
        state = "idle";
        if (tts != null) tts.stop();
        focus.release();
    }

    void shutdown() {
        gen++;
        state = "idle";
        focus.release();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }

    private void applyVoice(String l) {
        String name = settings.voiceFor(l);
        if (name.isEmpty()) return;
        try {
            Set<Voice> vs = tts.getVoices();
            if (vs == null) return;
            for (Voice v : vs) {
                if (v.getName().equals(name)) {
                    tts.setVoice(v);
                    return;
                }
            }
        } catch (Exception ignored) {
        }
    }

    JSONArray voices(String l) {
        JSONArray arr = new JSONArray();
        if (!ready) return arr;
        try {
            Set<Voice> vs = tts.getVoices();
            if (vs == null) return arr;
            List<Voice> list = new ArrayList<Voice>();
            for (Voice v : vs) {
                if (v.getLocale() == null || !l.equals(v.getLocale().getLanguage())) continue;
                Set<String> f = v.getFeatures();
                if (f != null && f.contains("notInstalled")) continue;
                list.add(v);
            }
            Collections.sort(list, new Comparator<Voice>() {
                @Override
                public int compare(Voice a, Voice b) {
                    int q = b.getQuality() - a.getQuality();
                    return q != 0 ? q : a.getName().compareTo(b.getName());
                }
            });
            String selected = settings.voiceFor(l);
            for (Voice v : list) {
                JSONObject o = new JSONObject();
                o.put("name", v.getName());
                o.put("locale", v.getLocale().toLanguageTag());
                o.put("quality", v.getQuality());
                o.put("network", v.isNetworkConnectionRequired());
                o.put("selected", v.getName().equals(selected));
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        return arr;
    }

    /** Убирает Markdown и режет текст на фразы до ~200 символов. */
    static List<String> split(String text) {
        List<String> out = new ArrayList<String>();
        if (text == null) return out;
        String t = text
                .replaceAll("(?s)```.*?```", " ")
                .replaceAll("`([^`]*)`", "$1")
                .replaceAll("!?\\[([^\\]]*)\\]\\([^)]*\\)", "$1")
                .replaceAll("(?m)^\\s{0,3}#{1,6}\\s*", "")
                .replaceAll("(?m)^\\s*[-*+]\\s+", "")
                .replaceAll("https?://\\S+", " ")
                .replaceAll("[*_>#|~]", "");
        String[] parts = t.split("(?<=[.!?…])\\s+|\\n+");
        StringBuilder cur = new StringBuilder();
        for (String raw : parts) {
            String p = raw.trim();
            if (p.isEmpty()) continue;
            while (p.length() > 260) {
                int cut = p.lastIndexOf(' ', 240);
                if (cut < 60) cut = 240;
                if (cur.length() > 0) {
                    out.add(cur.toString());
                    cur.setLength(0);
                }
                out.add(p.substring(0, cut).trim());
                p = p.substring(cut).trim();
            }
            if (p.isEmpty()) continue;
            if (cur.length() > 0 && cur.length() + p.length() + 1 > 200) {
                out.add(cur.toString());
                cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(p);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }
}
