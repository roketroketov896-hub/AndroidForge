package com.jarvis.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Интернет-инструменты JARVIS: поиск и чтение страниц прямо с телефона.
 * Адреса локальной сети, localhost и служебные диапазоны запрещены (в том числе после перенаправлений),
 * размер ответа ограничен. Содержимое страниц передаётся модели как недоверенные данные.
 * Это чтение текста и переход по ссылкам, страницы с JavaScript-интерфейсом и формы не поддерживаются.
 */
final class WebTools {
    private static final String UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";
    private static final int MAX_BYTES = 1500000;

    private WebTools() {
    }

    static final class WebException extends Exception {
        WebException(String message) {
            super(message);
        }
    }

    static JSONObject run(String name, JSONObject args) throws Exception {
        if ("web_search".equals(name)) return search(args.optString("q", args.optString("query", "")));
        if ("web_fetch".equals(name)) return fetch(args.optString("url", ""));
        throw new WebException("Неизвестный инструмент: " + name);
    }

    // ---------- безопасность адреса ----------

    private static void validate(String u) throws Exception {
        URL url = new URL(u);
        String p = url.getProtocol();
        if (!"http".equals(p) && !"https".equals(p)) throw new WebException("Разрешены только http и https.");
        String host = url.getHost();
        if (host == null || host.isEmpty()) throw new WebException("Пустой адрес.");
        for (InetAddress a : InetAddress.getAllByName(host)) {
            byte[] b = a.getAddress();
            boolean bad = a.isAnyLocalAddress() || a.isLoopbackAddress() || a.isLinkLocalAddress()
                    || a.isSiteLocalAddress() || a.isMulticastAddress();
            if (b.length == 4 && (b[0] & 0xFF) == 100 && (b[1] & 0xC0) == 64) bad = true;   // 100.64.0.0/10
            if (b.length == 16 && (b[0] & 0xFE) == 0xFC) bad = true;                         // fc00::/7
            if (bad) throw new WebException("Адрес из локальной сети запрещён.");
        }
    }

    // ---------- загрузка ----------

    private static final class Page {
        String url;
        String body;
    }

    private static Page download(String start) throws Exception {
        String u = start;
        for (int hop = 0; hop < 5; hop++) {
            validate(u);
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            try {
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(12000);
                c.setReadTimeout(15000);
                c.setRequestProperty("User-Agent", UA);
                c.setRequestProperty("Accept", "text/html,text/plain,application/xhtml+xml,application/json;q=0.8,*/*;q=0.5");
                c.setRequestProperty("Accept-Language", "ru,en;q=0.8,az;q=0.6,tr;q=0.6");
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null) throw new WebException("Перенаправление без адреса.");
                    u = new URL(new URL(u), loc).toString();
                    continue;
                }
                if (code >= 400) throw new WebException("Сайт ответил ошибкой " + code + ".");
                String type = c.getContentType() == null ? "" : c.getContentType().toLowerCase();
                if (!type.isEmpty() && !type.contains("text") && !type.contains("json") && !type.contains("xml"))
                    throw new WebException("Этот тип содержимого прочитать нельзя: " + type);
                Charset cs = Charset.forName("UTF-8");
                Matcher m = Pattern.compile("charset=([\\w-]+)").matcher(type);
                if (m.find()) {
                    try {
                        cs = Charset.forName(m.group(1));
                    } catch (Exception ignored) {
                    }
                }
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                try (InputStream in = c.getInputStream()) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0 && bos.size() < MAX_BYTES) bos.write(buf, 0, n);
                }
                Page p = new Page();
                p.url = u;
                p.body = new String(bos.toByteArray(), cs);
                return p;
            } finally {
                c.disconnect();
            }
        }
        throw new WebException("Слишком много перенаправлений.");
    }

    // ---------- разбор HTML ----------

    private static String unescape(String s) {
        s = s.replace("&nbsp;", " ").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&");
        Matcher m = Pattern.compile("&#(\\d{2,5});").matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String rep;
            try {
                rep = String.valueOf((char) Integer.parseInt(m.group(1)));
            } catch (Exception e) {
                rep = " ";
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static String stripTags(String s) {
        return unescape(s.replaceAll("(?s)<[^>]*>", " ")).replaceAll("[ \\t\\u00a0]+", " ").trim();
    }

    static JSONObject fetch(String url) throws Exception {
        if (url == null || url.trim().isEmpty()) throw new WebException("Не указан адрес.");
        Page page = download(url.trim());
        String html = page.body;
        Matcher tm = Pattern.compile("(?is)<title[^>]*>(.*?)</title>").matcher(html);
        String title = tm.find() ? stripTags(tm.group(1)) : "";
        String clean = html.replaceAll("(?is)<(script|style|noscript|svg|head)[^>]*>.*?</\\1>", " ").replaceAll("(?s)<!--.*?-->", " ");
        JSONArray links = new JSONArray();
        Set<String> seen = new HashSet<String>();
        Matcher lm = Pattern.compile("(?is)<a\\s+[^>]*href\\s*=\\s*[\"']([^\"'#][^\"']*)[\"'][^>]*>(.*?)</a>").matcher(clean);
        while (lm.find() && links.length() < 40) {
            String href = unescape(lm.group(1).trim());
            String low = href.toLowerCase();
            if (low.startsWith("javascript:") || low.startsWith("mailto:") || low.startsWith("tel:")) continue;
            String abs;
            try {
                abs = new URL(new URL(page.url), href).toString();
            } catch (Exception e) {
                continue;
            }
            String text = stripTags(lm.group(2));
            if (text.isEmpty() || !seen.add(abs)) continue;
            JSONObject l = new JSONObject();
            l.put("i", links.length() + 1);
            l.put("text", text.length() > 80 ? text.substring(0, 80) : text);
            l.put("url", abs);
            links.put(l);
        }
        String text = unescape(clean.replaceAll("(?is)</(p|div|li|h[1-6]|tr|section|article)>|<br\\s*/?>", "\n").replaceAll("(?s)<[^>]*>", " "))
                .replaceAll("[ \\t\\u00a0]+", " ").replaceAll("\\s*\\n\\s*", "\n").replaceAll("\\n{3,}", "\n\n").trim();
        boolean truncated = text.length() > 12000;
        if (truncated) text = text.substring(0, 12000);
        JSONObject out = new JSONObject();
        out.put("url", page.url);
        out.put("title", title);
        out.put("text", text);
        out.put("truncated", truncated);
        out.put("links", links);
        return out;
    }

    static JSONObject search(String q) throws Exception {
        if (q == null || q.trim().isEmpty()) throw new WebException("Пустой поисковый запрос.");
        Page page = download("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q.trim(), "UTF-8"));
        List<String> snippets = new ArrayList<String>();
        Matcher sm = Pattern.compile("(?is)class=\"result__snippet\"[^>]*>(.*?)</(?:a|td|div)>").matcher(page.body);
        while (sm.find()) snippets.add(stripTags(sm.group(1)));
        JSONArray results = new JSONArray();
        Matcher am = Pattern.compile("(?is)<a\\s+([^>]*class=\"[^\"]*result__a[^\"]*\"[^>]*)>(.*?)</a>").matcher(page.body);
        while (am.find() && results.length() < 8) {
            Matcher hm = Pattern.compile("href=\"([^\"]+)\"").matcher(am.group(1));
            if (!hm.find()) continue;
            String href = unescape(hm.group(1));
            Matcher um = Pattern.compile("[?&]uddg=([^&]+)").matcher(href);
            if (um.find()) href = URLDecoder.decode(um.group(1), "UTF-8");
            else if (href.startsWith("//")) href = "https:" + href;
            if (!href.startsWith("http")) continue;
            JSONObject r = new JSONObject();
            r.put("i", results.length() + 1);
            r.put("title", stripTags(am.group(2)));
            r.put("url", href);
            r.put("snippet", results.length() < snippets.size() ? snippets.get(results.length()) : "");
            results.put(r);
        }
        if (results.length() == 0) throw new WebException("Поиск не вернул результатов (сервис мог изменить формат страницы или временно ограничить доступ).");
        JSONObject out = new JSONObject();
        out.put("query", q.trim());
        out.put("results", results);
        return out;
    }
}
