package com.jarvis.ai;

import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Настоящие файлы JARVIS: вложения пользователя (копия сохраняется, чтобы её можно было открыть из чата)
 * и файлы, которые создаёт сам JARVIS (текст, ZIP, изображения). Всё лежит во внутреннем хранилище
 * приложения (filesDir/files), наружу отдаётся только через {@link FileShareProvider}.
 * «Скачать» копирует файл в системную папку «Загрузки/JARVIS» (MediaStore, без лишних разрешений).
 * APK и подобные установочные файлы JARVIS не создаёт.
 */
final class FileStore {
    private FileStore() {
    }

    static final long MAX_TEXT = 8L * 1024 * 1024;
    static final long MAX_BIN = 25L * 1024 * 1024;
    private static final long KEEP_TOTAL = 400L * 1024 * 1024;
    private static final Set<String> BLOCKED = new HashSet<String>();

    static {
        BLOCKED.add("apk");
        BLOCKED.add("xapk");
        BLOCKED.add("apks");
        BLOCKED.add("aab");
        BLOCKED.add("dex");
    }

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "files");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static String ext(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 || i == name.length() - 1 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    /** Безопасное имя файла: без путей, управляющих и запрещённых символов. */
    static String safeName(String n, String fallback) {
        String s = n == null ? "" : n.replace('\\', '/');
        int slash = s.lastIndexOf('/');
        if (slash >= 0) s = s.substring(slash + 1);
        s = s.replaceAll("[\\p{Cntrl}:*?\"<>|]", "_").trim();
        while (s.startsWith(".")) s = s.substring(1);
        if (s.length() > 80) {
            String e = ext(s);
            s = s.substring(0, 70) + (e.isEmpty() ? "" : "." + e);
        }
        return s.isEmpty() ? fallback : s;
    }

    private static File unique(File d, String name) {
        File f = new File(d, name);
        if (!f.exists()) return f;
        String e = ext(name);
        String base = e.isEmpty() ? name : name.substring(0, name.length() - e.length() - 1);
        for (int i = 2; i < 1000; i++) {
            f = new File(d, base + " (" + i + ")" + (e.isEmpty() ? "" : "." + e));
            if (!f.exists()) return f;
        }
        return new File(d, System.currentTimeMillis() + "_" + name);
    }

    static String mime(String name) {
        switch (ext(name)) {
            case "png": return "image/png";
            case "jpg": case "jpeg": return "image/jpeg";
            case "webp": return "image/webp";
            case "gif": return "image/gif";
            case "svg": return "image/svg+xml";
            case "pdf": return "application/pdf";
            case "zip": return "application/zip";
            case "txt": case "log": return "text/plain";
            case "md": return "text/markdown";
            case "csv": return "text/csv";
            case "json": return "application/json";
            case "xml": return "text/xml";
            case "html": case "htm": return "text/html";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "pptx": return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
            case "mp3": return "audio/mpeg";
            case "mp4": return "video/mp4";
            default: return "application/octet-stream";
        }
    }

    static String kind(String name) {
        String m = mime(name);
        if (m.startsWith("image/")) return "image";
        if (m.equals("application/zip")) return "archive";
        if (m.equals("application/pdf")) return "pdf";
        if (m.startsWith("text/") || m.equals("application/json")) return "text";
        return "file";
    }

    static JSONObject describe(File f) {
        JSONObject o = new JSONObject();
        try {
            o.put("id", f.getName());
            o.put("name", f.getName());
            o.put("size", f.length());
            o.put("mime", mime(f.getName()));
            o.put("kind", kind(f.getName()));
        } catch (Exception ignored) {
        }
        return o;
    }

    /** Файл по id (= имя в нашей папке) или null: выход за пределы папки невозможен. */
    static File resolve(Context c, String id) {
        if (id == null || id.isEmpty() || id.contains("/") || id.contains("\\") || id.startsWith(".")) return null;
        File f = new File(dir(c), id);
        return f.isFile() ? f : null;
    }

    private static JSONObject fail(String message) {
        JSONObject r = new JSONObject();
        try {
            r.put("ok", false);
            r.put("message", message);
        } catch (Exception ignored) {
        }
        return r;
    }

    private static JSONObject done(File f, String message) {
        JSONObject r = new JSONObject();
        try {
            r.put("ok", true);
            r.put("file", describe(f));
            r.put("message", message);
        } catch (Exception ignored) {
        }
        return r;
    }

    private static String blockedMsg(String name) {
        return BLOCKED.contains(ext(name)) ? "Файлы установки приложений (." + ext(name) + ") JARVIS не создаёт." : null;
    }

    /** Создаёт файл из текста или из base64. */
    static JSONObject create(Context c, String name, String content, boolean base64) {
        try {
            String n = safeName(name, "jarvis.txt");
            String b = blockedMsg(n);
            if (b != null) return fail(b);
            byte[] data;
            if (base64) {
                data = Base64.decode(content == null ? "" : content.replaceAll("^data:[^,]*,", ""), Base64.DEFAULT);
                if (data.length > MAX_BIN) return fail("Файл больше 25 МБ.");
            } else {
                data = (content == null ? "" : content).getBytes(StandardCharsets.UTF_8);
                if (data.length > MAX_TEXT) return fail("Текст больше 8 МБ: разбей на несколько файлов.");
            }
            if (data.length == 0) return fail("Пустое содержимое: файл не создан.");
            prune(c);
            File f = unique(dir(c), n);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(data);
            }
            return done(f, "Файл создан: " + f.getName() + " (" + data.length + " байт).");
        } catch (Exception e) {
            return fail("Не удалось создать файл (" + e.getClass().getSimpleName() + ").");
        }
    }

    static JSONObject createBytes(Context c, String name, byte[] data) {
        try {
            String n = safeName(name, "jarvis.bin");
            String b = blockedMsg(n);
            if (b != null) return fail(b);
            if (data == null || data.length == 0) return fail("Пустые данные.");
            if (data.length > MAX_BIN) return fail("Файл больше 25 МБ.");
            prune(c);
            File f = unique(dir(c), n);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(data);
            }
            return done(f, "Файл создан: " + f.getName());
        } catch (Exception e) {
            return fail("Не удалось сохранить файл (" + e.getClass().getSimpleName() + ").");
        }
    }

    /** Собирает настоящий ZIP из списка {name, content[, base64]}. */
    static JSONObject zip(Context c, String zipName, JSONArray files) {
        try {
            if (files == null || files.length() == 0) return fail("Нет файлов для архива.");
            if (files.length() > 200) return fail("В архиве может быть не больше 200 файлов.");
            String n = safeName(zipName, "jarvis.zip");
            if (!n.toLowerCase(Locale.ROOT).endsWith(".zip")) n = n + ".zip";
            prune(c);
            File f = unique(dir(c), n);
            long total = 0;
            Set<String> used = new HashSet<String>();
            try (ZipOutputStream zo = new ZipOutputStream(new FileOutputStream(f))) {
                for (int i = 0; i < files.length(); i++) {
                    JSONObject it = files.optJSONObject(i);
                    if (it == null) continue;
                    String en = it.optString("name", "file" + (i + 1) + ".txt").replace('\\', '/');
                    // Путь внутри архива: подпапки разрешены, выход наверх (..) и абсолютные пути нет
                    StringBuilder path = new StringBuilder();
                    for (String part : en.split("/")) {
                        String p = safeName(part, "");
                        if (p.isEmpty() || p.equals("..")) continue;
                        if (path.length() > 0) path.append('/');
                        path.append(p);
                    }
                    String entry = path.length() == 0 ? "file" + (i + 1) + ".txt" : path.toString();
                    String b = blockedMsg(entry);
                    if (b != null) {
                        f.delete();
                        return fail(b);
                    }
                    while (!used.add(entry)) entry = "_" + entry;
                    byte[] data = it.optBoolean("base64", false)
                            ? Base64.decode(it.optString("content", "").replaceAll("^data:[^,]*,", ""), Base64.DEFAULT)
                            : it.optString("content", "").getBytes(StandardCharsets.UTF_8);
                    total += data.length;
                    if (total > MAX_BIN) {
                        f.delete();
                        return fail("Содержимое архива больше 25 МБ.");
                    }
                    zo.putNextEntry(new ZipEntry(entry));
                    zo.write(data);
                    zo.closeEntry();
                }
            }
            return done(f, "Архив создан: " + f.getName() + " (" + files.length() + " файл(ов)).");
        } catch (Exception e) {
            return fail("Не удалось создать архив (" + e.getClass().getSimpleName() + ").");
        }
    }

    /** Копирует выбранный пользователем файл в хранилище, чтобы его можно было открыть из чата. */
    static JSONObject importUri(Context c, Uri uri, String name) {
        try {
            String n = safeName(name, "file");
            if (BLOCKED.contains(ext(n))) return null;   // установочные файлы не храним
            prune(c);
            File f = unique(dir(c), n);
            long total = 0;
            try (InputStream in = c.getContentResolver().openInputStream(uri); FileOutputStream os = new FileOutputStream(f)) {
                if (in == null) return null;
                byte[] buf = new byte[16384];
                int r;
                while ((r = in.read(buf)) > 0) {
                    total += r;
                    if (total > MAX_BIN) {
                        os.close();
                        f.delete();
                        return null;
                    }
                    os.write(buf, 0, r);
                }
            }
            return describe(f);
        } catch (Exception e) {
            return null;
        }
    }

    /** Не даёт папке расти бесконечно: старые файлы удаляются, когда набирается больше ~400 МБ. */
    private static void prune(Context c) {
        try {
            File[] all = dir(c).listFiles();
            if (all == null) return;
            long sum = 0;
            for (File f : all) sum += f.length();
            if (sum < KEEP_TOTAL) return;
            java.util.Arrays.sort(all, new java.util.Comparator<File>() {
                @Override
                public int compare(File a, File b) {
                    return Long.compare(a.lastModified(), b.lastModified());
                }
            });
            for (File f : all) {
                if (sum < KEEP_TOTAL * 3 / 4) break;
                sum -= f.length();
                f.delete();
            }
        } catch (Exception ignored) {
        }
    }

    /** Уменьшенное изображение как data:-URL для показа в чате. */
    static String thumbDataUrl(Context c, String id, int maxSide) {
        File f = resolve(c, id);
        if (f == null || !kind(f.getName()).equals("image") || ext(f.getName()).equals("svg")) return "";
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int s = 1;
            while (o.outWidth / (s * 2) >= maxSide || o.outHeight / (s * 2) >= maxSide) s *= 2;
            BitmapFactory.Options d = new BitmapFactory.Options();
            d.inSampleSize = s;
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath(), d);
            if (b == null) return "";
            int w = b.getWidth(), h = b.getHeight(), m = Math.max(w, h);
            if (m > maxSide) {
                float k = (float) maxSide / m;
                b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k)), true);
            }
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            boolean png = ext(f.getName()).equals("png") && b.hasAlpha();
            b.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 88, bo);
            return "data:" + (png ? "image/png" : "image/jpeg") + ";base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable t) {
            return "";
        }
    }

    /** Открыть файл в подходящем приложении (системный выбор). */
    static boolean open(MainActivity act, String id) {
        File f = resolve(act, id);
        if (f == null) return false;
        try {
            Uri u = FileShareProvider.uriFor(act, f.getName());
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, mime(f.getName()));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.setClipData(ClipData.newRawUri("", u));
            Intent ch = Intent.createChooser(i, "Открыть: " + f.getName());
            ch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            act.startActivity(ch);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Поделиться файлом (системное меню «Отправить»). */
    static boolean share(MainActivity act, String id) {
        File f = resolve(act, id);
        if (f == null) return false;
        try {
            Uri u = FileShareProvider.uriFor(act, f.getName());
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime(f.getName()));
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.setClipData(ClipData.newRawUri("", u));
            Intent ch = Intent.createChooser(i, "Отправить: " + f.getName());
            ch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            act.startActivity(ch);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Копия в «Загрузки/JARVIS». Возвращает {ok, where, name}. */
    static JSONObject saveToDownloads(Context c, String id) {
        File f = resolve(c, id);
        if (f == null) return fail("Файл не найден: возможно, он был удалён.");
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = c.getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, f.getName());
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime(f.getName()));
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/JARVIS");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri dst = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (dst == null) return fail("Система не дала создать файл в «Загрузках».");
                try (InputStream in = new FileInputStream(f); OutputStream os = cr.openOutputStream(dst)) {
                    if (os == null) return fail("Не удалось записать в «Загрузки».");
                    byte[] buf = new byte[16384];
                    int r;
                    while ((r = in.read(buf)) > 0) os.write(buf, 0, r);
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(dst, done, null, null);
                String shown = f.getName();
                try (android.database.Cursor q = cr.query(dst, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                    if (q != null && q.moveToFirst() && q.getString(0) != null) shown = q.getString(0);
                } catch (Exception ignored) {
                }
                JSONObject r = new JSONObject();
                r.put("ok", true);
                r.put("name", shown);
                r.put("where", "Загрузки/JARVIS/" + shown);
                return r;
            }
            // Android 6–9: без разрешения на запись в общую память пишем в папку приложения «Загрузки»
            File base = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (base == null) return fail("Нет доступа к памяти телефона.");
            File dst = unique(base, f.getName());
            try (InputStream in = new FileInputStream(f); FileOutputStream os = new FileOutputStream(dst)) {
                byte[] buf = new byte[16384];
                int r;
                while ((r = in.read(buf)) > 0) os.write(buf, 0, r);
            }
            JSONObject r = new JSONObject();
            r.put("ok", true);
            r.put("name", dst.getName());
            r.put("where", "Android/data/" + c.getPackageName() + "/files/Download/" + dst.getName());
            return r;
        } catch (Exception e) {
            return fail("Не удалось сохранить файл (" + e.getClass().getSimpleName() + ").");
        }
    }

    /** Открывает системное приложение «Загрузки» («Мои файлы»). */
    static boolean openDownloads(Context c) {
        try {
            Intent i = new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
