package com.jarvis.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Передний план для Live Voice. Пока служба работает, Android разрешает микрофону продолжать работу после
 * сворачивания приложения, а пользователь всегда видит уведомление с кнопкой «Остановить». Сама служба
 * микрофон не включает: запись ведёт приложение, а служба только легально удерживает её в фоне.
 * Запускается только по явному нажатию пользователя.
 */
public class LiveVoiceService extends Service {
    static final String ACTION_START = "com.jarvis.ai.LIVE_START";
    static final String ACTION_STOP = "com.jarvis.ai.LIVE_STOP";
    private static final String CHANNEL = "jarvis_live";
    private static final int NOTIF_ID = 4712;

    interface Listener {
        void onStopped();
    }

    static volatile Listener listener;
    static volatile boolean running = false;
    private PowerManager.WakeLock wake;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopLive(true);
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action)) {
            if (!running) stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Live Voice JARVIS", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent open = PendingIntent.getActivity(this, 11,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT | imm);
        PendingIntent stop = PendingIntent.getService(this, 12,
                new Intent(this, LiveVoiceService.class).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT | imm);
        b.setContentTitle("JARVIS слушает")
                .setContentText("Live включён: слушаю, даже когда приложение свёрнуто. Нажми «Остановить», чтобы выключить.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Остановить", stop);
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 30) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(NOTIF_ID, n);
            running = true;
            acquireWake();
        } catch (Exception e) {
            running = false;
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void stopLive(boolean notify) {
        boolean was = running;
        running = false;
        releaseWake();
        stopForeground(true);
        stopSelf();
        Listener l = listener;
        if (notify && was && l != null) l.onStopped();
    }

    /** Пока Live включён, процессор не засыпает при выключенном экране (иначе голос в кармане не работает). Лимит 3 часа. */
    private void acquireWake() {
        try {
            if (wake == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:live");
                wake.setReferenceCounted(false);
            }
            if (!wake.isHeld()) wake.acquire(3L * 60 * 60 * 1000);
        } catch (Exception ignored) {
        }
    }

    private void releaseWake() {
        try {
            if (wake != null && wake.isHeld()) wake.release();
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDestroy() {
        releaseWake();
        running = false;
        super.onDestroy();
    }
}
