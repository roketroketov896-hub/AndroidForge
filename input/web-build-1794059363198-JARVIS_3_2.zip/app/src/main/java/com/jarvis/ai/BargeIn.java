package com.jarvis.ai;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.NoiseSuppressor;
import android.os.Handler;
import android.os.Looper;

/**
 * Перебивание в Live: пока JARVIS говорит, слушаем микрофон (источник VOICE_COMMUNICATION, у которого на
 * большинстве телефонов включено системное эхоподавление) и ищем голос пользователя. Как только речь
 * держится около четверти секунды, вызываем onSpeech(): вызывающий останавливает озвучку и запускает
 * распознавание. Ничего не записывается и не сохраняется: считается только громкость кадров.
 *
 * Работает только пока включён Live (его видно в уведомлении) и только во время речи JARVIS.
 * Честное ограничение: на телефонах без аппаратного эхоподавления голос JARVIS из динамика может
 * срабатывать как «перебивание»; тогда порог выше, а лучше всего перебивание работает в наушниках.
 */
final class BargeIn {
    interface Callback {
        void onSpeech();
    }

    private static final int RATE = 16000;
    private static final int FRAME = 320;            // 20 мс
    private static final int WARMUP_MS = 450;        // первые мгновения только учимся уровню эха
    private static final int NEED_FRAMES = 13;       // ~260 мс подряд

    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile Thread worker;
    private volatile boolean run = false;

    boolean isRunning() {
        return run;
    }

    /** Главный поток. Разрешение RECORD_AUDIO должно быть выдано. */
    void start(final Callback cb) {
        stop();
        run = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                loop(cb);
            }
        }, "jarvis-bargein");
        t.setDaemon(true);
        worker = t;
        t.start();
    }

    void stop() {
        run = false;
        Thread t = worker;
        worker = null;
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join(400);
            } catch (InterruptedException ignored) {
            }
        }
    }

    private void loop(final Callback cb) {
        AudioRecord rec = null;
        AcousticEchoCanceler aec = null;
        NoiseSuppressor ns = null;
        boolean triggered = false;
        try {
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) return;
            rec = new AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, FRAME * 8) * 2);
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) return;
            boolean hasAec = false;
            try {
                if (AcousticEchoCanceler.isAvailable()) {
                    aec = AcousticEchoCanceler.create(rec.getAudioSessionId());
                    if (aec != null) {
                        aec.setEnabled(true);
                        hasAec = true;
                    }
                }
            } catch (Throwable ignored) {
            }
            try {
                if (NoiseSuppressor.isAvailable()) {
                    ns = NoiseSuppressor.create(rec.getAudioSessionId());
                    if (ns != null) ns.setEnabled(true);
                }
            } catch (Throwable ignored) {
            }
            double floor = hasAec ? 1300.0 : 2600.0;
            double mult = hasAec ? 2.1 : 3.2;
            rec.startRecording();
            if (rec.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) return;

            short[] buf = new short[FRAME];
            double peak = 0;
            int hot = 0, miss = 0;
            long t0 = System.currentTimeMillis();
            while (run) {
                int n = rec.read(buf, 0, FRAME);
                if (n <= 0) {
                    if (n < 0) break;
                    continue;
                }
                double sum = 0;
                for (int i = 0; i < n; i++) sum += (double) buf[i] * buf[i];
                double rms = Math.sqrt(sum / n);
                if (System.currentTimeMillis() - t0 < WARMUP_MS) {
                    peak = Math.max(peak, rms);
                    continue;
                }
                double thr = Math.max(floor, peak * mult);
                if (rms > thr) {
                    hot++;
                    miss = 0;
                    if (hot >= NEED_FRAMES) {
                        triggered = true;
                        break;
                    }
                } else {
                    if (hot > 0 && ++miss > 3) hot = 0;
                    peak = Math.max(rms, peak * 0.997);   // след эха; медленно затухает
                }
            }
        } catch (Throwable ignored) {
        } finally {
            run = false;
            try {
                if (aec != null) aec.release();
            } catch (Throwable ignored) {
            }
            try {
                if (ns != null) ns.release();
            } catch (Throwable ignored) {
            }
            if (rec != null) {
                try {
                    rec.stop();
                } catch (Throwable ignored) {
                }
                try {
                    rec.release();
                } catch (Throwable ignored) {
                }
            }
        }
        if (triggered && cb != null) {
            main.post(new Runnable() {
                @Override
                public void run() {
                    cb.onSpeech();
                }
            });
        }
    }
}
