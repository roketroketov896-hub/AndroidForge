package com.stella.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stella.ai.data.model.AiProvider
import com.stella.ai.ui.StellaViewModel
import com.stella.ai.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: StellaViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val settings = uiState.settings

    var geminiKey by remember { mutableStateOf(settings.apiKeys.gemini) }
    var openaiKey by remember { mutableStateOf(settings.apiKeys.openai) }
    var claudeKey by remember { mutableStateOf(settings.apiKeys.claude) }

    // Update local state when settings change
    LaunchedEffect(settings) {
        geminiKey = settings.apiKeys.gemini
        openaiKey = settings.apiKeys.openai
        claudeKey = settings.apiKeys.claude
    }

    Scaffold(
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Настройки",
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Назад",
                            tint = NeonCyan
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Provider selection
            SectionTitle("ИИ-провайдер")
            
            AiProvider.entries.forEach { provider ->
                ProviderItem(
                    provider = provider,
                    isSelected = settings.selectedProvider == provider,
                    onClick = { viewModel.selectProvider(provider) }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // API Keys
            SectionTitle("API-ключи")

            ApiKeyField(
                label = "Google Gemini",
                value = geminiKey,
                onValueChange = { geminiKey = it },
                onSave = { viewModel.saveApiKey(AiProvider.GEMINI, geminiKey) }
            )

            ApiKeyField(
                label = "OpenAI (GPT)",
                value = openaiKey,
                onValueChange = { openaiKey = it },
                onSave = { viewModel.saveApiKey(AiProvider.OPENAI, openaiKey) }
            )

            ApiKeyField(
                label = "Anthropic Claude",
                value = claudeKey,
                onValueChange = { claudeKey = it },
                onSave = { viewModel.saveApiKey(AiProvider.CLAUDE, claudeKey) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Voice settings
            SectionTitle("Голос")

            SettingsSwitch(
                title = "Голосовой ввод",
                subtitle = "Разрешить использование микрофона",
                checked = settings.voiceEnabled,
                onCheckedChange = viewModel::setVoiceEnabled
            )

            SettingsSwitch(
                title = "Автоозвучка ответов",
                subtitle = "Стелла будет озвучивать свои ответы женским голосом",
                checked = settings.autoSpeak,
                onCheckedChange = viewModel::setAutoSpeak
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Info
            Text(
                text = "API-ключи хранятся только на устройстве и никогда не передаются третьим лицам.",
                color = TextMuted,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text.uppercase(),
        color = NeonCyan,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.5.sp
    )
}

@Composable
fun ProviderItem(
    provider: AiProvider,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (isSelected) NeonCyan.copy(alpha = 0.1f) else DarkCard,
                RoundedCornerShape(12.dp)
            )
            .border(
                width = 1.dp,
                color = if (isSelected) NeonCyan else DarkSurfaceVariant,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = provider.displayName,
            color = if (isSelected) NeonCyan else TextPrimary,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            modifier = Modifier.weight(1f)
        )
        if (isSelected) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = NeonCyan
            )
        }
    }
}

@Composable
fun ApiKeyField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    onSave: () -> Unit
) {
    var visible by remember { mutableStateOf(false) }

    Column {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 13.sp,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text("Вставьте API-ключ…", color = TextMuted)
                },
                visualTransformation = if (visible) VisualTransformation.None
                else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { visible = !visible }) {
                        Icon(
                            imageVector = if (visible) Icons.Default.VisibilityOff
                            else Icons.Default.Visibility,
                            contentDescription = null,
                            tint = TextMuted
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = DarkSurfaceVariant,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = NeonCyan,
                    focusedContainerColor = DarkCard,
                    unfocusedContainerColor = DarkCard
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
            Button(
                onClick = onSave,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan,
                    contentColor = DarkBackground
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Сохранить", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun SettingsSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkCard, RoundedCornerShape(12.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = TextPrimary, fontWeight = FontWeight.Medium)
            Text(text = subtitle, color = TextMuted, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = DarkBackground,
                checkedTrackColor = NeonCyan,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = DarkSurfaceVariant
            )
        )
    }
}
