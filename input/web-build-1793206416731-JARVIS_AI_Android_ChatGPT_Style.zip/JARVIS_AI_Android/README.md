# JARVIS AI — Android source project

This is an Android Gradle project (not just a web folder). It wraps a ChatGPT-inspired chat UI in Android WebView and uses a small native Java bridge for OpenRouter requests.

## Build with AndroidForge

Upload the ZIP as the AndroidForge source ZIP and choose `auto` or `debug`. The ZIP is structured with `settings.gradle` and `app/build.gradle` at the project root so project detection should classify it as a Gradle Android app.

## First launch

1. Open JARVIS AI and tap the settings/gear button.
2. Paste your OpenRouter key and save it. The key is stored in this app's local SharedPreferences on the phone; it is not embedded in this ZIP.
3. The default model is `openrouter/auto`. If your account cannot use automatic routing, enter a model ID available to your OpenRouter account.
4. Return to the chat and send a test message.

## Included

- ChatGPT-inspired dark chat interface, mobile sidebar, new chat and suggestion cards.
- OpenRouter API request from native Android code (not browser `fetch`).
- API key and system prompt settings; model defaults to `openrouter/auto`.
- Short in-memory conversation context, copy response and Android/browser speech synthesis if available.
- Friendly messages for common API errors.

## Not included yet

- Persistent chat history after app restart, long-term memory, WhatsApp/Telegram integration, image generation, real-time voice conversation, login/sync, Play Store release/signing.

## Security note

The key is stored locally in ordinary app-private SharedPreferences, not encrypted with Android Keystore. Treat this as a personal test build and do not distribute an APK containing your personal key. For a public release, move API requests behind a secured backend.

## Validation status

JavaScript syntax and AndroidManifest XML were checked in the working environment. A full Android/Gradle APK build has not been run here; AndroidForge's build result is still required to verify the APK.
