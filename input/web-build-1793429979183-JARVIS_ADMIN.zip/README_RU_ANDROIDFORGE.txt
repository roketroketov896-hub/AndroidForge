# JARVIS ADMIN

Самостоятельный Android Gradle-проект, выделенный из JARVIS_AI_ULTIMATE.zip.

## Сборка APK через AndroidForge
1. Открой https://professional-x.github.io/AndroidForge/
2. Загрузи этот ZIP как Android source ZIP.
3. Выбери Android и Debug (или Auto).
4. Нажми Build и дождись завершения.
5. Скачай APK из завершённого GitHub Actions run.

В архиве только Android-модуль `admin`. `settings.gradle` настроен на сборку только этого модуля.
Application ID: `com.jarvis.admin`. Версия: `2.0.0`.

## Важно
- Это исходный код для сборки APK, не готовый APK.
- Для серверных функций нужен отдельно развёрнутый backend из папки `backend/` и HTTPS-адрес сервера.
- `jarvis-config.properties` содержит только необязательные значения конфигурации. Не вставляй секретные API-ключи в ZIP.
- Админский серверный режим `ADMIN_MODE=open` отключает проверку входа и позволяет любому, кто знает URL сервера, управлять им. Не используй его на публичном сервере; используй защищённый режим Google с ограниченным `ADMIN_EMAILS`.
- GitHub PAT вводи только на официальной странице AndroidForge. Не отправляй токен другим людям и не публикуй его.

Исходные Java-файлы, HTML/CSS/JS, ресурсы, манифесты, Gradle-настройки и debug-keystore выбранного модуля скопированы без изменений.
