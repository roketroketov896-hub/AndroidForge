package com.jarvis.ai;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("jarvis_settings", MODE_PRIVATE);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF212121);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new JarvisBridge(), "JarvisBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class JarvisBridge {
        @JavascriptInterface public String getSettings() {
            JSONObject out = new JSONObject();
            try {
                out.put("model", prefs.getString("model", "openrouter/auto"));
                out.put("systemPrompt", prefs.getString("systemPrompt", "Ты JARVIS — полезный персональный ИИ-помощник. Отвечай ясно и на языке пользователя."));
                out.put("hasKey", !prefs.getString("apiKey", "").isEmpty());
                out.put("memory", prefs.getString("memory", ""));
            } catch (Exception ignored) {}
            return out.toString();
        }
        @JavascriptInterface public void saveSettings(String key, String model, String systemPrompt) {
            SharedPreferences.Editor editor = prefs.edit();
            if (key != null && !key.trim().isEmpty()) editor.putString("apiKey", key.trim());
            editor.putString("model", (model == null || model.trim().isEmpty()) ? "openrouter/auto" : model.trim())
                    .putString("systemPrompt", (systemPrompt == null || systemPrompt.trim().isEmpty()) ? "Ты JARVIS — полезный персональный ИИ-помощник. Отвечай ясно и на языке пользователя." : systemPrompt.trim())
                    .apply();
            mainHandler.post(() -> webView.evaluateJavascript("window.settingsSaved && window.settingsSaved()", null));
        }
        @JavascriptInterface public String getMemory() { return prefs.getString("memory", ""); }
        @JavascriptInterface public void saveMemory(String memory) { prefs.edit().putString("memory", memory == null ? "" : memory.trim()).apply(); }
        @JavascriptInterface public void clearApiKey() {
            prefs.edit().remove("apiKey").apply();
            mainHandler.post(() -> webView.evaluateJavascript("window.keyCleared && window.keyCleared()", null));
        }
        @JavascriptInterface public void sendMessage(String id, String userText, String historyJson) {
            executor.execute(() -> {
                String answer;
                boolean error = false;
                try { answer = requestOpenRouter(userText, historyJson); }
                catch (Exception e) { answer = readableError(e); error = true; }
                final String result = answer;
                final boolean isError = error;
                try {
                    JSONObject payload = new JSONObject(); payload.put("id", id); payload.put("text", result); payload.put("error", isError);
                    String js = "window.onJarvisResponse && window.onJarvisResponse(" + JSONObject.quote(payload.toString()) + ")";
                    mainHandler.post(() -> webView.evaluateJavascript(js, null));
                } catch (Exception ignored) {}
            });
        }
    }

    private String requestOpenRouter(String userText, String historyJson) throws Exception {
        String key = prefs.getString("apiKey", "").trim();
        String model = prefs.getString("model", "openrouter/auto").trim();
        String system = prefs.getString("systemPrompt", "Ты JARVIS — полезный персональный ИИ-помощник. Отвечай ясно и на языке пользователя.");
        String memory = prefs.getString("memory", "").trim();
        if (!memory.isEmpty()) system += "\n\nПамять пользователя (учитывай только если уместно):\n" + memory;
        if (key.isEmpty()) throw new Exception("NO_KEY");
        JSONArray messages = new JSONArray();
        JSONObject sys = new JSONObject(); sys.put("role", "system"); sys.put("content", system); messages.put(sys);
        try {
            JSONArray history = new JSONArray(historyJson == null ? "[]" : historyJson);
            int start = Math.max(0, history.length() - 16);
            for (int i = start; i < history.length(); i++) messages.put(history.getJSONObject(i));
        } catch (Exception ignored) {}
        JSONObject user = new JSONObject(); user.put("role", "user"); user.put("content", userText); messages.put(user);
        JSONObject payload = new JSONObject(); payload.put("model", model); payload.put("messages", messages); payload.put("temperature", 0.7);
        HttpURLConnection conn = (HttpURLConnection) new URL("https://openrouter.ai/api/v1/chat/completions").openConnection();
        conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(60000); conn.setDoOutput(true);
        conn.setRequestProperty("Authorization", "Bearer " + key);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setRequestProperty("HTTP-Referer", "https://localhost");
        conn.setRequestProperty("X-OpenRouter-Title", "JARVIS AI");
        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) { os.write(body); }
        int status = conn.getResponseCode();
        InputStream stream = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder text = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = br.readLine()) != null) text.append(line);
        }
        conn.disconnect();
        JSONObject data = new JSONObject(text.toString());
        if (status < 200 || status >= 300) {
            String msg = data.optJSONObject("error") == null ? "HTTP " + status : data.getJSONObject("error").optString("message", "HTTP " + status);
            throw new Exception("API_" + status + ":" + msg);
        }
        JSONArray choices = data.optJSONArray("choices");
        if (choices == null || choices.length() == 0) throw new Exception("Провайдер не вернул ответ. Попробуй другую модель.");
        return choices.getJSONObject(0).getJSONObject("message").optString("content", "").trim();
    }

    private String readableError(Exception e) {
        String m = e.getMessage() == null ? "" : e.getMessage();
        if (m.equals("NO_KEY")) return "Сначала открой настройки и сохрани API-ключ OpenRouter.";
        if (m.startsWith("API_401") || m.startsWith("API_403")) return "OpenRouter отклонил ключ. Проверь его в настройках.";
        if (m.startsWith("API_402")) return "Для этого запроса недоступен баланс или лимит OpenRouter.";
        if (m.startsWith("API_429")) return "Сработал лимит запросов. Подожди немного и попробуй снова.";
        if (m.startsWith("API_404")) return "Модель не найдена. Проверь ID модели или выбери openrouter/auto.";
        if (m.startsWith("API_")) return "Ошибка OpenRouter: " + m.substring(m.indexOf(':') >= 0 ? m.indexOf(':') + 1 : 4);
        return "Не удалось подключиться. Проверь интернет и настройки OpenRouter. Детали: " + m;
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("window.jarvisBack && window.jarvisBack()", null);
        else super.onBackPressed();
    }
    @Override protected void onDestroy() { if (webView != null) webView.destroy(); executor.shutdownNow(); super.onDestroy(); }
}
