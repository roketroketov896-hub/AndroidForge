# JARVIS AI — Android source project

This is an Android Gradle project (not just a web folder). It wraps a ChatGPT-inspired chat UI in Android WebView and uses a small native Java bridge for OpenRouter requests.

## Build with AndroidForge

Upload the ZIP as the AndroidForge source ZIP and choose `auto` or `debug`. The ZIP is structured with `settings.gradle` and `app/build.gradle` at the project root so project detection should classify it as a Gradle Android app.

## First launch

1. Open JARVIS AI and tap the settings/gear button.
2. Paste your OpenRouter key and save it. The key is stored in this app's local SharedPreferences on the phone; it is not embedded in this ZIP.
3. The default model is `openrouter/auto`. If your account cannot use automatic routing, enter a model ID available to your OpenRouter account.
4. Return to the chat and send a test message.

## Included

- ChatGPT-inspired dark chat interface, mobile sidebar, new chat and suggestion cards.
- OpenRouter API request from native Android code (not browser `fetch`).
- API key and system prompt settings; model defaults to `openrouter/auto`.
- Local chat history saved in WebView storage (up to 40 chats), with reopening previous chats.
- Local editable memory notes included in the system instructions sent to OpenRouter.
- Voice screen with animated orb, browser speech recognition when the Android WebView exposes it, and speech synthesis when available.
- Copy response and per-answer read-aloud button.
- Friendly messages for common API errors.

## Limits to know

- Speech recognition and text-to-speech depend on the Android WebView and installed speech services; the app reports when recognition is unavailable. This is not yet a fully hands-free, always-listening voice assistant.
- Memory is a local editable note, not automatic extraction of facts from every conversation.
- No cloud sync, image generation, WhatsApp/Telegram integration, or Play Store release/signing.

## Security note

The key is stored locally in ordinary app-private SharedPreferences, not encrypted with Android Keystore. Treat this as a personal test build and do not distribute an APK containing your personal key. For a public release, move API requests behind a secured backend.

## Validation status

JavaScript syntax and AndroidManifest XML should be checked after extraction. A full Android/Gradle APK build has not been run in this environment; AndroidForge's build result is still required to verify the APK and device-specific voice support.
