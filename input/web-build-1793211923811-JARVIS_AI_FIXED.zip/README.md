# JARVIS AI — Android project

A native Android shell with a local HTML/CSS/JS interface, an Android Java bridge for OpenRouter, local chat history, text-to-speech, and speech recognition. This is a source ZIP for AndroidForge, not a prebuilt APK.

## Build with AndroidForge

Upload this ZIP as the AndroidForge source ZIP. The project root contains `settings.gradle`, root `build.gradle`, and `app/build.gradle`, so it is structured as a Gradle Android app.

## First launch

1. Open JARVIS AI and tap the gear button.
2. Paste your OpenRouter API key and save. The key is stored in app-private SharedPreferences on the phone and is not included in this ZIP.
3. The default model is `openrouter/auto`. If automatic routing is unavailable to your account, enter a model ID available to you.
4. Return to chat and send a test message. Internet access and an active OpenRouter key/allowance are required.

## Included in this build

- ChatGPT-inspired dark mobile interface and original glowing JARVIS orb emblem.
- Send messages to OpenRouter through native Java networking.
- Local history of chats, loading previous chats, starting a new chat, and deleting a chat.
- Per-answer copy and read-aloud buttons using Android TextToSpeech.
- Voice mode with animated orb, Android speech recognition, and spoken AI response. Android may request microphone permission and may require a speech recognition service.
- API key, model ID, and system-prompt settings.
- Friendly messages for common OpenRouter errors.

## Limits and security

- Chat history is stored locally in WebView storage and is not synced to another device. Clearing app data can erase it.
- The API key is stored in app-private SharedPreferences, not encrypted with Android Keystore. Treat this as a personal test build; do not share an APK that has your personal key configured. A public app should send requests through a secured backend.
- Voice recognition depends on the Android speech service and language packs installed on the phone.
- Telegram/WhatsApp integrations, cloud memory, login/sync, image generation, and public release signing are not included yet.

## Validation

Static checks only: AndroidManifest.xml parsed as XML, app.js passed `node --check`, Java brace balance verified. A Gradle/APK build and a real-device test were NOT run (no Android SDK or network in the editing environment).

## Fixes in this revision

- MainActivity: `startListeningInternal()` was private inside the inner class `JarvisBridge` but called from `onRequestPermissionsResult` of the outer class (compile error "cannot find symbol"). Moved into `MainActivity`.
- MainActivity: null/non-JSON HTTP error bodies from OpenRouter no longer crash the request thread.
- AndroidManifest: added `<queries>` for speech recognition and TTS services (required on Android 11+).
- app.js: voice orb animates while waiting for the reply; API errors in voice mode are shown.
