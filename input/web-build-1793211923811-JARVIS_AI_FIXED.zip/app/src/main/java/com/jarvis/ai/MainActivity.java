package com.jarvis.ai;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.Manifest;
import android.content.pm.PackageManager;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.content.Intent;
import android.os.Build;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean speechReady = false;
    private static final int REQUEST_AUDIO = 701;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("jarvis_settings", MODE_PRIVATE);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF212121);
        getWindow().setStatusBarColor(0xFF212121);
        getWindow().setNavigationBarColor(0xFF171717);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new JarvisBridge(), "JarvisBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        textToSpeech = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) { int result = textToSpeech.setLanguage(new Locale("ru", "RU")); speechReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED; textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() { @Override public void onStart(String utteranceId) { mainHandler.post(() -> webView.evaluateJavascript("window.onJarvisSpeechState && window.onJarvisSpeechState('speaking')", null)); } @Override public void onDone(String utteranceId) { mainHandler.post(() -> webView.evaluateJavascript("window.onJarvisSpeechState && window.onJarvisSpeechState('finished')", null)); } @Override public void onError(String utteranceId) { mainHandler.post(() -> webView.evaluateJavascript("window.onJarvisSpeechState && window.onJarvisSpeechState('error')", null)); } }); } });
    }

    private class JarvisBridge {
        @JavascriptInterface public String getSettings() {
            JSONObject out = new JSONObject();
            try {
                out.put("model", prefs.getString("model", "openrouter/auto"));
                out.put("systemPrompt", prefs.getString("systemPrompt", "Ты JARVIS — полезный персональный ИИ-помощник. Отвечай ясно и на языке пользователя."));
                out.put("hasKey", !prefs.getString("apiKey", "").isEmpty());
            } catch (Exception ignored) {}
            return out.toString();
        }
        @JavascriptInterface public void saveSettings(String key, String model, String systemPrompt) {
            SharedPreferences.Editor editor = prefs.edit();
            if (key != null && !key.trim().isEmpty()) editor.putString("apiKey", key.trim());
            editor.putString("model", (model == null || model.trim().isEmpty()) ? "openrouter/auto" : model.trim())
                    .putString("systemPrompt", (systemPrompt == null || systemPrompt.trim().isEmpty()) ? "Ты JARVIS — полезный персональный ИИ-помощник. Отвечай ясно и на языке пользователя." : systemPrompt.trim())
                    .apply();
            mainHandler.post(() -> webView.evaluateJavascript("window.settingsSaved && window.settingsSaved()", null));
        }
        @JavascriptInterface public void speak(String text) {
            if (textToSpeech != null && speechReady && text != null && !text.trim().isEmpty()) {
                mainHandler.post(() -> { textToSpeech.stop(); textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply"); });
            } else mainHandler.post(() -> webView.evaluateJavascript("window.onJarvisSpeechState && window.onJarvisSpeechState('error')", null));
        }
        @JavascriptInterface public void startListening() {
            mainHandler.post(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
                } else startListeningInternal();
            });
        }
        @JavascriptInterface public void stopListening() {
            mainHandler.post(() -> { if (speechRecognizer != null) { try { speechRecognizer.cancel(); } catch (Exception ignored) {} speechRecognizer.destroy(); speechRecognizer = null; } });
        }
        @JavascriptInterface public void clearApiKey() {
            prefs.edit().remove("apiKey").apply();
            mainHandler.post(() -> webView.evaluateJavascript("window.keyCleared && window.keyCleared()", null));
        }
        @JavascriptInterface public void sendMessage(String id, String userText, String historyJson) {
            executor.execute(() -> {
                String answer;
                boolean error = false;
                try { answer = requestOpenRouter(userText, historyJson); }
                catch (Exception e) { answer = readableError(e); error = true; }
                final String result = answer;
                final boolean isError = error;
                try {
                    JSONObject payload = new JSONObject(); payload.put("id", id); payload.put("text", result); payload.put("error", isError);
                    String js = "window.onJarvisResponse && window.onJarvisResponse(" + JSONObject.quote(payload.toString()) + ")";
                    mainHandler.post(() -> webView.evaluateJavascript(js, null));
                } catch (Exception ignored) {}
            });
        }
    }

    private void startListeningInternal() {
        try {
            if (!SpeechRecognizer.isRecognitionAvailable(MainActivity.this)) {
                webView.evaluateJavascript("window.onJarvisSpeechState && window.onJarvisSpeechState('error')", null); return;
            }
            if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle params) { webView.evaluateJavascript("window.onJarvisSpeechState && window.onJarvisSpeechState('listening')", null); }
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float rmsdB) {}
                public void onBufferReceived(byte[] buffer) {}
                public void onEndOfSpeech() { webView.evaluateJavascript("window.onJarvisSpeechState && window.onJarvisSpeechState('processing')", null); }
                public void onError(int error) { webView.evaluateJavascript("window.onJarvisSpeechState && window.onJarvisSpeechState('error')", null); }
                public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String spoken = (matches == null || matches.isEmpty()) ? "" : matches.get(0);
                    webView.evaluateJavascript("window.onJarvisSpeechResult && window.onJarvisSpeechResult(" + JSONObject.quote(spoken) + ", " + (spoken.isEmpty() ? "'Не удалось распознать речь'" : "null") + ")", null);
                }
                public void onPartialResults(Bundle partialResults) {}
                public void onEvent(int eventType, Bundle params) {}
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ru-RU");
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            speechRecognizer.startListening(intent);
        } catch (Exception e) { webView.evaluateJavascript("window.onJarvisSpeechState && window.onJarvisSpeechState('error')", null); }
    }

    private String requestOpenRouter(String userText, String historyJson) throws Exception {
        String key = prefs.getString("apiKey", "").trim();
        String model = prefs.getString("model", "openrouter/auto").trim();
        String system = prefs.getString("systemPrompt", "Ты JARVIS — полезный персональный ИИ-помощник. Отвечай ясно и на языке пользователя.");
        if (key.isEmpty()) throw new Exception("NO_KEY");
        JSONArray messages = new JSONArray();
        JSONObject sys = new JSONObject(); sys.put("role", "system"); sys.put("content", system); messages.put(sys);
        try {
            JSONArray history = new JSONArray(historyJson == null ? "[]" : historyJson);
            int start = Math.max(0, history.length() - 16);
            for (int i = start; i < history.length(); i++) messages.put(history.getJSONObject(i));
        } catch (Exception ignored) {}
        JSONObject user = new JSONObject(); user.put("role", "user"); user.put("content", userText); messages.put(user);
        JSONObject payload = new JSONObject(); payload.put("model", model); payload.put("messages", messages); payload.put("temperature", 0.7);
        HttpURLConnection conn = (HttpURLConnection) new URL("https://openrouter.ai/api/v1/chat/completions").openConnection();
        conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(60000); conn.setDoOutput(true);
        conn.setRequestProperty("Authorization", "Bearer " + key);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setRequestProperty("HTTP-Referer", "https://localhost");
        conn.setRequestProperty("X-OpenRouter-Title", "JARVIS AI");
        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) { os.write(body); }
        int status = conn.getResponseCode();
        InputStream stream = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
        if (stream == null) throw new Exception("API_" + status + ":HTTP " + status);
        StringBuilder text = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = br.readLine()) != null) text.append(line);
        }
        conn.disconnect();
        JSONObject data;
        try { data = new JSONObject(text.toString()); }
        catch (Exception parseError) {
            if (status < 200 || status >= 300) throw new Exception("API_" + status + ":HTTP " + status);
            throw new Exception("Некорректный ответ сервера.");
        }
        if (status < 200 || status >= 300) {
            String msg = data.optJSONObject("error") == null ? "HTTP " + status : data.getJSONObject("error").optString("message", "HTTP " + status);
            throw new Exception("API_" + status + ":" + msg);
        }
        JSONArray choices = data.optJSONArray("choices");
        if (choices == null || choices.length() == 0) throw new Exception("Провайдер не вернул ответ. Попробуй другую модель.");
        return choices.getJSONObject(0).getJSONObject("message").optString("content", "").trim();
    }

    private String readableError(Exception e) {
        String m = e.getMessage() == null ? "" : e.getMessage();
        if (m.equals("NO_KEY")) return "Сначала открой настройки и сохрани API-ключ OpenRouter.";
        if (m.startsWith("API_401") || m.startsWith("API_403")) return "OpenRouter отклонил ключ. Проверь его в настройках.";
        if (m.startsWith("API_402")) return "Для этого запроса недоступен баланс или лимит OpenRouter.";
        if (m.startsWith("API_429")) return "Сработал лимит запросов. Подожди немного и попробуй снова.";
        if (m.startsWith("API_404")) return "Модель не найдена. Проверь ID модели или выбери openrouter/auto.";
        if (m.startsWith("API_")) return "Ошибка OpenRouter: " + m.substring(m.indexOf(':') >= 0 ? m.indexOf(':') + 1 : 4);
        return "Не удалось подключиться. Проверь интернет и настройки OpenRouter. Детали: " + m;
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("window.jarvisBack && window.jarvisBack()", null);
        else super.onBackPressed();
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mainHandler.postDelayed(() -> startListeningInternal(), 200);
            } else if (webView != null) {
                webView.evaluateJavascript("window.onJarvisSpeechState && window.onJarvisSpeechState('error')", null);
            }
        }
    }
    @Override protected void onDestroy() { if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; } if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); } if (webView != null) webView.destroy(); executor.shutdownNow(); super.onDestroy(); }
}
