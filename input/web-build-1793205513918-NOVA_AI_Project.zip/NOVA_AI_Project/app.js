const $ = (s) => document.querySelector(s);
const promptBox = $("#prompt"), messages = $("#messages"), welcome = $("#welcome"), toast = $("#toast");
let lastAssistantText = "";
let toastTimer;
function notify(text) {
  toast.textContent = text; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove("show"), 2300);
}
function addMessage(text, who) {
  welcome.style.display = "none";
  const wrap = document.createElement("div");
  wrap.className = `message ${who}`;
  const avatar = document.createElement("div");
  avatar.className = "message-avatar"; avatar.textContent = who === "user" ? "Я" : "✦";
  const body = document.createElement("div");
  const bubble = document.createElement("div"); bubble.className = "bubble"; bubble.textContent = text;
  body.appendChild(bubble);
  if (who === "assistant") {
    const tools = document.createElement("div"); tools.className = "message-tools";
    const copy = document.createElement("button"); copy.className = "mini-btn"; copy.textContent = "Копировать";
    copy.addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(text); notify("Ответ скопирован"); }
      catch { notify("Не удалось скопировать в этом браузере"); }
    });
    const speak = document.createElement("button"); speak.className = "mini-btn"; speak.textContent = "🔊 Озвучить";
    speak.addEventListener("click", () => speakText(text)); tools.append(copy, speak); body.appendChild(tools);
  }
  wrap.append(avatar, body); messages.appendChild(wrap);
  wrap.scrollIntoView({behavior:"smooth", block:"nearest"});
}
function demoReply(userText) {
  const q = userText.toLowerCase();
  if (/привет|здравствуй|салам|hello|hi\b/.test(q)) return "Привет! Я NOVA — твой AI-помощник. Сейчас я работаю в демо-режиме. Когда подключим API настоящей модели, здесь появятся полноценные ответы.";
  if (/идея|проект/.test(q)) return "Давай начнём с цели проекта. В рабочей версии я смогу помогать исследовать варианты, составлять план и дорабатывать идеи. Сейчас это демонстрационный ответ — настоящая AI-модель ещё не подключена.";
  if (/план/.test(q)) return "Для начала запиши цель, затем разбей её на небольшие задачи, расставь приоритеты и отмечай прогресс. Это пример демо-ответа; после подключения модели NOVA сможет составлять план под твой запрос.";
  if (/спасибо/.test(q)) return "Всегда пожалуйста! Это пока демонстрация интерфейса NOVA. Подключение настоящего ИИ сделаем отдельным этапом.";
  return "Сообщение принято! ✦\n\nСейчас NOVA — только визуальный прототип, поэтому этот ответ демонстрационный. Следующий этап — безопасно подключить API настоящей AI-модели, а затем интеграции Telegram и WhatsApp.";
}
function sendMessage(text) {
  const clean = text.trim(); if (!clean) return;
  addMessage(clean, "user"); promptBox.value = ""; resizeInput();
  setTimeout(() => { lastAssistantText = demoReply(clean); addMessage(lastAssistantText, "assistant"); }, 350);
}
function resizeInput(){ promptBox.style.height="auto"; promptBox.style.height=Math.min(promptBox.scrollHeight,140)+"px"; }
$("#chatForm").addEventListener("submit", e => { e.preventDefault(); sendMessage(promptBox.value); });
promptBox.addEventListener("input", resizeInput);
promptBox.addEventListener("keydown", e => { if(e.key==="Enter" && !e.shiftKey && window.innerWidth>600){e.preventDefault();$("#chatForm").requestSubmit();} });
document.querySelectorAll(".suggestion").forEach(b => b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));
function newChat(){messages.innerHTML="";welcome.style.display="";lastAssistantText="";promptBox.value="";resizeInput();closeMenu();}
$("#newChat").addEventListener("click",newChat);
function speakText(text){
  if(!("speechSynthesis" in window)){notify("Озвучивание не поддерживается этим браузером");return;}
  window.speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(text);utterance.lang="ru-RU";utterance.rate=1;window.speechSynthesis.speak(utterance);notify("Озвучивание запущено");
}
$("#voiceBtn").addEventListener("click",()=>{if(lastAssistantText)speakText(lastAssistantText);else notify("Сначала отправь сообщение");});
$("#themeBtn").addEventListener("click",()=>{document.body.classList.toggle("light");notify(document.body.classList.contains("light")?"Светлая тема":"Тёмная тема");});
const sidebar=$("#sidebar"),scrim=$("#scrim");
function openMenu(){sidebar.classList.add("open");scrim.classList.add("show");}
function closeMenu(){sidebar.classList.remove("open");scrim.classList.remove("show");}
$("#menuBtn").addEventListener("click",openMenu);$("#closeSidebar").addEventListener("click",closeMenu);scrim.addEventListener("click",closeMenu);
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>{
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("active"));b.classList.add("active");closeMenu();
  if(b.dataset.page==="chat"){notify("Открыт чат");return;}
  if(b.dataset.page==="library")notify("Библиотека появится в следующей версии");
  if(b.dataset.page==="tools")notify("Инструменты появятся в следующей версии");
}));
