# Как включить облако JARVIS 3.4 (3 минуты, без командной строки)

База D1 уже подготовлена: таблицы `jobs`, `files`, `usage_daily` созданы в `jarvis-db`.

1. Cloudflare → Workers & Pages → `jarvis-backend` → Edit code.
2. Выделите весь код, удалите и вставьте содержимое файла `cloud/worker.js` из архива. Нажмите Deploy.
3. Привязки (Bindings), секреты и переменные менять не нужно: `DB`, `OPENROUTER_API_KEY`, `FISH_AUDIO_API_KEY`, `GOOGLE_CLIENT_ID`, `PROVIDER_ENCRYPTION_KEY` остаются как были.
4. Проверка: откройте `https://<ваш-воркер>.workers.dev/health`: в ответе должно быть `"cloud":true` и `"version":"3.4.0-cloudflare"`.
5. ВАЖНО: переменная `GOOGLE_CLIENT_ID` в Worker должна совпадать с `JARVIS_WEB_CLIENT_ID` в `jarvis-config.properties` приложения. Если в Worker она не задана, он принимает только старый встроенный ID (…fqqck3g5…), а приложение использует (…ncjrjddrh0…): вход тогда будет отклонён. Проверьте это в Settings → Variables.

Лимиты по умолчанию (меняются строкой `cloudLimits` в таблице `config`, JSON вида `{"free":{"image":5},"pro":{"image":50}}`): Free: 3 изображения, 20 файлов в день, 20 МБ, хранение 7 дней. Pro: 30, 200, 100 МБ, 30 дней.

Не включено (нужны R2 или Queues, их нельзя включить без вашего действия в панели): файлы больше 1,5 МБ, PDF, PPTX, конвертация, настоящие очереди. Пока задачи идут фоном без Queues, клиент опрашивает статус.
