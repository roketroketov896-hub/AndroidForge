import { DatabaseSync } from 'node:sqlite';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import worker from '../worker.js';

const db = new DatabaseSync(':memory:');
db.exec(`CREATE TABLE users(sub TEXT PRIMARY KEY,email TEXT,started_at INTEGER,last_seen INTEGER,plan TEXT DEFAULT 'free',plan_until INTEGER,blocked INTEGER DEFAULT 0,daily_limit INTEGER,day_key TEXT,count INTEGER DEFAULT 0,total INTEGER DEFAULT 0,tts_day TEXT,tts_chars INTEGER DEFAULT 0);
CREATE TABLE config(key TEXT PRIMARY KEY,value TEXT);CREATE TABLE event_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,ts INTEGER,level TEXT,type TEXT,message TEXT,extra TEXT);CREATE TABLE histories(sub TEXT PRIMARY KEY,data TEXT,updated_at INTEGER);
CREATE TABLE ai_providers(id TEXT PRIMARY KEY,name TEXT,base_url TEXT,model TEXT);CREATE TABLE ai_provider_secrets(provider_id TEXT PRIMARY KEY,iv TEXT,ciphertext TEXT);CREATE TABLE ai_provider_routing(id INTEGER PRIMARY KEY,free_provider_id TEXT,pro_provider_id TEXT,legacy_visible INTEGER);
CREATE TABLE jobs (id TEXT PRIMARY KEY, sub TEXT NOT NULL, type TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('queued','running','completed','failed','cancelled')), input TEXT NOT NULL DEFAULT '{}', result TEXT, error TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, finished_at INTEGER);
CREATE TABLE files (id TEXT PRIMARY KEY, sub TEXT NOT NULL, name TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, storage TEXT NOT NULL DEFAULT 'd1' CHECK(storage IN ('d1','r2')), r2_key TEXT, data TEXT, version INTEGER NOT NULL DEFAULT 1, job_id TEXT, created_at INTEGER NOT NULL, expires_at INTEGER);
CREATE TABLE usage_daily (sub TEXT NOT NULL, day TEXT NOT NULL, kind TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (sub, day, kind));`);
const mk = (sql) => { const st = db.prepare(sql); let args = []; const o = {
  bind: (...a) => { args = a; return o; },
  first: async () => st.get(...args) || null,
  all: async () => ({ results: st.all(...args) }),
  run: async () => { const r = st.run(...args); return { meta: { changes: Number(r.changes) }, success: true }; } }; return o; };
const env = { DB: { prepare: mk, batch: async (l) => { const out = []; for (const s of l) out.push(await s.run()); return out; } }, GOOGLE_CLIENT_ID: 'cid', OPENROUTER_API_KEY: 'test-key' };
const tokens = { A: { sub: 'ua', email: 'a@x.com' }, B: { sub: 'ub', email: 'b@x.com' } };
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');
let imageCalls = 0;
globalThis.fetch = async (u, init) => {
  u = String(u);
  if (u.startsWith('https://oauth2.googleapis.com/tokeninfo')) { const t = tokens[new URL(u).searchParams.get('id_token')]; if (!t) return new Response('{}', { status: 400 }); return new Response(JSON.stringify({ aud: 'cid', exp: String(Math.floor(Date.now() / 1000) + 3600), iss: 'accounts.google.com', email_verified: 'true', ...t })); }
  if (u.includes('/chat/completions')) { imageCalls++; return new Response(JSON.stringify({ choices: [{ message: { images: [{ image_url: { url: 'data:image/png;base64,' + PNG.toString('base64') } }] } }] })); }
  throw new Error('unexpected fetch ' + u);
};
const bg = []; const ctx = { waitUntil: (p) => bg.push(p) };
const call = async (method, path, tok, body) => { const r = await worker.fetch(new Request('https://w.test' + path, { method, headers: { ...(tok ? { authorization: 'Bearer ' + tok } : {}), 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined }), env, ctx); const text = await r.text(); let j = null; try { j = JSON.parse(text); } catch {} return { status: r.status, json: j, text }; };
let n = 0; const ok = (m) => { n++; console.log('  ✓', m); };

assert.equal((await call('GET', '/health')).json.cloud, true); ok('health');
assert.equal((await call('GET', '/v1/cloud/status')).status, 401); ok('без входа Google доступа нет');
let r = await call('GET', '/v1/cloud/status', 'A'); assert.equal(r.status, 200); assert.equal(r.json.limits.image, 3); assert.ok(r.json.notSupported.includes('pdf')); ok('статус: лимиты и честный список неподдерживаемых форматов');
const files = {};
for (const [name, body] of [['report.docx', { content: '# Отчёт\nПривет, мир — тест кириллицы' }], ['data.xlsx', { rows: [['Имя', 'Сумма'], ['Анна', 12.5]] }], ['notes.txt', { content: 'hello' }], ['pack.zip', { files: [{ name: 'src/a.py', content: 'print(1)' }, { name: 'README.md', content: '# hi' }] }], ['doc.rtf', { content: 'Привет' }]]) {
  r = await call('POST', '/v1/cloud/files', 'A', { name, ...body }); assert.equal(r.status, 201, name + ' ' + r.text); files[name] = r.json.file;
}
ok('создание docx, xlsx, txt, zip, rtf');
fs.mkdirSync('/tmp/cf', { recursive: true });
for (const name of ['report.docx', 'data.xlsx', 'pack.zip']) { r = await call('GET', '/v1/cloud/files/' + files[name].id + '?encoding=base64', 'A'); assert.equal(r.json.size, files[name].size); fs.writeFileSync('/tmp/cf/' + name, Buffer.from(r.json.data, 'base64')); }
ok('скачивание base64 совпадает по размеру');
const raw = await worker.fetch(new Request('https://w.test/v1/cloud/files/' + files['notes.txt'].id, { headers: { authorization: 'Bearer A' } }), env, ctx); assert.equal(await raw.text(), 'hello'); assert.match(raw.headers.get('content-disposition'), /attachment/); ok('бинарная загрузка с attachment');
assert.equal((await call('GET', '/v1/cloud/files/' + files['notes.txt'].id, 'B')).status, 404); ok('чужие файлы недоступны');
assert.equal((await call('POST', '/v1/cloud/files', 'A', { name: 'evil.apk', content: 'x' })).status, 400); assert.equal((await call('POST', '/v1/cloud/files', 'A', { name: 'a.zip', files: [{ name: 'x.exe', content: 'x' }] })).status, 400); assert.equal((await call('POST', '/v1/cloud/files', 'A', { name: 'a.pdf', content: 'x' })).status, 400); ok('исполняемые файлы и неподдерживаемые форматы отклоняются');
r = await call('POST', '/v1/cloud/files', 'A', { name: '../../etc/passwd.txt', content: 'x' }); assert.equal(r.json.file.name, 'passwd.txt'); ok('путь в имени файла обезвреживается');
// квоты
for (let i = 0; i < 20; i++) await call('POST', '/v1/cloud/files', 'B', { name: 'q' + i + '.txt', content: 'x' });
assert.equal((await call('POST', '/v1/cloud/files', 'B', { name: 'over.txt', content: 'x' })).status, 429); ok('серверный дневной лимит файлов (20 для Free)');
assert.equal((await call('POST', '/v1/cloud/files', 'A', { name: 'big.txt', content: 'x'.repeat(1_600_000) })).status, 413); ok('файл больше лимита D1 отклоняется с понятной причиной');
// изображения
r = await call('POST', '/v1/cloud/jobs', 'A', { type: 'image', prompt: 'красный куб на белом фоне' }); assert.equal(r.status, 202); assert.equal(r.json.job.status, 'queued'); const jid = r.json.job.id;
await Promise.all(bg); r = await call('GET', '/v1/cloud/jobs/' + jid, 'A'); assert.equal(r.json.job.status, 'completed'); assert.ok(r.json.job.result.fileId); ok('задача изображения: queued → completed');
r = await call('GET', '/v1/cloud/files/' + r.json.job.result.fileId + '?encoding=base64', 'A'); assert.deepEqual(Buffer.from(r.json.data, 'base64'), PNG); ok('результат — настоящий PNG, байты совпадают');
assert.equal((await call('GET', '/v1/cloud/jobs/' + jid, 'B')).status, 404); ok('чужая задача недоступна');
assert.equal((await call('POST', '/v1/cloud/jobs', 'A', { type: 'image', prompt: 'nude child' })).status, 400); ok('опасный запрос на изображение отклонён до вызова провайдера');
const before = imageCalls; for (let i = 0; i < 3; i++) { await call('POST', '/v1/cloud/jobs', 'A', { type: 'image', prompt: 'картинка ' + i }); await Promise.all(bg); }
r = await call('POST', '/v1/cloud/jobs', 'A', { type: 'image', prompt: 'ещё одна картинка' }); assert.equal(r.status, 429); assert.equal(r.json.error.code, 'image_limit'); ok('лимит изображений 3/день для Free');
// отмена и сбой с возвратом квоты
const envKey = env.OPENROUTER_API_KEY; env.OPENROUTER_API_KEY = ''; r = await call('POST', '/v1/cloud/jobs', 'B', { type: 'image', prompt: 'тест без ключа' }); await Promise.all(bg); r = await call('GET', '/v1/cloud/jobs/' + r.json.job.id, 'B'); assert.equal(r.json.job.status, 'failed'); assert.match(r.json.job.error, /ключ/); env.OPENROUTER_API_KEY = envKey;
r = await call('GET', '/v1/cloud/status', 'B'); assert.equal(r.json.usedToday.image, 0); ok('при сбое задача failed с причиной, квота возвращается');
db.prepare("UPDATE users SET blocked=1 WHERE sub='ub'").run(); assert.equal((await call('GET', '/v1/cloud/status', 'B')).status, 403); ok('заблокированный пользователь не получает доступ');
db.prepare("UPDATE users SET plan='pro' WHERE sub='ua'").run(); assert.equal((await call('GET', '/v1/cloud/status', 'A')).json.limits.image, 30); ok('Pro-лимиты применяются сервером');
assert.equal((await call('DELETE', '/v1/cloud/files/' + files['notes.txt'].id, 'A')).json.ok, true); ok('удаление файла');
assert.equal((await call('GET', '/v1/status', 'A')).status, 200); assert.equal((await call('GET', '/v1/history', 'A')).status, 200); ok('прежние эндпоинты /v1/status и /v1/history работают');
console.log('\nПройдено: ' + n);
