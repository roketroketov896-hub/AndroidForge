const VERSION = '3.4.0-cloudflare';
const DEFAULTS = {
  freeModel: 'openrouter/auto', proModel: 'openrouter/auto', unlimitedDays: 15,
  dailyLimit: 5, proDailyLimit: 200, maxTokens: 1500, systemPrompt: '',
  announcement: '', maintenance: false, temperature: null, topP: null,
  ttsEnabled: true, ttsFreeChars: 6000, ttsProChars: 60000, voiceRate: 0,
  features: { gmail: true, screenShare: true, onlineTts: false },
  voices: { ru: 'ru-RU-DmitryNeural', az: 'az-AZ-BabekNeural', tr: 'tr-TR-AhmetNeural', en: 'en-US-GuyNeural' }
};
const json = (data, status=200, headers={}) => new Response(JSON.stringify(data), {status, headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store',...headers}});
const err = (status, code, message, extra={}) => json({error:{code,message},...extra}, status);
const now = () => Date.now();
const dayKey = t => new Date(t).toISOString().slice(0,10);
const adminEmails = env => String(env.ADMIN_EMAILS || 'fazercell19@gmail.com').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
const tokenFrom = req => (req.headers.get('authorization')||'').match(/^Bearer\s+(.+)$/i)?.[1] || '';
async function verifyGoogle(token, env) {
  if (!token) return null;
  try {
    const r = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token='+encodeURIComponent(token));
    if (!r.ok) return null;
    const p = await r.json();
    const t = Math.floor(Date.now()/1000);
    if (p.aud !== (env.GOOGLE_CLIENT_ID || '457753025568-fqqck3g5r8ka5kjjri012mtgi1ecuhg2.apps.googleusercontent.com')) return null;
    if (!Number(p.exp) || Number(p.exp) <= t) return null;
    if (!['accounts.google.com','https://accounts.google.com'].includes(p.iss)) return null;
    if (!(p.email_verified === true || p.email_verified === 'true')) return null;
    if (!p.sub || !p.email) return null;
    return {sub:String(p.sub),email:String(p.email).toLowerCase(),emailVerified:true};
  } catch { return null; }
}
async function readJson(req, max=1024*1024) {
  const raw = await req.text();
  if (raw.length > max) throw new Error('too_large');
  try { return raw ? JSON.parse(raw) : {}; } catch { throw new Error('bad_json'); }
}
async function getConfig(env) {
  const rows = await env.DB.prepare('SELECT key,value FROM config').all();
  const c = {...DEFAULTS};
  for (const r of (rows.results||[])) { try { c[r.key]=JSON.parse(r.value); } catch {} }
  return c;
}
async function setConfig(env, obj) {
  const allowed = ['freeModel','proModel','unlimitedDays','dailyLimit','proDailyLimit','maxTokens','systemPrompt','announcement','maintenance','temperature','topP','ttsEnabled','ttsFreeChars','ttsProChars','voiceRate','features','voices'];
  const stmts=[];
  for (const k of allowed) if (Object.prototype.hasOwnProperty.call(obj,k)) {
    let v=obj[k];
    if (['freeModel','proModel'].includes(k) && (typeof v!=='string'||v.length>120)) throw new Error('Некорректное значение: '+k);
    if (k==='systemPrompt' && (typeof v!=='string'||v.length>8000)) throw new Error('Некорректное значение: '+k);
    if (k==='announcement' && (typeof v!=='string'||v.length>500)) throw new Error('Некорректное значение: '+k);
    if (['maintenance','ttsEnabled'].includes(k) && typeof v!=='boolean') throw new Error('Некорректное значение: '+k);
    if (['unlimitedDays','dailyLimit','proDailyLimit','maxTokens','ttsFreeChars','ttsProChars'].includes(k)) {v=Number(v);if(!Number.isInteger(v)||v<0||v>10000000)throw new Error('Некорректное значение: '+k);}
    if (['temperature','topP','voiceRate'].includes(k) && v!==null) {v=Number(v);if(!Number.isFinite(v))throw new Error('Некорректное значение: '+k);}
    stmts.push(env.DB.prepare('INSERT INTO config(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k,JSON.stringify(v)));
  }
  if (obj.features && typeof obj.features==='object') {
    const old=(await getConfig(env)).features||{}; const next={...old};
    for (const k of ['gmail','screenShare','onlineTts']) if(typeof obj.features[k]==='boolean') next[k]=obj.features[k];
    stmts.push(env.DB.prepare('INSERT INTO config(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind('features',JSON.stringify(next)));
  }
  if (obj.voices && typeof obj.voices==='object') {
    const old=(await getConfig(env)).voices||{}; const next={...old};
    for (const k of ['ru','az','tr','en']) if(typeof obj.voices[k]==='string' && /^[A-Za-z0-9-]{3,60}$/.test(obj.voices[k])) next[k]=obj.voices[k];
    stmts.push(env.DB.prepare('INSERT INTO config(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind('voices',JSON.stringify(next)));
  }
  if (stmts.length) await env.DB.batch(stmts);
}
async function getUser(env,u) {
  const t=now();
  await env.DB.prepare(`INSERT INTO users(sub,email,started_at,last_seen) VALUES(?,?,?,?) ON CONFLICT(sub) DO UPDATE SET email=excluded.email,last_seen=excluded.last_seen`).bind(u.sub,u.email,t,t).run();
  return await env.DB.prepare('SELECT * FROM users WHERE sub=?').bind(u.sub).first();
}
function activePlan(u,t) { return u.plan==='pro' && (!u.plan_until || u.plan_until>t) ? 'pro':'free'; }
function status(u,c,t) {
  const used=u.day_key===dayKey(t)?u.count:0;
  if (u.blocked) return {allowed:false,phase:'blocked',plan:activePlan(u,t),usedToday:used,dailyLimit:0,remainingToday:0};
  if (activePlan(u,t)==='pro') { const lim=u.daily_limit==null?c.proDailyLimit:u.daily_limit; return {allowed:used<lim,phase:'pro',plan:'pro',planUntil:u.plan_until||null,dailyLimit:lim,usedToday:used,remainingToday:Math.max(0,lim-used),resetAt:Date.UTC(new Date(t).getUTCFullYear(),new Date(t).getUTCMonth(),new Date(t).getUTCDate()+1)}; }
  const lim=u.daily_limit==null?c.dailyLimit:u.daily_limit, until=u.started_at+c.unlimitedDays*86400000;
  if(t<until) return {allowed:true,phase:'unlimited',plan:'free',unlimitedUntil:until,daysLeft:Math.ceil((until-t)/86400000),dailyLimit:lim,usedToday:used};
  return {allowed:used<lim,phase:'limited',plan:'free',unlimitedUntil:until,daysLeft:0,dailyLimit:lim,usedToday:used,remainingToday:Math.max(0,lim-used),resetAt:Date.UTC(new Date(t).getUTCFullYear(),new Date(t).getUTCMonth(),new Date(t).getUTCDate()+1)};
}
const REVOKED_FISH_KEY_HASH='b30cc40272d50d1b014b9945d36e2f5d9c963a49937a1d0610305ea57e639f12';
async function fishKeyAvailable(env){const k=env.FISH_AUDIO_API_KEY;if(typeof k!=='string'||k.length<20)return false;const d=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(k));const h=Array.from(new Uint8Array(d),x=>x.toString(16).padStart(2,'0')).join('');return h!==REVOKED_FISH_KEY_HASH;}
async function log(env,level,type,message,extra={}) { try { await env.DB.prepare('INSERT INTO event_logs(ts,level,type,message,extra) VALUES(?,?,?,?,?)').bind(now(),level,type,String(message).slice(0,300),JSON.stringify(extra)).run(); } catch {} }
function pubUser(u,c,t,hasHistory=false) { return {sub:u.sub,email:u.email,plan:activePlan(u,t),planUntil:u.plan_until||null,blocked:!!u.blocked,dailyLimitOverride:u.daily_limit==null?null:u.daily_limit,startedAt:u.started_at,lastSeen:u.last_seen,total:u.total,ttsCharsToday:u.tts_day===dayKey(t)?u.tts_chars:0,hasHistory,status:status(u,c,t)}; }
async function requireAdmin(req,env) { const u=await verifyGoogle(tokenFrom(req),env); if(!u) return {error:err(401,'auth_required','Нужен действительный вход через Google.')}; if(!adminEmails(env).includes(u.email)) return {error:err(403,'forbidden','Этот Google-аккаунт не является администратором.')}; return {user:u}; }

const LEGACY_ID = 'legacy-openrouter';
const LEGACY_BASE = 'https://openrouter.ai/api/v1';
const MASKED_KEY = '••••';
const encoder = new TextEncoder();
function b64(bytes) { return btoa(String.fromCharCode(...new Uint8Array(bytes))); }
function fromB64(text) {
  const raw = atob(text);
  return Uint8Array.from(raw, ch => ch.charCodeAt(0));
}
async function encryptionKey(env) {
  const s = env.PROVIDER_ENCRYPTION_KEY;
  if (typeof s !== 'string') return null;
  let raw;
  try {
    if (/^[0-9a-fA-F]{64}$/.test(s)) raw = Uint8Array.from(s.match(/../g), x => parseInt(x, 16));
    else if (/^[A-Za-z0-9+/]{43}=$/.test(s)) raw = fromB64(s);
    else return null;
    if (raw.length !== 32) return null;
    return await crypto.subtle.importKey('raw', raw, {name:'AES-GCM'}, false, ['encrypt','decrypt']);
  } catch { return null; }
}
async function sealSecret(key, id, secret) {
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:encoder.encode('jarvis-provider:v1:'+id)},key,encoder.encode(secret));
  return {iv:b64(iv),ciphertext:b64(ciphertext)};
}
async function openSecret(env, id, row) {
  const key=await encryptionKey(env);
  if(!key) throw new Error('provider_encryption_unavailable');
  try {
    const bytes=await crypto.subtle.decrypt({name:'AES-GCM',iv:fromB64(row.iv),additionalData:encoder.encode('jarvis-provider:v1:'+id)},key,fromB64(row.ciphertext));
    return new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  } catch { throw new Error('provider_decryption_failed'); }
}
function safeBaseUrl(value) {
  if(typeof value!=='string'||value.length>512||value!==value.trim()||!/^https:\/\/[A-Za-z0-9.-]+(?::443)?(?:\/[A-Za-z0-9/-]*)?$/.test(value)) throw new Error('Укажите HTTPS baseUrl без учётных данных, запроса и фрагмента.');
  let url; try { url=new URL(value); } catch { throw new Error('Некорректный baseUrl.'); }
  const h=url.hostname.toLowerCase();
  if(!publicHostname(h)) throw new Error('Локальные, внутренние и IP-адреса запрещены.');
  const path=url.pathname.replace(/\/+$/,'');
  const prefixes=new Set(['','/v1','/v2','/v3','/v4','/v1beta','/api','/api/v1','/api/v2','/api/v3','/api/v4','/openai','/openai/v1','/openai/v2','/v1beta/openai','/compatible-mode/v1','/inference/v1','/api/inference/v1','/v1/openai','/v2/openai','/api/openai/v1','/api/v1/openai','/api/paas/v4']);
  if(!prefixes.has(path)) throw new Error('Недопустимый путь baseUrl; используйте стандартный префикс API без токенов.');
  return 'https://'+h+path;
}
function publicHostname(h) {
  return typeof h==='string'&&h.length<=253&&!h.endsWith('.')&&h.includes('.')&&h.split('.').every(x=>/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(x))&&!/^\d+\.\d+\.\d+\.\d+$/.test(h)&&!/^\d+$/.test(h.split('.').at(-1))&&!/(^|\.)(localhost|local|localdomain|internal|intranet|home|lan|test|invalid|example|onion|arpa)$/.test(h);
}
function publicIPv4(s) {
  if(typeof s!=='string')return false;
  const parts=s.split('.');
  if(parts.length!==4||parts.some(x=>!/^\d{1,3}$/.test(x)||String(Number(x))!==x||Number(x)>255))return false;
  const [a,b,c]=parts.map(Number);
  if(a===0||a===10||a===127||a>=224||a===100&&b>=64&&b<=127||a===169&&b===254||a===172&&b>=16&&b<=31||a===192&&b===168||a===192&&b===0&&c===0||a===192&&b===0&&c===2||a===192&&b===88&&c===99||a===198&&(b===18||b===19)||a===198&&b===51&&c===100||a===203&&b===0&&c===113)return false;
  return true;
}
function publicIPv6(s) {
  if(typeof s!=='string'||!s.includes(':')||s.includes('.')||s.includes('%')||!/^[0-9a-f:]+$/i.test(s))return false;
  const halves=s.toLowerCase().split('::'); if(halves.length>2)return false;
  const left=halves[0]?halves[0].split(':'):[],right=halves.length===2&&halves[1]?halves[1].split(':'):[];
  if([...left,...right].some(x=>!/^[0-9a-f]{1,4}$/.test(x)))return false;
  const missing=8-left.length-right.length;
  if(halves.length===1&&missing!==0||halves.length===2&&missing<1)return false;
  const p=[...left,...Array(missing).fill('0'),...right].map(x=>parseInt(x,16));
  if((p[0]&0xe000)!==0x2000||p[0]===0x2001&&((p[1]&0xfe00)===0||p[1]===0x0db8)||p[0]===0x2002||p[0]===0x3fff&&(p[1]&0xf000)===0)return false;
  return true;
}
async function assertPublicDns(baseUrl) {
  const host=new URL(baseUrl).hostname;
  let answers;
  try {
    answers=await Promise.all(['A','AAAA'].map(async type=>{
      const q='https://cloudflare-dns.com/dns-query?name='+encodeURIComponent(host)+'&type='+type;
      const r=await fetch(q,{headers:{Accept:'application/dns-json'},redirect:'manual',signal:AbortSignal.timeout(8000)});
      if(!r.ok)throw new Error('dns'); const j=await r.json();
      if(!j||typeof j!=='object'||j.Status!==0||j.TC!==undefined&&j.TC!==false||j.Answer!==undefined&&!Array.isArray(j.Answer))throw new Error('dns');
      return {type,records:j.Answer||[]};
    }));
  } catch { throw new Error('Не удалось безопасно проверить DNS провайдера.'); }
  let count=0;
  for(const {type,records} of answers) for(const a of records) {
    if(!a||typeof a!=='object')throw new Error('Некорректный ответ DNS провайдера.');
    if(a.type===5){
      const target=typeof a.data==='string'?a.data.toLowerCase().replace(/\.$/,''):'';
      if(!publicHostname(target))throw new Error('DNS провайдера содержит запрещённое имя.');
    } else if(a.type===1&&type==='A'){
      count++;if(!publicIPv4(a.data))throw new Error('DNS провайдера содержит запрещённый адрес.');
    } else if(a.type===28&&type==='AAAA'){
      count++;if(!publicIPv6(a.data))throw new Error('DNS провайдера содержит запрещённый адрес.');
    } else throw new Error('Некорректный ответ DNS провайдера.');
  }
  if(!count)throw new Error('DNS провайдера не содержит публичных адресов.');
}
function validateMetadata(b, env, legacy=false) {
  if(!b||typeof b!=='object'||Array.isArray(b))throw new Error('Некорректные данные провайдера.');
  if(typeof b.name!=='string'||!b.name.trim()||b.name.length>100||/[\x00-\x1f\x7f]/.test(b.name))throw new Error('Некорректное имя провайдера.');
  if(typeof b.model!=='string'||!b.model||b.model.length>120||!/^[A-Za-z0-9._:/-]+$/.test(b.model))throw new Error('Некорректная модель.');
  if(b.apiKey!==undefined&&(typeof b.apiKey!=='string'||b.apiKey.length>4096||/[\x00-\x1f\x7f]/.test(b.apiKey)||(/\s/.test(b.apiKey)&&b.apiKey.trim()!=='')))throw new Error('Некорректный API-ключ.');
  const apiKey=typeof b.apiKey==='string'?b.apiKey.trim():'';
  if(apiKey&&(b.name.includes(apiKey)||b.model.includes(apiKey)||String(b.baseUrl).includes(apiKey)))throw new Error('API-ключ должен находиться только в поле apiKey.');
  const baseUrl=legacy?(b.baseUrl===LEGACY_BASE?LEGACY_BASE:null):safeBaseUrl(b.baseUrl);
  if(!baseUrl)throw new Error('Адрес встроенного OpenRouter нельзя изменить.');
  return {name:b.name.trim(),model:b.model,baseUrl,apiKey};
}
async function providerRouting(env) {
  return await env.DB.prepare('SELECT free_provider_id,pro_provider_id,legacy_visible FROM ai_provider_routing WHERE id=1').first() || {free_provider_id:LEGACY_ID,pro_provider_id:LEGACY_ID,legacy_visible:1};
}
async function providerRecord(env,id,c) {
  if(id===LEGACY_ID){
    const [meta,secret]=await Promise.all([
      env.DB.prepare('SELECT name FROM ai_providers WHERE id=?').bind(id).first(),
      env.DB.prepare('SELECT iv,ciphertext FROM ai_provider_secrets WHERE provider_id=?').bind(id).first()
    ]);
    return {id,name:meta?.name||'OpenRouter (legacy)',baseUrl:LEGACY_BASE,model:c.freeModel,hasKey:!!secret||!!env.OPENROUTER_API_KEY,keyHint:secret||env.OPENROUTER_API_KEY?MASKED_KEY:'',legacy:true,secret};
  }
  const r=await env.DB.prepare('SELECT p.id,p.name,p.base_url,p.model,s.iv,s.ciphertext FROM ai_providers p LEFT JOIN ai_provider_secrets s ON s.provider_id=p.id WHERE p.id=?').bind(id).first();
  if(!r)return null;
  return {id:r.id,name:r.name,baseUrl:r.base_url,model:r.model,hasKey:!!r.ciphertext,keyHint:r.ciphertext?MASKED_KEY:'',legacy:false,secret:r.ciphertext?{iv:r.iv,ciphertext:r.ciphertext}:null};
}
function publicProvider(p) { const {secret,...safe}=p; return safe; }
async function providerCredential(env,p) {
  if(p.secret)return await openSecret(env,p.id,p.secret);
  if(p.legacy&&env.OPENROUTER_API_KEY)return env.OPENROUTER_API_KEY;
  throw new Error('provider_key_missing');
}
function encryptionRequired(){return err(503,'encryption_not_configured','Для управления провайдерами настройте PROVIDER_ENCRYPTION_KEY: 32 случайных байта в hex или base64.');}
function providerUnavailable(){return err(503,'provider_unavailable','Назначенный ИИ-провайдер недоступен или его ключ не может быть расшифрован. Проверьте настройки администратора.');}
async function checkedProvider(env,p) {
  if(!p||!p.hasKey)throw new Error('provider_missing');
  const baseUrl=p.legacy?LEGACY_BASE:safeBaseUrl(p.baseUrl);
  await assertPublicDns(baseUrl);
  const apiKey=await providerCredential(env,p);
  if(typeof apiKey!=='string'||!apiKey||/[\s\x00-\x1f\x7f]/.test(apiKey))throw new Error('provider_key_invalid');
  return {...p,baseUrl,apiKey};
}
async function chooseProvider(env,c,plan) {
  const r=await providerRouting(env),id=plan==='pro'?r.pro_provider_id:r.free_provider_id;
  if(id===LEGACY_ID&&!r.legacy_visible)throw new Error('provider_hidden');
  const p=await checkedProvider(env,await providerRecord(env,id,c));
  if(p.legacy)p.model=plan==='pro'?c.proModel:c.freeModel;
  return p;
}
async function handleProviderAdmin(req,env,method,path,c) {
  const route=await providerRouting(env);
  if(path==='/admin/providers'&&method==='GET'){
    const rows=await env.DB.prepare('SELECT id FROM ai_providers WHERE id<>? ORDER BY name,id').bind(LEGACY_ID).all();
    const providers=[];
    if(route.legacy_visible)providers.push(publicProvider(await providerRecord(env,LEGACY_ID,c)));
    for(const x of rows.results||[]){const p=await providerRecord(env,x.id,c);if(p)providers.push(publicProvider(p));}
    return json({providers,freeProviderId:route.free_provider_id,proProviderId:route.pro_provider_id,encryptionReady:!!await encryptionKey(env)});
  }
  const match=path.match(/^\/admin\/providers\/([A-Za-z0-9_-]+)(\/test)?$/);
  if(match&&match[2]&&method==='POST'){
    const id=match[1]; if(id===LEGACY_ID&&!route.legacy_visible)return err(404,'not_found','Провайдер не найден.');
    const p=await providerRecord(env,id,c);if(!p)return err(404,'not_found','Провайдер не найден.');
    try {
      const checked=await checkedProvider(env,p);
      const r=await fetch(checked.baseUrl+'/models',{headers:{Authorization:'Bearer '+checked.apiKey},redirect:'manual',signal:AbortSignal.timeout(15000)});
      return json({ok:r.ok,message:r.ok?'Провайдер ответил на /models. Это не подтверждает доступ к выбранной модели или генерацию.':'Провайдер отклонил проверку /models (код '+r.status+'). Это не обязательно означает, что генерация недоступна.'});
    }catch{return json({ok:false,message:'Не удалось проверить провайдера или расшифровать ключ. Проверьте настройки, DNS и PROVIDER_ENCRYPTION_KEY.'});}
  }
  const isWrite=path==='/admin/providers'&&method==='POST'||match&&!match[2]&&(method==='PUT'||method==='DELETE')||path==='/admin/provider-routing'&&method==='PUT';
  if(!isWrite)return err(404,'not_found','Не найдено.');
  const key=await encryptionKey(env);if(!key)return encryptionRequired();
  if(path==='/admin/provider-routing'&&method==='PUT'){
    let b;try{b=await readJson(req,32768);}catch{return err(400,'bad_request','Некорректный запрос.');}
    if(!b||typeof b.freeProviderId!=='string'||typeof b.proProviderId!=='string')return err(400,'bad_request','Выберите оба провайдера.');
    const selected=[];
    try {
      for(const id of [b.freeProviderId,b.proProviderId]){
        const p=await providerRecord(env,id,c);
        await checkedProvider(env,p);
        selected.push(p);
      }
    } catch {return err(400,'bad_request','Провайдер не найден или его URL, DNS либо ключ недоступны.');}
    const checks=[],params=[b.freeProviderId,b.proProviderId,b.freeProviderId,LEGACY_ID,b.proProviderId,LEGACY_ID];
    for(const p of selected){
      if(p.legacy){
        if(p.secret){checks.push('EXISTS(SELECT 1 FROM ai_provider_secrets s WHERE s.provider_id=? AND s.iv=? AND s.ciphertext=?)');params.push(p.id,p.secret.iv,p.secret.ciphertext);}
        else {checks.push('NOT EXISTS(SELECT 1 FROM ai_provider_secrets s WHERE s.provider_id=?)');params.push(p.id);}
      }else{
        checks.push('EXISTS(SELECT 1 FROM ai_providers p JOIN ai_provider_secrets s ON s.provider_id=p.id WHERE p.id=? AND p.base_url=? AND p.name=? AND p.model=? AND s.iv=? AND s.ciphertext=?)');
        params.push(p.id,p.baseUrl,p.name,p.model,p.secret.iv,p.secret.ciphertext);
      }
    }
    const result=await env.DB.prepare(`INSERT INTO ai_provider_routing(id,free_provider_id,pro_provider_id,legacy_visible)
      SELECT 1,?,?,CASE WHEN ?=? OR ?=? THEN 1 ELSE COALESCE((SELECT legacy_visible FROM ai_provider_routing WHERE id=1),1) END
      WHERE ${checks.join(' AND ')}
      ON CONFLICT(id) DO UPDATE SET free_provider_id=excluded.free_provider_id,pro_provider_id=excluded.pro_provider_id,legacy_visible=excluded.legacy_visible`)
      .bind(...params).run();
    if(!result.meta?.changes)return err(409,'provider_changed','Настройки провайдера изменились; повторите назначение маршрута.');
    return json({ok:true,freeProviderId:b.freeProviderId,proProviderId:b.proProviderId});
  }
  const id=match?match[1]:'p_'+crypto.randomUUID();
  if(match&&id===LEGACY_ID&&!route.legacy_visible)return err(404,'not_found','Провайдер не найден.');
  if(method==='DELETE'){
    if(id===LEGACY_ID){
      const results=await env.DB.batch([
        env.DB.prepare('UPDATE ai_provider_routing SET legacy_visible=0 WHERE id=1 AND legacy_visible=1 AND free_provider_id<>? AND pro_provider_id<>?').bind(id,id),
        env.DB.prepare('DELETE FROM ai_provider_secrets WHERE provider_id=? AND EXISTS(SELECT 1 FROM ai_provider_routing WHERE id=1 AND legacy_visible=0 AND free_provider_id<>? AND pro_provider_id<>?)').bind(id,id,id),
        env.DB.prepare('DELETE FROM ai_providers WHERE id=? AND EXISTS(SELECT 1 FROM ai_provider_routing WHERE id=1 AND legacy_visible=0 AND free_provider_id<>? AND pro_provider_id<>?)').bind(id,id,id)
      ]);
      if(!results[0].meta?.changes)return err(409,'provider_assigned','Нельзя удалить назначенного провайдера.');
      return json({ok:true});
    }
    const exists=await providerRecord(env,id,c);if(!exists)return err(404,'not_found','Провайдер не найден.');
    const results=await env.DB.batch([
      env.DB.prepare('DELETE FROM ai_providers WHERE id=? AND NOT EXISTS(SELECT 1 FROM ai_provider_routing WHERE id=1 AND (free_provider_id=? OR pro_provider_id=?))').bind(id,id,id),
      env.DB.prepare('DELETE FROM ai_provider_secrets WHERE provider_id=? AND NOT EXISTS(SELECT 1 FROM ai_providers WHERE id=?)').bind(id,id)
    ]);
    if(!results[0].meta?.changes)return err(409,'provider_assigned','Нельзя удалить назначенного провайдера.');
    return json({ok:true});
  }
  const isCreate=!match;
  const existing=isCreate?null:await providerRecord(env,id,c);
  if(!isCreate&&!existing)return err(404,'not_found','Провайдер не найден.');
  let b;try{b=await readJson(req,16384);}catch{return err(400,'bad_request','Некорректный запрос.');}
  let v;try{
    v=validateMetadata(b,env,id===LEGACY_ID);
    if(isCreate&&!v.apiKey)throw new Error('Укажите API-ключ.');
    const endpointChanged=!!existing&&existing.baseUrl!==v.baseUrl;
    if(endpointChanged&&!v.apiKey)throw new Error('При изменении адреса или пути провайдера укажите новый API-ключ.');
    if(existing?.hasKey){
      let previousKey;
      try{previousKey=await providerCredential(env,existing);}catch{throw new Error('Не удалось проверить сохранённый ключ. Восстановите ключ шифрования.');}
      if(endpointChanged&&v.apiKey===previousKey)throw new Error('При изменении адреса или пути требуется другой API-ключ.');
      if(previousKey&&[v.name,v.model,v.baseUrl].some(x=>x.includes(previousKey)))throw new Error('API-ключ должен находиться только в поле apiKey.');
    }
    await assertPublicDns(v.baseUrl);
  }catch(e){return err(400,'bad_request',e.message);}
  const stmts=[];
  if(!isCreate&&id!==LEGACY_ID){
    const secretCheck=existing.secret?'EXISTS(SELECT 1 FROM ai_provider_secrets s WHERE s.provider_id=? AND s.iv=? AND s.ciphertext=?)':'NOT EXISTS(SELECT 1 FROM ai_provider_secrets s WHERE s.provider_id=?)';
    const secretArgs=existing.secret?[id,existing.secret.iv,existing.secret.ciphertext]:[id];
    const oldMeta=[id,existing.baseUrl,existing.name,existing.model];
    if(v.apiKey){
      const s=await sealSecret(key,id,v.apiKey);
      stmts.push(env.DB.prepare(`INSERT INTO ai_provider_secrets(provider_id,iv,ciphertext)
        SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM ai_providers WHERE id=? AND base_url=? AND name=? AND model=?) AND ${secretCheck}
        ON CONFLICT(provider_id) DO UPDATE SET iv=excluded.iv,ciphertext=excluded.ciphertext`).bind(id,s.iv,s.ciphertext,...oldMeta,...secretArgs));
      stmts.push(env.DB.prepare(`UPDATE ai_providers SET name=?,base_url=?,model=? WHERE id=? AND base_url=? AND name=? AND model=?
        AND EXISTS(SELECT 1 FROM ai_provider_secrets s WHERE s.provider_id=? AND s.iv=? AND s.ciphertext=?)`).bind(v.name,v.baseUrl,v.model,...oldMeta,id,s.iv,s.ciphertext));
    }else{
      stmts.push(env.DB.prepare(`UPDATE ai_providers SET name=?,base_url=?,model=? WHERE id=? AND base_url=? AND name=? AND model=? AND ${secretCheck}`).bind(v.name,v.baseUrl,v.model,...oldMeta,...secretArgs));
    }
  }else{
    if(isCreate)stmts.push(env.DB.prepare('INSERT INTO ai_providers(id,name,base_url,model) VALUES(?,?,?,?)').bind(id,v.name,v.baseUrl,v.model));
    else stmts.push(env.DB.prepare('INSERT INTO ai_providers(id,name,base_url,model) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name').bind(id,v.name,LEGACY_BASE,c.freeModel));
    if(v.apiKey){
      const s=await sealSecret(key,id,v.apiKey);
      stmts.push(env.DB.prepare('INSERT INTO ai_provider_secrets(provider_id,iv,ciphertext) SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM ai_providers WHERE id=?) ON CONFLICT(provider_id) DO UPDATE SET iv=excluded.iv,ciphertext=excluded.ciphertext').bind(id,s.iv,s.ciphertext,id));
    }
  }
  const results=await env.DB.batch(stmts);
  if(results.some(r=>!r.meta?.changes))return err(409,'provider_changed','Настройки провайдера изменились; повторите сохранение.');
  const p=await providerRecord(env,id,id===LEGACY_ID?await getConfig(env):c);
  return json({provider:publicProvider(p)},isCreate?201:200);
}

async function handleAdmin(req,url,env,method) {
  const a=await requireAdmin(req,env); if(a.error)return a.error;
  const p=url.pathname,m=method||req.method,u=a.user,c=await getConfig(env),t=now();
  if(p==='/admin/providers'||p.startsWith('/admin/providers/')||p==='/admin/provider-routing')return handleProviderAdmin(req,env,m,p,c);
  if(p==='/admin/me'&&m==='GET') return json({admin:true,mode:'google',email:u.email});
  if(p==='/admin/config'&&m==='GET') return json({...c,hasKey:!!env.OPENROUTER_API_KEY,keyHint:env.OPENROUTER_API_KEY?MASKED_KEY:'',keySource:env.OPENROUTER_API_KEY?'secret':'none',encryptedAtRest:false,hasAzureKey:false,azureRegion:''});
  if(p==='/admin/config'&&m==='PUT') { let b;try{b=await readJson(req,128*1024);}catch{return err(400,'bad_request','Некорректный запрос.');} try{await setConfig(env,b);await log(env,'info','admin','Изменены настройки',{by:u.email});return json({...await getConfig(env),hasKey:!!env.OPENROUTER_API_KEY,keyHint:env.OPENROUTER_API_KEY?MASKED_KEY:'',keySource:env.OPENROUTER_API_KEY?'secret':'none',hasAzureKey:false});}catch(e){return err(400,'bad_request',e.message);} }
  if(p==='/admin/test-key'&&m==='POST') { if(!env.OPENROUTER_API_KEY)return json({ok:false,message:'Добавь OPENROUTER_API_KEY в Cloudflare Secrets.'});try{const r=await fetch('https://openrouter.ai/api/v1/auth/key',{headers:{Authorization:'Bearer '+env.OPENROUTER_API_KEY}});return json({ok:r.ok,status:r.status,message:r.ok?'Ключ принят провайдером.':'Провайдер отклонил ключ (код '+r.status+').' });}catch{return json({ok:false,message:'Не удалось связаться с OpenRouter.'});} }
  if(p==='/admin/test-tts'&&m==='POST'){if(!await fishKeyAvailable(env))return json({ok:false,message:'Добавь новый FISH_AUDIO_API_KEY как Secret в Cloudflare.'});try{const r=await fetch('https://api.fish.audio/v1/tts',{method:'POST',headers:{Authorization:'Bearer '+env.FISH_AUDIO_API_KEY,'Content-Type':'application/json','model':'s2.1-pro-free'},body:JSON.stringify({text:'Проверка голоса JARVIS. Система готова.',format:'mp3'})});return json({ok:r.ok,status:r.status,message:r.ok?'Fish Audio отвечает, генерация аудио работает.':'Fish Audio вернул ошибку '+r.status+'.'});}catch{return json({ok:false,message:'Не удалось связаться с Fish Audio.'});}}
  if(p==='/admin/integrations'&&m==='GET') return json({integrations:[{id:'ai',name:'ИИ-провайдер (OpenRouter)',configured:!!env.OPENROUTER_API_KEY,source:env.OPENROUTER_API_KEY?'secret':'none',hint:env.OPENROUTER_API_KEY?MASKED_KEY:'',note:'Ключ хранится в Cloudflare Secret'},{id:'google',name:'Вход через Google',configured:true,source:'env',hint:'',note:'Google ID token проверяется сервером'},{id:'tts',name:'Fish Audio S2.1 Pro',configured:await fishKeyAvailable(env),source:await fishKeyAvailable(env)?'secret':'none',hint:'',note:'Ключ хранится в Cloudflare Secret'},{id:'gmail',name:'Gmail',configured:null,source:'device',hint:'',note:'Подключается на устройстве'}]});
  if(p==='/admin/stats'&&m==='GET') { const r=await env.DB.prepare("SELECT COUNT(*) users,SUM(blocked) blocked,SUM(CASE WHEN plan='pro' AND (plan_until IS NULL OR plan_until>?) THEN 1 ELSE 0 END) pro,SUM(CASE WHEN day_key=? THEN count ELSE 0 END) requestsToday,SUM(total) totalRequests FROM users").bind(t,dayKey(t)).first();return json({users:r.users||0,blocked:r.blocked||0,pro:r.pro||0,requestsToday:r.requestsToday||0,totalRequests:r.totalRequests||0}); }
  if(p==='/admin/diagnostics'&&m==='GET') {const r=await env.DB.prepare("SELECT COUNT(*) n FROM event_logs WHERE level='error' AND ts>?").bind(t-3600000).first();const u2=await env.DB.prepare('SELECT COUNT(*) n FROM users').first();return json({version:VERSION,runtime:'Cloudflare Workers',uptimeSec:null,serverTime:t,adminMode:'google',users:u2.n,memoryMB:null,activeChats:null,keyConfigured:!!env.OPENROUTER_API_KEY,ttsAvailable:await fishKeyAvailable(env),googleConfigured:true,errorsLastHour:r.n,storage:'D1'});}
  if(p==='/admin/logs'&&m==='GET') {const lim=Math.min(500,Math.max(1,Number(url.searchParams.get('limit'))||100)),lvl=url.searchParams.get('level');const r=lvl?await env.DB.prepare('SELECT ts t,level,type,message,extra FROM event_logs WHERE level=? ORDER BY id DESC LIMIT ?').bind(lvl,lim).all():await env.DB.prepare('SELECT ts t,level,type,message,extra FROM event_logs ORDER BY id DESC LIMIT ?').bind(lim).all();return json({logs:(r.results||[]).map(x=>({...x,extra:JSON.parse(x.extra||'{}')}))});}
  if(p==='/admin/logs'&&m==='DELETE'){await env.DB.prepare('DELETE FROM event_logs').run();return json({ok:true});}
  if(p==='/admin/users'&&m==='GET'){const q=(url.searchParams.get('q')||'').toLowerCase();const r=q?await env.DB.prepare('SELECT * FROM users WHERE lower(email) LIKE ? ORDER BY last_seen DESC LIMIT 200').bind('%'+q+'%').all():await env.DB.prepare('SELECT * FROM users ORDER BY last_seen DESC LIMIT 200').all();const out=[];for(const x of r.results||[]){const h=await env.DB.prepare('SELECT 1 FROM histories WHERE sub=?').bind(x.sub).first();out.push(pubUser(x,c,t,!!h));}return json({users:out});}
  const match=p.match(/^\/admin\/users\/([^/]+)$/);
  if(match&&(m==='PATCH'||m==='POST'&&req.headers.get('x-http-method-override')==='PATCH')) {let b;try{b=await readJson(req,128*1024);}catch{return err(400,'bad_request','Некорректный запрос.');}const sub=decodeURIComponent(match[1]),x=await env.DB.prepare('SELECT * FROM users WHERE sub=?').bind(sub).first();if(!x)return err(404,'not_found','Пользователь не найден.');let plan=x.plan,until=x.plan_until,blocked=x.blocked,daily=x.daily_limit,count=x.count,tts=x.tts_chars;if(typeof b.blocked==='boolean')blocked=b.blocked?1:0;if(b.plan==='pro'){plan='pro';const d=Number(b.days);until=Number.isFinite(d)&&d>0?t+Math.min(d,3650)*86400000:null;}else if(b.plan==='free'){plan='free';until=null;}if(b.dailyLimit===null)daily=null;else if(b.dailyLimit!==undefined){daily=Number(b.dailyLimit);if(!Number.isInteger(daily)||daily<0||daily>100000)return err(400,'bad_request','Некорректный лимит.');}if(b.resetToday===true){count=0;tts=0;}await env.DB.prepare('UPDATE users SET plan=?,plan_until=?,blocked=?,daily_limit=?,count=?,tts_chars=? WHERE sub=?').bind(plan,until,blocked,daily,count,tts,sub).run();if(b.deleteHistory===true)await env.DB.prepare('DELETE FROM histories WHERE sub=?').bind(sub).run();await log(env,'info','admin','Изменён пользователь '+x.email,{by:u.email});const fresh=await env.DB.prepare('SELECT * FROM users WHERE sub=?').bind(sub).first();const h=await env.DB.prepare('SELECT 1 FROM histories WHERE sub=?').bind(sub).first();return json(pubUser(fresh,c,t,!!h));}
  return err(404,'not_found','Не найдено.');
}

/* ======================= JARVIS Cloud 3.4: задачи, файлы, изображения ======================= */
/* Таблицы jobs, files, usage_daily уже созданы в D1. Очередь Queues не используется (бесплатный план):
   задача создаётся со статусом queued, выполняется фоном (ctx.waitUntil), клиент опрашивает статус. */
const CLOUD_LIMITS = {
  free: { image: 3, file: 20, storageMB: 20, retentionDays: 7 },
  pro: { image: 30, file: 200, storageMB: 100, retentionDays: 30 }
};
const MAX_FILE_BYTES = 1500000;           // D1: строка до 2 МБ, base64 даёт +33%
const BLOCKED_EXT = new Set(['apk','xapk','apks','aab','dex','exe','msi','bat','cmd','com','scr','dll','so','jar','ps1','vbs','app','dmg','deb','rpm','bin','sys','lnk']);
const TEXT_MIME = { txt:'text/plain', md:'text/markdown', csv:'text/csv', json:'application/json', xml:'application/xml', html:'text/html', css:'text/css', js:'text/javascript', ts:'text/plain', py:'text/x-python', java:'text/x-java', kt:'text/plain', c:'text/plain', cpp:'text/plain', h:'text/plain', go:'text/plain', rs:'text/plain', php:'text/plain', rb:'text/plain', sql:'text/plain', yaml:'text/yaml', yml:'text/yaml', log:'text/plain', svg:'image/svg+xml', sh:'text/plain', ini:'text/plain', toml:'text/plain' };
const OFFICE_MIME = { docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', rtf:'application/rtf', zip:'application/zip', png:'image/png', jpg:'image/jpeg' };
const utf8 = s => new TextEncoder().encode(s);
const xmlEsc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'');

function cloudLimits(c, plan) {
  const base = CLOUD_LIMITS[plan] || CLOUD_LIMITS.free;
  const o = (c.cloudLimits && c.cloudLimits[plan]) || {};
  const pick = k => (Number.isFinite(Number(o[k])) && Number(o[k]) >= 0 ? Number(o[k]) : base[k]);
  return { image: pick('image'), file: pick('file'), storageMB: pick('storageMB'), retentionDays: pick('retentionDays') };
}
function safeFileName(name, fallback) {
  let n = String(name || fallback || 'file').split(/[\\/]/).pop().trim();
  n = n.replace(/[^\p{L}\p{N}._\- ()]/gu, '_').replace(/\.{2,}/g, '.').slice(0, 100);
  if (!n || n === '.' || n === '..') n = fallback || 'file';
  return n;
}
const extOf = n => { const i = n.lastIndexOf('.'); return i < 0 ? '' : n.slice(i + 1).toLowerCase(); };

/* --- ZIP (store, без сжатия) --- */
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(b) { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC_T[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function zipStore(entries) {
  const parts = [], central = []; let offset = 0;
  const u16 = v => [v & 255, (v >>> 8) & 255], u32 = v => [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255];
  for (const e of entries) {
    const name = utf8(e.name), data = e.data, crc = crc32(data);
    const local = new Uint8Array([0x50,0x4b,3,4, ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0x6000), ...u16(0x5821), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0)]);
    parts.push(local, name, data);
    central.push(new Uint8Array([0x50,0x4b,1,2, ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0x6000), ...u16(0x5821), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset)]), name);
    offset += local.length + name.length + data.length;
  }
  let csize = 0; for (const p of central) csize += p.length;
  const end = new Uint8Array([0x50,0x4b,5,6, ...u16(0), ...u16(0), ...u16(entries.length), ...u16(entries.length), ...u32(csize), ...u32(offset), ...u16(0)]);
  const all = [...parts, ...central, end]; let total = 0; for (const p of all) total += p.length;
  const out = new Uint8Array(total); let pos = 0; for (const p of all) { out.set(p, pos); pos += p.length; }
  return out;
}

/* --- Генераторы форматов --- */
function makeDocx(text) {
  const lines = String(text).replace(/\r/g, '').split('\n');
  const body = lines.map(l => {
    const h = l.match(/^(#{1,3})\s+(.*)$/);
    if (h) return `<w:p><w:pPr><w:spacing w:after="120"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="${h[1].length === 1 ? 36 : h[1].length === 2 ? 30 : 26}"/></w:rPr><w:t xml:space="preserve">${xmlEsc(h[2])}</w:t></w:r></w:p>`;
    return `<w:p><w:r><w:t xml:space="preserve">${xmlEsc(l)}</w:t></w:r></w:p>`;
  }).join('');
  const doc = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${body}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`;
  return zipStore([
    { name: '[Content_Types].xml', data: utf8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>') },
    { name: '_rels/.rels', data: utf8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>') },
    { name: 'word/document.xml', data: utf8(doc) }
  ]);
}
function colName(i) { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; }
function parseCsv(text) {
  const rows = []; let row = [], cur = '', q = false;
  const s = String(text).replace(/\r/g, '');
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (q) { if (ch === '"') { if (s[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
    else if (ch === '"') q = true; else if (ch === ',' || ch === ';') { row.push(cur); cur = ''; }
    else if (ch === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; } else cur += ch;
  }
  if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
  return rows;
}
function makeXlsx(rows) {
  const data = rows.slice(0, 5000).map((r, ri) => `<row r="${ri + 1}">${(Array.isArray(r) ? r : [r]).slice(0, 100).map((v, ci) => {
    const ref = colName(ci) + (ri + 1), sv = v == null ? '' : String(v);
    if (sv.trim() !== '' && /^-?\d+(\.\d+)?$/.test(sv.trim()) && sv.trim().length < 16) return `<c r="${ref}"><v>${sv.trim()}</v></c>`;
    return `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xmlEsc(sv)}</t></is></c>`;
  }).join('')}</row>`).join('');
  return zipStore([
    { name: '[Content_Types].xml', data: utf8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>') },
    { name: '_rels/.rels', data: utf8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>') },
    { name: 'xl/workbook.xml', data: utf8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>') },
    { name: 'xl/_rels/workbook.xml.rels', data: utf8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>') },
    { name: 'xl/worksheets/sheet1.xml', data: utf8(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${data}</sheetData></worksheet>`) }
  ]);
}
function makeRtf(text) {
  let out = '{\\rtf1\\ansi\\ansicpg1251\\deff0{\\fonttbl{\\f0 Arial;}}\\f0\\fs24 ';
  for (const ch of String(text).replace(/\r/g, '')) {
    const cp = ch.codePointAt(0);
    if (ch === '\\' || ch === '{' || ch === '}') out += '\\' + ch;
    else if (ch === '\n') out += '\\par\n';
    else if (cp < 128) out += ch;
    else if (cp <= 0xFFFF) out += '\\u' + (cp > 32767 ? cp - 65536 : cp) + '?';
    else { const v = cp - 0x10000, hi = 0xD800 + (v >> 10), lo = 0xDC00 + (v & 1023); out += '\\u' + (hi - 65536) + '?\\u' + (lo - 65536) + '?'; }
  }
  return utf8(out + '}');
}
const bytesToB64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode(...u8.subarray(i, i + 0x8000)); return btoa(s); };
const b64ToBytes = s => Uint8Array.from(atob(s), ch => ch.charCodeAt(0));

/* Строит файл из запроса. Возвращает {name, mime, bytes} или бросает Error с понятным текстом. */
function buildFile(b) {
  let name = safeFileName(b.name, 'jarvis.txt');
  let ext = extOf(name);
  if (!ext && typeof b.format === 'string') { ext = b.format.toLowerCase().replace(/[^a-z0-9]/g, ''); name += '.' + ext; }
  if (!ext) { ext = 'txt'; name += '.txt'; }
  if (BLOCKED_EXT.has(ext)) throw new Error('Создание исполняемых и установочных файлов (.' + ext + ') запрещено.');
  const content = typeof b.content === 'string' ? b.content : '';
  if (ext === 'xlsx') {
    const rows = Array.isArray(b.rows) ? b.rows : parseCsv(content);
    if (!rows.length) throw new Error('Для таблицы нужны rows (массив строк) или content в формате CSV.');
    return { name, mime: OFFICE_MIME.xlsx, bytes: makeXlsx(rows) };
  }
  if (ext === 'docx') { if (!content.trim()) throw new Error('Для документа нужен content.'); return { name, mime: OFFICE_MIME.docx, bytes: makeDocx(content) }; }
  if (ext === 'rtf') { if (!content.trim()) throw new Error('Для RTF нужен content.'); return { name, mime: OFFICE_MIME.rtf, bytes: makeRtf(content) }; }
  if (ext === 'zip') {
    const files = Array.isArray(b.files) ? b.files.slice(0, 40) : [];
    if (!files.length) throw new Error('Для ZIP нужен массив files.');
    const entries = [], seen = new Set();
    for (const f of files) {
      const parts = String(f && f.name || '').split('/').filter(x => x && x !== '.' && x !== '..').map(x => safeFileName(x, 'file'));
      const en = parts.join('/'); if (!en || seen.has(en)) continue;
      if (BLOCKED_EXT.has(extOf(en))) throw new Error('В архив нельзя добавлять исполняемые файлы (.' + extOf(en) + ').');
      seen.add(en); entries.push({ name: en, data: utf8(String(f.content == null ? '' : f.content)) });
    }
    if (!entries.length) throw new Error('В files нет корректных файлов.');
    return { name, mime: OFFICE_MIME.zip, bytes: zipStore(entries) };
  }
  if (TEXT_MIME[ext]) {
    if (!content.length) throw new Error('Пустой content.');
    return { name, mime: TEXT_MIME[ext] + '; charset=utf-8', bytes: utf8(content) };
  }
  throw new Error('Формат .' + ext + ' сервер создать не может. Доступны: txt, md, csv, json, xml, html, css, js, py, java, kt, sql, yaml, svg, rtf, docx, xlsx, zip.');
}

async function takeQuota(env, sub, kind, limit, t) {
  if (limit <= 0) return false;
  const r = await env.DB.prepare('INSERT INTO usage_daily(sub,day,kind,count) VALUES(?,?,?,1) ON CONFLICT(sub,day,kind) DO UPDATE SET count=count+1 WHERE count<?').bind(sub, dayKey(t), kind, limit).run();
  return !!(r.meta && r.meta.changes);
}
async function refundQuota(env, sub, kind, t) {
  try { await env.DB.prepare('UPDATE usage_daily SET count=MAX(0,count-1) WHERE sub=? AND day=? AND kind=?').bind(sub, dayKey(t), kind).run(); } catch {}
}
async function usageToday(env, sub, t) {
  const r = await env.DB.prepare('SELECT kind,count FROM usage_daily WHERE sub=? AND day=?').bind(sub, dayKey(t)).all();
  const o = {}; for (const x of r.results || []) o[x.kind] = x.count; return o;
}
async function storageUsed(env, sub) {
  const r = await env.DB.prepare('SELECT COALESCE(SUM(size),0) n FROM files WHERE sub=?').bind(sub).first();
  return r ? r.n : 0;
}
async function storeFile(env, sub, f, plan, lim, t, jobId) {
  if (f.bytes.length > MAX_FILE_BYTES) throw new Error('Файл больше ' + Math.round(MAX_FILE_BYTES / 1000) + ' КБ: бесплатное хранилище D1 не принимает такие файлы. Для больших файлов нужно включить R2.');
  const used = await storageUsed(env, sub);
  if (used + f.bytes.length > lim.storageMB * 1048576) throw new Error('Хранилище файлов заполнено (лимит ' + lim.storageMB + ' МБ). Удали старые файлы.');
  const id = 'f_' + crypto.randomUUID().replace(/-/g, '').slice(0, 20);
  await env.DB.prepare('INSERT INTO files(id,sub,name,mime,size,storage,data,version,job_id,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .bind(id, sub, f.name, f.mime, f.bytes.length, 'd1', bytesToB64(f.bytes), 1, jobId || null, t, t + lim.retentionDays * 86400000).run();
  return { id, name: f.name, mime: f.mime, size: f.bytes.length, expiresAt: t + lim.retentionDays * 86400000 };
}
async function setJob(env, id, sub, status, fields = {}) {
  const t = now(), done = ['completed', 'failed', 'cancelled'].includes(status);
  await env.DB.prepare("UPDATE jobs SET status=?,result=COALESCE(?,result),error=COALESCE(?,error),updated_at=?,finished_at=? WHERE id=? AND sub=? AND status NOT IN ('completed','failed','cancelled')")
    .bind(status, fields.result ? JSON.stringify(fields.result) : null, fields.error || null, t, done ? t : null, id, sub).run();
}
const pubJob = j => ({ id: j.id, type: j.type, status: j.status, result: j.result ? JSON.parse(j.result) : null, error: j.error || null, createdAt: j.created_at, updatedAt: j.updated_at, finishedAt: j.finished_at || null });
const BAD_IMAGE = /(child|kid|minor|teen|underage|ребён|ребен|малолет|несовершеннолет|школьниц|школьник)[\s\S]{0,60}(nude|naked|sex|porn|erotic|обнаж|гол|секс|порно|эрот)|(nude|naked|sex|porn|erotic|обнаж|секс|порно|эрот)[\s\S]{0,60}(child|kid|minor|teen|underage|ребён|ребен|малолет|несовершеннолет|школьниц)/i;

async function runImageJob(env, c, jobId, sub, prompt, plan, lim) {
  try {
    await setJob(env, jobId, sub, 'running');
    let key = env.OPENROUTER_API_KEY || '';
    if (!key) { try { key = await providerCredential(env, await providerRecord(env, LEGACY_ID, c)); } catch { key = ''; } }
    if (!key) throw new Error('На сервере не настроен ключ OpenRouter для генерации изображений.');
    const model = typeof c.imageModel === 'string' && /^[A-Za-z0-9._:/-]{3,120}$/.test(c.imageModel) ? c.imageModel : 'google/gemini-2.5-flash-image';
    const r = await fetch(LEGACY_BASE + '/chat/completions', { method: 'POST', redirect: 'manual', signal: AbortSignal.timeout(100000),
      headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json', 'HTTP-Referer': 'https://jarvis-admin.pages.dev', 'X-Title': 'JARVIS AI' },
      body: JSON.stringify({ model, modalities: ['image', 'text'], messages: [{ role: 'user', content: prompt }] }) });
    if (!r.ok) throw new Error('Провайдер изображений вернул ошибку ' + r.status + '.');
    const j = await r.json();
    const url = j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.images && j.choices[0].message.images[0] && j.choices[0].message.images[0].image_url && j.choices[0].message.images[0].image_url.url || '';
    const m = String(url).match(/^data:(image\/(?:png|jpeg|webp));base64,(.+)$/);
    if (!m) throw new Error('Модель ' + model + ' не вернула изображение.');
    const bytes = b64ToBytes(m[2]);
    const ext = m[1] === 'image/png' ? 'png' : m[1] === 'image/jpeg' ? 'jpg' : 'webp';
    const cur = await env.DB.prepare('SELECT status FROM jobs WHERE id=?').bind(jobId).first();
    if (!cur || cur.status === 'cancelled') { await refundQuota(env, sub, 'image', now()); return; }
    const file = await storeFile(env, sub, { name: 'image-' + jobId.slice(2, 10) + '.' + ext, mime: m[1], bytes }, plan, lim, now(), jobId);
    await setJob(env, jobId, sub, 'completed', { result: { fileId: file.id, name: file.name, size: file.size, mime: file.mime, model } });
  } catch (e) {
    await refundQuota(env, sub, 'image', now());
    await setJob(env, jobId, sub, 'failed', { error: String(e && e.message || 'Ошибка генерации').slice(0, 300) });
    await log(env, 'error', 'image', 'Ошибка генерации изображения');
  }
}

async function handleCloud(req, env, ctx, url, m, user, u, c, t) {
  if (u.blocked) return err(403, 'blocked', 'Доступ к JARVIS заблокирован администратором.');
  if (c.maintenance) return err(503, 'maintenance', c.announcement || 'Идут технические работы.');
  const plan = activePlan(u, t), lim = cloudLimits(c, plan), p = url.pathname.replace(/\/+$/, '');
  // уборка просроченных файлов пользователя
  await env.DB.prepare('DELETE FROM files WHERE sub=? AND expires_at IS NOT NULL AND expires_at<?').bind(user.sub, t).run();

  if (p === '/v1/cloud/status' && m === 'GET') {
    const use = await usageToday(env, user.sub, t);
    return json({ ok: true, plan, limits: lim, usedToday: { image: use.image || 0, file: use.file || 0 }, storageUsedBytes: await storageUsed(env, user.sub), maxFileBytes: MAX_FILE_BYTES, storage: 'd1', formats: ['txt','md','csv','json','xml','html','css','js','py','java','kt','sql','yaml','svg','rtf','docx','xlsx','zip'], notSupported: ['pdf','pptx','ods','odt','odp','conversion'] });
  }
  if (p === '/v1/cloud/files' && m === 'POST') {
    let b; try { b = await readJson(req, 2 * 1024 * 1024); } catch { return err(400, 'bad_request', 'Некорректный запрос.'); }
    let f; try { f = buildFile(b); } catch (e) { return err(400, 'bad_file', e.message); }
    if (!(await takeQuota(env, user.sub, 'file', lim.file, t))) return err(429, 'file_limit', 'Дневной лимит создания файлов исчерпан (' + lim.file + ').', { limits: lim });
    try {
      const file = await storeFile(env, user.sub, f, plan, lim, t, null);
      return json({ ok: true, file }, 201);
    } catch (e) { await refundQuota(env, user.sub, 'file', t); return err(413, 'store_failed', e.message); }
  }
  if (p === '/v1/cloud/files' && m === 'GET') {
    const r = await env.DB.prepare('SELECT id,name,mime,size,version,created_at,expires_at FROM files WHERE sub=? ORDER BY created_at DESC LIMIT 100').bind(user.sub).all();
    return json({ ok: true, files: r.results || [] });
  }
  const fm = p.match(/^\/v1\/cloud\/files\/(f_[a-z0-9]+)$/);
  if (fm) {
    const row = await env.DB.prepare('SELECT * FROM files WHERE id=? AND sub=?').bind(fm[1], user.sub).first();
    if (!row) return err(404, 'not_found', 'Файл не найден или срок хранения истёк.');
    if (m === 'GET') {
      if (url.searchParams.get('encoding') === 'base64') return json({ ok: true, id: row.id, name: row.name, mime: row.mime, size: row.size, data: row.data });
      return new Response(b64ToBytes(row.data), { status: 200, headers: { 'content-type': row.mime, 'content-disposition': 'attachment; filename*=UTF-8\'\'' + encodeURIComponent(row.name), 'cache-control': 'no-store' } });
    }
    if (m === 'DELETE') { await env.DB.prepare('DELETE FROM files WHERE id=? AND sub=?').bind(row.id, user.sub).run(); return json({ ok: true }); }
  }
  if (p === '/v1/cloud/jobs' && m === 'POST') {
    let b; try { b = await readJson(req, 64 * 1024); } catch { return err(400, 'bad_request', 'Некорректный запрос.'); }
    if (b.type !== 'image') return err(400, 'bad_type', 'Поддерживаются задачи типа image. Файлы создаются через /v1/cloud/files.');
    const prompt = typeof b.prompt === 'string' ? b.prompt.trim().slice(0, 1500) : '';
    if (prompt.length < 3) return err(400, 'bad_request', 'Нужно описание изображения.');
    if (BAD_IMAGE.test(prompt)) return err(400, 'refused', 'Такой запрос на генерацию изображения не поддерживается.');
    const active = await env.DB.prepare("SELECT COUNT(*) n FROM jobs WHERE sub=? AND status IN ('queued','running') AND created_at>?").bind(user.sub, t - 300000).first();
    if (active && active.n >= 2) return err(429, 'too_many_jobs', 'Уже выполняются 2 задачи. Дождись их завершения.');
    if (!(await takeQuota(env, user.sub, 'image', lim.image, t))) return err(429, 'image_limit', 'Дневной лимит изображений исчерпан (' + lim.image + ').', { limits: lim });
    const id = 'j_' + crypto.randomUUID().replace(/-/g, '').slice(0, 20);
    await env.DB.prepare("INSERT INTO jobs(id,sub,type,status,input,created_at,updated_at) VALUES(?,?,?,?,?,?,?)").bind(id, user.sub, 'image', 'queued', JSON.stringify({ prompt }), t, t).run();
    ctx.waitUntil(runImageJob(env, c, id, user.sub, prompt, plan, lim));
    return json({ ok: true, job: { id, type: 'image', status: 'queued' } }, 202);
  }
  const jm = p.match(/^\/v1\/cloud\/jobs\/(j_[a-z0-9]+)(\/cancel)?$/);
  if (jm) {
    const row = await env.DB.prepare('SELECT * FROM jobs WHERE id=? AND sub=?').bind(jm[1], user.sub).first();
    if (!row) return err(404, 'not_found', 'Задача не найдена.');
    if (jm[2] && m === 'POST') { await setJob(env, row.id, user.sub, 'cancelled'); const r2 = await env.DB.prepare('SELECT * FROM jobs WHERE id=?').bind(row.id).first(); return json({ ok: true, job: pubJob(r2) }); }
    if (m === 'GET') {
      if ((row.status === 'queued' || row.status === 'running') && t - row.created_at > 180000) { await setJob(env, row.id, user.sub, 'failed', { error: 'Задача не завершилась вовремя.' }); await refundQuota(env, user.sub, 'image', t); const r3 = await env.DB.prepare('SELECT * FROM jobs WHERE id=?').bind(row.id).first(); return json({ ok: true, job: pubJob(r3) }); }
      return json({ ok: true, job: pubJob(row) });
    }
  }
  return err(404, 'not_found', 'Не найдено.');
}

async function handle(req,env,ctx) {
  const url=new URL(req.url);let p=url.pathname.replace(/\/+$/,'')||'/',m=req.method.toUpperCase();
  if(m==='OPTIONS')return new Response(null,{status:204});
  if(m==='POST'&&p.startsWith('/admin/')&&req.headers.get('x-http-method-override')==='PATCH')m='PATCH';
  if(p==='/health'||p==='/api/health')return json({ok:true,service:'JARVIS BACKEND',version:VERSION,status:'online',runtime:'Cloudflare Workers',storage:env.DB?'D1':'D1 binding missing',cloud:true,timestamp:new Date().toISOString()});
  if(p==='/api/auth/verify'&&m==='POST'){let b;try{b=await readJson(req,32768);}catch{return err(400,'bad_request','Некорректный запрос.');}const u=await verifyGoogle(b.credential,env);if(!u)return err(401,'auth_failed','Google token недействителен.');if(!adminEmails(env).includes(u.email))return err(403,'forbidden','Нет доступа администратора.');return json({ok:true,email:u.email});}
  if(!env.DB)return err(503,'storage_not_configured','В Cloudflare Worker не подключена D1 database binding с именем DB.');
  if(p.startsWith('/admin/'))return handleAdmin(req,url,env,m);
  if(p==='/v1/app-config'&&m==='GET'){const c=await getConfig(env),available=await fishKeyAvailable(env);return json({systemPrompt:c.systemPrompt,announcement:c.announcement,maintenance:!!c.maintenance,features:{...c.features,onlineTts:available,cloudFiles:true},ttsAvailable:available,freeModel:c.freeModel});}
  const user=await verifyGoogle(tokenFrom(req),env);if(!user)return err(401,'auth_required','Нужен вход через Google.');
  const t=now(),c=await getConfig(env),u=await getUser(env,user);
  if(p.startsWith('/v1/cloud/'))return handleCloud(req,env,ctx,url,m,user,u,c,t);
  if(p==='/v1/status'&&m==='GET')return json({ok:true,email:u.email,startedAt:u.started_at,serverTime:t,ttsAvailable:await fishKeyAvailable(env),...status(u,c,t)});
  if(p==='/v1/tts'&&m==='POST'){if(u.blocked)return err(403,'blocked','Доступ к JARVIS заблокирован администратором.');if(c.maintenance)return err(503,'maintenance',c.announcement||'Идут технические работы.');if(!await fishKeyAvailable(env))return err(503,'not_configured','Fish Audio не настроен: добавь новый FISH_AUDIO_API_KEY как Secret в Cloudflare.');if(c.ttsEnabled===false)return err(503,'tts_disabled','Нейро-голос временно отключён администратором.');let b;try{b=await readJson(req,32768);}catch{return err(400,'bad_request','Некорректный запрос.');}const textValue=typeof b.text==='string'?b.text.trim():'';if(!textValue)return err(400,'empty_text','Нет текста для озвучивания.');if(textValue.length>4000)return err(413,'text_too_long','Слишком длинный текст для одного фрагмента.');const bytes=new TextEncoder().encode(textValue).length,day=dayKey(t),plan=activePlan(u,t),limit=plan==='pro'?c.ttsProChars:c.ttsFreeChars,used=u.tts_day===day?u.tts_chars:0;if(used+bytes>limit)return json({error:{code:'tts_limit',message:'Дневной лимит нейро-голоса исчерпан.'},tts:{used,limit,remaining:Math.max(0,limit-used)}},429);let audio;try{audio=await fetch('https://api.fish.audio/v1/tts',{method:'POST',headers:{Authorization:'Bearer '+env.FISH_AUDIO_API_KEY,'Content-Type':'application/json','model':'s2.1-pro-free'},body:JSON.stringify({text:textValue,format:'mp3'})});}catch{await log(env,'error','tts','Fish Audio недоступен',{user:user.email});return err(502,'tts_upstream','Сервис нейро-голоса временно недоступен.');}if(!audio.ok){const code=audio.status;await log(env,'error','tts','Fish Audio вернул '+code,{user:user.email});return err(code===429?429:502,'tts_upstream','Fish Audio не смог создать аудио (код '+code+').');}const blob=await audio.arrayBuffer();await env.DB.prepare('UPDATE users SET tts_day=?,tts_chars=? WHERE sub=?').bind(day,used+bytes,user.sub).run();return new Response(blob,{status:200,headers:{'content-type':audio.headers.get('content-type')||'audio/mpeg','cache-control':'no-store','x-tts-provider':'fish-audio','x-tts-bytes':String(bytes)}});}
  if(p==='/v1/history'){
    if(m==='GET'){const h=await env.DB.prepare('SELECT data FROM histories WHERE sub=?').bind(user.sub).first();return json(h?JSON.parse(h.data):{chats:[]});}
    if(m==='PUT'){let b;try{b=await readJson(req,5*1024*1024);}catch{return err(400,'bad_request','Некорректная история.');}if(!Array.isArray(b.chats))return err(400,'bad_request','Некорректная история.');await env.DB.prepare('INSERT INTO histories(sub,data,updated_at) VALUES(?,?,?) ON CONFLICT(sub) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at').bind(user.sub,JSON.stringify({version:2,at:t,chats:b.chats}),t).run();return json({ok:true});}
    if(m==='DELETE'){await env.DB.prepare('DELETE FROM histories WHERE sub=?').bind(user.sub).run();return json({ok:true});}
  }
  if(p==='/v1/chat'&&m==='POST'){
    if(u.blocked)return err(403,'blocked','Доступ к JARVIS заблокирован администратором.');if(c.maintenance)return err(503,'maintenance',c.announcement||'Идут технические работы.');let provider;try{provider=await chooseProvider(env,c,activePlan(u,t));}catch{return providerUnavailable();}
    let b;try{b=await readJson(req,6*1024*1024);}catch{return err(400,'bad_request','Некорректный запрос.');}if(!Array.isArray(b.messages)||!b.messages.length)return err(400,'bad_request','Нет сообщений.');
    const st=status(u,c,t);if(!st.allowed)return json({error:{code:'daily_limit',message:'Дневной лимит исчерпан.'},status:st},429);
    const msgs=b.messages.slice(-40).filter(x=>x&&['system','user','assistant'].includes(x.role)).map(x=>({role:x.role,content:typeof x.content==='string'?x.content.slice(0,40000):x.content}));if(c.systemPrompt){const rest=msgs.filter(x=>x.role!=='system');const sys=msgs.filter(x=>x.role==='system').map(x=>typeof x.content==='string'?x.content:'').join('\n');msgs.splice(0,msgs.length,{role:'system',content:c.systemPrompt+(sys?'\n\n'+sys:'')},...rest);}
    const day=dayKey(t),nextCount=(u.day_key===day?u.count:0)+1;await env.DB.prepare('UPDATE users SET day_key=?,count=?,total=total+1,last_seen=? WHERE sub=?').bind(day,nextCount,t,user.sub).run();
    let upstream;try{upstream=await fetch(provider.baseUrl+'/chat/completions',{method:'POST',redirect:'manual',headers:{Authorization:'Bearer '+provider.apiKey,'Content-Type':'application/json',...(provider.legacy?{'HTTP-Referer':'https://jarvis-admin.pages.dev','X-Title':'JARVIS AI'}:{})},body:JSON.stringify({model:provider.model,messages:msgs,stream:true,max_tokens:c.maxTokens,...(c.temperature!==null?{temperature:c.temperature}:{}),...(c.topP!==null?{top_p:c.topP}:{})})});}catch{await env.DB.prepare('UPDATE users SET count=MAX(0,count-1),total=MAX(0,total-1) WHERE sub=?').bind(user.sub).run();await log(env,'error','upstream','ИИ-провайдер недоступен',{user:user.email});return err(502,'upstream','ИИ-провайдер недоступен.');}
    if(!upstream.ok){await env.DB.prepare('UPDATE users SET count=MAX(0,count-1),total=MAX(0,total-1) WHERE sub=?').bind(user.sub).run();await log(env,'error','upstream','ИИ-провайдер вернул '+upstream.status,{user:user.email});return err(502,'upstream','ИИ-провайдер вернул ошибку '+upstream.status+'.');}
    return new Response(upstream.body,{status:200,headers:{'content-type':'text/event-stream; charset=utf-8','cache-control':'no-store','x-accel-buffering':'no'}});
  }
  return err(404,'not_found','Не найдено.');
}
export default { async fetch(request,env,ctx) { const origin=request.headers.get('origin');let response;try{response=await handle(request,env,ctx);}catch(e){try{await log(env,'error','worker','Unhandled error');}catch{}response=err(500,'server_error','Внутренняя ошибка сервера.');}const h=new Headers(response.headers);h.set('access-control-allow-origin',origin||'*');h.set('access-control-allow-methods','GET,POST,PUT,PATCH,DELETE,OPTIONS');h.set('access-control-allow-headers','Content-Type,Authorization,X-HTTP-Method-Override');h.set('vary','Origin');h.set('x-content-type-options','nosniff');return new Response(response.body,{status:response.status,statusText:response.statusText,headers:h});} };
