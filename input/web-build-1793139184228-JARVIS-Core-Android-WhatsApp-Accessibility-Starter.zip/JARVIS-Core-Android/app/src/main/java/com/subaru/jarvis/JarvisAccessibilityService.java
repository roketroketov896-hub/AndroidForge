package com.subaru.jarvis;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;

/** User-enabled accessibility service. The yellow halo is a visual indicator, not proof that a click succeeded. */
public class JarvisAccessibilityService extends AccessibilityService {
    public static final String ACTION_STOP = "com.subaru.jarvis.ACTION_STOP_AUTOMATION";
    public static final String ACTION_TAP = "com.subaru.jarvis.ACTION_TAP";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";
    private WindowManager wm;
    private FrameLayout halo;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile boolean stopped = false;
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (ACTION_STOP.equals(intent.getAction())) { stopped = true; hideHalo(); }
            else if (ACTION_TAP.equals(intent.getAction())) {
                stopped = false;
                int x = intent.getIntExtra(EXTRA_X, -1), y = intent.getIntExtra(EXTRA_Y, -1);
                if (x >= 0 && y >= 0) tapAt(x, y);
            }
        }
    };

    @Override public void onServiceConnected() {
        super.onServiceConnected(); wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        IntentFilter f = new IntentFilter(); f.addAction(ACTION_STOP); f.addAction(ACTION_TAP);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver, f);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (stopped || event == null || event.getEventType() != AccessibilityEvent.TYPE_VIEW_CLICKED) return;
        AccessibilityNodeInfo node = event.getSource();
        if (node == null) return;
        Rect r = new Rect(); node.getBoundsInScreen(r); node.recycle();
        if (!r.isEmpty()) showHalo(r.centerX(), r.centerY());
    }

    private void tapAt(int x, int y) {
        if (stopped) return;
        showHalo(x, y);
        Path path = new Path(); path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 90);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gesture) { super.onCompleted(gesture); }
            @Override public void onCancelled(GestureDescription gesture) { super.onCancelled(gesture); }
        }, handler);
    }

    private void showHalo(int x, int y) {
        if (wm == null || stopped) return;
        handler.post(() -> {
            try {
                if (halo == null) {
                    halo = new FrameLayout(this);
                    GradientDrawable circle = new GradientDrawable(); circle.setShape(GradientDrawable.OVAL);
                    circle.setColor(Color.argb(55, 255, 214, 0)); circle.setStroke(4, Color.argb(190, 255, 214, 0));
                    halo.setBackground(circle);
                    WindowManager.LayoutParams p = new WindowManager.LayoutParams(62, 62,
                        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT);
                    p.gravity = Gravity.TOP | Gravity.LEFT; p.x = Math.max(0, x-31); p.y = Math.max(0, y-31);
                    wm.addView(halo, p);
                } else {
                    WindowManager.LayoutParams p = (WindowManager.LayoutParams)halo.getLayoutParams();
                    p.x = Math.max(0, x-31); p.y = Math.max(0, y-31); wm.updateViewLayout(halo, p); halo.setVisibility(android.view.View.VISIBLE);
                }
                handler.removeCallbacks(hideRunnable); handler.postDelayed(hideRunnable, 550);
            } catch (Exception ignored) { }
        });
    }
    private final Runnable hideRunnable = this::hideHalo;
    private void hideHalo() { handler.post(() -> { try { if (halo != null) halo.setVisibility(android.view.View.GONE); } catch (Exception ignored) {} }); }

    @Override public void onInterrupt() { stopped = true; hideHalo(); }
    @Override public void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) { }
        try { if (halo != null) wm.removeView(halo); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
