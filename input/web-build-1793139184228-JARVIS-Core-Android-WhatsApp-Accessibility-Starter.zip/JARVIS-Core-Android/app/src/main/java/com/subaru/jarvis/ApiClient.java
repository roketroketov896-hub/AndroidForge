package com.subaru.jarvis;

import android.content.Context;
import android.util.Base64;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import org.json.JSONArray;
import org.json.JSONObject;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ApiClient {
    public interface Callback { void onSuccess(String answer); void onError(String error); }
    private static final String PREF="jarvis_secure_prefs", KEY_ALIAS="jarvis_api_aes_key";
    private static final String ENDPOINT="https://openrouter.ai/api/v1/chat/completions";
    private static final ExecutorService EXEC=Executors.newSingleThreadExecutor();
    private ApiClient(){}

    private static android.content.SharedPreferences prefs(Context c){ return c.getSharedPreferences(PREF,Context.MODE_PRIVATE); }
    public static String getModel(Context c){ return prefs(c).getString("model","openrouter/auto"); }
    public static void saveModel(Context c,String model){ prefs(c).edit().putString("model",model).apply(); }
    public static boolean hasKey(Context c){ return prefs(c).contains("encrypted_key"); }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if(ks.containsAlias(KEY_ALIAS)) return ((KeyStore.SecretKeyEntry)ks.getEntry(KEY_ALIAS,null)).getSecretKey();
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());
        return gen.generateKey();
    }
    public static void saveKey(Context c,String key) throws Exception {
        SecretKey secret=getOrCreateKey(); Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,secret);
        byte[] iv=cipher.getIV(), encrypted=cipher.doFinal(key.getBytes(StandardCharsets.UTF_8));
        byte[] all=new byte[iv.length+encrypted.length]; System.arraycopy(iv,0,all,0,iv.length); System.arraycopy(encrypted,0,all,iv.length,encrypted.length);
        prefs(c).edit().putString("encrypted_key",Base64.encodeToString(all,Base64.NO_WRAP)).apply();
    }
    private static String readKey(Context c) throws Exception {
        String encoded=prefs(c).getString("encrypted_key",null); if(encoded==null||encoded.isEmpty()) return "";
        byte[] all=Base64.decode(encoded,Base64.NO_WRAP); byte[] iv=new byte[12], encrypted=new byte[all.length-12];
        System.arraycopy(all,0,iv,0,12); System.arraycopy(all,12,encrypted,0,encrypted.length);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE,getOrCreateKey(),new GCMParameterSpec(128,iv));
        return new String(cipher.doFinal(encrypted),StandardCharsets.UTF_8);
    }
    public static void chat(Context c,String prompt,Callback cb){ EXEC.execute(()->request(c,prompt,cb)); }
    public static void test(Context c,Callback cb){ EXEC.execute(()->request(c,"Reply with exactly: JARVIS connection successful.",cb)); }
    private static void request(Context c,String prompt,Callback cb) {
        HttpURLConnection conn=null;
        try {
            String key=readKey(c); if(key.isEmpty()) throw new Exception("API-ключ не сохранён");
            JSONObject body=new JSONObject(); body.put("model",getModel(c));
            JSONArray messages=new JSONArray(); JSONObject system=new JSONObject(); system.put("role","system"); system.put("content","Ты JARVIS — персональный ИИ-помощник. Отвечай естественно, полезно и по делу. Обращайся к владельцу «сэр». Не утверждай, что выполнял действия на телефоне, если это не подтверждено."); messages.put(system);
            JSONObject user=new JSONObject(); user.put("role","user"); user.put("content",prompt); messages.put(user); body.put("messages",messages);
            conn=(HttpURLConnection)new URL(ENDPOINT).openConnection(); conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(30000); conn.setDoOutput(true);
            conn.setRequestProperty("Authorization","Bearer "+key); conn.setRequestProperty("Content-Type","application/json"); conn.setRequestProperty("HTTP-Referer","https://jarvis.local"); conn.setRequestProperty("X-Title","JARVIS Android");
            byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8); conn.getOutputStream().write(bytes);
            int code=conn.getResponseCode(); InputStream stream=(code>=200&&code<300)?conn.getInputStream():conn.getErrorStream();
            String response=readAll(stream); JSONObject json=new JSONObject(response);
            if(code<200||code>=300) {
                String msg=json.optJSONObject("error")!=null?json.getJSONObject("error").optString("message","HTTP "+code):"HTTP "+code;
                throw new Exception(msg.length()>220?msg.substring(0,220):msg);
            }
            JSONArray choices=json.optJSONArray("choices"); if(choices==null||choices.length()==0) throw new Exception("Модель вернула пустой ответ");
            String answer=choices.getJSONObject(0).getJSONObject("message").optString("content","").trim();
            if(answer.isEmpty()) throw new Exception("Пустой ответ от модели");
            cb.onSuccess(answer);
        } catch(Exception e) { String m=e.getMessage(); cb.onError(m==null?"неизвестная ошибка":m); }
        finally { if(conn!=null) conn.disconnect(); }
    }
    private static String readAll(InputStream in) throws Exception {
        if(in==null) return "{}"; ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] b=new byte[4096]; int n;
        while((n=in.read(b))!=-1) out.write(b,0,n); in.close(); return new String(out.toByteArray(),StandardCharsets.UTF_8);
    }
}
