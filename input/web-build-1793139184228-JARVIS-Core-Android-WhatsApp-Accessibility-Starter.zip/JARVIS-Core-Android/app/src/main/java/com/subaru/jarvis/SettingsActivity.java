package com.subaru.jarvis;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;

public class SettingsActivity extends Activity {
    private int bg = Color.rgb(8,13,25), panel = Color.rgb(18,27,45), blue = Color.rgb(68,190,255), white = Color.rgb(235,243,255);
    private EditText keyInput, modelInput;
    private TextView status;
    private boolean reveal = false;

    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private TextView text(String value, int size, int color) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); return t; }
    private Button button(String label) { Button b = new Button(this); b.setText(label); return b; }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,22,20,20); root.setBackgroundColor(bg);
        ScrollView scroll = new ScrollView(this); LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("СЕКРЕТНЫЕ НАСТРОЙКИ", 21, white); title.setTypeface(null, Typeface.BOLD); content.addView(title);
        TextView subtitle = text("Подключение модели JARVIS", 13, blue); subtitle.setPadding(0,5,0,18); content.addView(subtitle);
        TextView providerLabel = text("ПРОВАЙДЕР", 11, blue); content.addView(providerLabel);
        TextView provider = text("OpenRouter  •  openrouter.ai", 16, white); provider.setPadding(14,14,14,14); provider.setBackground(shape(panel,16));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1,-2); pp.topMargin=7; pp.bottomMargin=18; content.addView(provider,pp);
        content.addView(text("API-КЛЮЧ", 11, blue));
        LinearLayout keyRow = new LinearLayout(this); keyRow.setGravity(Gravity.CENTER_VERTICAL); keyRow.setBackground(shape(panel,16)); keyRow.setPadding(8,2,4,2);
        keyInput = new EditText(this); keyInput.setSingleLine(true); keyInput.setTextColor(white); keyInput.setHintTextColor(Color.rgb(130,145,165)); keyInput.setHint("sk-or-v1-…"); keyInput.setTextSize(14);
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); keyInput.setBackgroundColor(Color.TRANSPARENT);
        keyRow.addView(keyInput,new LinearLayout.LayoutParams(0,-2,1));
        Button eye=button("Показать"); eye.setTextSize(10); eye.setOnClickListener(v -> { reveal=!reveal; keyInput.setInputType(InputType.TYPE_CLASS_TEXT | (reveal ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD)); keyInput.setSelection(keyInput.length()); eye.setText(reveal?"Скрыть":"Показать"); });
        keyRow.addView(eye); LinearLayout.LayoutParams krp=new LinearLayout.LayoutParams(-1,-2); krp.topMargin=7; krp.bottomMargin=6; content.addView(keyRow,krp);
        TextView hint=text("Ключ хранится в зашифрованном виде на этом устройстве. Не отправляйте его в чат.",11,Color.rgb(145,161,184)); content.addView(hint);
        TextView modelLabel=text("МОДЕЛЬ",11,blue); modelLabel.setPadding(0,20,0,0); content.addView(modelLabel);
        modelInput=new EditText(this); modelInput.setSingleLine(true); modelInput.setTextColor(white); modelInput.setHintTextColor(Color.rgb(130,145,165)); modelInput.setHint("Например: openrouter/auto"); modelInput.setTextSize(14); modelInput.setPadding(14,12,14,12); modelInput.setBackground(shape(panel,16)); content.addView(modelInput,new LinearLayout.LayoutParams(-1,-2));
        TextView modelHint=text("Можно указать идентификатор любой модели, доступной вашему аккаунту OpenRouter.",11,Color.rgb(145,161,184)); modelHint.setPadding(0,6,0,0); content.addView(modelHint);
        Button save=button("СОХРАНИТЬ НАСТРОЙКИ"); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=20; content.addView(save,bp);
        Button test=button("ПРОВЕРИТЬ ПОДКЛЮЧЕНИЕ"); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2); tp.topMargin=8; content.addView(test,tp);
        status=text("Статус: настройки ещё не проверены",12,Color.rgb(145,161,184)); status.setPadding(4,12,4,12); content.addView(status);
        Button back=button("НАЗАД В JARVIS"); content.addView(back);
        TextView note=text("Важно: прямой вызов API из APK подходит для личного тестирования, но ключ теоретически можно извлечь с устройства. Для публикации приложения лучше использовать собственный сервер-посредник.",11,Color.rgb(145,161,184)); note.setPadding(0,18,0,8); content.addView(note);
        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        modelInput.setText(ApiClient.getModel(this));
        save.setOnClickListener(v -> saveSettings());
        test.setOnClickListener(v -> { saveSettings(); if (!ApiClient.hasKey(this)) { setStatus("Вставьте API-ключ OpenRouter.", true); return; } setStatus("Проверяю соединение…", false); test.setEnabled(false); ApiClient.test(this,new ApiClient.Callback(){ public void onSuccess(String s){runOnUiThread(()->{test.setEnabled(true);setStatus("Подключение успешно. Ответ получен от OpenRouter.",false);});} public void onError(String e){runOnUiThread(()->{test.setEnabled(true);setStatus("Ошибка: "+e,true);});}}); });
        back.setOnClickListener(v -> finish());
    }
    private void saveSettings() {
        String key=keyInput.getText().toString().trim(); String model=modelInput.getText().toString().trim();
        if (!key.isEmpty()) { try { ApiClient.saveKey(this,key); } catch(Exception e) { setStatus("Не удалось зашифровать ключ: "+e.getMessage(),true); return; } }
        if (model.isEmpty()) model="openrouter/auto";
        ApiClient.saveModel(this,model);
        setStatus("Настройки сохранены на устройстве.",false);
        Toast.makeText(this,"Настройки сохранены",Toast.LENGTH_SHORT).show();
    }
    private void setStatus(String s, boolean error) { status.setText("Статус: "+s); status.setTextColor(error?Color.rgb(255,130,130):blue); }
}
