# Установка и бесплатный тестовый деплой JARVIS AI

## Ограничения бесплатного размещения

Рекомендуемая схема для теста: **Render Free Web Service + Neon Free PostgreSQL**.

- Render предоставляет HTTPS/Node.js на Free compute, но локальная файловая система эфемерная: данные при перезапуске/сне теряются, а сервис засыпает после 15 минут без запросов. Бесплатный Render Postgres истекает через 30 дней — его здесь использовать нельзя.
- Neon Free даёт постоянный PostgreSQL, ограничение 1 GB на проект и 100 CU-часов в месяц; по текущей странице тарифов это бесплатный план без срока окончания и без банковской карты.
- Render предупреждает, что free-инстансы предназначены для тестирования/хобби, а не production; возможны холодный старт, приостановка по лимитам и приостановка при необычно высоком исходящем трафике. Поэтому бесплатная схема не является надёжной production-гарантией для публичного приложения.

Проверь условия на страницах [Render Free](https://render.com/docs/free) и [Neon Pricing](https://neon.com/pricing) непосредственно перед регистрацией: лимиты и тарифы могут меняться. Если сайт регистрации потребует карту, оплату или переход на платный план — остановись; платную услугу этот архив не включает и не оформляет.

## Подготовка хостинга

1. Создай Neon проект на Free плане и скопируй PostgreSQL connection string. Это пароль к базе: не публикуй его и не вставляй в чат.
2. Создай репозиторий, содержащий содержимое папки `backend` в его корне, либо укажи в Render корневую папку `backend`.
3. Подключи репозиторий к Render и выбери blueprint `render.yaml`. Выбери только **Free** compute; не добавляй disk, платные базы или дополнения.
4. Введи требуемые секреты и значения в Render Environment:
   - `DATABASE_URL` — Neon connection string;
   - `ADMIN_API_KEY` — отдельная случайная строка не менее 32 байт;
   - `CONFIG_SECRET` — другая случайная строка не менее 32 байт;
   - `GOOGLE_WEB_CLIENT_ID` — Web Client ID для входа USER.
5. Сохрани переменные и запусти бесплатное развёртывание. Не указывай `ADMIN_MODE=open`; blueprint выбирает `key`.
6. После завершения скопируй фактический HTTPS URL из Render Dashboard. Проверь `https://<этот-адрес>/health`. Пока настоящий деплой не завершён, URL не существует — не используй примерные домены.
7. В ADMIN Android-приложении выбери **Система**, введи полученный HTTPS URL и то же значение `ADMIN_API_KEY`; ключ передаётся только через HTTPS и хранится в приложении только в оперативной памяти.

В бесплатном режиме не ожидай постоянного процесса: первый запрос после сна может ждать запуск сервера. Данные хранятся в Neon, не в файловой системе Render. Скачивай резервные копии базы отдельно; бесплатный план не является заменой проверенной backup-политике.

## Переменные окружения

### Нужны для описанной схемы

| Переменная | Где получить/как использовать |
|---|---|
| `ADMIN_MODE=key` | Безопасный режим авторизации ADMIN-клиента. |
| `ADMIN_API_KEY` | Сгенерировать локально командой `openssl rand -hex 32`; один и тот же секрет в Render и поле ключа на устройстве ADMIN. |
| `CONFIG_SECRET` | Отдельно сгенерировать, например `openssl rand -hex 48`; шифрует AI/TTS ключи, введённые в ADMIN. |
| `DATABASE_URL` | Connection string из Neon; хранить в Render Secrets. |
| `GOOGLE_WEB_CLIENT_ID` | Google Cloud Console → OAuth Client ID типа Web application; совпадает с `JARVIS_WEB_CLIENT_ID` в USER-сборке. |

### Необязательные

`OPENROUTER_API_KEY`, `AZURE_SPEECH_KEY`, `AZURE_SPEECH_REGION`, `ADMIN_EMAILS` (только для `ADMIN_MODE=google`), `FREE_MODEL`, `PRO_MODEL`, `DAILY_LIMIT`, `PRO_DAILY_LIMIT`, `UNLIMITED_DAYS`, `MAX_TOKENS`, `TTS_FREE_CHARS`, `TTS_PRO_CHARS`, `VOICE_RU`, `VOICE_AZ`, `VOICE_TR`, `VOICE_EN`, `TRUST_PROXY=1`.

Для AI добавь OpenRouter key через Render Secrets или сохрани его из защищённой ADMIN-панели после задания `CONFIG_SECRET`. Получить ключ можно в аккаунте OpenRouter в разделе API Keys. Использование OpenRouter может стоить денег; ключ в этой поставке не задан и сервис без него отвечает `503 not_configured`. Для нейро-голоса отдельно нужна подписка/ключ Azure Speech; он не задан и не подключался.

`PORT` назначает хостинг. `DATA_FILE` применяется только при файловом режиме; на Render Free его нельзя использовать для важных данных. `DATABASE_URL` делает PostgreSQL источником данных.

## Подключение JARVIS USER

1. Получи и сохрани Google OAuth Web Client ID.
2. В корневом `jarvis-config.properties` укажи:

   ```properties
   JARVIS_BACKEND_URL=https://<фактический-render-url>
   JARVIS_WEB_CLIENT_ID=<Google-Web-Client-ID>
   ```

3. На backend задай тот же `GOOGLE_WEB_CLIENT_ID`.
4. Пересобери USER APK и выполни Google sign-in. Без валидного Google ID token маршруты `/v1/status`, `/v1/chat`, `/v1/tts` и `/v1/history` возвращают 401.
5. Серверный бесплатный режим использует OpenRouter key, заданный оператором. Режим личного API key в USER-приложении остаётся прямым соединением с выбранным провайдером и не использует server quota.

## Подключение JARVIS ADMIN

1. Используй изменённый исходник ADMIN из `JARVIS_ADMIN_KEY_PATCH.zip` либо перенеси четыре изменённых файла в исходный проект.
2. Собери и установи обновлённый ADMIN APK.
3. В **Система** введи HTTPS URL и `ADMIN_API_KEY`, затем сохрани и проверь подключение. Из-за режима только в памяти повторно вводи ключ после полного закрытия приложения.
4. Старый ADMIN APK не отправляет `X-Admin-Key`. Не переводите публичный сервер на `ADMIN_MODE=open` ради старой версии: обнови APK либо временно не используй публичное администрирование.

## Переменные Android-сборки

`JARVIS_BACKEND_URL` и `JARVIS_WEB_CLIENT_ID` задаются в корневом `jarvis-config.properties` перед USER-сборкой. ADMIN принимает адрес и admin key в интерфейсе и не требует вшивать секрет в APK.

## Что не выполнено в этом архиве

Публичный сервер не развёрнут, внешний аккаунт Render/Neon не подключён, реальные секреты не предоставлялись, а публичный HTTPS URL не подтверждён HTTP-запросом. До ввода собственных Google Client ID и подключения БД/хостинга проверить живые USER/ADMIN приложения невозможно. Инструкция не выдаёт пример URL за действующий сервер.

## Вход администратора через Google (ADMIN_MODE=google)
Переменные: `ADMIN_MODE=google`, `GOOGLE_WEB_CLIENT_ID` (тот же Web Client ID, что в ADMIN и USER), `ADMIN_EMAILS` (подтверждённые почты через запятую). Админ-APK отправляет `Authorization: Bearer <Google ID token>`; сервер проверяет подпись, `iss`, `aud`, срок и почту. Маршруты `/admin/*` без токена, с чужим токеном или с почтой не из списка закрыты (401/403). `GET /health` показывает `adminMode`, `adminConfigured`, `googleConfigured` (без секретов). Тесты: `node admin-google.test.mjs`.
