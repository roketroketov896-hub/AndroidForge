# JARVIS AI backend

Backend Node.js for the existing JARVIS USER and JARVIS ADMIN Android apps. The public Android API paths and request/response formats are unchanged.

## Requirements and local run

- Node.js 18 or newer
- npm
- No AI, Google, or Azure credentials are needed to run the local backend test suite.

```sh
npm install
npm test
npm start
```

The server listens on `PORT` (default `8080`). For local development without `DATABASE_URL`, it stores the database at `DATA_FILE` (default `./data/jarvis-data.json`). Local JSON storage is atomic, uses restrictive file permissions, and refuses to start if an existing file is malformed rather than replacing it with an empty database.
The Dockerfile stores its JSON file under `/data`; attach a named persistent volume at that path or use `DATABASE_URL`. Do not assume a container's writable layer survives image replacement.

## Storage

Choose one of these modes:

- **Local JSON file:** leave `DATABASE_URL` unset. Use this only on a machine or host with a persistent disk. Back up the data file.
- **PostgreSQL:** set `DATABASE_URL`. The server creates a `jarvis_state` table and stores the existing `users`, `history`, and `config` state as one JSONB document. When the database is empty, an existing local JSON file is copied into it once. Once a database row exists, PostgreSQL is authoritative.

PostgreSQL mode is intended for one backend instance, matching the current single-process design. It is not a multi-instance coordination or high-scale database design.

## Environment variables

| Variable | Required | Purpose |
|---|---:|---|
| `ADMIN_MODE` | Yes in deployment | `key` is recommended for the Android ADMIN app; `google` checks `ADMIN_EMAILS`; `open` disables admin authentication and is unsafe on a public server. |
| `ADMIN_API_KEY` | With `ADMIN_MODE=key` | Random secret of 32–1024 bytes. Sent by the ADMIN app in `X-Admin-Key` over HTTPS; the app keeps it in memory only. |
| `CONFIG_SECRET` | To save provider keys in ADMIN | Random secret of at least 32 bytes. Encrypts OpenRouter/Azure keys before storing the database state and migrates legacy `plain:` key fields on startup. If moving such legacy data into a new empty database, this secret is required. |
| `DATABASE_URL` | For hosted free storage | PostgreSQL connection string, for example from a Neon project. Treat it as a password. |
| `GOOGLE_WEB_CLIENT_ID` | For USER Google sign-in | Google OAuth Web Client ID used to validate USER ID tokens. |
| `ADMIN_EMAILS` | Only for `ADMIN_MODE=google` | Comma-separated administrator email addresses. |
| `OPENROUTER_API_KEY` | Optional | Server-side OpenRouter key. Alternatively, enter it in ADMIN after setting `CONFIG_SECRET`. Chat returns `503` until a key is configured. |
| `AZURE_SPEECH_KEY` | Optional | Azure Speech key for server-backed neural TTS. |
| `AZURE_SPEECH_REGION` | With Azure TTS | Azure Speech resource region. |
| `DATA_FILE` | Optional | Local JSON path when `DATABASE_URL` is not set. |
| `PORT` | Hosting supplies it | HTTP port; defaults to `8080` locally. |
| `TRUST_PROXY` | Optional | Set to `1` only when running behind the trusted hosting proxy, so IP rate limits use the forwarded client IP. |
| `FREE_MODEL`, `PRO_MODEL` | Optional | OpenRouter model names. |
| `DAILY_LIMIT`, `PRO_DAILY_LIMIT`, `UNLIMITED_DAYS`, `MAX_TOKENS` | Optional | Initial quotas and model request limits. |
| `TTS_FREE_CHARS`, `TTS_PRO_CHARS` | Optional | Daily TTS character budgets. |
| `VOICE_RU`, `VOICE_AZ`, `VOICE_TR`, `VOICE_EN` | Optional | Default Azure Speech voices. |

Generate secrets locally; do not paste them into chat or commit them:

```sh
openssl rand -hex 32
openssl rand -hex 48
```

Use separate generated values for `ADMIN_API_KEY` and `CONFIG_SECRET`, and store both only in the hosting provider's environment/secrets UI.

## Android integration

### JARVIS USER

The USER app keeps the existing API contract and requires a Google ID token for server-backed free mode:

- `GET /health`
- `GET /v1/app-config` (public app settings)
- `GET /v1/status`
- `POST /v1/chat` (streamed SSE response)
- `POST /v1/tts` (audio/mpeg response)
- `GET`, `PUT`, `DELETE /v1/history`

Set `JARVIS_BACKEND_URL=https://<actual-host>` and `JARVIS_WEB_CLIENT_ID=<Google Web Client ID>` in the root `jarvis-config.properties` before building the USER APK. The Google Web Client ID must match the backend's `GOOGLE_WEB_CLIENT_ID`. Without it, Google sign-in is unavailable. The app's own-provider mode remains direct-to-provider and does not use the backend quota.

### JARVIS ADMIN

The ADMIN app keeps the existing `/admin/*` routes and request bodies. The updated ADMIN source adds the `X-Admin-Key` header and a password field in **Система**:

1. Set `ADMIN_MODE=key` and `ADMIN_API_KEY` on the server.
2. Apply the source files from the separate `JARVIS_ADMIN_KEY_PATCH.zip`, then build/install the updated ADMIN APK.
3. Enter the real HTTPS server URL and the matching key under **Система**.

The key is held only in process memory and must be re-entered after the app closes. No API key is included in the APK. The old ADMIN APK sends neither `X-Admin-Key` nor a Google bearer token; against this backend it only works in the legacy `open` mode (unsafe) unless an external authentication proxy is added.

## API routes

**Public:** `GET /health`, `GET /v1/app-config`.

**USER (Google ID token required):** `GET /v1/status`, `POST /v1/chat`, `POST /v1/tts`, and `GET|PUT|DELETE /v1/history`.

**ADMIN (controlled by `ADMIN_MODE`):**

- `GET /admin/me`, `GET|PUT /admin/config`
- `POST /admin/test-key`, `POST /admin/test-tts`
- `GET /admin/integrations`, `GET /admin/stats`
- `GET|DELETE /admin/logs`, `GET /admin/diagnostics`
- `GET /admin/users`, `PATCH /admin/users/:sub`

The ADMIN Android client uses `POST` with `X-HTTP-Method-Override: PATCH` for the user update route, as before.

## AI providers and cost

The backend server-side AI implementation uses OpenRouter. No OpenRouter or Azure credentials are bundled here. The USER app's personal API-key mode is a separate direct connection from the device. No paid provider has been enabled or called by this delivery. OpenRouter usage may be billed by the provider; configure a key only after checking that account's terms and limits.

## Deployment notes

`render.yaml` is a free-tier blueprint for a Node web service that uses an external PostgreSQL `DATABASE_URL`; it intentionally does not attach a paid disk or an expiring Render Free Postgres database. Render Free services sleep after inactivity, can have cold starts, and are documented as unsuitable for production. Treat this as a zero-cost test/low-traffic option, not a production availability guarantee. See `DEPLOYMENT_RU.md`.

## Tests

Run `npm test`. The backend tests use local mock upstreams and an in-memory PostgreSQL adapter fake; they do not call Google, OpenRouter, Azure Speech, Neon, or a public deployment. The Android browser E2E scripts live in the project-level `tests/` folder and require Playwright plus Chromium.
