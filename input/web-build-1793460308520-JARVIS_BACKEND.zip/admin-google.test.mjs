// Вход администратора через Google: реальные подписанные RS256-токены, проверка подписи, aud, срока, iss и ADMIN_EMAILS.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
import { createApp } from './server.mjs';

const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const jwk = { ...publicKey.export({ format: 'jwk' }), kid: 'k1', alg: 'RS256', use: 'sig' };
const enc = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const sign = (payload, key = privateKey, alg = 'RS256') => { const h = enc({ alg, kid: 'k1', typ: 'JWT' }), p = enc(payload); return h + '.' + p + '.' + crypto.sign('RSA-SHA256', Buffer.from(h + '.' + p), key).toString('base64url'); };
const CID = '123-web.apps.googleusercontent.com';
const base = { iss: 'https://accounts.google.com', aud: CID, sub: 'S1', email: 'Boss@Example.com', email_verified: true, exp: Math.floor(Date.now() / 1000) + 600 };

const app = createApp({ dataFile: path.join(os.tmpdir(), 'ag-' + Date.now() + '.json'), googleClientId: CID, adminMode: 'google', adminEmails: ['boss@example.com'], getJwks: async () => ({ keys: [jwk] }), ipLimitPerMin: 1e6, openrouterKey: 'k' });
await new Promise((r) => app.server.listen(0, r));
const url = 'http://127.0.0.1:' + app.server.address().port;
const get = (p, tok, extra = {}) => fetch(url + p, { headers: { ...(tok ? { Authorization: 'Bearer ' + tok } : {}), ...extra } });

assert.equal((await (await get('/health')).json()).adminMode, 'google');
assert.equal((await get('/admin/me')).status, 401, 'без токена админ-маршруты закрыты');
assert.equal((await get('/admin/config', null, { 'X-Admin-Key': 'x'.repeat(40) })).status, 401, 'посторонний заголовок не даёт доступа');
const ok = await get('/admin/me', sign(base)); assert.equal(ok.status, 200); assert.equal((await ok.json()).admin, true);
assert.equal((await get('/admin/users', sign(base))).status, 200);
assert.equal((await get('/admin/me', sign({ ...base, email: 'other@example.com' }))).status, 403, 'не из ADMIN_EMAILS');
assert.equal((await get('/admin/me', sign({ ...base, email_verified: false }))).status, 403, 'почта не подтверждена');
assert.equal((await get('/admin/me', sign({ ...base, aud: 'other.apps.googleusercontent.com' }))).status, 401, 'чужая аудитория');
assert.equal((await get('/admin/me', sign({ ...base, exp: Math.floor(Date.now() / 1000) - 10 }))).status, 401, 'истёкший токен');
assert.equal((await get('/admin/me', sign({ ...base, iss: 'https://evil.example' }))).status, 401, 'чужой издатель');
const other = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 }).privateKey;
assert.equal((await get('/admin/me', sign(base, other))).status, 401, 'чужая подпись');
assert.equal((await get('/admin/me', 'not.a.jwt')).status, 401);
// PATCH через переопределение метода (так отправляет Android) тоже требует токен
assert.equal((await fetch(url + '/admin/users/x', { method: 'POST', headers: { 'X-HTTP-Method-Override': 'PATCH', 'Content-Type': 'application/json' }, body: '{}' })).status, 401);
app.server.close();
console.log('admin google tests passed');
process.exit(0);
