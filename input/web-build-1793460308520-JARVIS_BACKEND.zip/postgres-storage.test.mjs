import assert from 'node:assert/strict';
import { createPostgresStorage } from './postgres-storage.mjs';

class FakePool {
  static latest;
  constructor(options) {
    FakePool.latest = this;
    this.options = options;
    this.queries = [];
    this.state = null;
    this.closed = false;
  }
  on() {}
  async query(sql, params = []) {
    this.queries.push(sql.replace(/\s+/g, ' ').trim());
    if (sql.includes('SELECT state')) return { rows: this.state === null ? [] : [{ state: this.state }] };
    if (sql.includes('INSERT INTO jarvis_state')) {
      this.state = JSON.parse(params[0]);
      return { rows: [] };
    }
    return { rows: [] };
  }
  async end() { this.closed = true; }
}

const store = await createPostgresStorage('postgresql://placeholder/jarvis?sslmode=require', { PoolClass: FakePool });
assert.equal(FakePool.latest.options.max, 1);
assert.match(FakePool.latest.queries[0], /CREATE TABLE IF NOT EXISTS jarvis_state/);
assert.equal(await store.load(), null);

const state = { users: { u1: { plan: 'free' } }, history: {}, config: { dailyLimit: 5 } };
await store.save(state);
assert.deepEqual(await store.load(), state);
assert.ok(FakePool.latest.queries.some((q) => /ON CONFLICT \(id\) DO UPDATE/.test(q)));
await store.close();
assert.equal(FakePool.latest.closed, true);
console.log('postgres storage adapter tests passed');
