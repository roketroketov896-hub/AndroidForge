// Single-document durable storage for the existing JARVIS JSON data model.
// Intended for one backend instance; it deliberately preserves the existing
// users/history/config shape instead of changing the Android-facing API.
export async function createPostgresStorage(connectionString, options = {}) {
  if (typeof connectionString !== 'string' || !connectionString.trim()) {
    throw new Error('DATABASE_URL is required for PostgreSQL storage');
  }

  let Pool = options.PoolClass;
  if (!Pool) {
    const pg = await import('pg');
    Pool = pg.Pool || pg.default?.Pool;
  }
  if (!Pool) throw new Error('The pg package does not expose Pool');

  const pool = new Pool({
    connectionString: connectionString.trim(),
    max: 1,
    connectionTimeoutMillis: 10000,
    idleTimeoutMillis: 30000,
  });
  pool.on('error', (error) => {
    console.error('postgres idle client error', String(error?.code || error?.name || 'error').slice(0, 64));
  });

  await pool.query(`
    CREATE TABLE IF NOT EXISTS jarvis_state (
      id SMALLINT PRIMARY KEY CHECK (id = 1),
      state JSONB NOT NULL,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )
  `);

  return {
    async load() {
      const result = await pool.query('SELECT state FROM jarvis_state WHERE id = 1');
      return result.rows[0]?.state ?? null;
    },
    async save(state) {
      await pool.query(
        `INSERT INTO jarvis_state (id, state, updated_at)
         VALUES (1, $1::jsonb, now())
         ON CONFLICT (id) DO UPDATE
         SET state = EXCLUDED.state, updated_at = now()`,
        [JSON.stringify(state)],
      );
    },
    close() {
      return pool.end();
    },
  };
}
