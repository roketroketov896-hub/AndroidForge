package com.example.pocketcalculator;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.math.BigDecimal;
import java.math.MathContext;

public class MainActivity extends Activity {
    private TextView display;
    private String current = "0";
    private double stored = 0;
    private String operator = "";
    private boolean startNew = true;
    private final int dark = Color.rgb(22, 25, 33);
    private final int panel = Color.rgb(35, 40, 52);
    private final int accent = Color.rgb(70, 130, 255);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(dark);
        getWindow().setNavigationBarColor(dark);
        getWindow().getDecorView().setSystemUiVisibility(0);

        LinearLayout base = new LinearLayout(this);
        base.setOrientation(LinearLayout.VERTICAL);
        base.setPadding(dp(18), dp(24), dp(18), dp(18));
        base.setBackgroundColor(dark);

        TextView title = new TextView(this);
        title.setText("КАЛЬКУЛЯТОР");
        title.setTextColor(Color.LTGRAY);
        title.setTextSize(14);
        title.setLetterSpacing(0.12f);
        title.setGravity(Gravity.CENTER_VERTICAL);
        base.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        display = new TextView(this);
        display.setText("0");
        display.setTextColor(Color.WHITE);
        display.setTextSize(42);
        display.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        display.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        display.setSingleLine(true);
        display.setPadding(0, dp(10), dp(4), dp(18));
        base.addView(display, new LinearLayout.LayoutParams(-1, 0, 1.2f));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(5);
        String[][] keys = {
            {"AC", "±", "%", "÷"},
            {"7", "8", "9", "×"},
            {"4", "5", "6", "−"},
            {"1", "2", "3", "+"},
            {"⌫", "0", ".", "="}
        };
        for (String[] row : keys) {
            for (String key : row) {
                Button b = new Button(this);
                b.setText(key);
                b.setTextSize(22);
                b.setAllCaps(false);
                b.setTextColor(Color.WHITE);
                b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                    isOperator(key) ? accent : (key.equals("AC") || key.equals("⌫") || key.equals("%") || key.equals("±") ? panel : Color.rgb(48, 54, 68))
                ));
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = 0;
                lp.height = dp(68);
                lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
                lp.setMargins(dp(4), dp(4), dp(4), dp(4));
                grid.addView(b, lp);
                b.setOnClickListener(v -> press(key));
            }
        }
        base.addView(grid, new LinearLayout.LayoutParams(-1, 0, 3f));
        setContentView(base);
    }

    private boolean isOperator(String k) {
        return k.equals("÷") || k.equals("×") || k.equals("−") || k.equals("+") || k.equals("=");
    }
    private void press(String k) {
        if (k.equals("AC")) { current="0"; stored=0; operator=""; startNew=true; update(); return; }
        if (k.equals("⌫")) {
            if (startNew) return;
            current = current.length() <= 1 || (current.length()==2 && current.startsWith("-")) ? "0" : current.substring(0,current.length()-1);
            update(); return;
        }
        if (k.equals("±")) {
            if (!current.equals("0")) current = current.startsWith("-") ? current.substring(1) : "-" + current;
            update(); return;
        }
        if (k.equals("%")) {
            try { current = fmt(Double.parseDouble(current)/100.0); update(); } catch(Exception ignored) {}
            return;
        }
        if (k.equals(".")) {
            if (startNew) { current="0."; startNew=false; }
            else if (!current.contains(".")) current += ".";
            update(); return;
        }
        if (k.matches("[0-9]")) {
            if (startNew || current.equals("0")) { current=k; startNew=false; }
            else if (current.length()<15) current += k;
            update(); return;
        }
        if (k.equals("=")) {
            calculate(); operator=""; startNew=true; update(); return;
        }
        if (!operator.isEmpty() && !startNew) calculate();
        try { stored=Double.parseDouble(current); } catch(Exception e) { stored=0; }
        operator=k; startNew=true; update();
    }
    private void calculate() {
        if (operator.isEmpty()) return;
        double rhs;
        try { rhs=Double.parseDouble(current); } catch(Exception e) { return; }
        double result;
        switch(operator) {
            case "+": result=stored+rhs; break;
            case "−": result=stored-rhs; break;
            case "×": result=stored*rhs; break;
            case "÷":
                if (rhs==0) { Toast.makeText(this, "На ноль делить нельзя", Toast.LENGTH_SHORT).show(); current="0"; return; }
                result=stored/rhs; break;
            default: return;
        }
        if (Double.isNaN(result) || Double.isInfinite(result)) { current="0"; return; }
        current=fmt(result);
    }
    private String fmt(double v) {
        if (Math.abs(v) < 1e-10) v=0;
        return BigDecimal.valueOf(v).round(new MathContext(12)).stripTrailingZeros().toPlainString();
    }
    private void update() { display.setText(current); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
