const $ = (s) => document.querySelector(s);
const promptBox = $("#prompt"), messages = $("#messages"), welcome = $("#welcome"), toast = $("#toast");
let toastTimer;
let conversation = [];
let busy = false;
const DEFAULT_SYSTEM = "Ты NOVA — дружелюбный AI-помощник. Отвечай понятно, полезно и на языке пользователя. Если не знаешь ответ, честно скажи об этом.";
function notify(text) {
  toast.textContent = text; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}
function getKey(){ return $("#apiKey").value.trim(); }
function getModel(){ return $("#modelId").value.trim(); }
function addMessage(text, who, options={}) {
  welcome.style.display = "none";
  const wrap = document.createElement("div");
  wrap.className = `message ${who}`;
  const avatar = document.createElement("div");
  avatar.className = "message-avatar"; avatar.textContent = who === "user" ? "Я" : "✦";
  const body = document.createElement("div");
  const bubble = document.createElement("div"); bubble.className = "bubble"; bubble.textContent = text;
  body.appendChild(bubble);
  if (who === "assistant" && !options.loading) {
    const tools = document.createElement("div"); tools.className = "message-tools";
    const copy = document.createElement("button"); copy.className = "mini-btn"; copy.textContent = "Копировать";
    copy.addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(text); notify("Ответ скопирован"); }
      catch { notify("Не удалось скопировать — попробуй выделить текст"); }
    });
    const speak = document.createElement("button"); speak.className = "mini-btn"; speak.textContent = "🔊 Озвучить";
    speak.addEventListener("click", () => speakText(text)); tools.append(copy, speak); body.appendChild(tools);
  }
  wrap.append(avatar, body); messages.appendChild(wrap);
  wrap.scrollIntoView({behavior:"smooth", block:"nearest"});
  return {wrap, bubble};
}
function setBusy(value){
  busy=value;
  const btn=$(".send-btn"); btn.disabled=value; btn.textContent=value?"…":"↑";
  promptBox.disabled=value;
}
function errorMessage(err, status){
  if(status===401 || status===403) return "OpenRouter не принял ключ. Проверь API key в настройках NOVA.";
  if(status===402) return "Похоже, для этой модели не хватает доступного баланса или лимита в OpenRouter.";
  if(status===429) return "Слишком много запросов или сработал лимит. Подожди немного и попробуй снова.";
  if(status===404) return "Модель не найдена. Проверь её ID в каталоге OpenRouter.";
  return "Не удалось получить ответ от OpenRouter. Проверь интернет, ключ и ID модели, затем попробуй снова. Подробности: " + (err || "неизвестная ошибка");
}
async function callOpenRouter(userText){
  const key=getKey(), model=getModel();
  if(!key){notify("Сначала добавь OpenRouter API key в настройках ⚙"); openSettings(); return;}
  if(!model){notify("Укажи ID модели в настройках ⚙"); openSettings(); return;}
  conversation.push({role:"user",content:userText});
  const system=$("#systemPrompt").value.trim() || DEFAULT_SYSTEM;
  const payload={model, messages:[{role:"system",content:system},...conversation], temperature:0.7};
  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method:"POST",
    headers:{"Authorization":"Bearer "+key,"Content-Type":"application/json","X-OpenRouter-Title":"NOVA AI"},
    body:JSON.stringify(payload)
  });
  let data={};
  try { data=await response.json(); } catch {}
  if(!response.ok) throw new Error((data && data.error && data.error.message) || ("HTTP "+response.status));
  const answer=data?.choices?.[0]?.message?.content;
  if(typeof answer!=="string" || !answer.trim()) throw new Error("Модель вернула пустой ответ");
  conversation.push({role:"assistant",content:answer});
  return answer.trim();
}
async function sendMessage(text) {
  const clean=text.trim(); if(!clean || busy) return;
  addMessage(clean,"user"); promptBox.value=""; resizeInput(); setBusy(true);
  const loading=addMessage("NOVA думает…","assistant",{loading:true});
  try {
    const answer=await callOpenRouter(clean);
    loading.bubble.textContent=answer;
    const tools=document.createElement("div"); tools.className="message-tools";
    const copy=document.createElement("button");copy.className="mini-btn";copy.textContent="Копировать";
    copy.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(answer);notify("Ответ скопирован")}catch{notify("Не удалось скопировать")}});
    const speak=document.createElement("button");speak.className="mini-btn";speak.textContent="🔊 Озвучить";speak.addEventListener("click",()=>speakText(answer));
    tools.append(copy,speak);loading.bubble.parentElement.appendChild(tools);
  } catch(e) {
    // Remove the failed user turn from local conversation so the user can retry cleanly.
    if(conversation.length && conversation[conversation.length-1].role==="user") conversation.pop();
    loading.bubble.textContent=errorMessage(e.message, Number((e.message.match(/HTTP (\d+)/)||[])[1]||0));
    notify("Не получилось получить ответ");
  } finally {setBusy(false);promptBox.focus();}
}
function resizeInput(){ promptBox.style.height="auto"; promptBox.style.height=Math.min(promptBox.scrollHeight,140)+"px"; }
$("#chatForm").addEventListener("submit", e => { e.preventDefault(); sendMessage(promptBox.value); });
promptBox.addEventListener("input", resizeInput);
promptBox.addEventListener("keydown", e => { if(e.key==="Enter" && !e.shiftKey && window.innerWidth>600){e.preventDefault();$("#chatForm").requestSubmit();} });
document.querySelectorAll(".suggestion").forEach(b => b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));
function newChat(){messages.innerHTML="";welcome.style.display="";conversation=[];promptBox.value="";resizeInput();closeMenu();notify("Новый чат готов");}
$("#newChat").addEventListener("click",newChat);
function speakText(text){
  if(!("speechSynthesis" in window)){notify("Озвучивание не поддерживается этим браузером");return;}
  window.speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(text);utterance.lang="ru-RU";utterance.rate=1;window.speechSynthesis.speak(utterance);notify("Озвучивание запущено");
}
$("#voiceBtn").addEventListener("click",()=>{const last=[...messages.querySelectorAll(".message.assistant .bubble")].filter(el=>el.textContent!=="NOVA думает…").pop();if(last)speakText(last.textContent);else notify("Сначала отправь сообщение");});
$("#themeBtn").addEventListener("click",()=>{document.body.classList.toggle("light");notify(document.body.classList.contains("light")?"Светлая тема":"Тёмная тема");});
const sidebar=$("#sidebar"),scrim=$("#scrim");
function openMenu(){sidebar.classList.add("open");scrim.classList.add("show");}
function closeMenu(){sidebar.classList.remove("open");scrim.classList.remove("show");}
$("#menuBtn").addEventListener("click",openMenu);$("#closeSidebar").addEventListener("click",closeMenu);scrim.addEventListener("click",closeMenu);
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>{
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("active"));b.classList.add("active");closeMenu();
  if(b.dataset.page==="chat"){notify("Открыт чат");return;}
  if(b.dataset.page==="library")notify("Библиотека появится в следующей версии");
  if(b.dataset.page==="tools")notify("Инструменты появятся в следующей версии");
}));
function openSettings(){
  $("#settingsOverlay").classList.add("show");$("#settingsOverlay").setAttribute("aria-hidden","false");
  $("#apiKey").value="";$("#rememberKey").checked=false;
  try{
    const saved=localStorage.getItem("nova_openrouter_key");
    if(saved){$("#apiKey").value=saved;$("#rememberKey").checked=true;}
    const savedModel=localStorage.getItem("nova_openrouter_model");if(savedModel)$("#modelId").value=savedModel;
    const savedPrompt=localStorage.getItem("nova_system_prompt");if(savedPrompt)$("#systemPrompt").value=savedPrompt;
  }catch{}
}
function closeSettings(){$("#settingsOverlay").classList.remove("show");$("#settingsOverlay").setAttribute("aria-hidden","true");}
$("#settingsBtn").addEventListener("click",openSettings);
$("#closeSettings").addEventListener("click",closeSettings);
$("#settingsOverlay").addEventListener("click",e=>{if(e.target===$("#settingsOverlay"))closeSettings();});
$("#saveSettings").addEventListener("click",()=>{
  const key=getKey(),model=getModel();
  if(!key){notify("Вставь API key OpenRouter");return;}
  if(!model){notify("Укажи ID модели");return;}
  try{
    if($("#rememberKey").checked)localStorage.setItem("nova_openrouter_key",key);
    else localStorage.removeItem("nova_openrouter_key");
    localStorage.setItem("nova_openrouter_model",model);
    localStorage.setItem("nova_system_prompt",$("#systemPrompt").value.trim()||DEFAULT_SYSTEM);
  }catch{notify("Браузер не разрешил сохранить настройки");return;}
  closeSettings();notify("Настройки сохранены. Можно писать NOVA.");
});
$("#clearSettings").addEventListener("click",()=>{
  $("#apiKey").value="";$("#modelId").value="";$("#systemPrompt").value=DEFAULT_SYSTEM;$("#rememberKey").checked=false;
  try{localStorage.removeItem("nova_openrouter_key");localStorage.removeItem("nova_openrouter_model");localStorage.removeItem("nova_system_prompt");}catch{}
  notify("Ключ и настройки удалены");
});
