# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in /sdk/tools/proguard/proguard-android.txt

# Keep Gemini SDK
-keep class com.google.ai.client.generativeai.** { *; }

# Keep OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
