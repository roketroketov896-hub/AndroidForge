package com.stella.ai.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.stella.ai.data.model.AiProvider
import com.stella.ai.data.model.ApiKeys
import com.stella.ai.data.model.StellaSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "stella_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val GEMINI_KEY = stringPreferencesKey("gemini_api_key")
        val OPENAI_KEY = stringPreferencesKey("openai_api_key")
        val CLAUDE_KEY = stringPreferencesKey("claude_api_key")
        val SELECTED_PROVIDER = stringPreferencesKey("selected_provider")
        val VOICE_ENABLED = booleanPreferencesKey("voice_enabled")
        val AUTO_SPEAK = booleanPreferencesKey("auto_speak")
    }

    val settingsFlow: Flow<StellaSettings> = context.dataStore.data.map { prefs ->
        StellaSettings(
            selectedProvider = AiProvider.entries.find { 
                it.id == prefs[Keys.SELECTED_PROVIDER] 
            } ?: AiProvider.GEMINI,
            apiKeys = ApiKeys(
                gemini = prefs[Keys.GEMINI_KEY] ?: "",
                openai = prefs[Keys.OPENAI_KEY] ?: "",
                claude = prefs[Keys.CLAUDE_KEY] ?: ""
            ),
            voiceEnabled = prefs[Keys.VOICE_ENABLED] ?: true,
            autoSpeak = prefs[Keys.AUTO_SPEAK] ?: true
        )
    }

    suspend fun saveApiKey(provider: AiProvider, key: String) {
        context.dataStore.edit { prefs ->
            when (provider) {
                AiProvider.GEMINI -> prefs[Keys.GEMINI_KEY] = key
                AiProvider.OPENAI -> prefs[Keys.OPENAI_KEY] = key
                AiProvider.CLAUDE -> prefs[Keys.CLAUDE_KEY] = key
            }
        }
    }

    suspend fun saveSelectedProvider(provider: AiProvider) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SELECTED_PROVIDER] = provider.id
        }
    }

    suspend fun saveVoiceEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.VOICE_ENABLED] = enabled
        }
    }

    suspend fun saveAutoSpeak(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.AUTO_SPEAK] = enabled
        }
    }
}
