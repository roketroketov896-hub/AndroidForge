package com.stella.ai.data.model

enum class AiProvider(val displayName: String, val id: String) {
    GEMINI("Google Gemini", "gemini"),
    OPENAI("OpenAI GPT", "openai"),
    CLAUDE("Anthropic Claude", "claude")
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val content: String,
    val isFromUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val isError: Boolean = false
)

data class ApiKeys(
    val gemini: String = "",
    val openai: String = "",
    val claude: String = ""
)

data class StellaSettings(
    val selectedProvider: AiProvider = AiProvider.GEMINI,
    val apiKeys: ApiKeys = ApiKeys(),
    val voiceEnabled: Boolean = true,
    val autoSpeak: Boolean = true
)
