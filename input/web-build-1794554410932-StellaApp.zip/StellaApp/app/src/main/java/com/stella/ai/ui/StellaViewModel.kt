package com.stella.ai.ui

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.stella.ai.data.model.AiProvider
import com.stella.ai.data.model.ChatMessage
import com.stella.ai.data.model.StellaSettings
import com.stella.ai.data.repository.AiRepository
import com.stella.ai.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

data class StellaUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val isListening: Boolean = false,
    val settings: StellaSettings = StellaSettings(),
    val error: String? = null,
    val inputText: String = ""
)

class StellaViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = SettingsRepository(application)
    private val aiRepository = AiRepository()

    private val _uiState = MutableStateFlow(StellaUiState())
    val uiState: StateFlow<StellaUiState> = _uiState.asStateFlow()

    private var tts: TextToSpeech? = null

    init {
        // Welcome message
        _uiState.update {
            it.copy(
                messages = listOf(
                    ChatMessage(
                        content = "Привет. Я Стелла — твой персональный ИИ-ассистент. Чем могу помочь?",
                        isFromUser = false
                    )
                )
            )
        }

        // Load settings
        viewModelScope.launch {
            settingsRepository.settingsFlow.collect { settings ->
                _uiState.update { it.copy(settings = settings) }
            }
        }

        // Initialize TTS with female Russian voice preference
        tts = TextToSpeech(application) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                // Try to select a female voice if available
                tts?.voices?.firstOrNull { voice ->
                    voice.locale.language == "ru" && 
                    (voice.name.contains("female", ignoreCase = true) || 
                     voice.name.contains("жен", ignoreCase = true) ||
                     voice.name.contains("female", ignoreCase = true))
                }?.let { femaleVoice ->
                    tts?.voice = femaleVoice
                }
            }
        }
    }

    fun onInputChange(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun sendMessage() {
        val text = _uiState.value.inputText.trim()
        if (text.isBlank() || _uiState.value.isLoading) return

        val userMessage = ChatMessage(content = text, isFromUser = true)
        
        _uiState.update {
            it.copy(
                messages = it.messages + userMessage,
                inputText = "",
                isLoading = true,
                error = null
            )
        }

        viewModelScope.launch {
            val currentMessages = _uiState.value.messages
            val settings = _uiState.value.settings

            val result = aiRepository.generateResponse(
                messages = currentMessages,
                provider = settings.selectedProvider,
                apiKeys = settings.apiKeys
            )

            result.fold(
                onSuccess = { response ->
                    val botMessage = ChatMessage(content = response, isFromUser = false)
                    _uiState.update {
                        it.copy(
                            messages = it.messages + botMessage,
                            isLoading = false
                        )
                    }
                    if (settings.autoSpeak && settings.voiceEnabled) {
                        speak(response)
                    }
                },
                onFailure = { error ->
                    val errorMessage = ChatMessage(
                        content = error.message ?: "Произошла ошибка",
                        isFromUser = false,
                        isError = true
                    )
                    _uiState.update {
                        it.copy(
                            messages = it.messages + errorMessage,
                            isLoading = false,
                            error = error.message
                        )
                    }
                }
            )
        }
    }

    fun setListening(listening: Boolean) {
        _uiState.update { it.copy(isListening = listening) }
    }

    fun onSpeechResult(text: String) {
        _uiState.update { it.copy(inputText = text, isListening = false) }
        sendMessage()
    }

    fun saveApiKey(provider: AiProvider, key: String) {
        viewModelScope.launch {
            settingsRepository.saveApiKey(provider, key)
        }
    }

    fun selectProvider(provider: AiProvider) {
        viewModelScope.launch {
            settingsRepository.saveSelectedProvider(provider)
        }
    }

    fun setAutoSpeak(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.saveAutoSpeak(enabled)
        }
    }

    fun setVoiceEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.saveVoiceEnabled(enabled)
        }
    }

    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    override fun onCleared() {
        tts?.shutdown()
        super.onCleared()
    }
}
