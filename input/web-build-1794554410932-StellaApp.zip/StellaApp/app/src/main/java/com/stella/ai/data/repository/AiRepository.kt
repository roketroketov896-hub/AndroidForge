package com.stella.ai.data.repository

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.stella.ai.data.model.AiProvider
import com.stella.ai.data.model.ApiKeys
import com.stella.ai.data.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AiRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val systemPrompt = """
        Ты — Стелла, персональный ИИ-ассистент в стиле Джарвиса из фильма "Железный человек".
        Ты умная, вежливая, немного саркастичная, но всегда полезная и преданная своему пользователю.
        Ты говоришь на русском языке.
        Обращайся к пользователю уважительно, но не слишком формально.
        Твои ответы должны быть полезными, точными и с лёгким характером.
        Если тебя спрашивают, кто ты — отвечай, что ты Стелла, цифровой дворецкий.
    """.trimIndent()

    suspend fun generateResponse(
        messages: List<ChatMessage>,
        provider: AiProvider,
        apiKeys: ApiKeys
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            when (provider) {
                AiProvider.GEMINI -> callGemini(messages, apiKeys.gemini)
                AiProvider.OPENAI -> callOpenAI(messages, apiKeys.openai)
                AiProvider.CLAUDE -> callClaude(messages, apiKeys.claude)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun callGemini(messages: List<ChatMessage>, apiKey: String): Result<String> {
        if (apiKey.isBlank()) {
            return Result.failure(Exception("API-ключ Gemini не задан"))
        }

        val model = GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = apiKey,
            systemInstruction = content { text(systemPrompt) }
        )

        val history = messages.dropLast(1).map { msg ->
            content(role = if (msg.isFromUser) "user" else "model") {
                text(msg.content)
            }
        }

        val chat = model.startChat(history = history)
        val lastMessage = messages.lastOrNull()?.content ?: ""
        val response = chat.sendMessage(lastMessage)
        
        return Result.success(response.text ?: "Извини, я не смогла сформулировать ответ.")
    }

    private fun callOpenAI(messages: List<ChatMessage>, apiKey: String): Result<String> {
        if (apiKey.isBlank()) {
            return Result.failure(Exception("API-ключ OpenAI не задан"))
        }

        val jsonMessages = JSONArray()
        jsonMessages.put(JSONObject().apply {
            put("role", "system")
            put("content", systemPrompt)
        })

        messages.forEach { msg ->
            jsonMessages.put(JSONObject().apply {
                put("role", if (msg.isFromUser) "user" else "assistant")
                put("content", msg.content)
            })
        }

        val body = JSONObject().apply {
            put("model", "gpt-4o-mini")
            put("messages", jsonMessages)
            put("temperature", 0.7)
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return Result.failure(Exception("OpenAI ошибка: ${response.code}"))
            }
            val json = JSONObject(response.body?.string() ?: "")
            val content = json
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
            return Result.success(content)
        }
    }

    private fun callClaude(messages: List<ChatMessage>, apiKey: String): Result<String> {
        if (apiKey.isBlank()) {
            return Result.failure(Exception("API-ключ Claude не задан"))
        }

        val jsonMessages = JSONArray()
        messages.forEach { msg ->
            jsonMessages.put(JSONObject().apply {
                put("role", if (msg.isFromUser) "user" else "assistant")
                put("content", msg.content)
            })
        }

        val body = JSONObject().apply {
            put("model", "claude-3-5-sonnet-20241022")
            put("max_tokens", 1024)
            put("system", systemPrompt)
            put("messages", jsonMessages)
        }

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return Result.failure(Exception("Claude ошибка: ${response.code}"))
            }
            val json = JSONObject(response.body?.string() ?: "")
            val content = json
                .getJSONArray("content")
                .getJSONObject(0)
                .getString("text")
            return Result.success(content)
        }
    }
}
