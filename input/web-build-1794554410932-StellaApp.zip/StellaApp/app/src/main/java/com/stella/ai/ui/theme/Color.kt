package com.stella.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Hyperpunk / Neon palette
val NeonCyan = Color(0xFF00F0FF)
val NeonMagenta = Color(0xFFFF00AA)
val NeonPink = Color(0xFFFF2E63)
val NeonPurple = Color(0xFF9D00FF)
val NeonLime = Color(0xFF00FF9F)
val NeonOrange = Color(0xFFFF6B00)

val DarkBackground = Color(0xFF0A0A12)
val DarkSurface = Color(0xFF12121E)
val DarkSurfaceVariant = Color(0xFF1A1A2E)
val DarkCard = Color(0xFF16162A)

val TextPrimary = Color(0xFFE8E8FF)
val TextSecondary = Color(0xFFA0A0C0)
val TextMuted = Color(0xFF6B6B8A)

val GlowCyan = Color(0x8000F0FF)
val GlowMagenta = Color(0x80FF00AA)
val ErrorRed = Color(0xFFFF3366)
val SuccessGreen = Color(0xFF00FF9F)
