# Stella — Персональный ИИ-ассистент

**Stella** — мобильное Android-приложение в стиле Джарвиса из «Железного человека».  
Современный Hyperpunk-дизайн, женский голос, поддержка нескольких ИИ-провайдеров.

## Возможности

- Чат с ИИ в образе Стеллы (умный, вежливый, слегка саркастичный дворецкий)
- Голосовой ввод (Speech-to-Text)
- Озвучка ответов женским голосом (Text-to-Speech)
- Поддержка API-ключей:
  - Google Gemini
  - OpenAI (GPT)
  - Anthropic Claude
- Полностью русский интерфейс
- Hyperpunk UI: неоновые акценты, glow-эффекты, тёмная тема

## Требования

- Android Studio Ladybug (2024.2.1) или новее
- JDK 17
- Android SDK 35
- Минимальная версия Android: 8.0 (API 26)

## Как запустить

1. Открой папку `StellaApp` в Android Studio
2. Дождись синхронизации Gradle
3. Подключи устройство или запусти эмулятор
4. Нажми **Run**

## Настройка API-ключей

1. Открой приложение → иконка шестерёнки (Настройки)
2. Выбери нужный ИИ-провайдер
3. Вставь свой API-ключ и нажми **Сохранить**

### Где взять ключи:

- **Google Gemini**: [Google AI Studio](https://aistudio.google.com/apikey)
- **OpenAI**: [platform.openai.com/api-keys](https://platform.openai.com/api-keys)
- **Claude**: [console.anthropic.com](https://console.anthropic.com/)

## Структура проекта

```
app/src/main/java/com/stella/ai/
├── MainActivity.kt
├── data/
│   ├── model/          # Модели данных
│   └── repository/     # Работа с API и настройками
└── ui/
    ├── StellaViewModel.kt
    ├── components/     # Neon-компоненты
    ├── screens/        # Экраны (Чат, Настройки)
    └── theme/          # Hyperpunk тема
```

## Технологии

- Kotlin
- Jetpack Compose + Material 3
- DataStore (хранение ключей)
- Google Generative AI SDK
- OkHttp / Retrofit
- Android SpeechRecognizer + TextToSpeech

## Лицензия

Проект создан для личного использования.
