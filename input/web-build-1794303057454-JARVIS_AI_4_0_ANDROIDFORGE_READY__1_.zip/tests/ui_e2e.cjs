// Автотест интерфейса пользовательского приложения в headless Chromium с имитацией Android-моста.
// Запуск: PLAYWRIGHT=/путь/к/playwright node tests/ui_e2e.cjs   (Android, Google и сервер здесь имитируются)
const path = require('path');
const assert = require('assert');
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
const PAGE = 'file://' + path.resolve(__dirname, '../app/src/main/assets/index.html');
let passed = 0; const ok = (name) => { passed++; console.log('  ✓', name); };

async function boot(browser, opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: opts.w || 390, height: opts.h || 800 } });
  const p = await ctx.newPage();
  p.errors = []; p.on('pageerror', (e) => p.errors.push(e.message));
  await p.addInitScript((o) => {
    window.__calls = []; window.__keys = { openrouter: true };
    const state = { settings: { mode: 'own', provider: 'openrouter', model: 'openrouter/auto', lang: 'auto', ttsRate: .95, ttsPitch: .85, ttsEngine: 'system', perf: 'lite', voices: {}, systemPrompt: '' },
      profile: o.signedIn ? { signedIn: true, email: 'me@x', name: 'Me' } : { signedIn: false }, configured: { backend: o.backend !== false, google: o.google !== false }, online: true, ttsReady: true };
    window.JarvisBridge = new Proxy({}, { get: (_, n) => (...a) => {
      window.__calls.push([n, ...a]);
      if (n === 'getState') return JSON.stringify(state);
      if (n === 'hasKey') return !!window.__keys[a[0]];
      if (n === 'saveApiKey') { window.__keys[a[0]] = true; return true; }
      if (n === 'getVoices') return '[]';
      if (n === 'saveSettings') Object.assign(state.settings, JSON.parse(a[0]));
      if (n === 'signIn') setTimeout(() => window.JarvisEvents.emit('auth', JSON.stringify({ signedIn: true, email: 'me@x', name: 'Me' })), 20);
      if (n === 'sendChat') window.__lastReq = a[0];
      if (n === 'hasHeadset') return !!window.__headset;
      if (n === 'openApp') return JSON.stringify({ ok: true, store: true, message: 'Приложение «' + a[0] + '» не установлено. Открываю его в Google Play.' });
      return null;
    } });
    if (o.keepStorage !== true) { try { localStorage.setItem('jarvis_key_prompt_skipped', '1'); } catch (e) { /* ignore */ } }
  }, opts);
  await p.goto(PAGE); await p.waitForTimeout(250);
  return p;
}
const emit = (p, ev, d) => p.evaluate(([e, x]) => window.JarvisEvents.emit(e, JSON.stringify(x)), [ev, d]);
const calls = (p, n) => p.evaluate((nm) => window.__calls.filter((c) => c[0] === nm), n);

(async () => {
  const browser = await chromium.launch();

  console.log('Вход (обязательная регистрация)');
  let p = await boot(browser, { signedIn: false });
  assert.ok(await p.$eval('#login', (e) => e.classList.contains('open'))); assert.ok(!(await p.$eval('#loginBtn', (e) => e.hidden))); ok('без сессии показан экран входа');
  assert.ok((await calls(p, 'appReady')).length === 1); ok('интерфейс сообщает нативной заставке о готовности ровно один раз');
  await p.click('#loginBtn'); await p.waitForTimeout(150);
  assert.ok(!(await p.$eval('#login', (e) => e.classList.contains('open')))); ok('после входа Google экран входа закрывается');
  await emit(p, 'auth', { signedIn: false }); await p.waitForTimeout(50);
  assert.ok(await p.$eval('#login', (e) => e.classList.contains('open'))); ok('после выхода экран входа возвращается');
  await emit(p, 'auth', { signedIn: false, error: 'GetCredentialCancellationException: x' }); await p.waitForTimeout(50);
  assert.match(await p.$eval('#loginErr', (e) => e.textContent), /отменён/); ok('отмена входа даёт понятное сообщение');
  await p.close();
  p = await boot(browser, { signedIn: false, google: false });
  assert.ok(await p.$eval('#loginBtn', (e) => e.hidden)); assert.ok(!(await p.$eval('#loginGuest', (e) => e.hidden)));
  assert.match(await p.$eval('#loginText', (e) => e.textContent), /не настроен/); ok('без Web Client ID честно сказано, что вход не настроен (без тупика)');
  await p.close();

  console.log('Чат');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'Привет'); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const userEl = await p.evaluateHandle(() => document.querySelector('.msg.user')); await p.evaluate((e) => { e.__mark = 1; }, userEl);
  const id1 = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatDelta', { id: id1, text: 'Первый абзац.\n\nВторой ' }); await p.waitForTimeout(150);
  await emit(p, 'chatDelta', { id: id1, text: 'абзац.' }); await p.waitForTimeout(150);
  await emit(p, 'chatDone', { id: id1 }); await p.waitForTimeout(150);
  assert.equal(await p.evaluate(() => document.querySelector('.msg.user').__mark), 1); ok('сообщения не пересоздаются при потоке и завершении (инкрементальный рендер)');
  assert.equal(await p.$$eval('.msg', (e) => e.length), 2); ok('нет дубликатов сообщений');
  assert.match(await p.$eval('.msg.assistant .md', (e) => e.textContent), /Первый абзац\.\s*Второй абзац\./); ok('потоковый ответ собран без потерь');
  // повторное завершение и «чужой» ответ не меняют чат
  await emit(p, 'chatDone', { id: id1 }); await emit(p, 'chatDelta', { id: 'ghost', text: 'ЧУЖОЙ' }); await p.waitForTimeout(100);
  assert.ok(!(await p.$eval('#messages', (e) => e.textContent.includes('ЧУЖОЙ')))); ok('запоздалый/чужой ответ игнорируется');
  // переключение чата во время генерации
  await p.fill('#input', 'Второй чат вопрос'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const id2 = await p.evaluate(() => window.__lastReq);
  await p.click('#topNew'); await p.waitForTimeout(80);
  await emit(p, 'chatDelta', { id: id2, text: 'ОТВЕТ-В-ПЕРВОМ-ЧАТЕ' }); await emit(p, 'chatDone', { id: id2 }); await p.waitForTimeout(150);
  assert.ok(!(await p.$eval('#messages', (e) => e.textContent.includes('ОТВЕТ-В-ПЕРВОМ-ЧАТЕ')))); ok('при переключении чата ответ не попадает в другой чат');
  await p.evaluate(() => document.querySelector('.chat-open').click()); await p.waitForTimeout(100);
  assert.ok(await p.$eval('#messages', (e) => e.textContent.includes('ОТВЕТ-В-ПЕРВОМ-ЧАТЕ'))); ok('ответ дошёл в чат, где был задан вопрос');
  // отмена генерации
  await p.fill('#input', 'ещё'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const id3 = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatDelta', { id: id3, text: 'частичный' }); await p.waitForTimeout(100);
  await p.click('#sendBtn'); await p.waitForTimeout(100);
  assert.equal((await calls(p, 'cancelChat')).pop()[1], id3); ok('отмена передаётся в Android (и далее на сервер)');
  await emit(p, 'chatDelta', { id: id3, text: ' ПОЗДНО' }); await p.waitForTimeout(100);
  assert.ok(!(await p.$eval('#messages', (e) => e.textContent.includes('ПОЗДНО')))); ok('после отмены поздние токены не добавляются');
  assert.match(await p.$eval('#messages', (e) => e.textContent), /Генерация остановлена/); ok('частичный ответ сохранён с пометкой');
  // XSS
  await p.fill('#input', 'xss'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const id4 = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatDelta', { id: id4, text: '<img src=x onerror=alert(1)> <script>window.__x=1</script> [a](javascript:alert(1)) [ok](https://example.com)' }); await emit(p, 'chatDone', { id: id4 }); await p.waitForTimeout(150);
  assert.equal(await p.$$eval('#messages img, #messages script', (e) => e.length), 0);
  assert.equal(await p.$$eval('#messages a[href^="javascript"]', (e) => e.length), 0); assert.equal(await p.evaluate(() => window.__x), undefined); ok('Markdown безопасен: HTML и javascript:-ссылки не выполняются');
  // ошибка сети
  await p.fill('#input', 'сеть'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const id5 = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatError', { id: id5, code: 'network', detail: '' }); await p.waitForTimeout(150);
  assert.match(await p.$eval('.msg.assistant.error', (e) => e.textContent), /Нет соединения/); ok('потеря сети: понятная ошибка, а не ложный успех');
  // длинное сообщение и 4 языка
  const long = ('Очень длинное слово ' + 'А'.repeat(300) + ' ').repeat(3) + ' Salam, necə kömək edə bilərsən? Merhaba, bugün nasılsın? Hello world.';
  await p.fill('#input', long); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const over = await p.evaluate(() => { const s = document.querySelector('#scroller'); return s.scrollWidth > s.clientWidth + 1; });
  assert.ok(!over); ok('длинный текст не вызывает горизонтальной прокрутки');
  assert.deepEqual(await p.evaluate(() => ['Привет, как дела?', 'Salam, necə kömək edə bilərsən?', 'Merhaba, bugün nasılsın?', 'Hello, how can you help me?'].map((t) => detectLang(t))), ['ru', 'az', 'tr', 'en']); ok('определение 4 языков');
  await p.close();

  console.log('Сохранение');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'Запомнить это'); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const idp = await p.evaluate(() => window.__lastReq); await emit(p, 'chatDelta', { id: idp, text: 'Сохранённый ответ' }); await emit(p, 'chatDone', { id: idp }); await p.waitForTimeout(500);
  const stored = await p.evaluate(() => localStorage.getItem('jarvis_chats_v2:me@x'));
  const ctx2 = p.context(); const p2 = await ctx2.newPage(); p2.errors = [];
  await p2.addInitScript(([s]) => { localStorage.setItem('jarvis_chats_v2:a@b', s); localStorage.setItem('jarvis_key_prompt_skipped', '1'); window.JarvisBridge = new Proxy({}, { get: (_, n) => () => (n === 'getState' ? JSON.stringify({ settings: { mode: 'own', provider: 'openrouter', model: 'm', lang: 'auto', voices: {}, systemPrompt: '' }, profile: { signedIn: true, email: 'a@b' }, configured: { backend: true, google: true } }) : n === 'hasKey' ? true : null) }); }, [stored]);
  await p2.goto(PAGE); await p2.waitForTimeout(250);
  await p2.evaluate(() => document.querySelector('.chat-open').click()); await p2.waitForTimeout(100);
  assert.ok(await p2.$eval('#messages', (e) => e.textContent.includes('Сохранённый ответ'))); ok('история восстанавливается после перезапуска');
  await p2.close(); await p.close();

  console.log('Сервер, сеть, объявления');
  p = await boot(browser, { signedIn: true });
  await emit(p, 'bootstrap', { serverChecked: true, serverOk: false, online: true, appConfig: '' }); await p.waitForTimeout(60);
  assert.ok(!(await p.$eval('#netPill', (e) => e.hidden))); assert.match(await p.$eval('#netPill', (e) => e.textContent), /недоступен/); ok('сервер недоступен: статус и кнопка повтора');
  await p.click('#netPill'); assert.equal((await calls(p, 'retryBootstrap')).length, 1); ok('повтор проверки сервера');
  await emit(p, 'bootstrap', { serverChecked: true, serverOk: true, online: false, appConfig: '' }); await p.waitForTimeout(60);
  assert.equal(await p.$eval('body', (e) => e.dataset.orb), 'offline'); ok('нет сети: шар в состоянии «нет соединения»');
  await emit(p, 'bootstrap', { serverChecked: true, serverOk: true, online: true, appConfig: JSON.stringify({ announcement: 'Работы до 12:00', maintenance: true, systemPrompt: 'Серверный промпт', features: { screenShare: false, onlineTts: false }, ttsAvailable: true }) }); await p.waitForTimeout(60);
  assert.equal(await p.$eval('#notice', (e) => e.textContent), 'Работы до 12:00'); ok('объявление администратора показывается');
  assert.ok(await p.$eval('[data-open="panelScreen"]', (e) => e.hidden)); ok('функция, выключенная админом, скрыта');
  assert.ok(await p.$eval('#ttsEngine option[value="online"]', (e) => e.disabled)); ok('нейро-голос недоступен, если выключен админом');
  await p.fill('#input', 'промпт'); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const sent = JSON.parse((await calls(p, 'sendChat')).pop()[2]);
  assert.ok(!/Серверный промпт/.test(sent[0].content)); ok('глобальный промпт не передаётся клиенту и не подмешивается в приложении (его добавляет Worker)');
  await p.close();

  console.log('Голосовой режим и озвучка');
  p = await boot(browser, { signedIn: true });
  for (let i = 0; i < 5; i++) { await p.click('#openVoice'); await p.waitForTimeout(60); await p.click('#vEnd'); await p.waitForTimeout(60); }
  assert.equal(await p.$$eval('#voiceLangs .chip', (e) => e.length), 4); ok('многократное открытие/закрытие не дублирует элементы');
  assert.equal((await calls(p, 'stopSpeech')).length >= 5, true); ok('закрытие голосового режима останавливает речь');
  await p.click('#openVoice'); await p.waitForTimeout(100);
  const chip = await p.evaluateHandle(() => document.querySelector('#voiceLangs .chip')); await p.evaluate((e) => { e.__m = 1; }, chip);
  await emit(p, 'speech', { type: 'listening' }); await emit(p, 'speech', { type: 'level', level: 0.7 }); await emit(p, 'speech', { type: 'partial', text: 'привет' });
  await emit(p, 'tts', { state: 'speaking', msgId: 'x', index: 0, total: 2 }); await emit(p, 'ttsWord', {}); await emit(p, 'tts', { state: 'paused', msgId: 'x', index: 1, total: 2 }); await emit(p, 'tts', { state: 'speaking', msgId: 'x', index: 1, total: 2 }); await p.waitForTimeout(100);
  assert.equal(await p.evaluate(() => document.querySelector('#voiceLangs .chip').__m), 1); ok('события голоса не пересоздают экран');
  assert.equal(await p.$eval('body', (e) => e.dataset.orb), 'speaking'); ok('пока говорит JARVIS, микрофон не слушает, шар в состоянии «говорю»');
  await emit(p, 'tts', { state: 'idle', msgId: 'x', index: 1, total: 2 }); await emit(p, 'speech', { type: 'listening' }); await p.waitForTimeout(40);
  assert.equal(await p.$eval('body', (e) => e.dataset.orb), 'listening'); ok('шар отражает «слушаю»');
  await emit(p, 'speech', { type: 'error', code: 'permission_denied', permanent: true }); await p.waitForTimeout(60);
  assert.ok(!(await p.$eval('#vPerm', (e) => e.hidden))); assert.match(await p.$eval('#vState', (e) => e.textContent), /микрофон/i); ok('отказ в разрешении микрофона: понятное сообщение и кнопка настроек');
  assert.equal(await p.$eval('body', (e) => e.dataset.orb) === 'listening', false); ok('шар не показывает прослушивание без микрофона');
  await p.click('#vEnd'); await p.waitForTimeout(50); await p.close();

  console.log('Озвучивание в чате');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'озвучь'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const ids = await p.evaluate(() => window.__lastReq); await emit(p, 'chatDelta', { id: ids, text: 'Ответ для озвучки' }); await emit(p, 'chatDone', { id: ids }); await p.waitForTimeout(150);
  await p.click('.msg.assistant .act.spk'); assert.equal((await calls(p, 'speak')).length, 1); ok('кнопка динамика запускает озвучку');
  await emit(p, 'tts', { state: 'speaking', msgId: ids, index: 0, total: 1 }); await p.waitForTimeout(60);
  assert.equal(await p.$eval('.msg.assistant', (e) => e.dataset.tts), 'speaking'); ok('появляется пауза/стоп, динамик активен');
  await p.click('.msg.assistant .act.pz'); assert.equal((await calls(p, 'pauseSpeech')).length, 1);
  await emit(p, 'tts', { state: 'paused', msgId: ids, index: 0, total: 1 }); await p.waitForTimeout(60);
  assert.equal(await p.$eval('body', (e) => e.dataset.orb), 'paused'); ok('пауза: шар в состоянии паузы');
  await p.click('.msg.assistant .act.pl'); assert.equal((await calls(p, 'resumeSpeech')).length, 1); ok('продолжение речи');
  await p.click('.msg.assistant .act.st'); assert.equal((await calls(p, 'stopSpeech')).length >= 1, true); ok('остановка речи');
  await p.click('#sendBtn'); // повторные нажатия не создают дублей
  for (let i = 0; i < 4; i++) await p.click('#topNew', { force: true });
  assert.equal(await p.$$eval('#chatList .chat-item', (e) => e.length) >= 1, true); ok('повторные нажатия кнопок не ломают интерфейс');
  await p.close();

  console.log('Профиль и настройки');
  p = await boot(browser, { signedIn: true });
  await p.evaluate(() => document.querySelector('[data-open="panelVoice"]').click()); await p.waitForTimeout(300);
  await p.selectOption('#ttsEngine', 'online'); await p.waitForTimeout(80);
  assert.ok((await calls(p, 'saveSettings')).some((c) => JSON.parse(c[1]).ttsEngine === 'online')); ok('выбор движка голоса сохраняется');
  await p.evaluate(() => document.querySelector('.panel.open [data-close]').click()); await p.waitForTimeout(250);
  await p.evaluate(() => document.querySelector('[data-open="panelAccount"]').click()); await p.waitForTimeout(300);
  assert.ok(!(await p.$eval('#panelAccount', (e) => e.textContent.includes('Web Client ID')))); ok('технические поля (Client ID) скрыты от пользователя');
  assert.equal(await p.$$eval('#perfSel', (e) => e.length), 0); assert.ok(!(await p.$eval('body', (e) => e.classList.contains('lite')))); ok('выбора анимации нет: всегда плавные эффекты');
  assert.equal(p.errors.length, 0); ok('ошибок JavaScript нет');
  await p.close();


  console.log('Код: подсветка, копирование, запуск');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'код'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  let cid = await p.evaluate(() => window.__lastReq);
  const md = 'Вот код:\n\n```js\nconst a = 2 + 3; // сумма\nconsole.log("a=" + a);\n```\n\n```python\ndef f(x):\n    return x * 2\n```\n\n```js\nwhile (true) {}\n```\n\n```js\nthrow new Error("упс");\n```';
  await emit(p, 'chatDelta', { id: cid, text: md }); await emit(p, 'chatDone', { id: cid }); await p.waitForTimeout(200);
  assert.equal(await p.$$eval('.msg.assistant .code', (e) => e.length), 4);
  assert.ok((await p.$$eval('.msg.assistant .code .t-k', (e) => e.length)) >= 3); assert.equal(await p.$$eval('.msg.assistant .code .t-c', (e) => e.length) >= 1, true); ok('код в отдельных блоках с подсветкой синтаксиса');
  assert.equal(await p.$$eval('.code-run', (e) => e.length), 3); assert.equal(await p.$$eval('.code-copy', (e) => e.length), 4); ok('кнопка копирования у каждого блока, запуск у JS');
  await p.click('.code:nth-of-type(1) .code-copy'); const cp = (await calls(p, 'copyText')).pop();
  assert.equal(cp[1], 'const a = 2 + 3; // сумма\nconsole.log("a=" + a);'); ok('копируется чистый код без разметки');
  await p.click('.msg.assistant .code >> nth=0 >> .code-run'); await p.waitForTimeout(1200);
  assert.match(await p.$eval('.msg.assistant .code >> nth=0 >> .code-out', (e) => e.textContent), /a=5/); ok('код выполняется в песочнице, виден результат');
  await p.evaluate(() => { window.JARVIS_RUN_TIMEOUT = 700; });
  await p.click('.msg.assistant .code >> nth=2 >> .code-run'); await p.waitForTimeout(2200);
  assert.match(await p.$eval('.msg.assistant .code >> nth=2 >> .code-out', (e) => e.textContent), /превышено время/); ok('бесконечный цикл останавливается по тайм-ауту, приложение не зависает');
  await p.click('.msg.assistant .code >> nth=3 >> .code-run'); await p.waitForTimeout(1200);
  assert.match(await p.$eval('.msg.assistant .code >> nth=3 >> .code-out', (e) => e.textContent), /упс/); ok('ошибка выполнения показывается');
  await p.locator('.msg.assistant .code').nth(3).locator('.code-fix').click(); assert.match(await p.$eval('#input', (e) => e.value), /Исправь ошибку[\s\S]*throw new Error/); assert.equal((await calls(p, 'sendChat')).filter((c) => !/^title_/.test(c[1])).length, 1); ok('«Исправить с JARVIS» подставляет текст, но не отправляет сам');
  await p.close();

  console.log('Голосовой ввод в поле');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'Привет,'); await p.click('#dictBtn'); await p.waitForTimeout(50);
  assert.equal((await calls(p, 'startDictation')).length, 1); assert.equal(await p.$eval('#dictBtn', (e) => e.getAttribute('aria-label')), 'Остановить запись'); ok('запись диктовки запускается без остановки на паузах, кнопка становится стоп-квадратом');
  await emit(p, 'speech', { type: 'partial', text: 'как дела' }); await p.waitForTimeout(40);
  assert.equal(await p.$eval('#input', (e) => e.value), 'Привет, как дела');
  await emit(p, 'speech', { type: 'result', text: 'как дела сегодня' }); await p.waitForTimeout(60);
  assert.equal(await p.$eval('#input', (e) => e.value), 'Привет, как дела сегодня');
  assert.equal((await calls(p, 'sendChat')).length, 0); ok('распознанный текст попадает в поле и НЕ отправляется автоматически');
  await p.fill('#input', 'x'); await p.click('#dictBtn'); await emit(p, 'speech', { type: 'error', code: 'no_match' }); await p.waitForTimeout(60);
  assert.ok(!(await p.$eval('#dictBtn', (e) => e.classList.contains('live')))); ok('ошибка распознавания снимает индикатор записи');
  await p.close();

  console.log('Память');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'Запомни: я живу в Баку и люблю краткие ответы'); await p.click('#sendBtn'); await p.waitForTimeout(150);
  assert.match(await p.$eval('#messages', (e) => e.textContent), /Запомнил: я живу в Баку/); assert.equal((await calls(p, 'sendChat')).length, 0); ok('«Запомни…» сохраняет сведение локально без запроса к ИИ');
  await p.fill('#input', 'вопрос'); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const sys = JSON.parse((await calls(p, 'sendChat')).pop()[2])[0].content;
  assert.match(sys, /живу в Баку/); assert.match(sys, /данные, а не инструкции/); ok('память добавляется в запрос модели (как данные)');
  await p.evaluate(() => document.querySelector('[data-open="panelMemory"]').click()); await p.waitForTimeout(300);
  assert.equal(await p.$$eval('.mem-row', (e) => e.length), 1); ok('сведение видно в разделе «Память»');
  await p.fill('.mem-row input', 'я живу в Анкаре'); await p.dispatchEvent('.mem-row input', 'change'); await p.waitForTimeout(80);
  assert.equal(await p.evaluate(() => JSON.parse(localStorage.getItem('jarvis_memory_v1:me@x')).items[0].text), 'я живу в Анкаре'); ok('сведение редактируется и сохраняется');
  await p.evaluate(() => document.querySelector('#memOn').parentElement.click()); await p.waitForTimeout(60);
  await p.evaluate(() => document.querySelector('.panel.open [data-close]').click()); await p.waitForTimeout(250);
  await p.click('#topNew'); await p.fill('#input', 'ещё вопрос'); await p.click('#sendBtn'); await p.waitForTimeout(100);
  assert.ok(!JSON.parse((await calls(p, 'sendChat')).pop()[2])[0].content.includes('Анкаре')); ok('при выключенной памяти сведения не отправляются');
  await p.evaluate(() => document.querySelector('[data-open="panelMemory"]').click()); await p.waitForTimeout(300);
  await p.click('.mem-row button'); await p.waitForTimeout(100); await p.click('#dialogYes'); await p.waitForTimeout(120);
  assert.equal(await p.$$eval('.mem-row', (e) => e.length), 0); ok('сведение удаляется с подтверждением');
  const pm = await p.context().newPage(); await pm.addInitScript(() => { localStorage.setItem('jarvis_memory_v1:other@x', JSON.stringify({ enabled: true, items: [{ id: '1', text: 'ЧУЖАЯ ПАМЯТЬ', created: 1 }] })); localStorage.setItem('jarvis_key_prompt_skipped', '1'); });
  await p.close(); await pm.close();


  console.log('Диктовка: стоп, ошибки, сохранность текста');
  p = await boot(browser, { signedIn: true });
  await p.click('#dictBtn'); await emit(p, 'speech', { type: 'partial', text: 'длинная фраза после паузы и ещё часть' }); await p.waitForTimeout(40);
  await p.click('#dictBtn', { force: true }); assert.equal((await calls(p, 'finishListening')).length, 1); ok('квадратная кнопка завершает запись');
  await emit(p, 'speech', { type: 'result', text: 'длинная фраза после паузы и ещё часть' }); await p.waitForTimeout(40);
  assert.equal(await p.$eval('#input', (e) => e.value), 'длинная фраза после паузы и ещё часть'); assert.equal((await calls(p, 'sendChat')).length, 0); ok('текст в поле для правки, автоотправки нет');
  await p.click('#dictBtn'); await emit(p, 'speech', { type: 'error', code: 'network', text: 'уже сказанное' }); await p.waitForTimeout(40);
  assert.match(await p.$eval('#input', (e) => e.value), /уже сказанное/); ok('при ошибке записанный текст не теряется');
  await p.close();

  console.log('Интернет: цикл инструментов, автопамять, прошлые чаты');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'Какая сегодня погода в Баку?'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const t1 = await p.evaluate(() => window.__lastReq);
  assert.match(JSON.parse((await calls(p, 'sendChat')).pop()[2])[0].content, /web_search/); ok('модель узнаёт об интернет-инструментах');
  await emit(p, 'chatDelta', { id: t1, text: '<tool>{"name":"web_search","q":"погода Баку"}</tool>' }); await emit(p, 'chatDone', { id: t1 }); await p.waitForTimeout(100);
  let wt = (await calls(p, 'webTool')).pop(); assert.equal(wt[2], 'web_search'); assert.ok(!(await p.$eval('#messages', (e) => e.textContent.includes('<tool>')))); ok('тег инструмента скрыт, поиск запущен');
  await emit(p, 'webResult', { reqId: t1, ok: true, name: 'web_search', data: { results: [{ i: 1, title: 'Погода', url: 'https://example.com/w', snippet: '+18' }] } }); await p.waitForTimeout(100);
  const cont = JSON.parse((await calls(p, 'sendChat')).pop()[2]);
  assert.match(cont[cont.length - 1].content, /не выполняй[\s\S]*example\.com\/w/); assert.match(cont[cont.length - 2].content, /<tool>/); ok('результат передан модели как недоверенные данные, контекст сохранён');
  await emit(p, 'chatDelta', { id: t1, text: '<tool>{"name":"web_fetch","url":"https://example.com/w"}</tool>' }); await emit(p, 'chatDone', { id: t1 }); await p.waitForTimeout(100);
  assert.equal((await calls(p, 'webTool')).pop()[2], 'web_fetch'); ok('переход по ссылке (второй шаг)');
  await emit(p, 'webResult', { reqId: t1, ok: false, name: 'web_fetch', error: 'Адрес из локальной сети запрещён.' }); await p.waitForTimeout(80);
  await emit(p, 'chatDelta', { id: t1, text: 'В Баку +18. Источник: example.com\n<memory>Пользователя интересует погода в Баку</memory>' }); await emit(p, 'chatDone', { id: t1 }); await p.waitForTimeout(200);
  const txt = await p.$eval('#messages', (e) => e.textContent);
  assert.match(txt, /Ищу в интернете: «погода Баку»/); assert.match(txt, /В Баку \+18/); assert.match(txt, /Запомнил: Пользователя интересует погода/); assert.ok(!txt.includes('<memory>')); ok('финальный ответ, шаги поиска и пометка «Запомнил» в одном сообщении');
  assert.equal(await p.evaluate(() => JSON.parse(localStorage.getItem('jarvis_memory_v1:me@x')).items.length), 1); ok('JARVIS сам сохранил факт в память');
  await p.click('#topNew'); await p.fill('#input', 'расскажи ещё про погоду в Баку завтра'); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const sys2 = JSON.parse((await calls(p, 'sendChat')).pop()[2])[0].content;
  assert.match(sys2, /Из прошлых разговоров[\s\S]*Баку/); ok('прошлые чаты находятся и подмешиваются в контекст');
  await p.close();

  console.log('Шаги действий, файлы, названия чатов');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'Найди вакансии для подростков в Баку'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const s1 = await p.evaluate(() => window.__lastReq);
  assert.match(JSON.parse((await calls(p, 'sendChat')).pop()[2])[0].content, /ОДНО короткое предложение/); ok('модель обязана коротко объяснить, что делает, перед действием');
  await emit(p, 'chatDelta', { id: s1, text: 'Ищу в интернете вакансии для подростков в Баку.\n<tool>{"name":"web_search","q":"вакансии подростки Баку"}</tool>' }); await emit(p, 'chatDone', { id: s1 }); await p.waitForTimeout(120);
  assert.match(await p.$eval('.msg.assistant', (e) => e.textContent), /Ищу в интернете вакансии для подростков/); ok('пояснение перед действием видно в чате');
  assert.ok(await p.$eval('.msg.assistant .step', (e) => e.classList.contains('run'))); assert.match(await p.$eval('.msg.assistant .step', (e) => e.textContent), /Ищу в интернете: «вакансии подростки Баку»/); ok('шаг показан строкой с иконкой и текстом, пока выполняется');
  await emit(p, 'webResult', { reqId: s1, ok: true, name: 'web_search', data: { results: [{ i: 1, title: 'Вакансии Tap.az', url: 'https://tap.az/jobs', snippet: 'x' }, { i: 2, title: 'Jooble', url: 'https://jooble.org/a', snippet: 'y' }] } }); await p.waitForTimeout(150);
  assert.ok(await p.$eval('.msg.assistant .step', (e) => e.classList.contains('ok') && e.classList.contains('has-more'))); ok('после результата шаг помечается выполненным');
  await p.click('.msg.assistant .step'); await p.waitForTimeout(100);
  assert.equal(await p.$$eval('#stepBody .src', (e) => e.length), 2); assert.match(await p.$eval('#stepBody', (e) => e.textContent), /tap\.az/); ok('нажатие на шаг открывает список источников');
  await p.click('#stepClose'); assert.ok(await p.$eval('#stepSheet', (e) => e.hidden)); ok('лист источников закрывается');
  await emit(p, 'chatDelta', { id: s1, text: 'Нашёл несколько сайтов: Tap.az и Jooble.' }); await emit(p, 'chatDone', { id: s1 }); await p.waitForTimeout(200);
  assert.ok(!(await p.$eval('#messages', (e) => e.textContent.includes('⟦')))); ok('служебные метки шагов не видны пользователю');
  assert.equal((await calls(p, 'sendChat')).filter((c) => /^title_/.test(c[1])).length, 1); ok('после первого ответа запрашивается название чата');
  const tid = (await calls(p, 'sendChat')).filter((c) => /^title_/.test(c[1]))[0][1];
  assert.match(await p.$eval('#chatList .chat-item b', (e) => e.textContent), /^Найди вакансии/); ok('пока ждём ИИ, название уже получено локально');
  await emit(p, 'chatDelta', { id: tid, text: '«Работа для подростков в Баку»' }); await emit(p, 'chatDone', { id: tid }); await p.waitForTimeout(200);
  assert.equal(await p.$eval('#chatList .chat-item b', (e) => e.textContent), 'Работа для подростков в Баку'); assert.equal(await p.$eval('#topTitle', (e) => e.textContent), 'Работа для подростков в Баку'); ok('ИИ придумал название чата («Недавние»)');
  assert.ok(!(await p.$eval('#messages', (e) => e.textContent.includes('Работа для подростков в Баку')))); ok('запрос названия не попал в сообщения чата');
  const mem = (await calls(p, 'sendChat')).length;
  await p.fill('#input', 'А ещё есть?'); await p.click('#sendBtn'); await p.waitForTimeout(60);
  const s2 = await p.evaluate(() => window.__lastReq); await emit(p, 'chatDelta', { id: s2, text: 'Да.' }); await emit(p, 'chatDone', { id: s2 }); await p.waitForTimeout(200);
  assert.equal((await calls(p, 'sendChat')).filter((c) => /^title_/.test(c[1])).length, 1); ok('название придумывается один раз, не после каждого ответа');
  // файлы, созданные JARVIS
  await p.fill('#input', 'Сделай архив с сайтом и картинку кота'); await p.click('#sendBtn'); await p.waitForTimeout(60);
  const f1 = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatDelta', { id: f1, text: 'Собираю архив.\n<tool>{"name":"create_zip","name2":"x","files":[{"name":"index.html","content":"<h1>Hi</h1>"}]}</tool>' }); await emit(p, 'chatDone', { id: f1 }); await p.waitForTimeout(100);
  assert.equal((await calls(p, 'androidTool')).pop()[2], 'create_zip'); ok('создание архива уходит в Android как инструмент');
  await emit(p, 'toolResult', { reqId: f1, ok: true, name: 'create_zip', data: { ok: true, file: { id: 'site.zip', name: 'site.zip', size: 2048, mime: 'application/zip', kind: 'archive' }, message: 'Архив создан' } }); await p.waitForTimeout(150);
  assert.equal(await p.$$eval('.msg.assistant .fcard', (e) => e.length), 1); assert.match(await p.$eval('.msg.assistant .fcard', (e) => e.textContent), /site\.zip[\s\S]*ZIP-архив · 2\.0 КБ/); ok('созданный ZIP показан карточкой файла (имя, тип, размер)');
  await p.click('.msg.assistant .fcard .fcard-tx'); await p.waitForTimeout(60);
  let dl = (await calls(p, 'fileDownload')).pop(); assert.equal(dl[1], 'site.zip'); assert.equal(dl[2], true); ok('нажатие на ZIP: сначала скачивание, затем открываются «Мои файлы»');
  await emit(p, 'toolResult', { reqId: f1, ok: true, name: 'generate_image', data: { ok: true, file: { id: 'cat.png', name: 'cat.png', size: 90000, mime: 'image/png', kind: 'image' } } }).catch(() => {});
  await emit(p, 'chatDelta', { id: f1, text: 'Рисую.\n<tool>{"name":"generate_image","prompt":"a cat"}</tool>' }); await emit(p, 'chatDone', { id: f1 }); await p.waitForTimeout(100);
  await emit(p, 'toolResult', { reqId: f1, ok: true, name: 'generate_image', data: { ok: true, file: { id: 'cat.png', name: 'cat.png', size: 90000, mime: 'image/png', kind: 'image' } } }); await p.waitForTimeout(150);
  assert.ok((await calls(p, 'fileThumb')).some((c) => c[1] === 'cat.png')); ok('для изображения запрашивается превью');
  await emit(p, 'fileThumb', { id: 'cat.png', url: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', side: 900 }); await p.waitForTimeout(60);
  assert.match(await p.$eval('.msg.assistant .fimg img', (e) => e.getAttribute('src')), /^data:image\/png/); ok('сгенерированное изображение показано прямо в чате');
  await p.click('.msg.assistant .fimg'); await p.waitForTimeout(80);
  assert.ok(!(await p.$eval('#lightbox', (e) => e.hidden))); ok('нажатие на изображение открывает его на весь экран');
  await p.click('#lbSave'); assert.equal((await calls(p, 'fileDownload')).pop()[1], 'cat.png'); ok('из просмотра изображение можно скачать');
  assert.equal(await p.evaluate(() => window.jarvisBack()), true); assert.ok(await p.$eval('#lightbox', (e) => e.hidden)); ok('«Назад» закрывает просмотр изображения');
  await emit(p, 'fileResult', { id: 'site.zip', action: 'download', ok: true, where: 'Загрузки/JARVIS/site.zip' }); await p.waitForTimeout(60);
  assert.match(await p.$eval('#toast', (e) => e.textContent), /Загрузки\/JARVIS\/site\.zip/); ok('после скачивания показано, куда сохранён файл');
  await emit(p, 'chatDelta', { id: f1, text: 'Готово: архив и картинка.' }); await emit(p, 'chatDone', { id: f1 }); await p.waitForTimeout(150);
  // вложение пользователя
  await emit(p, 'files', { items: [{ ok: true, name: 'док.txt', kind: 'text', text: 'привет', chars: 6, size: 12, fid: 'док.txt', mime: 'text/plain' }] }); await p.waitForTimeout(60);
  await p.fill('#input', 'прочти'); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const uf = await p.$$('.msg.user .fcard'); assert.ok(uf.length >= 1); ok('вложенный файл показан в чате карточкой, а не просто названием');
  await p.locator('.msg.user .fcard').last().locator('.fcard-tx').click(); assert.equal((await calls(p, 'fileOpen')).pop()[1], 'док.txt'); ok('вложенный текстовый файл открывается нажатием');
  assert.equal(p.errors.length, 0); ok('ошибок JavaScript нет');
  await p.close();

  console.log('Правка сообщения и экспорт');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'Первый вопрос'); await p.click('#sendBtn'); await p.waitForTimeout(60);
  const e1 = await p.evaluate(() => window.__lastReq); await emit(p, 'chatDelta', { id: e1, text: 'Ответ.' }); await emit(p, 'chatDone', { id: e1 }); await p.waitForTimeout(200);
  await p.click('.msg.user [data-a="edit"]'); await p.waitForTimeout(80);
  assert.equal(await p.$eval('#input', (e) => e.value), 'Первый вопрос'); assert.equal(await p.$$eval('#messages .msg', (e) => e.length), 0); ok('«Изменить»: текст вернулся в поле, старый ответ убран');
  await p.click('.msg.assistant [data-a="share"]').catch(() => {}); 
  assert.equal(p.errors.length, 0); ok('ошибок JavaScript нет');
  await p.close();

  console.log('Live Voice и экран');
  p = await boot(browser, { signedIn: true });
  await emit(p, 'ttsReady', { ready: true });
  await p.click('#openVoice'); await p.waitForTimeout(450);
  assert.equal((await calls(p, 'startLive')).length, 1); assert.equal((await calls(p, 'keepScreenOn')).pop()[1], true); assert.ok((await calls(p, 'startListening')).length >= 1); ok('Live включается сам при открытии: служба с уведомлением, экран не гаснет, слушает');
  assert.ok(await p.$eval('#voice', (e) => e.classList.contains('is-live'))); assert.ok(!(await p.$eval('#vMic', (e) => e.offsetParent !== null))); ok('в Live ручной микрофон скрыт, слушает сам');
  const l0 = (await calls(p, 'startListening')).length;
  await emit(p, 'speech', { type: 'error', code: 'no_match' }); await p.waitForTimeout(600);
  assert.ok((await calls(p, 'startListening')).length > l0); ok('Live сам продолжает слушать после тишины');
  assert.notEqual(await p.evaluate(() => document.body.dataset.orb), 'error'); ok('тишина в Live не мигает ошибкой');
  await emit(p, 'speech', { type: 'listening' });
  await emit(p, 'speech', { type: 'partial', text: 'привет' }); await p.waitForTimeout(1500);
  assert.ok((await calls(p, 'finishListening')).length >= 1); ok('конец фразы фиксируется сам по паузе ~1,3 с (быстрее системной)');
  await emit(p, 'speech', { type: 'result', text: 'привет' }); await p.waitForTimeout(100);
  const lid = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatDelta', { id: lid, text: 'Здравствуйте, сэр. Чем могу' }); await p.waitForTimeout(50);
  const st = await calls(p, 'ttsStreamStart'), ad = await calls(p, 'ttsStreamAdd');
  assert.equal(st.length, 1); assert.equal(ad.length, 1); assert.match(ad[0][1], /^Здравствуйте, сэр\.$/); ok('Live озвучивает первое предложение, не дожидаясь конца ответа');
  assert.equal((await calls(p, 'speak')).length, 0); ok('в Live не ждёт полного ответа перед речью');
  const l1 = (await calls(p, 'startListening')).length;
  await emit(p, 'tts', { state: 'speaking', msgId: lid, index: 0, total: 1 }); await p.waitForTimeout(300);
  assert.ok((await calls(p, 'cancelListening')).length >= 1); assert.equal((await calls(p, 'bargeStart')).length, 1); ok('пока говорит JARVIS: распознавание выключено (нет самопрослушивания), включён детектор перебивания');
  await emit(p, 'tts', { state: 'speaking', msgId: lid, index: 1, total: 2 }); await p.waitForTimeout(100);
  assert.equal((await calls(p, 'bargeStart')).length, 1); ok('детектор перебивания не перезапускается на каждой фразе');
  await emit(p, 'chatDelta', { id: lid, text: ' помочь?' }); await emit(p, 'chatDone', { id: lid }); await p.waitForTimeout(100);
  assert.equal((await calls(p, 'ttsStreamAdd')).pop()[1], 'Чем могу помочь?'); assert.equal((await calls(p, 'ttsStreamEnd')).length, 1); ok('остаток ответа дозвучивается, поток закрывается');
  assert.equal((await calls(p, 'startListening')).length, l1); ok('микрофон не включается, пока JARVIS договаривает');
  await emit(p, 'tts', { state: 'idle', msgId: lid, index: 1, total: 2 }); await p.waitForTimeout(500);
  assert.ok((await calls(p, 'startListening')).length > l1); assert.ok((await calls(p, 'bargeStop')).length >= 1); ok('после ответа Live сразу снова слушает');
  // перебивание: пользователь заговорил поверх длинного ответа
  await emit(p, 'speech', { type: 'listening' }); await emit(p, 'speech', { type: 'result', text: 'расскажи длинную историю' }); await p.waitForTimeout(100);
  const lid2 = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatDelta', { id: lid2, text: 'Жил-был дракон. Он любил читать книги и ' }); await emit(p, 'tts', { state: 'speaking', msgId: lid2, index: 0, total: 1 }); await p.waitForTimeout(100);
  const sc0 = (await calls(p, 'cancelChat')).length, ls0 = (await calls(p, 'startListening')).length;
  await emit(p, 'live', { state: 'bargein' }); await p.waitForTimeout(100);
  assert.ok((await calls(p, 'cancelChat')).length > sc0); ok('перебивание останавливает генерацию ответа');
  await emit(p, 'tts', { state: 'idle', msgId: lid2, index: 0, total: 1 }); await p.waitForTimeout(400);
  assert.ok((await calls(p, 'startListening')).length > ls0); ok('после перебивания сразу слушает пользователя');
  await emit(p, 'chatDelta', { id: lid2, text: ' ещё текст. И ещё одно предложение.' }); await p.waitForTimeout(50);
  assert.equal((await calls(p, 'ttsStreamAdd')).filter((c) => /ещё текст/.test(c[1])).length, 0); ok('после перебивания старый ответ больше не озвучивается');
  await p.click('#vMute'); await p.waitForTimeout(50);
  assert.ok(await p.$eval('#vMute', (e) => e.classList.contains('on'))); ok('выключение микрофона в Live');
  await p.click('#vMute');
  assert.equal(await p.evaluate(() => window.jarvisBack()), true); assert.ok(await p.$eval('#voice', (e) => e.classList.contains('open'))); ok('«Назад» не выключает Live');
  await emit(p, 'live', { state: 'stopped' }); await p.waitForTimeout(100);
  assert.ok(!(await p.$eval('#voice', (e) => e.classList.contains('is-live')))); ok('кнопка «Стоп» в уведомлении выключает Live в интерфейсе');
  await p.click('#vScreen'); assert.equal((await calls(p, 'startScreenShare')).length, 1);
  await emit(p, 'screen', { state: 'started' }); await p.waitForTimeout(50);
  const sp = p.evaluate(() => new Promise((r) => { window.JarvisEvents.emit('speech', JSON.stringify({ type: 'result', text: 'что на экране?' })); setTimeout(() => window.JarvisEvents.emit('screen', JSON.stringify({ state: 'frame', image: 'data:image/jpeg;base64,AAAA' })), 150); setTimeout(r, 400); }));
  await sp; await p.waitForTimeout(100);
  const withImg = JSON.parse((await calls(p, 'sendChat')).pop()[2]).filter((m) => m.image);
  assert.equal(withImg.length, 1); ok('вопрос голосом уходит вместе со свежим кадром экрана'); await p.close();

  console.log('Приложения');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'открой телеграм'); await p.click('#sendBtn'); await p.waitForTimeout(150);
  assert.match(await p.$eval('#messages', (e) => e.textContent), /Google Play/); assert.equal((await calls(p, 'sendChat')).length, 0); ok('команда открытия приложения выполняется локально (установлено: запуск, нет: Google Play)');
  await p.close();

  await browser.close();
  console.log('\nПройдено проверок: ' + passed);
})().catch((e) => { console.error('ПРОВАЛ:', e.message); process.exit(1); });
