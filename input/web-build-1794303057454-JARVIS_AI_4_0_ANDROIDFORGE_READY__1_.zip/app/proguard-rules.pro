# JNI-слой Sherpa-ONNX читает поля и конструкторы этих классов по именам: переименование ломает распознавание.
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class ai.onnxruntime.** { *; }
