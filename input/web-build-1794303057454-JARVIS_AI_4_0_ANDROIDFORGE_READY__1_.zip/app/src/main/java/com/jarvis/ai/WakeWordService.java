package com.jarvis.ai;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

/**
 * Голосовая активация «Джарвис». Foreground-служба с постоянным уведомлением и кнопкой «Выключить»:
 * пока служба работает, микрофон слушает ТОЛЬКО локальный детектор слова (аудио не сохраняется и никуда
 * не отправляется). После срабатывания запись останавливается, микрофон освобождается, открывается голосовой
 * диалог JARVIS; после диалога приложение возобновляет ожидание (resume()).
 * Запускается только когда приложение на экране (ограничение Android 14 для микрофонных служб).
 */
public class WakeWordService extends Service {
    static final String ACTION_START = "com.jarvis.ai.WAKE_START";
    static final String ACTION_STOP = "com.jarvis.ai.WAKE_STOP";
    static final String ACTION_WAKE = "com.jarvis.ai.WAKE";
    private static final String CHANNEL = "jarvis_wake";
    private static final String CHANNEL_ALERT = "jarvis_wake_alert";
    private static final int NOTIF_ID = 4713, NOTIF_ALERT = 4714;
    private static final float THRESHOLD = 0.5f;
    private static final int PATIENCE = 2;

    static volatile boolean running = false;
    static volatile boolean paused = false;
    static volatile boolean pendingWake = false;
    static volatile String lastError = "";
    private static volatile WakeWordService inst;

    private volatile boolean stopFlag = false;
    private Thread worker;

    static boolean start(Context c) {
        if (c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false;
        try {
            Intent i = new Intent(c, WakeWordService.class).setAction(ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
            return true;
        } catch (Exception e) {
            lastError = "Не удалось запустить службу: " + e.getClass().getSimpleName();
            return false;
        }
    }

    static void stop(Context c) {
        try { c.startService(new Intent(c, WakeWordService.class).setAction(ACTION_STOP)); } catch (Exception ignored) { }
    }

    /** Освободить микрофон для приложения (диктовка, голосовой диалог). */
    static void pause() {
        paused = true;
    }

    /** Вернуться к ожиданию слова после диалога. */
    static void resume() {
        paused = false;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            shutdown();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action)) {
            if (!running) stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Голосовая активация JARVIS", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent open = PendingIntent.getActivity(this, 21,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT | imm);
        PendingIntent off = PendingIntent.getService(this, 22,
                new Intent(this, WakeWordService.class).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT | imm);
        b.setContentTitle("JARVIS ждёт слово «Джарвис»")
                .setContentText("Микрофон слушает только локальный детектор слова. Аудио не сохраняется и не отправляется.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", off);
        try {
            if (Build.VERSION.SDK_INT >= 30) startForeground(NOTIF_ID, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(NOTIF_ID, b.build());
        } catch (Exception e) {
            lastError = "Android не разрешил запуск микрофонной службы: " + e.getClass().getSimpleName();
            stopSelf();
            return START_NOT_STICKY;
        }
        running = true;
        inst = this;
        stopFlag = false;
        lastError = "";
        paused = false;
        worker = new Thread(new Runnable() {
            @Override public void run() { loop(); }
        }, "jarvis-wake");
        worker.start();
        return START_NOT_STICKY;
    }

    private void loop() {
        WakeWordEngine engine = null;
        AudioRecord rec = null;
        try {
            engine = WakeWordEngine.create(getApplicationContext());
            short[] buf = new short[WakeWordEngine.CHUNK];
            int hits = 0;
            long cooldownUntil = 0;
            while (!stopFlag) {
                if (paused) {
                    if (rec != null) { releaseRec(rec); rec = null; }
                    if (engine != null) engine.reset();
                    hits = 0;
                    SystemClock.sleep(200);
                    continue;
                }
                if (rec == null) {
                    rec = openRec();
                    if (rec == null) { lastError = "Микрофон занят или недоступен"; SystemClock.sleep(1500); continue; }
                }
                int got = 0;
                while (got < buf.length && !stopFlag && !paused) {
                    int n = rec.read(buf, got, buf.length - got);
                    if (n <= 0) break;
                    got += n;
                }
                if (got < buf.length) {
                    if (stopFlag || paused) continue;
                    releaseRec(rec); rec = null; SystemClock.sleep(500); continue;
                }
                if (SystemClock.uptimeMillis() < cooldownUntil) { engine.feed(buf); continue; }
                float score = engine.feed(buf);
                hits = score >= THRESHOLD ? hits + 1 : 0;
                if (hits >= PATIENCE) {
                    hits = 0;
                    cooldownUntil = SystemClock.uptimeMillis() + 3000;
                    paused = true;                  // отдаём микрофон приложению
                    releaseRec(rec); rec = null;
                    engine.reset();
                    onWake();
                }
            }
        } catch (Throwable t) {
            lastError = "Ошибка детектора: " + t.getClass().getSimpleName();
        } finally {
            if (rec != null) releaseRec(rec);
            if (engine != null) engine.close();
            running = false;
            stopForeground(true);
            stopSelf();
        }
    }

    private AudioRecord openRec() {
        try {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return null;
            int min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            AudioRecord r = new AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, WakeWordEngine.CHUNK * 8));
            if (r.getState() != AudioRecord.STATE_INITIALIZED) { r.release(); return null; }
            r.startRecording();
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    private static void releaseRec(AudioRecord r) {
        try { r.stop(); } catch (Exception ignored) { }
        try { r.release(); } catch (Exception ignored) { }
    }

    private void onWake() {
        pendingWake = true;
        if (MainActivity.foreground) {
            MainActivity a = MainActivity.current;
            if (a != null) { a.onWakeWord(); return; }
        }
        // приложение не на экране: пробуем открыть; Android может это запретить, поэтому есть уведомление
        Intent i = new Intent(this, MainActivity.class).setAction(ACTION_WAKE)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try { startActivity(i); } catch (Exception ignored) { }
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL_ALERT, "Обращение к JARVIS", NotificationManager.IMPORTANCE_HIGH));
                b = new Notification.Builder(this, CHANNEL_ALERT);
            } else {
                b = new Notification.Builder(this);
            }
            int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
            PendingIntent pi = PendingIntent.getActivity(this, 23, i, PendingIntent.FLAG_UPDATE_CURRENT | imm);
            b.setContentTitle("Слушаю вас").setContentText("Нажмите, чтобы продолжить диалог с JARVIS")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setAutoCancel(true);
            nm.notify(NOTIF_ALERT, b.build());
        } catch (Exception ignored) { }
    }

    private void shutdown() {
        stopFlag = true;
        if (worker == null || !worker.isAlive()) {
            running = false;
            stopForeground(true);
            stopSelf();
        }
    }

    @Override
    public void onDestroy() {
        stopFlag = true;
        running = false;
        if (inst == this) inst = null;
        super.onDestroy();
    }
}
