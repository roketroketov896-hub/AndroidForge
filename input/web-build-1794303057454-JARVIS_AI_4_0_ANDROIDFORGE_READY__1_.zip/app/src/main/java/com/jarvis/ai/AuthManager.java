package com.jarvis.ai;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import androidx.credentials.ClearCredentialStateRequest;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;

/**
 * Вход через Google (Credential Manager) + долгая сессия сервера JARVIS.
 * Google показывается один раз: ID-токен меняется на подписанную сессию Worker (30 дней, продлевается),
 * которая хранится в Keystore-шифровании (SecureStore). Тихих окон Google при возврате в приложение нет.
 * Права администратора определяет только сервер.
 */
final class AuthManager {
    private final SharedPreferences prefs;
    private final SecureStore store;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Executor mainExecutor = new Executor() {
        @Override
        public void execute(Runnable command) {
            main.post(command);
        }
    };
    private volatile String idToken = "";

    AuthManager(SharedPreferences prefs, SecureStore store) {
        this.prefs = prefs;
        this.store = store;
    }

    JSONObject profile() {
        JSONObject o = new JSONObject();
        try {
            o.put("signedIn", isSignedIn());
            String em = prefs.getString("auth_email", "");
            String gName = prefs.getString("auth_name", "");
            String cn = prefs.getString("cp_name_" + em, "");
            String cp = prefs.getString("cp_photo_" + em, "");
            o.put("googleName", gName);
            o.put("name", cn.isEmpty() ? gName : cn);
            o.put("customName", cn);
            o.put("email", em);
            o.put("photo", cp.isEmpty() ? prefs.getString("auth_photo", "") : cp);
            o.put("customPhoto", !cp.isEmpty());
            o.put("avatar", prefs.getString("cp_avatar_" + em, ""));
            o.put("isAdmin", isSignedIn() && prefs.getBoolean("auth_admin", false));
        } catch (Exception ignored) {
        }
        return o;
    }

    /** Свой профиль: только на телефоне, по аккаунту. Google-аккаунт не меняется. */
    void saveProfile(JSONObject p) {
        String em = prefs.getString("auth_email", "");
        if (em.isEmpty()) return;
        SharedPreferences.Editor e = prefs.edit();
        if (p.has("name")) {
            String n = p.optString("name").trim();
            if (n.length() > 40) n = n.substring(0, 40);
            if (n.isEmpty()) e.remove("cp_name_" + em); else e.putString("cp_name_" + em, n);
        }
        if (p.has("photo")) {
            String ph = p.optString("photo");
            if (ph.startsWith("data:image/") && ph.length() < 200000) e.putString("cp_photo_" + em, ph); else e.remove("cp_photo_" + em);
        }
        if (p.has("avatar")) {
            String av = p.optString("avatar");
            if (av.matches("std:[0-9]{1,2}")) e.putString("cp_avatar_" + em, av); else e.remove("cp_avatar_" + em);
        }
        e.commit();
    }

    void resetProfile() {
        String em = prefs.getString("auth_email", "");
        prefs.edit().remove("cp_name_" + em).remove("cp_photo_" + em).remove("cp_avatar_" + em).commit();
    }

    boolean isSignedIn() {
        return prefs.getBoolean("auth_signed_in", false);
    }

    interface Done {
        void done(boolean ok, String error);
    }

    /** Явный вход: системный выбор аккаунта Google, затем обмен на сессию сервера. Главный поток. */
    void signIn(final Activity act, final String webClientId, final String base, final Done done) {
        if (webClientId == null || webClientId.trim().isEmpty()) {
            done.done(false, "no_client_id");
            return;
        }
        try {
            GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(webClientId.trim()).build();
            GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
            CredentialManager manager = CredentialManager.create(act);
            manager.getCredentialAsync(act, request, new CancellationSignal(), mainExecutor,
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override
                        public void onResult(final GetCredentialResponse result) {
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    final String[] err = {""};
                                    final boolean ok = handle(result.getCredential(), base, err);
                                    main.post(new Runnable() {
                                        @Override
                                        public void run() {
                                            done.done(ok, err[0]);
                                        }
                                    });
                                }
                            }, "jarvis-login").start();
                        }

                        @Override
                        public void onError(GetCredentialException e) {
                            done.done(false, e.getClass().getSimpleName() + ": " + e.getMessage());
                        }
                    });
        } catch (Exception e) {
            done.done(false, e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    /** Фоновый поток. Сохраняет профиль и сессию. */
    private boolean handle(Credential credential, String base, String[] err) {
        try {
            if (!(credential instanceof CustomCredential)
                    || !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                err[0] = "unexpected_credential";
                return false;
            }
            GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(credential.getData());
            String gid = g.getIdToken();
            String newEmail = g.getId() == null ? "" : g.getId().toLowerCase();
            String oldEmail = prefs.getString("auth_email", "").toLowerCase();
            // Смена аккаунта: полностью сбрасываем прошлую сессию и права.
            if (!oldEmail.isEmpty() && !oldEmail.equals(newEmail)) wipeSession();
            boolean admin = false;
            String session = "";
            if (base != null && !base.isEmpty()) {
                JSONObject r = post(base + "/v1/session", "", new JSONObject().put("credential", gid), err);
                if (r != null && r.optBoolean("ok")) {
                    session = r.optString("session", "");
                    JSONObject u = r.optJSONObject("user");
                    admin = u != null && u.optBoolean("isAdmin", false);
                } else if (!"session_not_configured".equals(err[0]) && !"network".equals(err[0])) {
                    return false; // сервер отверг токен
                }
            }
            if (!session.isEmpty()) {
                store.put("session", session);
                store.clear("idtoken");
                idToken = "";
            } else {
                // Совместимый режим: сервер без SESSION_SECRET. Живёт, пока действует Google-токен (~1 ч).
                idToken = gid;
                store.put("idtoken", gid);
                store.clear("session");
            }
            err[0] = "";
            String name = g.getDisplayName() == null ? "" : g.getDisplayName();
            String photo = g.getProfilePictureUri() == null ? "" : g.getProfilePictureUri().toString();
            prefs.edit()
                    .putBoolean("auth_signed_in", true)
                    .putBoolean("auth_admin", admin)
                    .putString("auth_name", name)
                    .putString("auth_email", newEmail)
                    .putString("auth_photo", photo)
                    .commit();
            return true;
        } catch (Exception e) {
            err[0] = e.getClass().getSimpleName() + ": " + e.getMessage();
            return false;
        }
    }

    /** HTTP к Worker. err[0] = код ошибки (session_not_configured, auth_required, network, ...). */
    private static JSONObject post(String url, String bearer, JSONObject body, String[] err) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            if (!bearer.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + bearer);
            try (OutputStream os = c.getOutputStream()) {
                os.write((body == null ? "{}" : body.toString()).getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            StringBuilder sb = new StringBuilder();
            if (in != null) {
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0 && sb.length() < 200000) sb.append(new String(buf, 0, n, StandardCharsets.UTF_8));
            }
            JSONObject j = sb.length() == 0 ? new JSONObject() : new JSONObject(sb.toString());
            if (code >= 400) {
                JSONObject e = j.optJSONObject("error");
                err[0] = e == null ? "http_" + code : e.optString("code", "http_" + code);
                if (code == 401 && "http_401".equals(err[0])) err[0] = "auth_required";
                return null;
            }
            return j;
        } catch (Exception e) {
            err[0] = "network";
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static long expiry(String jwt) {
        try {
            String payload = jwt.split("\\.")[1];
            byte[] b = Base64.decode(payload, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            return new JSONObject(new String(b, StandardCharsets.UTF_8)).optLong("exp", 0L);
        } catch (Exception e) {
            return 0L;
        }
    }

    private static boolean valid(String t) {
        return t != null && !t.isEmpty() && expiry(t) > System.currentTimeMillis() / 1000L + 120L;
    }

    /** Действующий токен без сети и без окон (для фоновых автоответов). Пусто, если нет или истёк. */
    String cachedToken() {
        String s = store.get("session");
        if (valid(s)) return s;
        if (valid(idToken)) return idToken;
        String saved = store.get("idtoken");
        if (valid(saved)) {
            idToken = saved;
            return saved;
        }
        return "";
    }

    /**
     * Токен для запросов к серверу. Блокирующий (сеть): только из фонового потока. Никогда не показывает окон Google.
     * Если сессия скоро истекает (меньше 7 дней), продлевает её у сервера. Если сервер сказал, что сессия
     * недействительна, локальный вход сбрасывается, и приложение покажет экран входа.
     */
    String ensureToken(Activity act, String webClientId) {
        return ensureToken(act, webClientId, MainActivity.normalizeBase(BuildConfig.BACKEND_URL));
    }

    String ensureToken(Activity act, String webClientId, String base) {
        String s = store.get("session");
        if (valid(s)) {
            long left = expiry(s) - System.currentTimeMillis() / 1000L;
            if (left < 7 * 86400L && base != null && !base.isEmpty()) {
                String[] err = {""};
                JSONObject r = post(base + "/v1/session/refresh", s, new JSONObject(), err);
                if (r != null && r.optBoolean("ok") && !r.optString("session").isEmpty()) {
                    store.put("session", r.optString("session"));
                    JSONObject u = r.optJSONObject("user");
                    prefs.edit().putBoolean("auth_admin", u != null && u.optBoolean("isAdmin", false)).apply();
                    return r.optString("session");
                }
                if ("auth_required".equals(err[0])) {
                    signOutLocal();
                    return "";
                }
            }
            return s;
        }
        if (!s.isEmpty()) { // сессия истекла
            signOutLocal();
            return "";
        }
        String c = cachedToken();
        if (!c.isEmpty()) return c;
        if (isSignedIn() && store.get("idtoken").isEmpty()) {
            signOutLocal();
        }
        return "";
    }

    /** Спрашивает у сервера, кто я и админ ли (единственный источник прав). Фоновый поток. true, если вход ещё действителен. */
    boolean checkMe(String base) {
        String t = cachedToken();
        if (t.isEmpty() || base == null || base.isEmpty()) return false;
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(base + "/v1/me").openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setRequestProperty("Authorization", "Bearer " + t);
            int code = c.getResponseCode();
            if (code == 401) {
                signOutLocal();
                return false;
            }
            if (code != 200) return true; // сервер временно недоступен: оставляем вход, права не меняем
            StringBuilder sb = new StringBuilder();
            byte[] buf = new byte[2048];
            int n;
            InputStream in = c.getInputStream();
            while ((n = in.read(buf)) > 0 && sb.length() < 20000) sb.append(new String(buf, 0, n, StandardCharsets.UTF_8));
            JSONObject j = new JSONObject(sb.toString());
            prefs.edit().putBoolean("auth_admin", j.optBoolean("isAdmin", false)).apply();
            return true;
        } catch (Exception e) {
            return true;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void wipeSession() {
        idToken = "";
        store.clear("idtoken");
        store.clear("session");
        prefs.edit()
                .putBoolean("auth_signed_in", false)
                .putBoolean("auth_admin", false)
                .remove("auth_name")
                .remove("auth_email")
                .remove("auth_photo")
                .commit();
    }

    private void signOutLocal() {
        wipeSession();
    }

    /** Выход из JARVIS: стирает сессию и права, заставляет Google забыть автовыбор аккаунта. Аккаунты на устройстве не трогает. */
    void signOut(Activity act) {
        wipeSession();
        try {
            CredentialManager.create(act).clearCredentialStateAsync(new ClearCredentialStateRequest(), new CancellationSignal(), mainExecutor,
                    new CredentialManagerCallback<Void, androidx.credentials.exceptions.ClearCredentialException>() {
                        @Override
                        public void onResult(Void r) {
                        }

                        @Override
                        public void onError(androidx.credentials.exceptions.ClearCredentialException e) {
                        }
                    });
        } catch (Throwable ignored) {
        }
    }
}
