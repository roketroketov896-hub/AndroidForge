package com.jarvis.ai;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Интеграция с WhatsApp через разрешённые механизмы Android:
 *  - ответ через действие «Ответить» из уведомления (NotificationListenerService + RemoteInput);
 *  - открытие чата по ссылке wa.me с готовым текстом; кнопку отправки может нажать служба доступности,
 *    если пользователь её включил.
 * Состояния: awaiting_confirmation → sent | prepared | failed. Статус "sent" выставляется только когда
 * система приняла отправку или кнопка отправки реально нажата. Доставку получателю приложение подтвердить не может.
 */
final class WhatsApp {
    static final class Draft {
        String id, to, phone, text, route, state = "awaiting_confirmation", detail = "";
    }

    static volatile Emitter emitter;
    private static final Map<String, Draft> DRAFTS = new ConcurrentHashMap<>();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private WhatsApp() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("jarvis_wa", Context.MODE_PRIVATE);
    }

    // ---------- настройки и журнал (общее ядро AutoReply) ----------

    static JSONObject config(Context c) {
        return AutoReply.config(c, AutoReply.WA);
    }

    static void saveConfig(Context c, JSONObject patch) {
        AutoReply.saveConfig(c, AutoReply.WA, patch);
    }

    private static boolean inList(JSONArray a, String name) {
        String n = AutoReply.contactKey(name);
        if (n.isEmpty() || a == null) return false;
        for (int i = 0; i < a.length(); i++) if (n.equals(AutoReply.contactKey(a.optString(i, "")))) return true;
        return false;
    }

    static JSONArray log(Context c) {
        return AutoReply.log(c, AutoReply.WA);
    }

    static void clearLog(Context c) {
        AutoReply.clearLog(c, AutoReply.WA);
    }

    private static void addLog(Context c, String who, String state, String detail) {
        AutoReply.addLog(c, AutoReply.WA, who, state, detail);
    }

    // ---------- черновики и отправка ----------

    static JSONObject draftJson(Draft d) {
        JSONObject o = new JSONObject();
        try {
            o.put("draftId", d.id);
            o.put("to", d.to);
            o.put("text", d.text);
            o.put("route", d.route);
            o.put("state", d.state);
            o.put("detail", d.detail);
            o.put("hasPhone", d.phone != null && !d.phone.isEmpty());
        } catch (Exception ignored) {
        }
        return o;
    }

    private static JSONObject err(String code, String msg) {
        JSONObject o = new JSONObject();
        try {
            o.put("ok", false);
            o.put("code", code);
            o.put("message", msg);
        } catch (Exception ignored) {
        }
        return o;
    }

    /** Готовит черновик. Ничего не отправляет: окончательное решение за пользователем. */
    static JSONObject prepare(Context c, String to, String text) {
        try {
            if (to == null || to.trim().isEmpty() || text == null || text.trim().isEmpty())
                return err("bad_args", "Нужны получатель и текст сообщения.");
            String name = to.trim();
            JSONObject cfg = config(c);
            if (inList(cfg.optJSONArray("blocked"), name)) return err("contact_blocked", "Контакт «" + name + "» в чёрном списке WhatsApp. Сообщение не подготовлено.");
            String phone = "";
            if (Contacts.looksLikePhone(name)) {
                phone = Contacts.digits(name);
            } else if (JarvisNotificationListener.findReplyTarget(name) == null) {
                JSONArray found;
                try {
                    found = Contacts.find(c, name);
                } catch (SecurityException se) {
                    return err("permission_needed:contacts", "Нужен доступ к контактам, чтобы найти номер «" + name + "».");
                }
                if (found.length() == 0) return err("not_found", "Контакт «" + name + "» не найден.");
                if (found.length() > 1) {
                    Set<String> names = new HashSet<>();
                    for (int i = 0; i < found.length(); i++) names.add(found.getJSONObject(i).optString("name"));
                    if (names.size() > 1) {
                        JSONObject r = err("ambiguous", "Найдено несколько контактов. Уточни, кому писать.");
                        r.put("candidates", found);
                        return r;
                    }
                }
                name = found.getJSONObject(0).optString("name", name);
                phone = Contacts.digits(found.getJSONObject(0).optString("phone"));
                if (inList(cfg.optJSONArray("blocked"), name)) return err("contact_blocked", "Контакт «" + name + "» в чёрном списке WhatsApp.");
            }
            Draft d = new Draft();
            d.id = UUID.randomUUID().toString().substring(0, 8);
            d.to = name;
            d.phone = phone;
            d.text = text.trim();
            boolean canReply = JarvisNotificationListener.isEnabled(c) && JarvisNotificationListener.findReplyTarget(name) != null;
            d.route = canReply ? "reply" : "deeplink";
            if (!canReply && phone.isEmpty()) return err("no_number", "Для «" + name + "» нет номера и нет свежего уведомления с возможностью ответа.");
            DRAFTS.put(d.id, d);
            JSONObject r = draftJson(d);
            r.put("ok", true);
            return r;
        } catch (Exception e) {
            return err("error", "Не удалось подготовить сообщение: " + e.getClass().getSimpleName());
        }
    }

    private static void emitState(Draft d) {
        Emitter e = emitter;
        if (e != null) e.emit("waState", draftJson(d));
    }

    private static String waPackage(Context c) {
        PackageManager pm = c.getPackageManager();
        for (String p : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
            try {
                pm.getPackageInfo(p, 0);
                return p;
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    static boolean installed(Context c) {
        return waPackage(c) != null;
    }

    /** Вызывается только после явного подтверждения пользователем в интерфейсе. */
    static JSONObject confirm(final Context c, String draftId, String finalText) {
        final Draft d = DRAFTS.get(draftId);
        if (d == null) return err("no_draft", "Черновик не найден или уже обработан.");
        if (!"awaiting_confirmation".equals(d.state)) return err("already", "Этот черновик уже обработан: " + d.state);
        if (finalText != null && !finalText.trim().isEmpty()) d.text = finalText.trim();
        String who = d.to;
        if ("reply".equals(d.route)) {
            JarvisNotificationListener.Item it = JarvisNotificationListener.findReplyTarget(d.to);
            if (it != null && JarvisNotificationListener.sendReply(c, it, d.text)) {
                d.state = "sent";
                d.detail = "Ответ передан WhatsApp через уведомление. Доставку приложение подтвердить не может.";
                AutoReply.noteOur(AutoReply.WA, d.to, d.text);
                addLog(c, who, "sent", "вручную: " + d.text);
                emitState(d);
                return draftJson(d);
            }
            if (d.phone == null || d.phone.isEmpty()) {
                d.state = "failed";
                d.detail = "Уведомление с ответом устарело, а номера контакта нет.";
                addLog(c, who, "failed", d.detail);
                emitState(d);
                return draftJson(d);
            }
        }
        String pkg = waPackage(c);
        if (pkg == null) {
            d.state = "failed";
            d.detail = "WhatsApp не установлен.";
            addLog(c, who, "failed", d.detail);
            emitState(d);
            return draftJson(d);
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + d.phone + "?text=" + Uri.encode(d.text)));
            i.setPackage(pkg);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception e) {
            d.state = "failed";
            d.detail = "Не удалось открыть WhatsApp.";
            addLog(c, who, "failed", d.detail);
            emitState(d);
            return draftJson(d);
        }
        d.state = "prepared";
        d.detail = "Чат открыт, текст вставлен. Нажми кнопку отправки в WhatsApp.";
        if (JarvisAccessibilityService.isConnected()) {
            tryClickSend(c, d, 0);
        } else {
            addLog(c, who, "prepared", "чат открыт, нужна ручная отправка");
        }
        emitState(d);
        return draftJson(d);
    }

    private static void tryClickSend(final Context c, final Draft d, final int attempt) {
        MAIN.postDelayed(new Runnable() {
            @Override
            public void run() {
                JarvisAccessibilityService s = JarvisAccessibilityService.instance;
                if (s != null && s.clickWhatsAppSend()) {
                    d.state = "sent";
                    d.detail = "Кнопка отправки нажата в WhatsApp. Доставку приложение подтвердить не может.";
                    AutoReply.noteOur(AutoReply.WA, d.to, d.text);
                    addLog(c, d.to, "sent", "вручную: " + d.text);
                    emitState(d);
                } else if (attempt < 5) {
                    tryClickSend(c, d, attempt + 1);
                } else {
                    d.detail = "Чат открыт, но кнопку отправки нажать не удалось. Нажми её сам.";
                    addLog(c, d.to, "prepared", "кнопка отправки не найдена");
                    emitState(d);
                }
            }
        }, attempt == 0 ? 1800 : 700);
    }

    static JSONObject cancel(String draftId) {
        Draft d = DRAFTS.remove(draftId);
        JSONObject o = new JSONObject();
        try {
            o.put("ok", d != null);
        } catch (Exception ignored) {
        }
        return o;
    }
}
