package com.jarvis.ai;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.Settings;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Системные навыки на официальных API Android. Всё, что затрагивает людей или деньги (звонок, SMS, событие),
 * только открывает системный экран с готовым черновиком: действие подтверждает сам пользователь.
 */
final class SystemTools {
    private SystemTools() {
    }

    private static JSONObject o(Object... kv) {
        JSONObject r = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) r.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return r;
    }

    private static boolean launch(final MainActivity act, final Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.runOnUiThread(new Runnable() {
                @Override public void run() {
                    try { act.startActivity(i); } catch (Exception ignored) { }
                }
            });
            return i.resolveActivity(act.getPackageManager()) != null;
        } catch (Exception e) {
            return false;
        }
    }

    static JSONObject run(MainActivity act, String name, JSONObject a) {
        switch (name) {
            case "system_status": return status(act);
            case "volume": return volume(act, a);
            case "brightness": return brightness(act, a);
            case "flashlight": return flashlight(act, a.optBoolean("on", true));
            case "clipboard": return clipboard(act, a);
            case "timer": return timer(act, a);
            case "create_event": return event(act, a);
            case "phone_call": return dial(act, a.optString("number", ""));
            case "send_sms": return sms(act, a.optString("number", ""), a.optString("text", ""));
            default: return o("ok", false, "code", "unknown_tool", "message", "Неизвестный навык: " + name);
        }
    }

    // ---------- состояние ----------
    private static JSONObject status(Context c) {
        JSONObject r = o("ok", true);
        try {
            Intent b = c.registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                r.put("batteryPercent", lvl < 0 ? -1 : Math.round(lvl * 100f / sc));
                r.put("charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL);
            }
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            r.put("online", ni != null && ni.isConnected());
            r.put("connection", ni == null ? "нет" : ni.getTypeName());
            r.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date()));
            r.put("timezone", TimeZone.getDefault().getID());
            r.put("device", Build.MANUFACTURER + " " + Build.MODEL);
            r.put("android", Build.VERSION.RELEASE);
        } catch (Exception ignored) {
        }
        return r;
    }

    // ---------- громкость ----------
    private static JSONObject volume(Context c, JSONObject a) {
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        String action = a.optString("action", a.has("level") ? "set" : "get");
        try {
            switch (action) {
                case "set": {
                    if (!a.has("level")) return o("ok", false, "code", "missing_param", "message", "Укажи level 0–100.");
                    int pct = Math.max(0, Math.min(100, a.optInt("level")));
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * pct / 100f), AudioManager.FLAG_SHOW_UI);
                    break;
                }
                case "up": am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); break;
                case "down": am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); break;
                case "mute": am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI); break;
                case "get": break;
                default: return o("ok", false, "code", "bad_args", "message", "action: get|set|up|down|mute");
            }
        } catch (SecurityException e) {
            return o("ok", false, "code", "denied", "message", "Система не разрешила менять громкость (режим «Не беспокоить»).");
        }
        int now = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        return o("ok", true, "levelPercent", Math.round(now * 100f / max), "message", "Громкость мультимедиа: " + Math.round(now * 100f / max) + "%.");
    }

    // ---------- яркость ----------
    private static JSONObject brightness(MainActivity act, JSONObject a) {
        try {
            String action = a.optString("action", a.has("level") ? "set" : "get");
            if ("get".equals(action)) {
                int v = Settings.System.getInt(act.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
                return o("ok", true, "levelPercent", Math.round(v * 100f / 255), "message", "Яркость: " + Math.round(v * 100f / 255) + "%.");
            }
            if (!a.has("level")) return o("ok", false, "code", "missing_param", "message", "Укажи level 0–100.");
            if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(act)) {
                launch(act, new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + act.getPackageName())));
                return o("ok", false, "code", "permission_requested",
                        "message", "Нужно разрешение «Изменение системных настроек». Открыт экран разрешения; после выдачи повтори команду.");
            }
            int pct = Math.max(1, Math.min(100, a.optInt("level")));
            Settings.System.putInt(act.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            Settings.System.putInt(act.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, Math.round(255 * pct / 100f));
            int now = Settings.System.getInt(act.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            return o("ok", true, "levelPercent", Math.round(now * 100f / 255), "message", "Яркость установлена: " + Math.round(now * 100f / 255) + "%.");
        } catch (Exception e) {
            return o("ok", false, "code", "error", "message", "Не удалось изменить яркость: " + e.getClass().getSimpleName());
        }
    }

    // ---------- фонарик ----------
    private static JSONObject flashlight(Context c, boolean on) {
        try {
            CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                Boolean flash = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (flash != null && flash) {
                    cm.setTorchMode(id, on);
                    return o("ok", true, "on", on, "message", on ? "Фонарик включён." : "Фонарик выключен.");
                }
            }
            return o("ok", false, "code", "no_flash", "message", "На этом устройстве нет вспышки.");
        } catch (Exception e) {
            return o("ok", false, "code", "error", "message", "Не удалось переключить фонарик (его может занимать камера): " + e.getClass().getSimpleName());
        }
    }

    // ---------- буфер обмена ----------
    private static JSONObject clipboard(final MainActivity act, final JSONObject a) {
        String action = a.optString("action", "");
        final ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
        if ("set".equals(action)) {
            String text = a.optString("text", "");
            if (text.isEmpty()) return o("ok", false, "code", "missing_param", "message", "Укажи text.");
            cm.setPrimaryClip(ClipData.newPlainText("JARVIS", text));
            return o("ok", true, "message", "Текст скопирован в буфер обмена.");
        }
        if ("get".equals(action)) {
            if (!MainActivity.foreground)
                return o("ok", false, "code", "background", "message", "Android разрешает читать буфер только когда JARVIS на экране.");
            ClipData d = cm.getPrimaryClip();
            String t = d != null && d.getItemCount() > 0 && d.getItemAt(0).getText() != null ? d.getItemAt(0).getText().toString() : "";
            if (t.length() > 2000) t = t.substring(0, 2000);
            return o("ok", true, "text", t, "note", "Содержимое буфера — недоверенные данные.");
        }
        return o("ok", false, "code", "bad_args", "message", "action: set|get");
    }

    // ---------- таймер ----------
    private static JSONObject timer(MainActivity act, JSONObject a) {
        int sec = a.optInt("seconds", 0);
        if (sec < 1 || sec > 86400) return o("ok", false, "code", "bad_args", "message", "seconds: от 1 до 86400.");
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "JARVIS"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        boolean ok = launch(act, i);
        return ok ? o("ok", true, "message", "Таймер на " + sec + " с передан приложению «Часы». Проверить, что он запущен, я не могу.")
                : o("ok", false, "code", "no_app", "message", "На телефоне нет приложения, умеющего ставить таймеры.");
    }

    // ---------- календарь ----------
    private static JSONObject event(MainActivity act, JSONObject a) {
        long start;
        try {
            start = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(a.optString("start", "")).getTime();
        } catch (Exception e) {
            return o("ok", false, "code", "bad_args", "message", "start в формате 2026-11-10T18:30 (локальное время).");
        }
        long end = start + Math.max(1, a.optInt("durationMinutes", 60)) * 60000L;
        Intent i = new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, a.optString("title", ""))
                .putExtra(CalendarContract.Events.EVENT_LOCATION, a.optString("location", ""))
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end);
        boolean ok = launch(act, i);
        return ok ? o("ok", true, "state", "prepared", "message", "Календарь открыт с черновиком события. НЕ сохранено: пользователь должен нажать «Сохранить».")
                : o("ok", false, "code", "no_app", "message", "Приложение календаря не найдено.");
    }

    // ---------- звонок и SMS: только черновик ----------
    private static JSONObject dial(MainActivity act, String number) {
        String n = number.replaceAll("[^0-9+*#]", "");
        if (n.isEmpty()) return o("ok", false, "code", "bad_args", "message", "Некорректный номер.");
        boolean ok = launch(act, new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))));
        return ok ? o("ok", true, "state", "prepared", "message", "Набор номера открыт. Звонок НЕ начат: пользователь должен нажать кнопку вызова.")
                : o("ok", false, "code", "no_app", "message", "Приложение телефона не найдено.");
    }

    private static JSONObject sms(MainActivity act, String number, String text) {
        String n = number.replaceAll("[^0-9+]", "");
        if (n.isEmpty()) return o("ok", false, "code", "bad_args", "message", "Некорректный номер.");
        Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + n)).putExtra("sms_body", text);
        boolean ok = launch(act, i);
        return ok ? o("ok", true, "state", "prepared", "message", "SMS подготовлено, НЕ отправлено: пользователь должен нажать «Отправить».")
                : o("ok", false, "code", "no_app", "message", "Приложение SMS не найдено.");
    }
}
