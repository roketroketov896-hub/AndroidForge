package com.jarvis.ai;

import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.view.Display;
import android.accessibilityservice.AccessibilityService;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

/**
 * Снимок экрана официальными средствами Android:
 *  - Android 11+: AccessibilityService.takeScreenshot (нужна включённая служба доступности JARVIS);
 *  - Android 6–10: последний кадр «показа экрана» (MediaProjection), который пользователь включает сам.
 * Защищённые окна (FLAG_SECURE: банки, пароли) Android не отдаёт — это честно сообщается, обхода нет.
 */
final class ScreenCapture {
    private ScreenCapture() {
    }

    static final class Result {
        Bitmap bitmap;
        String code = "";      // "" — успех
        String message = "";
    }

    /** Блокирующий вызов: только из фонового потока. Bitmap нужно recycle() после использования. */
    static Result capture() {
        Result r = new Result();
        if (Build.VERSION.SDK_INT >= 30) {
            final JarvisAccessibilityService svc = JarvisAccessibilityService.instance;
            if (svc == null) {
                r.code = "service_needed";
                r.message = "Для снимка экрана нужна включённая служба доступности JARVIS.";
                return r;
            }
            for (int attempt = 0; attempt < 2; attempt++) {
                final CountDownLatch done = new CountDownLatch(1);
                final Bitmap[] out = new Bitmap[1];
                final int[] err = {0};
                try {
                    svc.takeScreenshot(Display.DEFAULT_DISPLAY, new Executor() {
                        @Override public void execute(Runnable c) { c.run(); }
                    }, new AccessibilityService.TakeScreenshotCallback() {
                        @Override public void onSuccess(AccessibilityService.ScreenshotResult s) {
                            try {
                                HardwareBuffer hb = s.getHardwareBuffer();
                                ColorSpace cs = s.getColorSpace();
                                Bitmap hw = Bitmap.wrapHardwareBuffer(hb, cs);
                                if (hw != null) {
                                    out[0] = hw.copy(Bitmap.Config.ARGB_8888, false);
                                    hw.recycle();
                                }
                                hb.close();
                            } catch (Throwable ignored) {
                            }
                            done.countDown();
                        }
                        @Override public void onFailure(int code) { err[0] = code; done.countDown(); }
                    });
                    if (!done.await(4, TimeUnit.SECONDS)) {
                        r.code = "timeout";
                        r.message = "Система не вернула снимок экрана за 4 секунды.";
                        return r;
                    }
                } catch (Throwable t) {
                    r.code = "error";
                    r.message = "Снимок экрана не удался: " + t.getClass().getSimpleName();
                    return r;
                }
                if (out[0] != null) { r.bitmap = out[0]; return r; }
                if (err[0] == AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT && attempt == 0) {
                    try { Thread.sleep(1200); } catch (InterruptedException ignored) { }
                    continue;
                }
                r.code = "failed_" + err[0];
                r.message = err[0] == AccessibilityService.ERROR_TAKE_SCREENSHOT_SECURE_WINDOW
                        ? "Это защищённое окно: Android запрещает его снимать."
                        : "Android отказал в снимке экрана (код " + err[0] + ").";
                return r;
            }
            return r;
        }
        Bitmap b = ScreenShareService.captureCopy();
        if (b == null) {
            r.code = "projection_needed";
            r.message = "На Android ниже 11 снимок берётся из «показа экрана»: включите его в JARVIS и повторите.";
            return r;
        }
        r.bitmap = b;
        return r;
    }
}
