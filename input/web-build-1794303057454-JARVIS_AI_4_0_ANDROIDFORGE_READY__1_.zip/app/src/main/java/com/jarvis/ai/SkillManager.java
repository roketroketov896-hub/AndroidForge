package com.jarvis.ai;

import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Реестр навыков: у каждого есть название, описание, обязательные параметры и уровень риска.
 * Проверка параметров выполняется ДО запуска навыка, поэтому модель получает понятную ошибку, а не падение.
 * В реестре только реально реализованные навыки (см. SystemTools и UiAutomation).
 */
final class SkillManager {
    private SkillManager() {
    }

    static final class Skill {
        final String title, description, risk;
        final String[] required;

        Skill(String title, String description, String risk, String... required) {
            this.title = title;
            this.description = description;
            this.risk = risk;
            this.required = required;
        }
    }

    private static final Map<String, Skill> SKILLS = new LinkedHashMap<>();

    static {
        SKILLS.put("ui_read", new Skill("Прочитать экран", "Видимые элементы текущего экрана", "safe"));
        SKILLS.put("ui_click", new Skill("Клик по экрану", "Нажатие по тексту или координатам", "low"));
        SKILLS.put("ui_type", new Skill("Ввод текста", "Ввод в поле, без отправки", "low", "text"));
        SKILLS.put("ui_swipe", new Skill("Свайп", "Прокрутка и свайпы", "low"));
        SKILLS.put("ui_wait", new Skill("Ожидание", "Ждать элемент или приложение", "safe"));
        SKILLS.put("ui_global", new Skill("Системная навигация", "Назад, домой, недавние", "low", "action"));
        SKILLS.put("screenshot", new Skill("Снимок экрана", "Снимок экрана в памяти", "low"));
        SKILLS.put("ocr_screen", new Skill("Распознать текст на экране", "OCR (латиница) с координатами", "low"));
        SKILLS.put("messenger_open_chat", new Skill("Открыть чат", "Telegram/WhatsApp: найти контакт и открыть чат с проверкой", "low", "app", "contact"));
        SKILLS.put("messenger_read", new Skill("Читать чат", "Видимые сообщения открытого чата", "safe"));
        SKILLS.put("messenger_send", new Skill("Отправить сообщение", "Отправка введённого текста, только после подтверждения", "confirm", "app", "text"));
        SKILLS.put("system_status", new Skill("Состояние телефона", "Батарея, сеть, время, устройство", "safe"));
        SKILLS.put("volume", new Skill("Громкость", "Узнать или изменить громкость", "low"));
        SKILLS.put("brightness", new Skill("Яркость", "Узнать или изменить яркость", "low"));
        SKILLS.put("flashlight", new Skill("Фонарик", "Включить или выключить", "safe", "on"));
        SKILLS.put("clipboard", new Skill("Буфер обмена", "Скопировать текст или прочитать буфер", "low", "action"));
        SKILLS.put("timer", new Skill("Таймер", "Запустить таймер", "low", "seconds"));
        SKILLS.put("create_event", new Skill("Событие календаря", "Открывает черновик события, сохраняет пользователь", "low", "title", "start"));
        SKILLS.put("phone_call", new Skill("Позвонить", "Открывает набор номера, звонок начинает пользователь", "confirm", "number"));
        SKILLS.put("send_sms", new Skill("SMS", "Открывает черновик SMS, отправляет пользователь", "confirm", "number", "text"));
    }

    static boolean known(String name) {
        return SKILLS.containsKey(name);
    }

    static Skill get(String name) {
        return SKILLS.get(name);
    }

    /** null, если параметры в порядке; иначе JSON-ошибка для модели. */
    static JSONObject validate(String name, JSONObject args) {
        Skill s = SKILLS.get(name);
        if (s == null) return null;
        for (String k : s.required) {
            if (!args.has(k) || args.isNull(k) || String.valueOf(args.opt(k)).trim().isEmpty()) {
                JSONObject r = new JSONObject();
                try {
                    r.put("ok", false);
                    r.put("code", "missing_param");
                    r.put("message", "Навык «" + s.title + "»: не указан обязательный параметр «" + k + "». Спроси у пользователя.");
                } catch (Exception ignored) {
                }
                return r;
            }
        }
        return null;
    }
}
