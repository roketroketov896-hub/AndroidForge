package com.jarvis.ai;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Голосовой ввод через Android SpeechRecognizer. Запускается только по явному действию пользователя.
 * Два режима:
 * 1) обычный (голосовой режим): одна фраза, распознавание заканчивается само после паузы;
 * 2) непрерывный (диктовка в поле): запись НЕ заканчивается из-за пауз. Распознаватель Android сам
 *    завершает сессию после тишины, поэтому он тут же перезапускается, а уже распознанные куски копятся
 *    и склеиваются. Запись идёт, пока пользователь не нажмёт квадратную кнопку. Между перезапусками
 *    возможен разрыв доли секунды: слова, сказанные ровно в этот момент, могут потеряться.
 */
final class SpeechInput {
    private static final int MAX_CONTINUOUS_MS = 10 * 60 * 1000;

    private final Context ctx;
    private final Emitter emitter;
    private final Handler main = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private boolean cancelledByUs = false;
    private long lastLevel = 0L;

    // непрерывный режим
    private boolean continuous = false;
    private boolean stopRequested = false;
    private final StringBuilder acc = new StringBuilder();
    private String lang = "ru";
    private long startedAt = 0L;
    private int networkErrors = 0;
    private final OfflineStt offline;
    private boolean offlineActive = false;

    SpeechInput(Context ctx, Emitter emitter) {
        this.ctx = ctx;
        this.emitter = emitter;
        this.offline = new OfflineStt(ctx, emitter);
    }

    private void send(String type, String text, String code, float level) {
        JSONObject d = new JSONObject();
        try {
            d.put("type", type);
            d.put("text", text);
            d.put("code", code);
            d.put("level", level);
        } catch (Exception ignored) {
        }
        emitter.emit("speech", d);
    }

    private static String tagFor(String lang) {
        if ("az".equals(lang)) return "az-AZ";
        if ("tr".equals(lang)) return "tr-TR";
        if ("en".equals(lang)) return "en-US";
        return "ru-RU";
    }

    private static String codeFor(int error) {
        switch (error) {
            case 7: return "no_match";
            case 6: return "timeout";
            case 1:
            case 2: return "network";
            case 3: return "audio";
            case 4: return "server";
            case 5: return "client";
            case 8: return "busy";
            case 9: return "permission";
            case 12:
            case 13: return "lang";
            default: return "unknown";
        }
    }

    private String joined(String tail) {
        String a = acc.toString().trim();
        String t = tail == null ? "" : tail.trim();
        if (a.isEmpty()) return t;
        return t.isEmpty() ? a : a + " " + t;
    }

    /** Главный поток; разрешение RECORD_AUDIO уже выдано. Одна фраза (голосовой режим). */
    void start(String language) {
        continuous = false;
        stopRequested = false;
        acc.setLength(0);
        lang = language;
        offlineActive = OfflineStt.wanted(language);
        if (offlineActive) { destroyRecognizer(); offline.start(language, false); return; }
        begin();
    }

    /** Непрерывная диктовка: пока не вызван finish(), запись не прекращается из-за пауз. */
    void startContinuous(String language) {
        continuous = true;
        stopRequested = false;
        acc.setLength(0);
        lang = language;
        startedAt = System.currentTimeMillis();
        networkErrors = 0;
        offlineActive = OfflineStt.wanted(language);
        if (offlineActive) { destroyRecognizer(); offline.start(language, true); return; }
        begin();
    }

    private void begin() {
        destroyRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            send("error", joined(""), "unavailable", 0f);
            return;
        }
        try {
            cancelledByUs = false;
            recognizer = SpeechRecognizer.createSpeechRecognizer(ctx);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                    send("listening", "", "", 0f);
                }

                @Override
                public void onBeginningOfSpeech() {
                }

                @Override
                public void onRmsChanged(float rmsdB) {
                    long now = System.currentTimeMillis();
                    if (now - lastLevel < 70L) return;
                    lastLevel = now;
                    send("level", "", "", Math.max(0f, Math.min(1f, (rmsdB + 2f) / 12f)));
                }

                @Override
                public void onBufferReceived(byte[] buffer) {
                }

                @Override
                public void onEndOfSpeech() {
                    if (!continuous) send("processing", "", "", 0f);
                }

                @Override
                public void onError(int error) {
                    if (cancelledByUs) return;
                    String code = codeFor(error);
                    if (continuous) {
                        if (stopRequested) {
                            finishContinuous();
                            return;
                        }
                        if ("no_match".equals(code) || "timeout".equals(code) || "busy".equals(code) || "client".equals(code)) {
                            restartSoon(code.equals("busy") ? 500 : 60);
                            return;
                        }
                        if ("network".equals(code) && networkErrors++ < 3) {
                            restartSoon(1500);
                            return;
                        }
                        // Непоправимая ошибка: уже записанный текст не теряем.
                        send("error", joined(""), code, 0f);
                        return;
                    }
                    send("error", "", code, 0f);
                }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> m = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String text = (m == null || m.isEmpty()) ? "" : m.get(0);
                    if (!continuous) {
                        if (text.isEmpty()) send("error", "", "no_match", 0f);
                        else send("result", text, "", 0f);
                        return;
                    }
                    if (!text.trim().isEmpty()) {
                        acc.append(acc.length() > 0 ? " " : "").append(text.trim());
                        networkErrors = 0;
                        send("partial", joined(""), "", 0f);
                    }
                    if (stopRequested) finishContinuous();
                    else restartSoon(40);
                }

                @Override
                public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> m = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (m != null && !m.isEmpty()) send("partial", continuous ? joined(m.get(0)) : m.get(0), "", 0f);
                }

                @Override
                public void onEvent(int eventType, Bundle params) {
                }
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, tagFor(lang));
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tagFor(lang));
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            // Подсказки о паузах: многие движки их учитывают, но не все.
            i.putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", continuous ? 15000 : 2500);
            i.putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", continuous ? 15000 : 2000);
            i.putExtra("android.speech.extra.SPEECH_INPUT_MINIMUM_LENGTH_MILLIS", continuous ? 60000 : 0);
            if (Build.VERSION.SDK_INT >= 33) {
                // Автоопределение языка (только там, где его поддерживает движок распознавания на устройстве).
                i.putExtra("android.speech.extra.ENABLE_LANGUAGE_DETECTION", true);
                ArrayList<String> allowed = new ArrayList<String>();
                allowed.add("ru-RU");
                allowed.add("en-US");
                allowed.add("tr-TR");
                allowed.add("az-AZ");
                i.putStringArrayListExtra("android.speech.extra.LANGUAGE_DETECTION_ALLOWED_LANGUAGES", allowed);
            }
            recognizer.startListening(i);
        } catch (Exception e) {
            send("error", joined(""), "client", 0f);
        }
    }

    private void restartSoon(long delay) {
        if (System.currentTimeMillis() - startedAt > MAX_CONTINUOUS_MS) {
            send("error", joined(""), "limit", 0f);
            return;
        }
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (continuous && !stopRequested && !cancelledByUs) begin();
            }
        }, delay);
    }

    private void finishContinuous() {
        String text = acc.toString().trim();
        continuous = false;
        stopRequested = false;
        destroyRecognizer();
        if (text.isEmpty()) send("error", "", "no_match", 0f);
        else send("result", text, "", 0f);
    }

    /** Пользователь нажал «стоп»: завершить запись и выдать накопленный текст. Повторные вызовы безопасны. */
    void finish() {
        if (offlineActive) { offline.finish(); return; }
        if (continuous) {
            if (stopRequested) return;
            stopRequested = true;
            if (recognizer != null) {
                try {
                    recognizer.stopListening();
                } catch (Exception e) {
                    finishContinuous();
                }
                // Если движок не вернёт итог, не зависаем.
                main.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (continuous && stopRequested) finishContinuous();
                    }
                }, 2500);
            } else {
                finishContinuous();
            }
            return;
        }
        if (recognizer != null) {
            try {
                recognizer.stopListening();
            } catch (Exception ignored) {
            }
        }
    }

    boolean isContinuous() {
        return continuous;
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            cancelledByUs = true;
            try {
                recognizer.cancel();
            } catch (Exception ignored) {
            }
            try {
                recognizer.destroy();
            } catch (Exception ignored) {
            }
            recognizer = null;
        }
    }

    void cancel() {
        if (offlineActive) { offline.cancel(); offlineActive = false; }
        continuous = false;
        stopRequested = false;
        acc.setLength(0);
        destroyRecognizer();
    }
}
