package com.jarvis.ai;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

/**
 * Чтение уведомлений (только после того, как пользователь сам включил «Доступ к уведомлениям»).
 * Уведомления хранятся ТОЛЬКО в памяти процесса (до 40 последних), на диск не пишутся.
 * Для WhatsApp запоминается действие «Ответить» (RemoteInput), через которое можно отправить ответ.
 */
public class JarvisNotificationListener extends NotificationListenerService {
    static final class Item {
        String pkg, app, title, text;
        long time;
        long postTime() { return time; }
        PendingIntent replyIntent;
        RemoteInput replyInput;
        boolean group;
        String key = "";
        volatile boolean removed;
    }

    private static final LinkedList<Item> RECENT = new LinkedList<>();
    static volatile JarvisNotificationListener instance;
    static volatile Context appCtx;

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        instance = this;
        appCtx = getApplicationContext();
    }

    @Override
    public void onListenerDisconnected() {
        if (instance == this) instance = null;
        super.onListenerDisconnected();
    }

    static boolean isEnabled(Context ctx) {
        try {
            String enabled = Settings.Secure.getString(ctx.getContentResolver(), "enabled_notification_listeners");
            if (TextUtils.isEmpty(enabled)) return false;
            String me = new ComponentName(ctx, JarvisNotificationListener.class).flattenToString();
            for (String s : enabled.split(":")) if (s.equalsIgnoreCase(me)) return true;
        } catch (Exception ignored) {
        }
        return false;
    }

    static boolean isWhatsApp(String pkg) {
        return "com.whatsapp".equals(pkg) || "com.whatsapp.w4b".equals(pkg);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || sbn.getPackageName().equals(getPackageName())) return;
            Notification n = sbn.getNotification();
            if (n == null) return;
            if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            Bundle e = n.extras;
            if (e == null) return;
            Item it = new Item();
            it.pkg = sbn.getPackageName();
            it.app = it.pkg;
            try {
                it.app = String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(it.pkg, 0)));
            } catch (Exception ignored) {
            }
            CharSequence t = e.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence x = e.getCharSequence(Notification.EXTRA_TEXT);
            it.title = t == null ? "" : t.toString();
            it.text = x == null ? "" : x.toString();
            it.time = sbn.getPostTime();
            it.key = sbn.getKey() == null ? "" : sbn.getKey();
            it.group = e.getBoolean("android.isGroupConversation", false);
            if (it.title.isEmpty() && it.text.isEmpty()) return;
            if (n.actions != null) {
                for (Notification.Action a : n.actions) {
                    RemoteInput[] ri = a.getRemoteInputs();
                    if (ri != null && ri.length > 0 && a.actionIntent != null) {
                        it.replyIntent = a.actionIntent;
                        it.replyInput = ri[0];
                        break;
                    }
                }
            }
            synchronized (RECENT) {
                if (!it.key.isEmpty()) for (Item o : RECENT) if (it.key.equals(o.key)) o.removed = true; // вытеснено новым сообщением
                RECENT.addFirst(it);
                while (RECENT.size() > 40) RECENT.removeLast();
            }
            String net = AutoReply.netOf(it.pkg);
            if (net != null) AutoReply.onIncoming(getApplicationContext(), net, it);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        try {
            if (sbn == null || sbn.getKey() == null) return;
            synchronized (RECENT) {
                for (Item o : RECENT) if (sbn.getKey().equals(o.key) && o.postTime() == sbn.getPostTime()) o.removed = true;
            }
        } catch (Exception ignored) {
        }
    }

    /** Самое свежее живое (не закрытое) уведомление мессенджера от собеседника с действием «Ответить». */
    static Item findLatest(String net, String sender) {
        String q = AutoReply.contactKey(sender);
        if (q.isEmpty()) return null;
        synchronized (RECENT) {
            for (Item it : RECENT) {
                if (it.removed || it.replyIntent == null || !net.equals(AutoReply.netOf(it.pkg))) continue;
                if (AutoReply.contactKey(it.title).equals(q)) return it;
            }
        }
        return null;
    }

    static List<String> recentSenders(String net) {
        List<String> l = new ArrayList<>();
        synchronized (RECENT) {
            for (Item it : RECENT) if (net.equals(AutoReply.netOf(it.pkg)) && !it.group && !l.contains(it.title)) l.add(it.title);
        }
        return l;
    }

    /** Последние уведомления без действий ответа, для передачи ИИ. */
    static JSONArray recent(String appFilter, int limit) {
        JSONArray out = new JSONArray();
        String f = appFilter == null ? "" : appFilter.toLowerCase(Locale.ROOT).trim();
        synchronized (RECENT) {
            for (Item it : RECENT) {
                if (!f.isEmpty() && !it.app.toLowerCase(Locale.ROOT).contains(f) && !it.pkg.toLowerCase(Locale.ROOT).contains(f)) continue;
                try {
                    JSONObject o = new JSONObject();
                    o.put("app", it.app);
                    o.put("from", it.title);
                    o.put("text", it.text.length() > 500 ? it.text.substring(0, 500) : it.text);
                    o.put("minutes_ago", Math.max(0, (System.currentTimeMillis() - it.time) / 60000));
                    o.put("can_reply", it.replyIntent != null);
                    out.put(o);
                } catch (Exception ignored) {
                }
                if (out.length() >= limit) break;
            }
        }
        return out;
    }

    /** Ищет самое свежее уведомление WhatsApp от собеседника с нужным именем и возможностью ответа. */
    static Item findReplyTarget(String name) {
        String q = name == null ? "" : name.toLowerCase(Locale.ROOT).trim();
        if (q.isEmpty()) return null;
        synchronized (RECENT) {
            for (Item it : RECENT) {
                if (!isWhatsApp(it.pkg) || it.removed || it.replyIntent == null || it.group) continue;
                String t = it.title.toLowerCase(Locale.ROOT);
                if (t.equals(q) || t.contains(q) || q.contains(t)) return it;
            }
        }
        return null;
    }

    static List<String> recentWhatsAppSenders() {
        List<String> l = new ArrayList<>();
        synchronized (RECENT) {
            for (Item it : RECENT) if (isWhatsApp(it.pkg) && !it.group && !l.contains(it.title)) l.add(it.title);
        }
        return l;
    }

    /** Отправляет ответ через RemoteInput уведомления. true, если система приняла отправку. */
    static boolean sendReply(Context ctx, Item it, String text) {
        try {
            Intent i = new Intent();
            Bundle b = new Bundle();
            b.putCharSequence(it.replyInput.getResultKey(), text);
            RemoteInput.addResultsToIntent(new RemoteInput[]{it.replyInput}, i, b);
            it.replyIntent.send(ctx, 0, i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
