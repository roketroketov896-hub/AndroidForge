package com.jarvis.ai;

import android.content.Context;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Iterator;

/**
 * Детектор слова «Джарвис» на модели openWakeWord (melspectrogram → embedding → djarvis).
 * Всё считается на телефоне, без интернета. Вход — 16 кГц, 16 бит, моно, блоками по 1280 отсчётов (80 мс).
 * Модели грузятся при create() и освобождаются в close().
 */
final class WakeWordEngine {
    static final int CHUNK = 1280;
    private static final int CONTEXT = 480;       // 3 кадра по 160 отсчётов контекста для мел-спектрограммы
    private static final int MEL_BINS = 32;
    private static final int EMB_WINDOW = 76;
    private static final int EMB_DIM = 96;
    private static final int FEAT_WINDOW = 16;

    private final OrtEnvironment env;
    private final OrtSession mel, emb, cls;
    private final float[] raw = new float[CHUNK + CONTEXT];
    private final ArrayDeque<float[]> melBuf = new ArrayDeque<>();
    private final ArrayDeque<float[]> featBuf = new ArrayDeque<>();
    private boolean primed = false;
    private float lastScore = 0f;

    private WakeWordEngine(OrtEnvironment env, OrtSession mel, OrtSession emb, OrtSession cls) {
        this.env = env;
        this.mel = mel;
        this.emb = emb;
        this.cls = cls;
    }

    static WakeWordEngine create(Context c) throws Exception {
        OrtEnvironment env = OrtEnvironment.getEnvironment();
        OrtSession.SessionOptions so = new OrtSession.SessionOptions();
        so.setIntraOpNumThreads(1);
        so.setInterOpNumThreads(1);
        OrtSession m = null, e = null, k = null;
        try {
            m = env.createSession(asset(c, "openwakeword/melspectrogram.onnx"), so);
            e = env.createSession(asset(c, "openwakeword/embedding_model.onnx"), so);
            k = env.createSession(asset(c, "openwakeword/djarvis.onnx"), so);
        } catch (Exception ex) {
            try { if (m != null) m.close(); } catch (Exception ignored) { }
            try { if (e != null) e.close(); } catch (Exception ignored) { }
            throw ex;
        }
        return new WakeWordEngine(env, m, e, k);
    }

    private static byte[] asset(Context c, String name) throws Exception {
        try (InputStream in = c.getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 20);
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        }
    }

    /** Подаёт блок из CHUNK отсчётов; возвращает оценку 0..1 (0, пока не накопился контекст). */
    float feed(short[] pcm) throws Exception {
        // сдвигаем окно: последние CONTEXT отсчётов прошлого блока + новый блок
        System.arraycopy(raw, CHUNK, raw, 0, CONTEXT);
        for (int i = 0; i < CHUNK; i++) raw[CONTEXT + i] = pcm[i];   // масштаб int16, как в openWakeWord

        float[][][][] melOut;
        try (OnnxTensor in = OnnxTensor.createTensor(env, new float[][]{raw.clone()});
             OrtSession.Result r = mel.run(Collections.singletonMap("input", in))) {
            melOut = (float[][][][]) r.get(0).getValue();
        }
        float[][] frames = melOut[0][0];
        for (float[] f : frames) {
            float[] g = new float[MEL_BINS];
            for (int j = 0; j < MEL_BINS; j++) g[j] = f[j] / 10f + 2f;
            melBuf.addLast(g);
        }
        while (melBuf.size() > EMB_WINDOW + 16) melBuf.removeFirst();
        if (melBuf.size() < EMB_WINDOW) return 0f;

        float[][][][] win = new float[1][EMB_WINDOW][MEL_BINS][1];
        int skip = melBuf.size() - EMB_WINDOW, idx = 0, k = 0;
        for (float[] f : melBuf) {
            if (idx++ < skip) continue;
            for (int j = 0; j < MEL_BINS; j++) win[0][k][j][0] = f[j];
            k++;
        }
        float[][][][] embOut;
        try (OnnxTensor in = OnnxTensor.createTensor(env, win);
             OrtSession.Result r = emb.run(Collections.singletonMap("input_1", in))) {
            embOut = (float[][][][]) r.get(0).getValue();
        }
        featBuf.addLast(embOut[0][0][0].clone());
        while (featBuf.size() > FEAT_WINDOW) featBuf.removeFirst();
        if (featBuf.size() < FEAT_WINDOW) return 0f;

        float[][][] x = new float[1][FEAT_WINDOW][EMB_DIM];
        int t = 0;
        for (Iterator<float[]> it = featBuf.iterator(); it.hasNext(); t++) x[0][t] = it.next();
        try (OnnxTensor in = OnnxTensor.createTensor(env, x);
             OrtSession.Result r = cls.run(Collections.singletonMap("onnx::Flatten_0", in))) {
            float[][] out = (float[][]) r.get(0).getValue();
            lastScore = out[0][0];
        }
        return lastScore;
    }

    void reset() {
        melBuf.clear();
        featBuf.clear();
        java.util.Arrays.fill(raw, 0f);
        lastScore = 0f;
    }

    void close() {
        try { mel.close(); } catch (Exception ignored) { }
        try { emb.close(); } catch (Exception ignored) { }
        try { cls.close(); } catch (Exception ignored) { }
    }
}
