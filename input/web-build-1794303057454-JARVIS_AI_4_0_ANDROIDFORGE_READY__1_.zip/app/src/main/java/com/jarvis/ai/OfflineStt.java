package com.jarvis.ai;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.SystemClock;

import com.k2fsa.sherpa.onnx.EndpointConfig;
import com.k2fsa.sherpa.onnx.EndpointRule;
import com.k2fsa.sherpa.onnx.OnlineModelConfig;
import com.k2fsa.sherpa.onnx.OnlineRecognizer;
import com.k2fsa.sherpa.onnx.OnlineRecognizerConfig;
import com.k2fsa.sherpa.onnx.OnlineStream;
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig;

import org.json.JSONObject;

import java.io.InputStream;

/**
 * Офлайн-распознавание речи: Sherpa-ONNX (streaming zipformer), всё считается на телефоне, сеть не используется.
 * Русский: sherpa-onnx-streaming-zipformer-small-ru-vosk-int8-2025-08-16. Английский: ...-en-20M-2023-02-17.
 * События те же, что у SpeechInput («speech»: listening / partial / result / error / level), поэтому интерфейс не меняется.
 * Если офлайн-режим включён, но модель не загрузилась, отдаётся ошибка: молча переключаться на сетевое распознавание нельзя.
 */
final class OfflineStt {
    static final String DIR_RU = "models/sherpa-onnx-streaming-zipformer-small-ru-vosk-int8-2025-08-16";
    static final String DIR_EN = "models/sherpa-onnx-streaming-zipformer-en-20M-2023-02-17";
    private static final int RATE = 16000;
    private static final int CHUNK = 1600;                 // 100 мс
    private static final long MAX_CONTINUOUS_MS = 10 * 60 * 1000L;
    private static final long NO_SPEECH_MS = 9000L;

    /** Включено ли офлайн-распознавание в настройках (выставляет MainActivity). */
    static volatile boolean enabled = false;

    // состояние для настроек
    private static volatile String loadedLang = "";          // язык загруженной модели ("" — не загружена)
    private static volatile String lastError = "";
    private static OnlineRecognizer recognizer;
    private static String recognizerLang = "";
    private static final Object LOCK = new Object();

    private final Context ctx;
    private final Emitter emitter;
    private volatile Thread worker;
    private volatile boolean cancelFlag, finishFlag;
    private volatile boolean continuous;

    OfflineStt(Context ctx, Emitter emitter) {
        this.ctx = ctx.getApplicationContext();
        this.emitter = emitter;
    }

    static boolean supportsLang(String lang) {
        return "ru".equals(lang) || "en".equals(lang);
    }

    static boolean wanted(String lang) {
        return enabled && supportsLang(lang);
    }

    // ---------- статус для настроек ----------

    /** state: off | model_missing | unsupported_abi | init_error | found | ready */
    static JSONObject status(Context c, String lang) {
        JSONObject o = new JSONObject();
        try {
            String dir = "en".equals(lang) ? DIR_EN : DIR_RU;
            boolean files = assetExists(c, dir + "/encoder.int8.onnx") && assetExists(c, dir + "/decoder.onnx")
                    && assetExists(c, dir + "/joiner.int8.onnx") && assetExists(c, dir + "/tokens.txt");
            String st;
            if (!files) st = "model_missing";
            else if (!abiOk()) st = "unsupported_abi";
            else if (lang.equals(loadedLang)) st = "ready";
            else if (!lastError.isEmpty()) st = "init_error";
            else st = enabled ? "found" : "off";
            o.put("state", st);
            o.put("lang", lang);
            o.put("error", lastError);
            o.put("enabled", enabled);
        } catch (Exception ignored) {
        }
        return o;
    }

    private static boolean abiOk() {
        for (String a : android.os.Build.SUPPORTED_ABIS) if ("arm64-v8a".equals(a)) return true;
        return false;
    }

    private static boolean assetExists(Context c, String path) {
        try (InputStream in = c.getAssets().open(path)) {
            return in.read() >= -1;
        } catch (Exception e) {
            return false;
        }
    }

    /** Загрузка модели (медленно: вызывать из фонового потока). Возвращает null при успехе или текст ошибки. */
    static String load(Context c, String lang) {
        synchronized (LOCK) {
            if (recognizer != null && lang.equals(recognizerLang)) return null;
            release();
            if (!abiOk()) return lastError = "Офлайн-распознавание работает только на 64-битных ARM-устройствах (arm64-v8a).";
            String dir = "en".equals(lang) ? DIR_EN : DIR_RU;
            if (!assetExists(c, dir + "/encoder.int8.onnx")) return lastError = "Файлы модели не найдены в приложении.";
            try {
                OnlineTransducerModelConfig tr = new OnlineTransducerModelConfig(
                        dir + "/encoder.int8.onnx", dir + "/decoder.onnx", dir + "/joiner.int8.onnx");
                OnlineModelConfig mc = new OnlineModelConfig(tr, dir + "/tokens.txt", 2, "en".equals(lang) ? "zipformer" : "zipformer2");
                OnlineRecognizerConfig rc = new OnlineRecognizerConfig(mc);
                recognizer = new OnlineRecognizer(c.getAssets(), rc);
                recognizerLang = lang;
                loadedLang = lang;
                lastError = "";
                return null;
            } catch (Throwable t) {
                recognizer = null;
                recognizerLang = "";
                loadedLang = "";
                lastError = "Не удалось загрузить модель: " + t.getClass().getSimpleName();
                return lastError;
            }
        }
    }

    /** Выгрузить модель из памяти. */
    static void release() {
        synchronized (LOCK) {
            if (recognizer != null) {
                try { recognizer.release(); } catch (Throwable ignored) { }
            }
            recognizer = null;
            recognizerLang = "";
            loadedLang = "";
        }
    }

    // ---------- запись и распознавание ----------

    void start(final String lang, final boolean cont) {
        cancel();
        cancelFlag = false;
        finishFlag = false;
        continuous = cont;
        worker = new Thread(new Runnable() {
            @Override public void run() { loop(lang, cont); }
        }, "jarvis-offline-stt");
        worker.start();
    }

    /** Корректно завершить диктовку: дораспознать остаток и отправить итог. */
    void finish() {
        finishFlag = true;
    }

    void cancel() {
        cancelFlag = true;
        Thread t = worker;
        if (t != null && t != Thread.currentThread()) {
            try { t.join(1500); } catch (InterruptedException ignored) { }
        }
    }

    private void send(String type, String text, String code, float level) {
        JSONObject d = new JSONObject();
        try {
            d.put("type", type);
            d.put("text", text);
            d.put("code", code);
            d.put("level", level);
        } catch (Exception ignored) {
        }
        emitter.emit("speech", d);
    }

    private static String cap(String s) {
        s = s.trim();
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private void loop(String lang, boolean cont) {
        AudioRecord rec = null;
        OnlineStream stream = null;
        StringBuilder acc = new StringBuilder();
        try {
            String err = load(ctx, lang);
            if (cancelFlag) return;
            if (err != null) { send("error", "", "offline_init", 0f); return; }
            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                send("error", "", "permission", 0f);
                return;
            }
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            rec = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, CHUNK * 8));
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) { send("error", "", "audio", 0f); return; }
            OnlineRecognizer r;
            synchronized (LOCK) {
                r = recognizer;
                if (r == null) { send("error", "", "offline_init", 0f); return; }
                stream = r.createStream();
            }
            rec.startRecording();
            send("listening", "", "", 0f);

            short[] pcm = new short[CHUNK];
            float[] f = new float[CHUNK];
            String lastText = "";
            long started = SystemClock.uptimeMillis();
            long lastLevel = 0;
            boolean heardSomething = false;

            while (!cancelFlag) {
                if (finishFlag) break;
                int got = 0;
                while (got < CHUNK && !cancelFlag && !finishFlag) {
                    int n = rec.read(pcm, got, CHUNK - got);
                    if (n <= 0) break;
                    got += n;
                }
                if (cancelFlag) return;
                if (got < CHUNK) { if (finishFlag) break; send("error", acc.toString().trim(), "audio", 0f); return; }
                double sum = 0;
                for (int i = 0; i < CHUNK; i++) { f[i] = pcm[i] / 32768f; sum += f[i] * f[i]; }
                long now = SystemClock.uptimeMillis();
                if (now - lastLevel > 70) {
                    lastLevel = now;
                    send("level", "", "", (float) Math.max(0, Math.min(1, Math.sqrt(sum / CHUNK) * 7)));
                }
                synchronized (LOCK) {
                    if (recognizer != r) { send("error", "", "offline_init", 0f); return; }
                    stream.acceptWaveform(f, RATE);
                    while (r.isReady(stream)) r.decode(stream);
                }
                String text = r.getResult(stream).getText();
                if (text == null) text = "";
                text = text.trim();
                if (!text.isEmpty()) heardSomething = true;
                if (!text.equals(lastText)) {
                    lastText = text;
                    String shown = cont ? join(acc, text) : cap(text);
                    if (!shown.isEmpty()) send("partial", shown, "", 0f);
                }
                boolean endpoint;
                synchronized (LOCK) { endpoint = r.isEndpoint(stream); }
                if (endpoint) {
                    if (!text.isEmpty()) {
                        if (cont) {
                            if (acc.length() > 0) acc.append(' ');
                            acc.append(text);
                            send("partial", cap(acc.toString()), "", 0f);
                        } else {
                            send("processing", "", "", 0f);
                            send("result", cap(text), "", 0f);
                            return;
                        }
                    }
                    synchronized (LOCK) { r.reset(stream); }
                    lastText = "";
                }
                long elapsed = now - started;
                if (!cont && !heardSomething && elapsed > NO_SPEECH_MS) { send("error", "", "no_match", 0f); return; }
                if (cont && elapsed > MAX_CONTINUOUS_MS) break;
            }
            if (cancelFlag) return;
            // завершение по команде пользователя: дораспознать остаток
            synchronized (LOCK) {
                if (recognizer == r) {
                    stream.inputFinished();
                    while (r.isReady(stream)) r.decode(stream);
                }
            }
            String tail = r.getResult(stream).getText();
            tail = tail == null ? "" : tail.trim();
            String all = cap(join(acc, tail));
            if (cont) send("result", all, "", 0f);
            else if (all.isEmpty()) send("error", "", "no_match", 0f);
            else send("result", all, "", 0f);
        } catch (Throwable t) {
            lastError = "Ошибка распознавания: " + t.getClass().getSimpleName();
            if (!cancelFlag) send("error", "", "offline_init", 0f);
        } finally {
            if (rec != null) {
                try { rec.stop(); } catch (Exception ignored) { }
                try { rec.release(); } catch (Exception ignored) { }
            }
            if (stream != null) {
                try { synchronized (LOCK) { stream.release(); } } catch (Throwable ignored) { }
            }
            worker = null;
        }
    }

    private static String join(StringBuilder acc, String tail) {
        String a = acc.toString().trim();
        if (a.isEmpty()) return tail;
        return tail.isEmpty() ? a : a + " " + tail;
    }
}
