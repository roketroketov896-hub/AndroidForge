package com.jarvis.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Сетевой клиент: потоковые запросы чата (SSE) к OpenRouter / OpenAI-совместимому API / серверу JARVIS,
 * а также простые JSON-запросы. Ключи нигде не логируются.
 */
final class ChatClient {

    interface Callback {
        void onDelta(String text);

        void onDone();

        void onError(String code, String detail);
    }

    static final class ApiException extends Exception {
        final int status;
        final String code;

        ApiException(int status, String code, String message) {
            super(message);
            this.status = status;
            this.code = code;
        }
    }

    static final class Result {
        int status;
        String body = "";
    }

    private final Map<String, HttpURLConnection> active = new ConcurrentHashMap<>();
    private final Set<String> cancelled = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());

    void cancel(String id) {
        cancelled.add(id);
        HttpURLConnection c = active.get(id);
        if (c != null) {
            try {
                c.disconnect();
            } catch (Exception ignored) {
            }
        }
    }

    private static String optStr(JSONObject o, String key) {
        if (o == null || !o.has(key) || o.isNull(key)) return "";
        return o.optString(key, "");
    }

    /** Собирает тело запроса. Поле "image" (data URL) превращается в мультимодальное сообщение. */
    static JSONObject buildBody(String model, JSONArray messages, boolean stream) throws Exception {
        JSONArray out = new JSONArray();
        for (int i = 0; i < messages.length(); i++) {
            JSONObject m = messages.getJSONObject(i);
            String role = optStr(m, "role");
            if (role.isEmpty()) role = "user";
            String content = optStr(m, "content");
            String image = optStr(m, "image");
            JSONObject o = new JSONObject();
            o.put("role", role);
            if (!image.isEmpty() && role.equals("user")) {
                JSONArray parts = new JSONArray();
                JSONObject t = new JSONObject();
                t.put("type", "text");
                t.put("text", content.isEmpty() ? "Опиши, что показано на скриншоте." : content);
                parts.put(t);
                JSONObject img = new JSONObject();
                img.put("type", "image_url");
                JSONObject u = new JSONObject();
                u.put("url", image);
                img.put("image_url", u);
                parts.put(img);
                o.put("content", parts);
            } else {
                o.put("content", content);
            }
            out.put(o);
        }
        JSONObject body = new JSONObject();
        if (model != null && !model.isEmpty()) body.put("model", model);
        body.put("messages", out);
        body.put("stream", stream);
        return body;
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[4096];
            int n;
            while ((n = br.read(buf)) > 0) sb.append(buf, 0, n);
        }
        return sb.toString();
    }

    private static ApiException toApiException(int status, String body) {
        String code = "http_" + status;
        String msg = "HTTP " + status;
        try {
            JSONObject j = new JSONObject(body);
            Object err = j.opt("error");
            if (err instanceof JSONObject) {
                JSONObject e = (JSONObject) err;
                String m = optStr(e, "message");
                if (!m.isEmpty()) msg = m;
                Object c = e.opt("code");
                if (c instanceof String && !((String) c).isEmpty()) code = (String) c;
            } else if (err instanceof String) {
                msg = (String) err;
            }
        } catch (Exception ignored) {
        }
        return new ApiException(status, code, msg);
    }

    /** Потоковый запрос чата. Блокирующий: вызывать из фонового потока. */
    void stream(String id, String url, String bearer, boolean openRouterHeaders, JSONObject body, Callback cb) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            active.put(id, conn);
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(90000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Authorization", "Bearer " + bearer);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("Accept", "text/event-stream");
            if (openRouterHeaders) {
                conn.setRequestProperty("HTTP-Referer", "https://localhost");
                conn.setRequestProperty("X-Title", "JARVIS AI");
            }
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(bytes);
            }
            int status = conn.getResponseCode();
            if (status < 200 || status >= 300) {
                throw toApiException(status, readAll(conn.getErrorStream()));
            }
            boolean gotDelta = false;
            StringBuilder raw = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (cancelled.contains(id)) break;
                    if (line.startsWith("data:")) {
                        String d = line.substring(5).trim();
                        if (d.isEmpty()) continue;
                        if (d.equals("[DONE]")) break;
                        JSONObject j = new JSONObject(d);
                        if (j.has("error") && !j.isNull("error")) {
                            throw toApiException(0, "{\"error\":" + j.get("error").toString() + "}");
                        }
                        JSONArray choices = j.optJSONArray("choices");
                        if (choices != null && choices.length() > 0) {
                            JSONObject delta = choices.getJSONObject(0).optJSONObject("delta");
                            String piece = optStr(delta, "content");
                            if (!piece.isEmpty()) {
                                gotDelta = true;
                                cb.onDelta(piece);
                            }
                        }
                    } else if (!line.startsWith(":") && !line.trim().isEmpty()) {
                        raw.append(line);
                    }
                }
            }
            if (cancelled.contains(id)) {
                cb.onDone();
                return;
            }
            if (!gotDelta && raw.length() > 0) {
                // Провайдер вернул обычный JSON без потока — запасной вариант.
                JSONObject j = new JSONObject(raw.toString());
                if (j.has("error") && !j.isNull("error")) throw toApiException(0, raw.toString());
                JSONArray choices = j.optJSONArray("choices");
                if (choices != null && choices.length() > 0) {
                    JSONObject msg = choices.getJSONObject(0).optJSONObject("message");
                    String full = optStr(msg, "content");
                    if (!full.isEmpty()) {
                        gotDelta = true;
                        cb.onDelta(full);
                    }
                }
            }
            if (!gotDelta) {
                cb.onError("empty", "Модель не вернула текст.");
            } else {
                cb.onDone();
            }
        } catch (ApiException e) {
            if (cancelled.contains(id)) cb.onDone();
            else cb.onError(e.code, e.getMessage());
        } catch (SocketTimeoutException e) {
            if (cancelled.contains(id)) cb.onDone();
            else cb.onError("timeout", "Время ожидания истекло.");
        } catch (IOException e) {
            if (cancelled.contains(id)) cb.onDone();
            else cb.onError("network", e.getClass().getSimpleName());
        } catch (Exception e) {
            if (cancelled.contains(id)) cb.onDone();
            else cb.onError("bad_response", e.getClass().getSimpleName());
        } finally {
            active.remove(id);
            cancelled.remove(id);
            if (conn != null) {
                try {
                    conn.disconnect();
                } catch (Exception ignored) {
                }
            }
        }
    }

    /** Простой запрос (GET/PUT/DELETE/POST) с JSON-телом. Блокирующий. */
    static Result request(String method, String url, String bearer, String body) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        try {
            if ("PATCH".equals(method)) {
                conn.setRequestMethod("POST"); // HttpURLConnection не умеет PATCH; Worker понимает переопределение метода
                conn.setRequestProperty("X-HTTP-Method-Override", "PATCH");
            } else {
                conn.setRequestMethod(method);
            }
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(40000);
            if (bearer != null && !bearer.isEmpty()) conn.setRequestProperty("Authorization", "Bearer " + bearer);
            conn.setRequestProperty("Accept", "application/json");
            if (body != null) {
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.getBytes(StandardCharsets.UTF_8));
                }
            }
            Result r = new Result();
            r.status = conn.getResponseCode();
            InputStream in = (r.status >= 200 && r.status < 300) ? conn.getInputStream() : conn.getErrorStream();
            r.body = readAll(in);
            return r;
        } finally {
            conn.disconnect();
        }
    }

    /** Проверяет, поддерживает ли модель OpenRouter изображения. Возвращает "yes", "no" или "unknown". */
    static String openRouterImageSupport(String model) {
        try {
            Result r = request("GET", "https://openrouter.ai/api/v1/models", null, null);
            if (r.status != 200) return "unknown";
            JSONArray data = new JSONObject(r.body).optJSONArray("data");
            if (data == null) return "unknown";
            for (int i = 0; i < data.length(); i++) {
                JSONObject m = data.getJSONObject(i);
                if (model.equals(optStr(m, "id"))) {
                    JSONObject arch = m.optJSONObject("architecture");
                    JSONArray mods = arch == null ? null : arch.optJSONArray("input_modalities");
                    if (mods == null) return "unknown";
                    for (int k = 0; k < mods.length(); k++) {
                        if ("image".equals(mods.optString(k))) return "yes";
                    }
                    return "no";
                }
            }
        } catch (Exception ignored) {
        }
        return "unknown";
    }
}
