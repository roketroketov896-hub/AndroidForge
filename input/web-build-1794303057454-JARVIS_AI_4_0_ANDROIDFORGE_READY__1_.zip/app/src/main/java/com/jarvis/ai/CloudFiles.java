package com.jarvis.ai;

import android.util.Base64;

import org.json.JSONObject;

/**
 * Клиент облачных функций JARVIS (Cloudflare Worker): создание DOCX/XLSX/RTF и генерация изображений на сервере.
 * Требует вход через Google и настроенный адрес сервера. Статусы и лимиты приходят от сервера, клиент их не выдумывает.
 */
final class CloudFiles {
    private CloudFiles() {
    }

    private static JSONObject o(Object... kv) {
        JSONObject r = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) r.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return r;
    }

    static boolean serverFormat(String name) {
        String n = name == null ? "" : name.toLowerCase();
        return n.endsWith(".docx") || n.endsWith(".xlsx") || n.endsWith(".rtf");
    }

    /** Возвращает null, если облако недоступно (нет сервера/входа), иначе ответ сервера. */
    private static ChatClient.Result call(MainActivity act, String method, String path, String body) throws Exception {
        String base = BuildConfig.BACKEND_URL == null ? "" : BuildConfig.BACKEND_URL.trim();
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        if (!base.startsWith("https://") || !act.auth.isSignedIn()) return null;
        String token = act.auth.ensureToken(act, BuildConfig.WEB_CLIENT_ID);
        if (token.isEmpty()) return null;
        return ChatClient.request(method, base + path, token, body);
    }

    private static String serverMessage(ChatClient.Result r, String dflt) {
        try {
            JSONObject e = new JSONObject(r.body).optJSONObject("error");
            if (e != null && !e.optString("message").isEmpty()) return e.optString("message");
        } catch (Exception ignored) {
        }
        return dflt + " (код " + r.status + ")";
    }

    private static byte[] download(MainActivity act, String fileId) throws Exception {
        ChatClient.Result r = call(act, "GET", "/v1/cloud/files/" + fileId + "?encoding=base64", null);
        if (r == null || r.status != 200) return null;
        return Base64.decode(new JSONObject(r.body).optString("data"), Base64.DEFAULT);
    }

    /** DOCX/XLSX/RTF создаются сервером; файл сохраняется на устройстве настоящим файлом. */
    static JSONObject create(MainActivity act, JSONObject args) {
        try {
            JSONObject req = new JSONObject();
            req.put("name", args.optString("name", "jarvis.docx"));
            req.put("content", args.optString("content", ""));
            if (args.optJSONArray("rows") != null) req.put("rows", args.optJSONArray("rows"));
            ChatClient.Result r = call(act, "POST", "/v1/cloud/files", req.toString());
            if (r == null) return o("ok", false, "code", "cloud_unavailable", "message", "Для DOCX, XLSX и RTF нужен вход через Google и настроенный сервер JARVIS. Сейчас облако недоступно. Текстовые форматы и ZIP создаются на устройстве.");
            if (r.status != 201) return o("ok", false, "message", "Сервер не создал файл: " + serverMessage(r, "ошибка"));
            JSONObject f = new JSONObject(r.body).getJSONObject("file");
            byte[] data = download(act, f.optString("id"));
            if (data == null) return o("ok", false, "message", "Сервер создал файл, но скачать его не удалось.");
            JSONObject saved = FileStore.createBytes(act, f.optString("name"), data);
            if (saved.optBoolean("ok")) saved.put("message", "Файл создан сервером JARVIS и сохранён на устройстве.");
            return saved;
        } catch (Exception e) {
            return o("ok", false, "message", "Не удалось связаться с сервером: " + e.getClass().getSimpleName());
        }
    }

    /** Генерация изображения на сервере. Возвращает null, если облако недоступно (тогда работает прежний путь). */
    static JSONObject image(MainActivity act, String prompt, String name) {
        try {
            ChatClient.Result r = call(act, "POST", "/v1/cloud/jobs", new JSONObject().put("type", "image").put("prompt", prompt).toString());
            if (r == null) return null;
            if (r.status == 429) return o("ok", false, "code", "quota", "message", serverMessage(r, "Лимит исчерпан"));
            if (r.status != 202) return null;
            String id = new JSONObject(r.body).getJSONObject("job").optString("id");
            long end = System.currentTimeMillis() + 110000;
            while (System.currentTimeMillis() < end) {
                Thread.sleep(2500);
                ChatClient.Result p = call(act, "GET", "/v1/cloud/jobs/" + id, null);
                if (p == null || p.status != 200) continue;
                JSONObject job = new JSONObject(p.body).getJSONObject("job");
                String st = job.optString("status");
                if ("completed".equals(st)) {
                    JSONObject res = job.getJSONObject("result");
                    byte[] data = download(act, res.optString("fileId"));
                    if (data == null) return o("ok", false, "message", "Изображение создано, но скачать его не удалось.");
                    String n = FileStore.safeName(name == null || name.isEmpty() ? "image" : name, "image");
                    String ext = res.optString("name").contains(".") ? res.optString("name").substring(res.optString("name").lastIndexOf('.')) : ".png";
                    if (n.contains(".")) n = n.substring(0, n.lastIndexOf('.'));
                    JSONObject saved = FileStore.createBytes(act, n + ext, data);
                    if (saved.optBoolean("ok")) saved.put("message", "Изображение создано на сервере JARVIS (" + res.optString("model") + ") и сохранено файлом.");
                    return saved;
                }
                if ("failed".equals(st) || "cancelled".equals(st)) return null; // пробуем прежний путь
            }
            call(act, "POST", "/v1/cloud/jobs/" + id + "/cancel", "{}");
            return null;
        } catch (Exception e) {
            return null;
        }
    }
}
