package com.k2fsa.sherpa.onnx;

public class OnlineTransducerModelConfig {
    private String encoder;
    private String decoder;
    private String joiner;
    private QnnConfig qnnConfig = new QnnConfig();

    public OnlineTransducerModelConfig(String encoder, String decoder, String joiner) {
        this.encoder = encoder; this.decoder = decoder; this.joiner = joiner;
    }
}
