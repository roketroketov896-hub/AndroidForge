package com.k2fsa.sherpa.onnx;

public class OnlineZipformer2CtcModelConfig {
    private String model = "";
    public OnlineZipformer2CtcModelConfig() { }
}
