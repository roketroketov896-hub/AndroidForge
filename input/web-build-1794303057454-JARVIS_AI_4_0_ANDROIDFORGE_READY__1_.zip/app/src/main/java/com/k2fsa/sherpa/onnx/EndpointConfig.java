package com.k2fsa.sherpa.onnx;

public class EndpointConfig {
    private EndpointRule rule1;
    private EndpointRule rule2;
    private EndpointRule rule3;

    public EndpointConfig() {
        this(new EndpointRule(false, 2.4f, 0f), new EndpointRule(true, 1.4f, 0f), new EndpointRule(false, 0f, 20f));
    }
    public EndpointConfig(EndpointRule rule1, EndpointRule rule2, EndpointRule rule3) {
        this.rule1 = rule1; this.rule2 = rule2; this.rule3 = rule3;
    }
}
