package com.k2fsa.sherpa.onnx;

public class QnnConfig {
    private String backendLib = "";
    private String contextBinary = "";
    private String systemLib = "";
    public QnnConfig() { }
}
