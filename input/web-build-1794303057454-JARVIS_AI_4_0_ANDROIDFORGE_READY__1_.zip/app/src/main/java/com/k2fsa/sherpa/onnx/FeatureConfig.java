package com.k2fsa.sherpa.onnx;

/** Совпадает с Kotlin-API Sherpa-ONNX 1.13.8: нативный код читает поля по именам. */
public class FeatureConfig {
    private int sampleRate;
    private int featureDim;
    private float dither;

    public FeatureConfig() { this(16000, 80, 0f); }
    public FeatureConfig(int sampleRate, int featureDim, float dither) {
        this.sampleRate = sampleRate; this.featureDim = featureDim; this.dither = dither;
    }
}
