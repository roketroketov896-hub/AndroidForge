package com.k2fsa.sherpa.onnx;

public class OnlineStream {
    private long ptr;

    public OnlineStream(long ptr) { this.ptr = ptr; }

    public void acceptWaveform(float[] samples, int sampleRate) { acceptWaveform(ptr, samples, sampleRate); }
    public void inputFinished() { inputFinished(ptr); }
    public long getPtr() { return ptr; }

    public void release() {
        if (ptr != 0L) { delete(ptr); ptr = 0L; }
    }

    private native void acceptWaveform(long ptr, float[] samples, int sampleRate);
    private native void inputFinished(long ptr);
    private native void delete(long ptr);
    private native String getOption(long ptr, String key);
    private native void setOption(long ptr, String key, String value);
}
