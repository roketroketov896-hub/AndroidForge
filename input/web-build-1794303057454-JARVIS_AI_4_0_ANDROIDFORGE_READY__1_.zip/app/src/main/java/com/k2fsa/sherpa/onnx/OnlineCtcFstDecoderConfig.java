package com.k2fsa.sherpa.onnx;

public class OnlineCtcFstDecoderConfig {
    private String graph = "";
    private int maxActive = 3000;
    public OnlineCtcFstDecoderConfig() { }
}
