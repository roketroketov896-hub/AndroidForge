package com.k2fsa.sherpa.onnx;

public class OnlineParaformerModelConfig {
    private String encoder = "";
    private String decoder = "";
    public OnlineParaformerModelConfig() { }
}
