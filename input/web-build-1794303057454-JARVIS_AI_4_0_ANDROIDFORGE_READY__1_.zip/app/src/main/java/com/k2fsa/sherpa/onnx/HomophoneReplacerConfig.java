package com.k2fsa.sherpa.onnx;

public class HomophoneReplacerConfig {
    private String dictDir = "";
    private String lexicon = "";
    private String ruleFsts = "";
    public HomophoneReplacerConfig() { }
}
