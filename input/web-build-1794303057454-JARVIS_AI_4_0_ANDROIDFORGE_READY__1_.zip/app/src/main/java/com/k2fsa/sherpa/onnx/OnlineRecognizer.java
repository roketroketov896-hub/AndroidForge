package com.k2fsa.sherpa.onnx;

import android.content.res.AssetManager;

/**
 * Java-версия Kotlin-API Sherpa-ONNX 1.13.8. Нативный слой — libsherpa-onnx-jni.so (arm64-v8a) из предоставленного APK;
 * его зависимость от ONNX Runtime переименована в libsherpa_ort1.so, чтобы не конфликтовать с ONNX Runtime из Maven.
 */
public class OnlineRecognizer {
    private long ptr;

    static {
        System.loadLibrary("sherpa_ort1");
        System.loadLibrary("sherpa-onnx-jni");
    }

    /** assetManager == null: пути — обычные файлы; иначе — пути внутри assets. */
    public OnlineRecognizer(AssetManager assetManager, OnlineRecognizerConfig config) {
        ptr = assetManager == null ? newFromFile(config) : newFromAsset(assetManager, config);
        if (ptr == 0L) throw new IllegalStateException("Sherpa: не удалось создать распознаватель");
    }

    public OnlineStream createStream() { return new OnlineStream(createStream(ptr, "")); }
    public boolean isReady(OnlineStream s) { return isReady(ptr, s.getPtr()); }
    public void decode(OnlineStream s) { decode(ptr, s.getPtr()); }
    public boolean isEndpoint(OnlineStream s) { return isEndpoint(ptr, s.getPtr()); }
    public void reset(OnlineStream s) { reset(ptr, s.getPtr()); }
    public OnlineRecognizerResult getResult(OnlineStream s) { return getResult(ptr, s.getPtr()); }

    public void release() {
        if (ptr != 0L) { delete(ptr); ptr = 0L; }
    }

    private native void delete(long ptr);
    private native long newFromAsset(AssetManager assetManager, OnlineRecognizerConfig config);
    private native long newFromFile(OnlineRecognizerConfig config);
    private native long createStream(long ptr, String hotwords);
    private native void reset(long ptr, long streamPtr);
    private native void decode(long ptr, long streamPtr);
    private native boolean isEndpoint(long ptr, long streamPtr);
    private native boolean isReady(long ptr, long streamPtr);
    private native OnlineRecognizerResult getResult(long ptr, long streamPtr);
}
