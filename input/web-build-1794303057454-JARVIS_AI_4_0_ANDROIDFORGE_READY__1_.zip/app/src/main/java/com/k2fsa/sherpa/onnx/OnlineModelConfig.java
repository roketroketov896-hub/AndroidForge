package com.k2fsa.sherpa.onnx;

public class OnlineModelConfig {
    private OnlineTransducerModelConfig transducer;
    private OnlineParaformerModelConfig paraformer = new OnlineParaformerModelConfig();
    private OnlineZipformer2CtcModelConfig zipformer2Ctc = new OnlineZipformer2CtcModelConfig();
    private OnlineNeMoCtcModelConfig neMoCtc = new OnlineNeMoCtcModelConfig();
    private OnlineToneCtcModelConfig toneCtc = new OnlineToneCtcModelConfig();
    private String tokens;
    private int numThreads;
    private boolean debug = false;
    private String provider = "cpu";
    private String modelType;
    private String modelingUnit = "";
    private String bpeVocab = "";

    public OnlineModelConfig(OnlineTransducerModelConfig transducer, String tokens, int numThreads, String modelType) {
        this.transducer = transducer; this.tokens = tokens; this.numThreads = numThreads; this.modelType = modelType;
    }
}
