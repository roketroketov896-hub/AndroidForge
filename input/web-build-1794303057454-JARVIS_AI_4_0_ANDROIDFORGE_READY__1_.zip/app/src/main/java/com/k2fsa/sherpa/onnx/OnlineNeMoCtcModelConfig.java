package com.k2fsa.sherpa.onnx;

public class OnlineNeMoCtcModelConfig {
    private String model = "";
    public OnlineNeMoCtcModelConfig() { }
}
