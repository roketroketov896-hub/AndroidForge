package com.k2fsa.sherpa.onnx;

public class EndpointRule {
    private boolean mustContainNonSilence;
    private float minTrailingSilence;
    private float minUtteranceLength;

    public EndpointRule(boolean mustContainNonSilence, float minTrailingSilence, float minUtteranceLength) {
        this.mustContainNonSilence = mustContainNonSilence;
        this.minTrailingSilence = minTrailingSilence;
        this.minUtteranceLength = minUtteranceLength;
    }
}
