package com.k2fsa.sherpa.onnx;

public class OnlineToneCtcModelConfig {
    private String model = "";
    public OnlineToneCtcModelConfig() { }
}
