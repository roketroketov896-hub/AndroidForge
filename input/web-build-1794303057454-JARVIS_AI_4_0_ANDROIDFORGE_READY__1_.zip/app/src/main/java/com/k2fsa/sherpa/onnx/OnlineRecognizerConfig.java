package com.k2fsa.sherpa.onnx;

public class OnlineRecognizerConfig {
    private FeatureConfig featConfig = new FeatureConfig();
    private OnlineModelConfig modelConfig;
    private OnlineLMConfig lmConfig = new OnlineLMConfig();
    private OnlineCtcFstDecoderConfig ctcFstDecoderConfig = new OnlineCtcFstDecoderConfig();
    private HomophoneReplacerConfig hr = new HomophoneReplacerConfig();
    private EndpointConfig endpointConfig = new EndpointConfig();
    private boolean enableEndpoint = true;
    private String decodingMethod = "greedy_search";
    private int maxActivePaths = 4;
    private String hotwordsFile = "";
    private float hotwordsScore = 1.5f;
    private String ruleFsts = "";
    private String ruleFars = "";
    private float blankPenalty = 0f;

    public OnlineRecognizerConfig(OnlineModelConfig modelConfig) {
        this.modelConfig = modelConfig;
    }
}
