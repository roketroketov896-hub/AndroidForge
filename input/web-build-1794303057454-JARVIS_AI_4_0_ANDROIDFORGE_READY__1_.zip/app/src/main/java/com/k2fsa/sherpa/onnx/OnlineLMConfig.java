package com.k2fsa.sherpa.onnx;

public class OnlineLMConfig {
    private String model = "";
    private float scale = 0.5f;
    public OnlineLMConfig() { }
}
