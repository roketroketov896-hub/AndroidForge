package com.example.simplecalculator;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView display;
    private String current = "0", operator = "";
    private double stored = 0;
    private boolean fresh = true;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12, 20, 12, 12);
        root.setBackgroundColor(Color.rgb(245,245,245));
        display = new TextView(this);
        display.setText("0"); display.setTextSize(36); display.setTextColor(Color.BLACK);
        display.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        display.setPadding(8, 16, 8, 16);
        root.addView(display, new LinearLayout.LayoutParams(-1, 0, 1));
        String[][] keys = {{"C","⌫","÷","×"},{"7","8","9","−"},{"4","5","6","+"},{"1","2","3","="},{"0",".","±","%"}};
        GridLayout grid = new GridLayout(this); grid.setColumnCount(4); grid.setRowCount(5);
        for (int r=0; r<keys.length; r++) for (int c=0; c<4; c++) {
            String key = keys[r][c]; Button b = new Button(this); b.setText(key); b.setTextSize(20);
            b.setOnClickListener(v -> press(key));
            GridLayout.LayoutParams p = new GridLayout.LayoutParams();
            p.width=0; p.height=0; p.columnSpec=GridLayout.spec(c,1f); p.rowSpec=GridLayout.spec(r,1f);
            p.setMargins(3,3,3,3); grid.addView(b,p);
        }
        root.addView(grid, new LinearLayout.LayoutParams(-1,0,2));
        setContentView(root);
    }
    private void press(String k) {
        try {
            if (k.equals("C")) { current="0"; stored=0; operator=""; fresh=true; }
            else if (k.equals("⌫")) { current=(!fresh && current.length()>1)?current.substring(0,current.length()-1):"0"; }
            else if (k.matches("[0-9]")) { current=(fresh || current.equals("0"))?k:current+k; fresh=false; }
            else if (k.equals(".")) { if (fresh) {current="0.";fresh=false;} else if (!current.contains(".")) current+="."; }
            else if (k.equals("±")) { if (!current.equals("0")) current=current.startsWith("-")?current.substring(1):"-"+current; }
            else if (k.equals("%")) { current=fmt(Double.parseDouble(current)/100.0); fresh=true; }
            else if (k.equals("=")) { calculate(); operator=""; fresh=true; }
            else { stored=Double.parseDouble(current); operator=k; fresh=true; }
            display.setText(current);
        } catch (Exception e) { current="0"; operator=""; fresh=true; display.setText(current); Toast.makeText(this,"Ошибка вычисления",Toast.LENGTH_SHORT).show(); }
    }
    private void calculate() {
        if (operator.isEmpty()) return;
        double a=stored, b=Double.parseDouble(current), result;
        switch(operator) {
            case "+": result=a+b; break;
            case "−": result=a-b; break;
            case "×": result=a*b; break;
            case "÷": if (b==0) { current="0"; display.setText("На ноль делить нельзя"); return; } result=a/b; break;
            default: return;
        }
        current=fmt(result);
    }
    private String fmt(double n) { return n==(long)n ? String.valueOf((long)n) : String.valueOf(n); }
}
