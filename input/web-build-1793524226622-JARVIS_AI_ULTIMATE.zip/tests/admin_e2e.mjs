import { createRequire } from 'node:module';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
const require = createRequire(import.meta.url);
const { chromium } = require((process.env.PLAYWRIGHT || 'playwright'));
const { createApp } = await import('../backend/server.mjs');

const bodies = [];
const up = http.createServer((req, res) => { let b = ''; req.on('data', c => (b += c)); req.on('end', () => {
  if (req.url.startsWith('/auth')) { res.writeHead(200); return res.end('{}'); }
  if (req.url.startsWith('/tts')) { res.writeHead(200, { 'Content-Type': 'audio/mpeg' }); return res.end(Buffer.from([1, 2, 3])); }
  bodies.push({ auth: req.headers.authorization, ...JSON.parse(b) }); res.writeHead(200, { 'Content-Type': 'text/event-stream' }); res.end('data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n'); }); });
await new Promise(r => up.listen(0, r));
const U = 'http://127.0.0.1:' + up.address().port;
const mk = mode => createApp({ dataFile: path.join(os.tmpdir(), 'a2-' + mode + Date.now() + '.json'), upstreamUrl: U + '/chat', keyCheckUrl: U + '/auth', ttsUrl: U + '/tts', openrouterKey: 'ENV-KEY-0000000000', freeModel: 'fm', adminMode: mode, ipLimitPerMin: 1e6,
  azureKey: 'AZURE-KEY-0000', verify: async t => (t === 'u' ? { sub: 'U', email: 'user@example.com' } : null) });
const open = mk('open'), guard = mk('google');
for (const a of [open, guard]) await new Promise(r => a.server.listen(0, r));
const openUrl = 'http://127.0.0.1:' + open.server.address().port, guardUrl = 'http://127.0.0.1:' + guard.server.address().port;
const asUser = (p, body) => fetch(openUrl + p, { method: 'POST', headers: { Authorization: 'Bearer u'.replace('u', 'u'), 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
await fetch(openUrl + '/v1/status', { headers: { Authorization: 'Bearer u' } });

async function session(label, startHost, steps) {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 390, height: 800 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  let host = startHost;
  await p.exposeFunction('nodeApi', async (m, pth, body) => { try { const r = await fetch(host + pth, { method: m, headers: { 'Content-Type': 'application/json' }, body: body || undefined }); return JSON.stringify({ ok: r.ok, status: r.status, body: await r.text() }); } catch { return JSON.stringify({ ok: false, status: 0, code: 'network', body: '' }); } });
  await p.exposeFunction('setHost', h => { host = h; });
  await p.addInitScript(h => {
    let saved = h;
    window.AdminBridge = { getState: () => JSON.stringify({ backendUrl: saved }), saveServer: u => { if (!u.startsWith('https://') && !u.startsWith('http://127.0.0.1')) return false; saved = u; window.setHost(u); return true; }, clearServer: () => { saved = ''; window.setHost(''); },
      api: async (id, m, path, body) => { const r = JSON.parse(await window.nodeApi(m, path, body)); window.AdminEvents.emit('api', JSON.stringify({ reqId: id, ok: r.ok, status: r.status, code: r.code || '', body: r.body })); } };
  }, startHost);
  await p.goto(new URL('../admin/src/main/assets/index.html', import.meta.url).href); await p.waitForTimeout(300);
  await steps(p);
  console.log(label, 'errors:', errs.length ? errs : 'none'); await b.close();
}
const cfg = async () => (await (await fetch(openUrl + '/admin/config')).json());

await session('NO-SERVER', '', async p => {
  console.log('home tiles without server:', await p.$$eval('.tile b', e => e.map(x => x.textContent).join(' | ')));
  console.log('banner:', await p.$eval('.banner b', e => e.textContent));
  await p.click('[data-go="users"]'); await p.waitForTimeout(200);
  console.log('users page w/o server:', await p.$eval('.banner b', e => e.textContent));
  await p.click('[data-go="system"]'); await p.waitForTimeout(200);
  await p.fill('#host', openUrl); await p.click('#saveHost'); await p.waitForTimeout(800);
  console.log('connect result:', await p.$eval('#so', e => e.textContent), '| pill:', await p.$eval('#conn', e => e.textContent));
});
await session('OPEN-MODE', openUrl, async p => {
  await p.waitForTimeout(400);
  console.log('pill:', await p.$eval('#conn', e => e.textContent), '| banner:', await p.$eval('.banner b', e => e.textContent));
  // ИИ
  await p.click('[data-go="ai"]'); await p.waitForTimeout(500);
  await p.fill('#newKey', 'NEW-ADMIN-KEY-123456'); await p.click('#saveKey'); await p.waitForTimeout(150); await p.click('#dialogYes'); await p.waitForTimeout(600);
  await p.fill('#freeModel', 'my/model'); await p.fill('#sysPrompt', 'Ты суровый ИИ'); await p.fill('#temperature', '0.4'); await p.fill('#maxTokens', '321'); await p.click('#saveAi'); await p.waitForTimeout(500);
  console.log('ai saved:', await p.$eval('#ao', e => e.textContent));
  await asUser('/v1/chat', { messages: [{ role: 'system', content: 'app' }, { role: 'user', content: 'hi' }] });
  const last = bodies.at(-1);
  assert.equal(last.auth, 'Bearer NEW-ADMIN-KEY-123456'); assert.equal(last.model, 'my/model'); assert.equal(last.temperature, 0.4); assert.equal(last.max_tokens, 321); assert.match(last.messages[0].content, /^Ты суровый ИИ/);
  console.log('user request reflects admin changes: key+model+prompt+temperature+max_tokens = yes');
  // лимиты
  await p.click('#back'); await p.click('[data-go="limits"]'); await p.waitForTimeout(400);
  await p.fill('#dailyLimit', '3'); await p.click('#save'); await p.waitForTimeout(400);
  assert.equal((await cfg()).dailyLimit, 3); console.log('limits saved on server: dailyLimit=3');
  // голос
  await p.click('#back'); await p.click('[data-go="voice"]'); await p.waitForTimeout(400);
  await p.fill('#v_ru', 'ru-RU-DmitryNeural'); await p.fill('#rate', '-8'); await p.click('#saveV'); await p.waitForTimeout(400);
  await p.click('[data-t="az"]'); await p.waitForTimeout(500);
  console.log('voice test:', await p.$eval('#vo', e => e.textContent));
  assert.equal((await cfg()).voiceRate, -8);
  // настройки JARVIS
  await p.click('#back'); await p.click('[data-go="appsettings"]'); await p.waitForTimeout(400);
  await p.fill('#ann', 'Тест объявления'); await p.click('#saveA'); await p.waitForTimeout(400);
  await p.click('label:has(#f_gmail)'); await p.click('#saveF'); await p.waitForTimeout(400);
  const ac = await (await fetch(openUrl + '/v1/app-config')).json();
  assert.equal(ac.announcement, 'Тест объявления'); assert.equal(ac.features.gmail, false); console.log('app-config visible to apps: announcement + gmail=false');
  // интеграции
  await p.click('#back'); await p.click('[data-go="integrations"]'); await p.waitForTimeout(500);
  console.log('integrations:', await p.$$eval('.card .logrow b', e => e.map(x => x.textContent).join(' | ')));
  // пользователи
  await p.click('#back'); await p.click('[data-go="users"]'); await p.waitForTimeout(500);
  await p.click('.ucard .uhead'); await p.click('[data-a="block"]'); await p.waitForTimeout(150); await p.click('#dialogYes'); await p.waitForTimeout(500);
  const blocked = await asUser('/v1/chat', { messages: [{ role: 'user', content: 'x' }] });
  assert.equal(blocked.status, 403); console.log('blocked user is refused (403): yes');
  // журнал и диагностика
  await p.click('#back'); await p.click('[data-go="logs"]'); await p.waitForTimeout(500);
  console.log('log rows:', await p.$$eval('.logrow', e => e.length), '| diagnostics rows:', await p.$$eval('.kv span', e => e.length / 2));
  // система + назад
  await p.click('#back'); await p.click('[data-go="system"]'); await p.waitForTimeout(300);
  assert.equal(await p.evaluate(() => window.adminBack()), true);
});
await session('GUARDED-SERVER', guardUrl, async p => {
  await p.waitForTimeout(600);
  console.log('guarded server banner:', await p.$eval('.banner b', e => e.textContent), '| tiles still shown:', await p.$$eval('.tile', e => e.length));
});
for (const a of [open, guard]) a.server.close(); up.close(); console.log('admin2 e2e done'); process.exit(0);
