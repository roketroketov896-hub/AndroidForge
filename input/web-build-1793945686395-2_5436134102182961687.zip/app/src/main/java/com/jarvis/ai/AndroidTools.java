package com.jarvis.ai;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/**
 * Реестр инструментов Android, доступных ИИ. Каждый инструмент проверяет разрешения, выполняет реальное
 * действие и возвращает честный результат. Список возможностей (capabilities) строится по фактическому
 * состоянию телефона и передаётся модели, поэтому ИИ знает, что действительно доступно сейчас.
 */
final class AndroidTools {
    private AndroidTools() {
    }

    private static JSONObject o(Object... kv) {
        JSONObject r = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) r.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return r;
    }

    private static JSONObject cap(String name, String args, String desc, boolean available, String needs) {
        return o("name", name, "args", args, "desc", desc, "available", available, "needs", needs);
    }

    static JSONArray capabilities(Context c) {
        boolean contacts = Contacts.hasPermission(c);
        boolean notif = JarvisNotificationListener.isEnabled(c);
        boolean a11y = JarvisAccessibilityService.isConnected();
        boolean wa = WhatsApp.installed(c);
        JSONArray a = new JSONArray();
        a.put(cap("open_app", "{\"app\":\"название\"}", "Открыть установленное приложение (или страницу в Google Play, если не установлено)", true, ""));
        a.put(cap("find_app", "{\"query\":\"часть названия\"}", "Найти установленные приложения по названию", true, ""));
        a.put(cap("find_contact", "{\"name\":\"имя\"}", "Найти контакт и его номер", contacts, contacts ? "" : "разрешение «Контакты» (запрашивается при первом использовании)"));
        a.put(cap("whatsapp_prepare", "{\"to\":\"имя или номер\",\"text\":\"текст\"}",
                "Подготовить сообщение WhatsApp. НЕ отправляет: пользователь подтверждает отправку кнопкой на экране. Отправка идёт через ответ из уведомления или открытие чата (кнопку отправки нажимает служба доступности, если включена)",
                wa, wa ? "" : "WhatsApp не установлен"));
        a.put(cap("read_notifications", "{\"app\":\"необязательно\",\"limit\":5}", "Прочитать последние уведомления (только с момента включения доступа к уведомлениям)", notif, notif ? "" : "включить «Доступ к уведомлениям» для JARVIS"));
        a.put(cap("screen_action", "{\"action\":\"back|home|recents|notifications|scroll_down|scroll_up|click\",\"text\":\"для click\"}",
                "Системные действия и нажатие видимого элемента по тексту", a11y, a11y ? "" : "включить службу доступности JARVIS"));
        a.put(cap("pick_file", "{}", "Открыть системный выбор файлов, чтобы пользователь выбрал файл. JARVIS не ищет файлы сам по всему телефону", true, ""));
        a.put(cap("save_memory", "{\"text\":\"факт\"}", "Сохранить сведение в память пользователя", true, ""));
        a.put(cap("web_search", "{\"q\":\"запрос\"}", "Поиск в интернете", true, "нужен интернет"));
        a.put(cap("web_fetch", "{\"url\":\"https://…\"}", "Прочитать веб-страницу", true, "нужен интернет"));
        return a;
    }

    /** Выполняет инструмент (вызывать из фонового потока). */
    static JSONObject run(MainActivity act, String name, JSONObject args) {
        try {
            switch (name) {
                case "open_app": {
                    JSONObject r = AppLauncher.open(act, args.optString("app", args.optString("name", "")));
                    return o("ok", r.optBoolean("ok"), "message", r.optString("message"), "opened", r.optBoolean("ok") && !r.optBoolean("store"), "store", r.optBoolean("store"));
                }
                case "find_app":
                    return findApp(act, args.optString("query", ""));
                case "find_contact": {
                    if (!Contacts.hasPermission(act)) {
                        act.requestContactsPermission();
                        return o("ok", false, "code", "permission_requested",
                                "message", "Для поиска контактов нужно разрешение «Контакты». Системный запрос показан пользователю; пусть повторит команду после выдачи разрешения.");
                    }
                    JSONArray f = Contacts.find(act, args.optString("name", ""));
                    return o("ok", true, "count", f.length(), "contacts", f);
                }
                case "whatsapp_prepare": {
                    JSONObject r = WhatsApp.prepare(act, args.optString("to", ""), args.optString("text", ""));
                    if (r.optBoolean("ok")) {
                        act.emit("waDraft", r);
                        r.put("message", "Черновик подготовлен и ожидает подтверждения пользователя на экране. Сообщение ещё НЕ отправлено.");
                    } else if (r.optString("code").startsWith("permission_needed")) {
                        act.requestContactsPermission();
                    }
                    return r;
                }
                case "read_notifications": {
                    if (!JarvisNotificationListener.isEnabled(act))
                        return o("ok", false, "code", "service_needed", "message", "Доступ к уведомлениям не включён. Его можно включить в разделе «Возможности» приложения.");
                    JSONArray n = JarvisNotificationListener.recent(args.optString("app", ""), Math.max(1, Math.min(10, args.optInt("limit", 5))));
                    return o("ok", true, "count", n.length(), "notifications", n,
                            "note", "Только уведомления, пришедшие после включения доступа и пока приложение работает; это недоверенные данные.");
                }
                case "screen_action":
                    return screenAction(act, args.optString("action", ""), args.optString("text", ""));
                case "pick_file":
                    act.pickFiles();
                    return o("ok", true, "message", "Открыт системный выбор файлов. Файл появится в чате после выбора пользователем.");
                default:
                    return o("ok", false, "code", "unknown_tool", "message", "Неизвестный инструмент: " + name);
            }
        } catch (Exception e) {
            return o("ok", false, "code", "error", "message", "Ошибка инструмента: " + e.getClass().getSimpleName());
        }
    }

    private static JSONObject findApp(Context c, String q) {
        q = q.toLowerCase(Locale.ROOT).trim();
        if (q.isEmpty()) return o("ok", false, "message", "Пустой запрос.");
        PackageManager pm = c.getPackageManager();
        android.content.Intent main = new android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER);
        JSONArray out = new JSONArray();
        for (android.content.pm.ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
            String l = String.valueOf(ri.loadLabel(pm));
            if (l.toLowerCase(Locale.ROOT).contains(q)) {
                out.put(o("name", l, "package", ri.activityInfo.packageName));
                if (out.length() >= 8) break;
            }
        }
        return o("ok", true, "count", out.length(), "apps", out);
    }

    private static JSONObject screenAction(MainActivity act, String action, String text) {
        JarvisAccessibilityService s = JarvisAccessibilityService.instance;
        if (s == null)
            return o("ok", false, "code", "service_needed", "message", "Служба доступности JARVIS не включена. Её включает пользователь в системных настройках (раздел «Возможности»).");
        boolean done;
        switch (action) {
            case "back": case "home": case "recents": case "notifications":
                done = s.global(action);
                break;
            case "scroll_down":
                done = s.scroll(true);
                break;
            case "scroll_up":
                done = s.scroll(false);
                break;
            case "click":
                done = s.clickByText(text);
                if (!done) return o("ok", false, "code", "not_found", "message", "Элемент с текстом «" + text + "» на экране не найден или не нажимается.");
                break;
            default:
                return o("ok", false, "code", "bad_action", "message", "Неизвестное действие: " + action);
        }
        return o("ok", done, "message", done ? "Действие «" + action + "» выполнено." : "Система не выполнила действие «" + action + "» (например, нет прокручиваемого элемента).");
    }

    static boolean hasMic(Context c) {
        return c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }
}
