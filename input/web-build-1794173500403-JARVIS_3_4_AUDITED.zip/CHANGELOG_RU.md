# CHANGELOG — подготовка JARVIS AI 3.4

## ZIP preparation
- Добавлен `PROJECT_AUDIT_RU.md` с фактическими результатами аудита.
- Добавлен `IMPLEMENTATION_PLAN_RU.md`.
- Обновлены `README.md`, `REPORT_RU.md`, `SETUP_GOOGLE_CLOUDFLARE_RU.txt`.
- Удалён `app/jarvis-debug.keystore` из итогового архива.
- Удалена жёсткая debug signing configuration из `app/build.gradle`, чтобы не ссылаться на удалённый приватный ключ.
- Остальная функциональность приложения не переписывалась; Telegram и профиль не заявляются как реализованные.
