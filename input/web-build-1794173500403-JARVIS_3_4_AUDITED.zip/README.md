# JARVIS AI 3.4.0 — Android project

Исходный Android-проект: `com.jarvis.ai`, Java + WebView UI + Cloudflare Worker.

## Состав
- `app/` — Android-приложение.
- `cloud/` — Cloudflare Worker и тесты.
- `tests/` — UI E2E tests.
- `jarvis-config.properties` — публичные endpoint и Google Web Client ID (не секретный API-ключ).

## Требования
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 34
- minSdk 23

## Сборка APK
Загрузите ZIP в AndroidForge и выберите задачу `:app:assembleDebug` (если платформа предлагает выбор задачи). Либо откройте проект в Android Studio и выполните `:app:assembleDebug`.

**Важно:** в архиве отсутствуют wrapper launcher/JAR (`gradlew`, `gradlew.bat`, `gradle-wrapper.jar`), а сборка в среде подготовки не выполнялась. Поэтому гарантировать сборку через AndroidForge нельзя. Если сайт требует Gradle Wrapper, проекту нужно добавить полный wrapper через Android Studio/установленный Gradle.

## Настройки OAuth и Cloudflare
См. `SETUP_GOOGLE_CLOUDFLARE_RU.txt`. До публикации проверьте соответствие `GOOGLE_CLIENT_ID` и `ADMIN_EMAILS` в Cloudflare. В аудите обнаружено расхождение значений; администраторский адрес не изменялся без подтверждения.

## Безопасность
Приватный `app/jarvis-debug.keystore` удалён из этого ZIP, фиксированная ссылка на него убрана из Gradle. Не добавляйте приватные ключи, API keys или токены в архив, APK или публичный JavaScript.

## Аудит и ограничения
См. `PROJECT_AUDIT_RU.md`, `IMPLEMENTATION_PLAN_RU.md`, `REPORT_RU.md`.
