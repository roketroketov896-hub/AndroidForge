package com.jarvis.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.view.WindowManager;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Окно приложения. Видеозаставки нет: сразу создаются WebView с интерфейсом и голосовые компоненты,
 * а в фоне идёт сетевая подготовка (настройки сервера, предпрогрев токена).
 * Сервер и ИИ-провайдер на готовность интерфейса не влияют.
 */
public class MainActivity extends Activity implements Emitter {
    static final int REQ_AUDIO = 701;
    static final int REQ_PROJECTION = 702;
    static final int REQ_NOTIF = 703;
    static final int REQ_CONTACTS = 704;
    static final int REQ_FILES = 705;
    static final int REQ_PICK_CONTACT = 706;
    static final int REQ_PHOTO = 707;

    WebView webView;
    JarvisSettings settings;
    SecureStore store;
    AuthManager auth;
    TtsController tts;
    OnlineTts online;
    SpeechInput speech;
    final ChatClient chat = new ChatClient();
    final ExecutorService executor = Executors.newCachedThreadPool();
    final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private FrameLayout root;
    private String pendingLang = "ru";
    private boolean pendingContinuous = false;
    private boolean servicesReady = false;


    private final BargeIn bargeIn = new BargeIn();
    private boolean uiReady = false;
    private boolean backgroundStarted = false;
    private boolean resumed = false;

    // подготовка в фоне
    private volatile String appConfigJson = "";
    private volatile boolean serverChecked = false;
    private volatile boolean serverOk = false;
    private volatile boolean bootstrapRunning = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("jarvis_settings", MODE_PRIVATE);
        settings = new JarvisSettings(prefs);
        store = new SecureStore(prefs);
        auth = new AuthManager(prefs, store);

        getWindow().setStatusBarColor(Color.parseColor("#161618"));
        getWindow().setNavigationBarColor(Color.parseColor("#161618"));

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#161618"));
        setContentView(root);

        ScreenShareService.listener = new ScreenShareService.Listener() {
            @Override
            public void onStarted() {
                emit("screen", json("state", "started"));
            }

            @Override
            public void onFrame(String dataUrl) {
                emit("screen", json("state", "frame", "image", dataUrl));
            }

            @Override
            public void onStopped(String reason) {
                emit("screen", json("state", "stopped", "reason", reason));
            }
        };

        LiveVoiceService.listener = new LiveVoiceService.Listener() {
            @Override
            public void onStopped() {
                emit("live", json("state", "stopped"));
            }
        };

        startBackground();
    }

    /** Вызывается интерфейсом, когда он отрисован и история загружена. */
    void onUiReady() {
        uiReady = true;
        pushBootstrap();
    }

    // ---------- фоновая подготовка ----------

    /** Один раз: создаёт голосовые компоненты и WebView и запускает сетевую подготовку. */
    private void startBackground() {
        if (backgroundStarted) return;
        backgroundStarted = true;
        main.post(new Runnable() {
            @Override
            public void run() {
                initServices();
                createWebView();
                bootstrapAsync();
            }
        });
    }

    private void initServices() {
        if (servicesReady) return;
        servicesReady = true;
        tts = new TtsController(this, settings, this);
        speech = new SpeechInput(this, this);
        online = new OnlineTts(this, this, new OnlineTts.Source() {
            @Override
            public String baseUrl() {
                return normalizeBase(BuildConfig.BACKEND_URL);
            }

            @Override
            public String token() {
                return auth.ensureToken(MainActivity.this, BuildConfig.WEB_CLIENT_ID);
            }
        });
    }

    static String normalizeBase(String url) {
        String u = url == null ? "" : url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u.startsWith("https://") ? u : "";
    }

    boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    /** Сетевая подготовка не блокирует запуск: результат приходит в интерфейс событием. */
    void bootstrapAsync() {
        if (bootstrapRunning) return;
        bootstrapRunning = true;
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String base = normalizeBase(BuildConfig.BACKEND_URL);
                    if (!base.isEmpty()) {
                        try {
                            ChatClient.Result r = ChatClient.request("GET", base + "/v1/app-config", null, null);
                            serverOk = r.status == 200;
                            if (serverOk) appConfigJson = r.body;
                        } catch (Exception e) {
                            serverOk = false;
                        }
                    }
                    serverChecked = true;
                    pushBootstrap();
                    // Серверная проверка сессии и прав администратора. Окон Google не показывает.
                    if (auth.isSignedIn() && !base.isEmpty()) {
                        auth.ensureToken(MainActivity.this, BuildConfig.WEB_CLIENT_ID);
                        auth.checkMe(base);
                        emit("auth", auth.profile());
                    }
                } finally {
                    bootstrapRunning = false;
                }
            }
        });
    }

    void retryBootstrap() {
        serverChecked = false;
        bootstrapAsync();
    }

    void pushBootstrap() {
        if (!uiReady || !serverChecked) return;
        JSONObject d = json("serverChecked", true, "serverOk", serverOk, "online", isOnline(),
                "backendConfigured", !normalizeBase(BuildConfig.BACKEND_URL).isEmpty(), "appConfig", appConfigJson);
        emit("bootstrap", d);
    }

    // ---------- WebView ----------

    private void createWebView() {
        if (webView != null) return;
        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#161618"));
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setSupportMultipleWindows(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);
        ws.setGeolocationEnabled(false);
        ws.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }

            /** Внешние ресурсы внутри страницы запрещены, кроме аватара Google. */
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    String host = u.getHost();
                    if (host == null || !host.endsWith(".googleusercontent.com")) {
                        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked",
                                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                    }
                }
                return null;
            }
        });
        webView.addJavascriptInterface(new JarvisBridge(this), "JarvisBridge");
        root.addView(webView, 0, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        webView.loadUrl("file:///android_asset/index.html");
    }

    private static JSONObject json(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return o;
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if ("file".equals(scheme)) return false;
        if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
            }
        }
        return true;
    }

    @Override
    public void emit(String event, JSONObject data) {
        final String js = "window.JarvisEvents&&window.JarvisEvents.emit("
                + JSONObject.quote(event) + "," + JSONObject.quote(data.toString()) + ")";
        main.post(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.evaluateJavascript(js, null);
            }
        });
    }

    // ---------- озвучивание: выбор движка и единое управление ----------

    private boolean wantsOnline() {
        return "online".equals(settings.str("ttsEngine"));
    }

    void speakText(String id, String text, String lang) {
        speakText(id, text, lang, false);
    }

    /** keepMic=true: не прерывать распознавание речи (Live с наушниками, чтобы можно было перебить). */
    void speakText(String id, String text, String lang, boolean keepMic) {
        if (!servicesReady) return;
        if (!keepMic) speech.cancel();
        if (wantsOnline()) {
            tts.stop();
            if (normalizeBase(BuildConfig.BACKEND_URL).isEmpty() || !auth.isSignedIn()) {
                emit("ttsError", json("code", "online_unavailable", "message",
                        "Нейро-голос требует входа через Google и подключённого сервера. Выбери системный голос в настройках.", "lang", lang));
                return;
            }
            online.speak(id, text, lang);
        } else {
            online.stop();
            tts.speak(id, text, lang);
        }
    }

    void pauseSpeech() {
        if (!servicesReady) return;
        tts.pause();
        online.pause();
    }

    void resumeSpeech() {
        if (!servicesReady) return;
        tts.resume();
        online.resume();
    }

    void stopSpeech() {
        if (!servicesReady) return;
        tts.stop();
        online.stop();
    }

    // ---------- Live: потоковая речь и перебивание ----------

    void ttsStreamStart(String id, String lang) {
        if (!servicesReady) return;
        online.stop();
        speech.cancel();
        tts.streamStart(id, lang);
    }

    void ttsStreamAdd(String text) {
        if (servicesReady) tts.streamAdd(text);
    }

    void ttsStreamEnd() {
        if (servicesReady) tts.streamEnd();
    }

    /** Пока JARVIS говорит: слушать голос пользователя, чтобы дать себя перебить. Только при включённом Live. */
    void startBargeIn() {
        if (!servicesReady || !LiveVoiceService.running) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        bargeIn.start(new BargeIn.Callback() {
            @Override
            public void onSpeech() {
                stopSpeech();
                emit("live", json("state", "bargein"));
            }
        });
    }

    void stopBargeIn() {
        bargeIn.stop();
    }

    // ---------- микрофон ----------

    void beginListening(String lang) {
        beginListening(lang, true, false);
    }

    /** interrupt: остановить речь JARVIS перед записью; continuous: диктовка без остановки на паузах. */
    void beginListening(String lang, boolean interrupt, boolean continuous) {
        if (!servicesReady) return;
        pendingLang = (lang == null || lang.isEmpty()) ? "ru" : lang;
        pendingContinuous = continuous;
        if (interrupt) stopSpeech();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        startRecognition();
    }

    private void startRecognition() {
        if (pendingContinuous) speech.startContinuous(pendingLang);
        else speech.start(pendingLang);
    }

    boolean hasHeadset() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int t = d.getType();
                if (t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                        || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    void keepScreenOn(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // ---------- Live Voice в фоне ----------

    /** Только по нажатию пользователя. Нужны разрешение микрофона и уведомления; служба показывает уведомление с кнопкой «Стоп». */
    void startLiveService() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            emit("live", json("state", "need_mic"));
            return;
        }
        try {
            Intent i = new Intent(this, LiveVoiceService.class).setAction(LiveVoiceService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            emit("live", json("state", "started"));
        } catch (Exception e) {
            emit("live", json("state", "error"));
        }
    }

    void stopLiveService() {
        try {
            stopService(new Intent(this, LiveVoiceService.class));
        } catch (Exception ignored) {
        }
    }

    // ---------- показ экрана ----------

    void requestScreenShare() {
        if (ScreenShareService.running) {
            emit("screen", json("state", "started"));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        launchProjection();
    }

    private void launchProjection() {
        try {
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQ_PROJECTION);
        } catch (Exception e) {
            emit("screen", json("state", "error", "reason", "no_projection"));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILES) {
            handleFilesResult(resultCode, data);
            return;
        }
        if (requestCode == REQ_PICK_CONTACT) {
            handleContactResult(resultCode, data);
            return;
        }
        if (requestCode == REQ_PHOTO) {
            handlePhotoResult(resultCode, data);
            return;
        }
        if (requestCode != REQ_PROJECTION) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent i = new Intent(this, ScreenShareService.class)
                    .setAction(ScreenShareService.ACTION_START)
                    .putExtra("code", resultCode)
                    .putExtra("data", data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } else {
            emit("screen", json("state", "denied"));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_AUDIO) {
            if (granted) {
                emit("permission", json("name", "mic", "granted", true));
                main.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startRecognition();
                    }
                }, 200);
            } else {
                boolean permanent = !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO);
                emit("speech", json("type", "error", "code", "permission_denied", "permanent", permanent));
            }
        } else if (requestCode == REQ_NOTIF) {
            launchProjection();
        } else if (requestCode == REQ_CONTACTS) {
            emit("caps", json("caps", AndroidTools.capabilities(this)));
            emit("permission", json("name", "contacts", "granted", granted));
        }
    }

    // ---------- контакты, файлы, возможности ----------

    void requestContactsPermission() {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (!Contacts.hasPermission(MainActivity.this)) requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS);
            }
        });
    }

    /** Выбор своего фото для профиля (SAF). Фото уменьшается до 256x256 и остаётся только на телефоне. */
    void pickPhoto() {
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("image/*");
                    startActivityForResult(i, REQ_PHOTO);
                } catch (Exception e) {
                    emit("photo", json("error", "Не удалось открыть выбор фото."));
                }
            }
        });
    }

    private void handlePhotoResult(int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            emit("photo", json("cancelled", true));
            return;
        }
        final Uri u = data.getData();
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    try (java.io.InputStream in = getContentResolver().openInputStream(u)) {
                        android.graphics.BitmapFactory.decodeStream(in, null, o);
                    }
                    int side = Math.max(1, Math.min(o.outWidth, o.outHeight));
                    o.inJustDecodeBounds = false;
                    o.inSampleSize = Math.max(1, side / 512);
                    android.graphics.Bitmap bmp;
                    try (java.io.InputStream in = getContentResolver().openInputStream(u)) {
                        bmp = android.graphics.BitmapFactory.decodeStream(in, null, o);
                    }
                    if (bmp == null) {
                        emit("photo", json("error", "Не удалось прочитать изображение."));
                        return;
                    }
                    int s = Math.min(bmp.getWidth(), bmp.getHeight());
                    android.graphics.Bitmap sq = android.graphics.Bitmap.createBitmap(bmp, (bmp.getWidth() - s) / 2, (bmp.getHeight() - s) / 2, s, s);
                    android.graphics.Bitmap out = android.graphics.Bitmap.createScaledBitmap(sq, 256, 256, true);
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    out.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, bo);
                    emit("photo", json("dataUrl", "data:image/jpeg;base64," + android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP)));
                } catch (Throwable e) {
                    emit("photo", json("error", "Не удалось обработать фото."));
                }
            }
        });
    }

    /** Системный выбор файлов (SAF): без широких разрешений на хранилище. */
    void pickFiles() {
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                            "application/pdf", "application/msword",
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            "application/vnd.ms-excel",
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                            "text/*", "application/json", "application/xml", "image/png", "image/jpeg", "image/webp",
                            "application/octet-stream"});
                    startActivityForResult(i, REQ_FILES);
                } catch (Exception e) {
                    emit("files", json("error", "Не удалось открыть выбор файлов."));
                }
            }
        });
    }

    private void handleFilesResult(int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null) {
            emit("files", json("cancelled", true));
            return;
        }
        final java.util.List<Uri> uris = new java.util.ArrayList<Uri>();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount() && i < 8; i++) uris.add(data.getClipData().getItemAt(i).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        executor.execute(new Runnable() {
            @Override
            public void run() {
                org.json.JSONArray items = new org.json.JSONArray();
                for (Uri u : uris) {
                    org.json.JSONObject it = FileExtractor.extract(MainActivity.this, u);
                    // Сохраняем копию вложения, чтобы его можно было открыть из чата
                    org.json.JSONObject saved = FileStore.importUri(MainActivity.this, u, it.optString("name", "file"));
                    if (saved != null) {
                        try {
                            it.put("fid", saved.optString("id"));
                            it.put("mime", saved.optString("mime"));
                        } catch (Exception ignored) {
                        }
                    }
                    items.put(it);
                }
                emit("files", json("items", items));
            }
        });
    }

    void pickContact() {
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI), REQ_PICK_CONTACT);
                } catch (Exception e) {
                    emit("contactPicked", json("error", "Не удалось открыть список контактов."));
                }
            }
        });
    }

    private void handleContactResult(int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        try (android.database.Cursor c = getContentResolver().query(data.getData(),
                new String[]{android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null)) {
            if (c != null && c.moveToFirst()) emit("contactPicked", json("name", c.getString(0), "phone", c.getString(1)));
        } catch (Exception e) {
            emit("contactPicked", json("error", "Не удалось прочитать контакт."));
        }
    }

    // ---------- жизненный цикл ----------

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        WhatsApp.emitter = this;
        if (servicesReady) emit("caps", json("caps", AndroidTools.capabilities(this), "a11y", JarvisAccessibilityService.isEnabled(this), "notif", JarvisNotificationListener.isEnabled(this)));
    }

    @Override
    protected void onPause() {
        resumed = false;
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("window.jarvisBack?String(window.jarvisBack()):'false'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value == null || !value.contains("true")) MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onStop() {
        // Когда приложение уходит с экрана, звук и запись прекращаются, КРОМЕ включённого пользователем Live Voice
        // (он виден в уведомлении и останавливается кнопкой).
        if (servicesReady && !LiveVoiceService.running) {
            bargeIn.stop();
            stopSpeech();
            speech.cancel();
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (WhatsApp.emitter == this) WhatsApp.emitter = null;
        ScreenShareService.listener = null;
        LiveVoiceService.listener = null;
        bargeIn.stop();
        stopLiveService();
        stopService(new Intent(this, ScreenShareService.class));
        if (servicesReady) {
            tts.shutdown();
            online.shutdown();
            speech.cancel();
        }
        executor.shutdownNow();
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
