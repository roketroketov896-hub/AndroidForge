package com.subaru.jarvis;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout messages;
    private EditText input;
    private ScrollView scroll;
    private TextToSpeech tts;
    private boolean voiceReady = false;
    private boolean speaking = true;
    private int blue = Color.rgb(68, 190, 255);
    private int bg = Color.rgb(8, 13, 25);
    private int panel = Color.rgb(18, 27, 45);
    private int white = Color.rgb(235, 243, 255);
    private String scenario = "Ожидаю команду";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("ru", "RU"));
                voiceReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        buildUi();
        addMessage("JARVIS", "Да, сэр. Я на связи. Откройте ⚙, чтобы настроить OpenRouter. После сохранения ключа я смогу отвечать через выбранную модель.", false);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); return t;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg); root.setPadding(14, 16, 14, 10);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(14, 12, 14, 12); header.setBackground(shape(panel, 24));
        TextView orb = text("◉", 34, blue); header.addView(orb, new LinearLayout.LayoutParams(52, 52));
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        TextView name = text("J.A.R.V.I.S.", 20, white); name.setTypeface(null, Typeface.BOLD);
        TextView sub = text("PERSONAL AI  •  CORE 0.2", 10, blue); titles.addView(name); titles.addView(sub);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = new Button(this); settings.setText("⚙"); settings.setTextSize(18);
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class))); header.addView(settings);
        Button voice = new Button(this); voice.setText("ГОЛОС"); voice.setTextSize(10);
        voice.setOnClickListener(v -> { speaking = !speaking; Toast.makeText(this, speaking ? "Голос включён" : "Голос выключен", Toast.LENGTH_SHORT).show(); });
        header.addView(voice); root.addView(header);

        TextView status = text("●  СИСТЕМА ГОТОВА  |  " + scenario, 11, blue);
        status.setPadding(8, 14, 8, 10); root.addView(status);
        scroll = new ScrollView(this); scroll.setFillViewport(true);
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); messages.setPadding(2, 6, 2, 10);
        scroll.addView(messages); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView quickLabel = text("БЫСТРЫЕ СЦЕНАРИИ", 10, blue); quickLabel.setPadding(4, 8, 4, 6); root.addView(quickLabel);
        LinearLayout quick = new LinearLayout(this);
        addQuick(quick, "Отдых"); addQuick(quick, "Продолжи"); addQuick(quick, "Остановись"); addQuick(quick, "У нас гости");
        HorizontalScrollView hsv = new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); hsv.addView(quick); root.addView(hsv);

        LinearLayout composer = new LinearLayout(this); composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(8, 6, 4, 6); composer.setBackground(shape(panel, 28));
        input = new EditText(this); input.setSingleLine(false); input.setMaxLines(3); input.setHint("Сэр, я слушаю...");
        input.setHintTextColor(Color.rgb(130,145,165)); input.setTextColor(white); input.setTextSize(15); input.setBackgroundColor(Color.TRANSPARENT);
        composer.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        Button send = new Button(this); send.setText("➤"); send.setTextColor(blue); send.setOnClickListener(v -> sendInput()); composer.addView(send);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = 10; root.addView(composer, cp);
        TextView foot = text("OpenRouter • локальные команды • озвучивание", 10, Color.rgb(120,137,160));
        foot.setGravity(Gravity.CENTER); foot.setPadding(4, 8, 4, 2); root.addView(foot);
        setContentView(root);
    }
    private void addQuick(LinearLayout row, String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(10); b.setOnClickListener(v -> handleCommand(label)); row.addView(b);
    }
    private void sendInput() {
        String s = input.getText().toString().trim(); if (s.isEmpty()) return; input.setText("");
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0);
        handleCommand(s);
    }
    private void addMessage(String who, String body, boolean user) {
        LinearLayout bubble = new LinearLayout(this); bubble.setOrientation(LinearLayout.VERTICAL); bubble.setPadding(14, 10, 14, 10);
        bubble.setBackground(shape(user ? Color.rgb(20, 62, 91) : panel, 20));
        TextView label = text(who, 10, blue); label.setTypeface(null, Typeface.BOLD);
        TextView content = text(body, 15, white); content.setPadding(0, 4, 0, 0); bubble.addView(label); bubble.addView(content);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(user ? -2 : -1, -2); p.topMargin = 6; p.bottomMargin = 6;
        p.gravity = user ? Gravity.RIGHT : Gravity.LEFT; p.leftMargin = user ? 34 : 0; p.rightMargin = user ? 0 : 34;
        messages.addView(bubble, p); scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
    private void respond(String answer) {
        addMessage("JARVIS", answer, false);
        if (speaking && voiceReady && tts != null) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
    }
    private void handleCommand(String raw) {
        addMessage("ВЫ", raw, true);
        String s = raw.toLowerCase(Locale.ROOT).trim();
        if (s.equals("hey jarvis") || s.contains("ты тут") || s.contains("you here")) { respond("Да, сэр. Я на связи."); return; }
        if (s.startsWith("открой ") || s.startsWith("открой приложение ")) {
            String target = s.replaceFirst("^открой( приложение)?\\s*", "").trim();
            if (openApp(target)) return;
        }
        if (s.startsWith("напиши сообщение ") || s.startsWith("составь сообщение ")) {
            String message = raw.substring(raw.indexOf(' ')+1).trim();
            if (message.toLowerCase(Locale.ROOT).startsWith("сообщение ")) message = message.substring(10).trim();
            openMessageComposer(message); return;
        }
        if (s.contains("остановись") || s.equals("stop")) { scenario = "Остановлено"; respond("Выполнение сценариев остановлено, сэр."); return; }
        if (s.contains("продолжи") || s.contains("continue")) { respond("Готов продолжить, сэр. Скажите, что именно нужно сделать."); return; }
        if (s.contains("отдых") || s.contains("relax")) { scenario = "Режим отдыха"; respond("Режим отдыха выбран, сэр. Какое приложение открыть?"); return; }
        if (s.contains("у нас гости") || s.contains("гости")) { scenario = "Режим «У нас гости»"; respond("Режим «У нас гости» выбран, сэр."); return; }
        if (s.equals("jarvis off") || s.equals("джарвис офф") || s.equals("off")) { respond("До связи, сэр. Вы можете закрыть приложение обычным способом."); return; }
        if (s.contains("голос выключи") || s.contains("mute")) { speaking = false; respond("Голосовой вывод выключен."); return; }
        if (s.contains("голос включи") || s.contains("unmute")) { speaking = true; respond("Голосовой вывод включён, сэр."); return; }
        if (!ApiClient.hasKey(this)) { respond("Я могу отвечать нормально через ИИ после настройки API. Нажмите ⚙, выберите OpenRouter, введите ключ и модель, затем сохраните настройки."); return; }
        respond("Секунду, сэр…");
        ApiClient.chat(this, raw, new ApiClient.Callback() {
            @Override public void onSuccess(String answer) { runOnUiThread(() -> { if (messages != null) respond(answer); }); }
            @Override public void onError(String error) { runOnUiThread(() -> respond("Не удалось получить ответ от ИИ: " + error)); }
        });
    }
    private boolean openApp(String target) {
        String[] packages;
        if (target.contains("whatsapp")) packages = new String[]{"com.whatsapp"};
        else if (target.contains("telegram")) packages = new String[]{"org.telegram.messenger"};
        else if (target.contains("youtube")) packages = new String[]{"com.google.android.youtube"};
        else if (target.contains("chrome") || target.contains("браузер")) packages = new String[]{"com.android.chrome"};
        else if (target.contains("калькулятор")) packages = new String[]{"com.google.android.calculator", "com.android.calculator2"};
        else if (target.contains("настройки")) packages = new String[]{"com.android.settings"};
        else if (target.contains("камер")) packages = new String[]{"com.android.camera2", "com.huawei.camera"};
        else { respond("Я пока не знаю, какое приложение открыть: " + target + ". Попробуйте WhatsApp, Telegram, YouTube, браузер, калькулятор или настройки."); return true; }
        for (String pkg : packages) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) { try { startActivity(launch); respond("Открываю приложение, сэр."); } catch (Exception e) { respond("Не получилось открыть это приложение."); } return true; }
        }
        respond("Не нашёл это приложение на телефоне, сэр."); return true;
    }
    private void openMessageComposer(String message) {
        if (message.isEmpty()) { respond("Скажите текст сообщения, сэр. Например: «Напиши сообщение Я скоро буду дома»."); return; }
        Intent intent = new Intent(Intent.ACTION_SEND); intent.setType("text/plain"); intent.putExtra(Intent.EXTRA_TEXT, message);
        try { startActivity(Intent.createChooser(intent, "Куда отправить сообщение?")); respond("Подготовил текст. Выберите приложение и проверьте сообщение перед отправкой, сэр."); }
        catch (Exception e) { respond("Не удалось открыть меню отправки сообщения."); }
    }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
